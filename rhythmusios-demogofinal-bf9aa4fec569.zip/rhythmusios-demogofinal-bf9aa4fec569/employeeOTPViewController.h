//
//  employeeOTPViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface employeeOTPViewController : UIViewController



@property (strong, nonatomic) IBOutlet UIView *ViewBACK;

@property (strong, nonatomic) NSString *CmpString;
@property (strong, nonatomic) NSString *CmpString2;

@property (strong, nonatomic) NSMutableString *EmpOTP;
- (IBAction)bckClicked:(id)sender;

@end
