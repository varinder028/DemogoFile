//
//  employeeOTPViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "employeeOTPViewController.h"
#import "employeeSignUPViewController.h"
#import "corporateLoginViewController.h"
@interface employeeOTPViewController ()<NSURLSessionDataDelegate,NSURLSessionDelegate>
{
    NSTimer *timer;
    long counter ;
    employeeSignUPViewController *Sign;
    
    NSMutableDictionary *GetDicDta;
    
    NSData * SendData;
    NSString *matchResponse;
    
    NSString *reciveOtp;
   
    
    
}
@property (strong, nonatomic) IBOutlet UITextField *OTPTextField;

    - (IBAction)VerifyButton:(id)sender;

            @property (strong, nonatomic) IBOutlet UIButton *verifyButtonOutlet;

                    @property (strong, nonatomic) IBOutlet UIButton *resendOtpOUTLET;

                            @property (strong, nonatomic) IBOutlet UILabel *Timelabel;
- (IBAction)ResendOTPButton:(UIButton *)sender;







@end

@implementation employeeOTPViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setTimer];
    counter =60;
    
   // self.navigationController.navigationBar.topItem.title = @"EMP.Otp";
    
    
    reciveOtp = [[NSString alloc]init];
    
    reciveOtp = self.EmpOTP;
    
    NSLog(@"%@",reciveOtp);
    
                        self.resendOtpOUTLET.layer.cornerRadius=5.5;
   
                                self.resendOtpOUTLET.hidden = YES;
  
                                        self.verifyButtonOutlet.layer.cornerRadius =5.5;
    
    self.ViewBACK.layer.cornerRadius = 10.5;
    
  
    NSAttributedString *str;
    
                                        str=[[NSAttributedString alloc]
       
                                                    initWithString:@"Please Enter OTP Code...."
         
                                                            attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
   
    self.OTPTextField.attributedPlaceholder=str;

    
    
    
     self.OTPTextField.keyboardType =UIKeyboardTypeNumberPad;
    
    
    // Do any additional setup after loading the view.
}

//////////////////   otp timer method    .......

-(void)setTimer
{
    timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(SetTimerConform) userInfo:nil repeats:YES];
    timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(SetTimerConform) userInfo:nil repeats:YES];
    
}






-(void)SetTimerConform
{
    if (counter==0)
    
    
    {
        
        [timer invalidate];
        
        
                    self.resendOtpOUTLET.hidden=NO;
        
        
                                self.resendOtpOUTLET.layer.cornerRadius = 5.5;
        
    }
    
    
    else
        
        
    {
        counter--;
        
                self.resendOtpOUTLET.hidden = YES;
       
                            _Timelabel.text = [NSString stringWithFormat:@"%ld",counter];
    }
}






- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"touchesBegan:withEvent:");
    
                    [self.view endEditing:YES];
   
                                    [super touchesBegan:touches withEvent:event];
}






- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}







-(void)OtpEqualDataWithNumber;
{
    NSString *otdat;
   
    NSError *linkError;
    
            NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    
                    otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/app/matchotp?mobile=%@&otp=%@",_CmpString,self.OTPTextField.text];
    
    
                                NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
                                            NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
    
    
                                                        NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                                                        NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    
                    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
    
    
                            [SendingRequest setHTTPMethod:@"POST"];
    
                                        GetDicDta = [NSMutableDictionary dictionaryWithObjectsAndKeys:_CmpString ,@"mobile",self.OTPTextField.text,@"otp", nil];
    
    
                                                            SendData= [NSJSONSerialization dataWithJSONObject:GetDicDta options:kNilOptions error:&linkError];
    
    
    
    
    
    //for (SendData in GetDicDta) {
    //
                                                                                    [SendingRequest setHTTPBody:SendData];
    //    }
    
    
    
    
    //NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              
                                              
                                              
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                
                                                  
                                                  NSError *jsonError;
                                                  
                                                            NSArray* PassedJSon;
                                                  
                                                  PassedJSon =[[NSArray alloc]init];
                                                 
                                                  
                                                                    PassedJSon =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                  
                                                  NSLog(@"%@",PassedJSon);
                                                  
                                                  _CmpString2= [PassedJSon valueForKey:@"message"];
                                                  
                                              });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
}






















-(IBAction)VerifyButton:(id)sender {
    
    
    
    if ([self.OTPTextField.text isEqualToString:@""])
        
        
        
    {
        
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"OTP Text details" message:@"Please write OTP Code" preferredStyle:UIAlertControllerStyleAlert];
        
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        
        
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
        
        
    }else
    {
        
        
        
        [self OtpEqualDataWithNumber];
        
    }
    
    
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:
                                          
                                          @"OTP Code" message:
                                          
                                          @"OTP code conform than conform press Other than user Change No. than press Edit No." preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction
                         actionWithTitle:@"Conform"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             if ([_CmpString2 isEqualToString:@"success"])
                                 
                                 
                             {
                                 
                                 Sign = [self.storyboard instantiateViewControllerWithIdentifier:@"ESignup"];
                                 
                                 Sign.MobileString=self.CmpString;
                                 
                                 [self.navigationController pushViewController:Sign animated:YES];
                             }else
                             {
                                 NSLog(@"error");
                             }
                             
                             
                         }];
    
    
    UIAlertAction* chng = [UIAlertAction
                           actionWithTitle:@"Change Num."
                           style:UIAlertActionStyleDefault
                           handler:^(UIAlertAction * action)
                           {
                               
                               for (corporateLoginViewController *aViewController in self.navigationController.viewControllers) {
                                   if ([aViewController isKindOfClass:[corporateLoginViewController class]]) {
                                       [self.navigationController popToViewController:aViewController animated:YES];
                                   }
                               }
                               
                           }];
    
    
    
    
    
    
    [alertController addAction:ok];
    
    [alertController addAction:chng];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
    
    
    
    
    
    
    
    
}


    
    
    
    
    
    
    
    
- (IBAction)ResendOTPButton:(UIButton *)sender

{
   // NSString *otdat;
    NSError *linkError;
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    
   NSString * otdate = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/resendotp?mobile=%@&otp=%@",_CmpString,reciveOtp];
    NSLog(@"%@",reciveOtp);
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *PushLinkUrl = [NSURL URLWithString:otdate];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
    
    
    
    
    [SendingRequest setHTTPMethod:@"POST"];
    
    NSMutableDictionary * GetDic = [[NSMutableDictionary alloc]init];
    
    [GetDic setObject:_CmpString forKey:@"mobile"];
    
    [GetDic setObject:reciveOtp forKey:@"otp"];
    
    NSLog(@"%@",GetDic);
    
    NSData * SendDat= [NSJSONSerialization dataWithJSONObject:GetDic options:kNilOptions error:&linkError];
    
    
    
    
    
    [SendingRequest setHTTPBody:SendDat];
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                  NSError *jsonError;
                                                  
                                                  
                                                  NSArray* PassedJS =[[NSArray alloc]init];
                                                  
                                                  PassedJS =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                  
                                                  NSLog(@"%@",PassedJS);
                                                  
                                                  
                                                  
                                              });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
}







- (IBAction)bckClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
@end
