//
//  EmployeeWelcomViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmployeeWelcomViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *NameFillLabel;
@property (strong, nonatomic) IBOutlet UILabel *EMailFillLabel;
- (IBAction)LOGINButton:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIButton *LOGINButtonOutlet;
@property (strong, nonatomic) NSString *NameString;

@property (strong, nonatomic) NSString *EmailIDString;

@end
