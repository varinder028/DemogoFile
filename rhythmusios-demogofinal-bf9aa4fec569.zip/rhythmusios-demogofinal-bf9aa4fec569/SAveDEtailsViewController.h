//
//  SAveDEtailsViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 05/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SAveDEtailsViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *UserdetailsLabel;
@property (strong, nonatomic) IBOutlet UITextField *FirstANmeTextfield;
@property (strong, nonatomic) IBOutlet UITextField *LastNAmeTextField;


@property (strong, nonatomic) IBOutlet UITextField *MobileTextField;
@property (strong, nonatomic) IBOutlet UITextField *EmailTExtField;
@property (strong, nonatomic) IBOutlet UITextField *EMployeeIDTextField;







- (IBAction)SelctRoleButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *SelectRoleButtonOutlet;

- (IBAction)SelctDepartmentButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *SelectDepartmentOutlet;







- (IBAction)ADDButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *ADDButttonOutlet;








@end
