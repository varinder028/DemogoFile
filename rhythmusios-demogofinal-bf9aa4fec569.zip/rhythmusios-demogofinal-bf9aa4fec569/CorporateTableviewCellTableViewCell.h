//
//  CorporateTableviewCellTableViewCell.h
//  DemogoApplication
//
//  Created by varinder singh on 1/27/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CorporateTableviewCellTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *ModeEnteryLbael;
@property (strong, nonatomic) IBOutlet UILabel *ChairPersonEnteryLabel;
@property (strong, nonatomic) IBOutlet UILabel *CompanyEnteryLabel;
@property (strong, nonatomic) IBOutlet UILabel *DateEnteryLabel;
@property (strong, nonatomic) IBOutlet UILabel *TimeEntryLabel;

@property (strong, nonatomic) IBOutlet UIImageView *ACCOUntImage;
@property (strong, nonatomic) IBOutlet UILabel *UsernameEntr;

@end
