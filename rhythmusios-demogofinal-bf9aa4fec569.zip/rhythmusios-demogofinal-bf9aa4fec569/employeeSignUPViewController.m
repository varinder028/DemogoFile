//
//  employeeSignUPViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "employeeSignUPViewController.h"
#import "EMployeeTableViewCell.h"
#import "DropDownView.h"
#import "Reachability.h"


#import "EmployeeWelcomViewController.h"
@interface employeeSignUPViewController ()<DropDownViewDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIScrollViewDelegate,UIAlertViewDelegate>{
    BOOL checked;
    NSAttributedString *str;
    NSAttributedString *compstr;
    NSAttributedString *str2;
    NSAttributedString *str3;
    NSAttributedString *str4;
    EmployeeWelcomViewController *PassDataview;
    
    EMployeeTableViewCell*cell;
    NSNumber *num ;
    NSString *strids;
    
    NSString *urlstring;

    NSMutableDictionary *GetDicDta;
    NSMutableDictionary *GetDic;
    NSMutableArray *collectCompanyData;
    NSMutableArray *collectCompanyID;
    
    NSString * CompanyDetails;
    NSMutableArray *arr ;
    NSMutableArray* allObjects;
    NSMutableURLRequest *request;
    NSURL *url;
    NSDictionary *mapData ;
    NSDictionary *items;
    NSArray *arra;
    NSData*SendDa;
    
}
///////////////////////////////////////////////////////////////////
@property (strong, nonatomic) IBOutlet UILabel *downCmp;

@property (strong, nonatomic) IBOutlet UILabel *firstNameLabel;

                @property (strong, nonatomic) NSMutableArray *CompanyID;


///////////////////////////////////////////////////////////////////

//@property (strong, nonatomic) NSMutableArray *CompanydetailsArray1;

@property (strong, nonatomic) IBOutlet UITableView *tableview;
- (IBAction)companyNameBTN:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *agreeOutlet;

@property (strong, nonatomic) IBOutlet UIButton *NameCmpBTN;



@property (strong, nonatomic) IBOutlet NSLayoutConstraint *compAutoLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *compImageAutoLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *CompDLabelAutolayut;





@property (strong, nonatomic) IBOutlet NSLayoutConstraint *resizeLabelAutolayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *ResizeLengthAutoLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *resizeImageAutoLayout;



@property (strong, nonatomic) IBOutlet NSLayoutConstraint *heightAutoLayout;





@property (strong, nonatomic) IBOutlet UIImageView *ResIzeImage;

@property (strong, nonatomic) IBOutlet UIImageView *companyImage;
@end

@implementation employeeSignUPViewController



- (void)viewDidAppear:(BOOL)animated
{
    [self.tableview reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [_EmailIdMobileNumber addTarget:self
                  action:@selector(textFieldDidChange:)
        forControlEvents:UIControlEventEditingChanged];
    
    _txtCompanylayout.constant = -30 ;
    _imgCompanyLayout.constant = -28 ;
    _lblHeightLayout.constant = 0;
    
    _imgTopLayout.constant = 0 ;
    _topCompanyLayout.constant = 0;
    _topLblLayout.constant = 0 ;
  
    _viewHeightLayout.constant = 0 ;
    
    
   [self.view layoutIfNeeded];
    
    
   

    
  //  self.navigationController.navigationBar.topItem.title = @"EMP.SIGNUP";
    
//    self.companyImage.hidden =YES;
//    self.NameCmpBTN.hidden =YES;
//    self.downCmp.hidden=YES;
    
    
//    self.resizeImageAutoLayout.constant=29;
//    self.ResizeLengthAutoLayout.constant=18;
//    
//    self.resizeLabelAutolayout.constant=9;
//    
//    
//    self.heightAutoLayout.constant=249;
//    
//    self.SIGNUPButtonOutlet.layer.cornerRadius = 5.5;
//    
//    self.tableview.layer.cornerRadius = 20;
//    self.navigationController.navigationBarHidden = YES;
    
    
    
    
    
    
    
    
    
    
    
    
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dissmisskeyboard)];
//    [self.view addGestureRecognizer:tap];

    
    collectCompanyData = [[NSMutableArray alloc]init];
    collectCompanyID = [[NSMutableArray alloc]init];
    arr = [[NSMutableArray alloc]init];
   //  arra = [NSArray arrayWithObjects:@"sccsd",@"wewed",@"Sdsdx", nil];
    
    
    
    [self.tableview resignFirstResponder];
    
    
    
    
    self.EmailIdMobileNumber.delegate=self;
    self.MobileNumber.delegate=self;
    

    
    
    
    
    
    str=[[NSAttributedString alloc]
         initWithString:@"Email Id/Mobile number"
         attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.EmailIdMobileNumber.attributedPlaceholder=str;
    
    
   // CompanydetailsArray1 = [[NSMutableArray alloc]init];
    
    
        str2=[[NSAttributedString alloc]
          initWithString:@"First Name"
          attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    self.FirstName.attributedPlaceholder=str2;
    

    
    
    str3=[[NSAttributedString alloc]
          initWithString:@"Last Name"
          attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    self.LastName.attributedPlaceholder=str3;
    
    
    str4=[[NSAttributedString alloc]
          initWithString:@"Mobile Number"
          attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    self.MobileNumber.attributedPlaceholder=str4;
    self.MobileNumber.text = self.MobileString;
    
    checked=NO;
    
    // Do any additional setup after loading the view.
}




//-(void)dissmisskeyboard;
//{
//      [self.LastName resignFirstResponder];
//    
//      [self.MobileNumber resignFirstResponder];
// 
//    
//}


- (BOOL)textFieldShouldReturn:(UITextField *)textField


{
    CGRect frm = self.view.frame ;
    frm.origin.y = 0 ;
    self.view.frame = frm ;
    
    [textField resignFirstResponder];
    
    
//    self.NameCmpBTN.hidden=NO;
//    self.companyImage.hidden=NO;
//   
//    
//    self.heightAutoLayout.constant=308;
//
//   // self.companyImage.hidden =YES;
//  //  self.NameCmpBTN.hidden =YES;
//    self.downCmp.hidden=NO;
//    
//    
//    self.resizeImageAutoLayout.constant=91;
//    self.ResizeLengthAutoLayout.constant=78;
//    
//    self.resizeLabelAutolayout.constant=9;
//    
//    
//
//    
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Select Company Name"
//                                           message:self.EmailIdMobileNumber.text
//                                          preferredStyle:
//                                          UIAlertControllerStyleAlert];
//    
//    
//       UIAlertAction* SelectCompany = [UIAlertAction
//                         actionWithTitle:@"Select Company Name"
//                         style:UIAlertActionStyleDefault
//                         handler:^(UIAlertAction * action)
//                         {
//                             [self SaveDataSecondApi];
//                             
//                             NSLog(@" Alert Activate You Work it ");
//                             
//                             [self.tableview reloadData];
//                         }];
//    
//    
//
//    
//    [alertController addAction:SelectCompany];
//    
//    [self presentViewController:alertController animated:YES completion:nil];
//
//    
//    
//    
    
    
   
    

    
    return YES;
    
    
}


//-(void)textFieldDidBeginEditing:(UITextField *)textField
//{
//    CGPoint scrollPoint = CGPointMake(0,  20);
//    [_scrollview setContentOffset:scrollPoint animated:YES];
//}
//-(void)textFieldDidEndEditing:(UITextField *)textField
//{
//    [_scrollview setContentOffset:CGPointZero animated:YES];
//}






- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    //[self.companyNameText endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}
























-(void)SaveDataSecondApi
{
    //NSError *linkError;
http://182.76.44.135:8080/demogomobile/company/getemaildetails?email=varinder.rhythmus@gmail.com
    
    urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/getemaildetails?email=%@",self.EmailIdMobileNumber.text];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    url = [NSURL URLWithString:urlstring];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    
    
    
    GetDicDta = [[NSMutableDictionary alloc]initWithObjectsAndKeys:
                 self.EmailIdMobileNumber.text,@"email",
                 
                 nil];
    
    
    // SendData= [NSJSONSerialization dataWithJSONObject:GetDicDta options:kNilOptions error:&linkError];
    
    
    
    
    // [SendingRequest setHTTPBody:SendData];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              
                                              dispatch_async(dispatch_get_main_queue(),^
                                                             {
                                                                 
                                                                 
                                                                 
                                                                 arr=[NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                                                                 
                                                                 
                                                                 NSLog(@"%@",arr);
                                                                 
                                                                 [self performSelectorOnMainThread:@selector(ShowCompanyField) withObject:nil waitUntilDone:YES];
                                                                 
                                                                 
                                                                 
                                                                 //  NSError *jsonError;
                                                                 
                                                                 //                                        NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                                                 //
                                                                 //                                        NSData *data =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                                                 //                                                                 NSError* error;
                                                                 //                                    NSDictionary *items = [NSJSONSerialization JSONObjectWithData:data
                                                                 //                                                                                                                options:kNilOptions
                                                                 //                                                                                                                         error:&error];
                                                                 //                                                                 self.CompanydetailsArray1= [[items objectForKey:@"cmpList"]valueForKey:@"cmpNm"];
                                                                 //
                                                                 
                                                                
                                                                 
//                                                                 if ([[arr valueForKey:@"message"] isEqualToString:@"Email ID Do not exist"]) {
//                                                                     _txtCompanylayout.constant = 0 ;
//                                                                                                                                      _imgCompanyLayout.constant = 0 ;
//                                                                                                                                      _lblHeightLayout.constant = 0;
//                                                                                                                                      [self.view layoutIfNeeded];
//                                                                     
//                                                                      UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the correct emailId/Mobile Number" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles: nil];
//                                                                     
//                                                                     [alert show];
//                                                                     
//
//                                                                     
//                                                                 }else{
//                                                                     
//                                                                     _txtCompanylayout.constant = 30 ;
//                                                                     _imgCompanyLayout.constant = 28 ;
//                                                                     _lblHeightLayout.constant = 1;
//                                                                     [self.view layoutIfNeeded];
//                                                                     
//                                                                     
//                                                                 }
                                                                 
                                                                 
                                                                 
                                                                 
//                                                                 _txtCompanylayout.constant = 0 ;
//                                                                 _imgCompanyLayout.constant = 0 ;
//                                                                 _lblHeightLayout.constant = 0;
//                                                                 [self.view layoutIfNeeded];
//                                                                 
                                                                 
//                                                                 for (NSDictionary *dataDict in [arr valueForKey:@"cmpList"]){
//                                                                     [collectCompanyData addObject:[dataDict objectForKey:@"cmpNm"]];
//                                                                    // NSLog(@"%@",collectCompanyData);
//                                                                     
//                                                                     [collectCompanyID addObject:[dataDict objectForKey:@"cmpId"]];
//                                                                     NSLog(@"%@",collectCompanyID);
//                                                                     
//                                                                     
//                                                                     
//                                                                     
//                                                                 }
                                                                 
                                                                 
                                                                

                                                                 
                                                             });
                                              
                                              
                                              
                                              
                                              
                                          }];
  
    
    [postDataTask resume];
    
    
    
    
    
    
    
}


-(void)ShowCompanyField{
    
    if ([[arr valueForKey:@"message"] isEqualToString:@"Email ID Do not exist"]) {
        _txtCompanylayout.constant = -30 ;
        _imgCompanyLayout.constant = -28 ;
        _lblHeightLayout.constant = 0;
        
        _imgTopLayout.constant = 0 ;
        _topCompanyLayout.constant = 0;
        _topLblLayout.constant = 0 ;
        _viewHeightLayout.constant = 0 ;
        
        [self.view layoutIfNeeded];
        
        alertEmail=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the correct emailId/Mobile Number" delegate:self cancelButtonTitle:@"ok" otherButtonTitles: nil];
        
        [alertEmail show];
        
        isError = YES;
        
        [_EmailIdMobileNumber becomeFirstResponder];
        
        
        
    }else{
        
        
        
        
        _txtCompanylayout.constant = 0 ;
        _imgCompanyLayout.constant = 0 ;
        _lblHeightLayout.constant = 1;
        
        _imgTopLayout.constant = 29 ;
        _topCompanyLayout.constant = 19;
        _topLblLayout.constant = 8 ;
        _viewHeightLayout.constant = 41.85 ;
        
        [self.view layoutIfNeeded];
        
        
        [self performSelectorOnMainThread:@selector(companyDatatable) withObject:nil waitUntilDone:YES];
        
        
        isError = NO;
        
        
    }
    
}


-(void)companyDatatable{
    
    NSMutableArray *arrAy = [[NSMutableArray alloc]initWithArray:[[arr  valueForKey:@"cmpList"]valueForKey:@"cmpNm"]];
    
    if (arrAy.count > 0) {
        dropDownView = [[DropDownView alloc] initWithArrayData:arrAy  cellHeight:40 heightTableView:120 paddingTop: 0    paddingLeft:_detailView.frame.origin.x   paddingRight:0 refView:_txtCompanyName animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
        
        dropDownView.delegate = self;
        
        [self.detailView addSubview:dropDownView.view];
        
        [self.view bringSubviewToFront:dropDownView.view];
        
        [dropDownView openAnimation];
        
        NSLog(@" SSS  SSSS  S S S S S  USUU U     UUUU  U U U  U");
        

    }
    
    
    
    
       
    
}



-(void)dropDownCellSelected:(NSInteger)returnIndex{
    
    
     NSMutableArray *arrAy = [[NSMutableArray alloc]initWithArray:[[arr  valueForKey:@"cmpList"]valueForKey:@"cmpNm"]];
    
    if (arrAy.count > 0) {
         self.txtCompanyName.text = [arrAy objectAtIndex:returnIndex];
        
        NSString *employeeId = [arrAy objectAtIndex:returnIndex];
        
        [[NSUserDefaults standardUserDefaults]setObject:employeeId forKey:@"EmployeeId"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    
   
    
  
    
    
    
    [dropDownView closeAnimation];
    
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    
    
    NSUInteger newLength = [_EmailIdMobileNumber.text length] + [string length] - range.length;
    
   
    
    if (newLength == 1) {
        
        return newLength ;
        
        
    }else{
        
        if ( isError == YES ) {
            
            // [self SaveDataSecondApi];
            
//            _txtCompanyName.text = @"" ;
//            _txtCompanylayout.constant = 0 ;
//            _imgCompanyLayout.constant = 0 ;
//            _lblHeightLayout.constant = 0;
//            
//            _imgTopLayout.constant = 0 ;
//            _topCompanyLayout.constant = 0;
//            _topLblLayout.constant = 0 ;
//            _heightAutoLayout.constant = 253 ;
            
            return newLength - 1 ;
            
            
        }else{
            
            if (newLength == 1) {
                
                return newLength;
            }
            else{
                return newLength - 1 ;
                
            }

        
    }
    
    
        
//
    
}
    
}

    // Prevent crashing undo bug – see note below.
//    if(range.length + range.location > textField.text.length)
//    {
//        return NO;
//    }
    
    
   

    
//    compId = [[userEmailID objectForKey:@"cmpList"]valueForKey:@"cmpId"];
//    
//    [[NSUserDefaults standardUserDefaults]setValue:compId forKey:@"ComId"];
//    [[NSUserDefaults standardUserDefaults]synchronize];
//    
    
   



/////////  2.Drop Down TableView     create     /////////////////////////////////




-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [collectCompanyData count];
}
-(EMployeeTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString * cellID = @"cell";
    cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell ==nil) {
        cell = [[EMployeeTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    
    NSDictionary *dictionary = [collectCompanyData objectAtIndex:indexPath.row];
      cell.companyNameData.text = (NSString *)dictionary ;
    
    
     
    
    return cell;
    
    
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    //self.checkOutlet.tag =102;
    cell=[self.tableview cellForRowAtIndexPath:indexPath];
    
    [self.NameCmpBTN setTitle:cell.companyNameData.text forState:UIControlStateNormal];
    
    
    
    self.tableview.hidden =YES;
}


















/////////  3.Register person detail in other API create     /////////////////////////////////





-(void)SecondAPi
{
    NSError *linkError;
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    //  config.HTTPAdditionalHeaders = @{@"Accept": @"application/json",
    
    //  config.HTTPAdditionalHeaders = @{ @"Authorization" : @"token"};
    // config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *PushLinkUrl = [NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/person/register"];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    
    
    [SendingRequest setHTTPMethod:@"POST"];
    
    
    
    
    
    for (NSDictionary *dicId in collectCompanyID) {
        
        strids = [NSString stringWithFormat:@"%@",dicId];
        NSLog(@"Company Id Is == %@",strids );
    }
    
    
    
//    SInteger questionId = [(NSNumber *)dicId integerValue];
//    
//    NSLog(@"%lid",(long)questionId);
    
//NSDictionary *dID = [NSDictionary dictionaryWithObject:<#(nonnull id)#> forKey:<#(nonnull id<NSCopying>)#>]
    
    GetDic = [[NSMutableDictionary alloc]initWithObjectsAndKeys:strids ,@"cmpId",
                                      self.FirstName.text,@"firstName",
                                      self.LastName.text,@"lastName",
                                    self.EmailIdMobileNumber.text,@"pemail",
                                      self.MobileNumber.text,@"pmobile",
                                                                                    nil];
    
     self.FirstName.text = [[GetDic valueForKey:@"firstName"] stringByReplacingOccurrencesOfString:@" " withString: @"%20"];
    
     self.LastName.text = [[GetDic valueForKey:@"lastName"] stringByReplacingOccurrencesOfString:@" " withString: @"%20"];
    
    self.MobileNumber.text = [[GetDic valueForKey:@"pmobile"] stringByReplacingOccurrencesOfString:@" " withString: @"%20"];
    
    
    //NSLog(@"%@",cmp);
    
   // [GetDic  setValue:[collectCompanyID valueForKey:@"cmpId"] forKey:@"cmpId"];
    
    NSLog(@"%@",GetDic);
    
    SendDa= [NSJSONSerialization dataWithJSONObject:GetDic options:kNilOptions error:&linkError];
    
    
    
    
    [SendingRequest setHTTPBody:SendDa];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                  NSError *jsonError;
                                                  NSArray* PassedJSon =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                  //NSLog(@"%@",[PassedJSonArray valueForKey:@"cmpId"]);
                                                  
                                                  // NSLog(@"%@",[PassedJSonArray valueForKey:@"token"]);
                                                  
                                                  
                                                  NSLog(@"%@",PassedJSon);
                                                  
                                                  [self performSelectorOnMainThread:@selector(PushView) withObject:nil waitUntilDone:YES];
                                                  
                                                  
                                                  
                                              });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
    
    
    
    
}

-(void)PushView{
    
    PassDataview =[self.storyboard instantiateViewControllerWithIdentifier:@"WC"];
    PassDataview.NameString = self.FirstName.text;
    PassDataview.EmailIDString = self.EmailIdMobileNumber.text;
    
    
    
    [self.navigationController pushViewController:PassDataview animated:YES];

}








/////////  4.  Agree Button    create     /////////////////////////////////





- (IBAction)AgreeCheckButton:(id)sender {
    
    
    
    if (!checked) {
        [self.agreeOutlet setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
        checked =YES;
    }else if (checked)
    {
        [self.agreeOutlet setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
        checked=NO;
    }
    
    
    
}





/////////  5.   SignUp Button    create     /////////////////////////////////




- (IBAction)SIGNUPButton:(id)sender {
//    else if (![self emailStringIsValidEmail :self.officialEmailId.text]) {
//        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the correct company's General Email ID " delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
//        [alert show];
//        
//    }
    
    
    if ([self.EmailIdMobileNumber.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the EmailId/Mobile Number" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        
    }
    else if (![self emailStringIsValidEmail :self.EmailIdMobileNumber.text]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the correct company's General Email ID " delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        
    }

    
    else if ([self.txtCompanyName.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select  Company Name" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        
    }
    
    else if ([self.FirstName.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter your First Name " delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        
    }
    else if ([self.LastName.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter your Last Name " delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        
    }

    else if ([self.MobileNumber.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter your Mobile Number" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        
    }
    else{
        
        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
        if (networkStatus == NotReachable) {
            UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message: @"No Network Connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alert show];
            return;
            
            
        }else{
        
         [self SecondAPi];
        }
    }
    
   
    
    
   // [self SaveDataSecondApi];
//    if (checked==YES) {
//        
//        PassDataview =[self.storyboard instantiateViewControllerWithIdentifier:@"WC"];
//        PassDataview.NameString = self.FirstName.text;
//        PassDataview.EmailIDString = self.EmailIdMobileNumber.text;
//        
//        
//        
//        [self.navigationController pushViewController:PassDataview animated:YES];
//        
//    }else
//    {
    
        
        //        UIAlertView *alert =[[UIAlertView alloc]initWithTitle:@"Error " message:@" Please select Check BOX Agree on terms and condition !" delegate:self cancelButtonTitle:@"ok" otherButtonTitles: nil];
        //        [alert show];
        //        
  //  }
    
    
}








   - (IBAction)companyNameBTN:(id)sender {
       
       
      
       
       if (self.tableview.hidden==YES) {
          
           
           self.tableview.hidden=NO;
       }else{
           self.tableview.hidden=YES;
                 }
       
   }


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    
    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    if (textField == _FirstName) {
        
        CGRect frm = self.view.frame ;
        frm.origin.y = -100 ;
        self.view.frame = frm ;
        
        
        if ([_EmailIdMobileNumber.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Enter EmailId/Mobile Number first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alert show];
            
            return NO;
            
            
        }else{
        
            
            if (![_txtCompanyName.text isEqualToString:@""]) {
                
                
                
            }else{
                
                [self SaveDataSecondApi];
                
            }

            
            
        }
        
        
    }  else if (textField == _EmailIdMobileNumber) {
        
        
        
        
        
    }
    else if (textField == _txtCompanyName) {
        
        [self.EmailIdMobileNumber resignFirstResponder];
        
        [self SaveDataSecondApi];
        
        
        return false ;
        
    }
     else if (textField == _LastName) {
         
         CGRect frm = self.view.frame ;
         frm.origin.y = -100 ;
         self.view.frame = frm ;

         
         
     }

    
    return YES ;
    
}


-(void)textFieldDidChange:(UITextField*)textfield{
    
    
    if (arr.count >0) {
        
       
            if ([[arr valueForKey:@"message"] isEqualToString:@"success"]) {
                
                [self SaveDataSecondApi];
                
            }else{
                
                _txtCompanyName.text = @"" ;
                
            }
        

        
    }
    
}



        
//        if ([_EmailIdMobileNumber.text isEqualToString:@""]) {
//            _txtCompanyHeight.constant = 0 ;
//            [self.view layoutIfNeeded];
//            return YES ;
//            
//        }else{
//            
//            
//            _txtCompanyHeight.constant = 50 ;
//            [self.view layoutIfNeeded];
//            
//            if ([_txtCompnay.text isEqualToString:@""] ) {
//                
//                
//                return NO ;
//                
//            }else{
//                
//                return YES;
//                
//            }
//            
//            
//            
//            
//        }
//        
//        
//        
//        
//        
//        
//    }
//    else if (textField == _txtCompnay) {
//        
//        
//        [self SaveDataSecondApi];
//        
//        
//        
//        
//        return false ;
//        
//    }
    
    
    
//}


    

- (IBAction)backBtnClicked:(id)sender {
    
    
    [self.navigationController popViewControllerAnimated:YES];
    
}


-(BOOL)emailStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = NO;
    // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
    
}


@end










































