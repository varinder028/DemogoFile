//
//  TableViewCellview.h
//  DemogoApplication
//
//  Created by varinder singh on 2/2/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCellview : UITableViewCell

@end
