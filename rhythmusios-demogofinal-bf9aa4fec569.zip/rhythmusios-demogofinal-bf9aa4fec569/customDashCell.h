//
//  customDashCell.h
//  DemogoApplication
//
//  Created by katoch on 05/07/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface customDashCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imgDash;
@property (strong, nonatomic) IBOutlet UILabel *txtDash;

@end
