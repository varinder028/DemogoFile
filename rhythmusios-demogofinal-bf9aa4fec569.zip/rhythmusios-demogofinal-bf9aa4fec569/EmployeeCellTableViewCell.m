//
//  EmployeeCellTableViewCell.m
//  DemogoApplication
//
//  Created by varinder singh on 1/27/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "EmployeeCellTableViewCell.h"

@implementation EmployeeCellTableViewCell
@synthesize ModeEnteryLbael,ChairPersonEnteryLabel,CompanyEnteryLabel,DateEnteryLabel,TimeEntryLabel;


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
