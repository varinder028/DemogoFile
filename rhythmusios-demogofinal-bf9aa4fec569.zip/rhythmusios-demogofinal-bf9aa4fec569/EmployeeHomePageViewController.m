//
//  EmployeeHomePageViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "EmployeeHomePageViewController.h"
#import "EmployeeCellTableViewCell.h"
@interface EmployeeHomePageViewController ()<UITabBarControllerDelegate,UITabBarDelegate,UITableViewDataSource,UITableViewDelegate>
{
    NSMutableDictionary *Dic;
    NSMutableArray *MeetingDetailReport;
    NSMutableArray *MeetingHeaderDetail;
    UIDatePicker *DateFormatPicker;
}

- (IBAction)DateOrTimeChangeButton:(UIButton *)sender;

@end

@implementation EmployeeHomePageViewController

@synthesize MonthNameLabel,DateLabel,DayLabel;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    DateLabel.text=@"28";
    
    MonthNameLabel.text =@"may";
    DayLabel.text=@"sunday";
    
    
    
    
    [self TableViewEditing];
    self.TableViewEditing.delegate=self;
    self.TableViewEditing .dataSource= self;
    
    
    
    // Do any additional setup after loading the view.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(EmployeeCellTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *str =@"cell";
    EmployeeCellTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:str forIndexPath:indexPath];
    if (cell==nil) {
        cell =[[EmployeeCellTableViewCell alloc]init];
        
    }
    return cell;
}

- (IBAction)DateOrTimeChangeButton:(UIButton *)sender {
    
    
    //////////////////////// Set Day Data//////////////////////

    NSDate *dateData =[NSDate date];
    NSDateFormatter *DateFormatter = [[NSDateFormatter alloc]init];
    [DateFormatter setDateFormat:@"EEEE"];
    DayLabel.text =[NSString stringWithFormat:@"%@",[DateFormatter stringFromDate:dateData]];
    
    ////////////////////////  Set Month Data /////////////////////
    NSDate *MonthData =[NSDate date];
    NSDateFormatter *monthFormatter = [[NSDateFormatter alloc]init];
    [monthFormatter setDateFormat:@"MMMM"];
    MonthNameLabel.text =[NSString stringWithFormat:@"%@",[monthFormatter stringFromDate:MonthData]];
    
    ////////////////////////   Set Date Data  /////////////////////
    
    NSDate *DayData =[NSDate date];
    NSDateFormatter *DayFormatter = [[NSDateFormatter alloc]init];
    [DayFormatter setDateFormat:@"dd"];
    DateLabel.text =[NSString stringWithFormat:@"%@",[DayFormatter stringFromDate:DayData]];
    
    

}
@end
