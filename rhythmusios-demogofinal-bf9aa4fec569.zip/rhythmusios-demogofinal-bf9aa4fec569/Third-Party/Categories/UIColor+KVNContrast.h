//
//  UIColor+KVNContrast.h
//  KVNProgress
//
//  Created by Kevin Hirsch on 13/03/15.
//  Copyright (c) 2015 Pinch. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIColor (KVNContrast)

- (UIStatusBarStyle)statusBarStyleConstrastStyle;

@end
