//
//  NotificationViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 29/03/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ViewController.h"

@interface NotificationViewController : ViewController

@end
