//
//  dropCell.h
//  DemogoApplication
//
//  Created by Rhythmus on 27/06/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface dropCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblName;
@property (strong, nonatomic) IBOutlet UIButton *btnDelete;

@end
