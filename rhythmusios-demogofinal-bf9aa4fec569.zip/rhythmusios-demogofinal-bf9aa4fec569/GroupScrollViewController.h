//
//  GroupScrollViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 12/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GroupScrollViewController : UIViewController

@end
