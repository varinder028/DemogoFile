//
//  ParticipantTabBar.h
//  DemogoApplication
//
//  Created by Rhythmus on 13/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ParticipantTabBar : UITabBarController



@property (weak, nonatomic) IBOutlet NSString *TABDependClient;



@end
