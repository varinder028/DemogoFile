//
//  CCResultViewController.h
//  CCIntegrationKit
//
//  Created by test on 5/16/14.
//  Copyright (c) 2014 Avenues. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CCResultViewController : UIViewController
    @property (strong, nonatomic) IBOutlet UILabel *resultLabel;
    @property (strong, nonatomic) NSString *transStatus;
@end
