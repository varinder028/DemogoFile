    //
//  DropDownView.m
//  CustomTableView
//
//  Created by Abdullah Md. Zubair on 19/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "DropDownView.h"

#import <QuartzCore/QuartzCore.h>
#import "dropCell.h"


@implementation DropDownView
{
    UITableViewCell *cell;
}
@synthesize uiTableView;

@synthesize arrayData,heightOfCell,refView;

@synthesize paddingLeft,paddingRight,paddingTop;

@synthesize open,close;

@synthesize heightTableView;

@synthesize delegate;



- (id)initWithArrayData:(NSArray*)data cellHeight:(CGFloat)cHeight heightTableView:(CGFloat)tHeightTableView paddingTop:(CGFloat)tPaddingTop paddingLeft:(CGFloat)tPaddingLeft paddingRight:(CGFloat)tPaddingRight refView:(UIView*)rView animation:(AnimationType)tAnimation openAnimationDuration:(CGFloat)openDuration closeAnimationDuration:(CGFloat)closeDuration{

	if ((self = [super init])) {
		
		self.arrayData = data;
		
		self.heightOfCell = cHeight;
		
		self.refView = rView;
		
		self.paddingTop = tPaddingTop;
		
		self.paddingLeft = tPaddingLeft;
		
		self.paddingRight = tPaddingRight;
		
		self.heightTableView = tHeightTableView;
		
		self.open = openDuration;
		
		self.close = closeDuration;
        
        
		
		CGRect refFrame = refView.frame;
        
        if([[NSUserDefaults standardUserDefaults]boolForKey:@"DropHome"]== true){
            
           self.view.frame = CGRectMake(refFrame.origin.x-paddingLeft,refFrame.origin.y+refFrame.size.height+paddingTop,refFrame.size.width*2 + 50, heightTableView);
            
        }else{
        
        
		
		self.view.frame = CGRectMake(refFrame.origin.x-paddingLeft,refFrame.origin.y+refFrame.size.height+paddingTop,refFrame.size.width+paddingRight, heightTableView);
		
        }
        
        	//self.view.layer.cornerRadius = 5;
        	//self.view.layer.masksToBounds = YES;
        

        
		self.view.layer.shadowColor = [[UIColor blackColor] CGColor];
      //  self.view.layer.borderWidth = 2.0f;

		self.view.layer.shadowOffset = CGSizeMake(5.0f, 5.0f);
		
		self.view.layer.shadowOpacity =1.0f;
		
		self.view.layer.shadowRadius = 5.0f;
		
		animationType = tAnimation;
		
	}
	
	return self;
	
}	

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    
	[super viewDidLoad];
	

    uiTableView.separatorStyle = UITableViewCellSelectionStyleNone ;
    uiTableView.layer.cornerRadius = 5.5f;
    //uiTableView.backgroundColor = [UIColor colorWithRed:0.14 green:0.11 blue:0.14 alpha:1];
    
    
	CGRect refFrame = refView.frame;
    if([[NSUserDefaults standardUserDefaults]boolForKey:@"DropHome"]== true){
        
        uiTableView = [[UITableView alloc] initWithFrame:CGRectMake(0,0,refFrame.size.width*2+30, (animationType == BOTH || animationType == BLENDIN)?heightTableView:1) style:UITableViewStylePlain];
        
        uiTableView.layer.cornerRadius = 5.5f;
        
//        if ([[NSUserDefaults standardUserDefaults]boolForKey:@"IncWidth"]==true)
//            
//        {
        
       // }
 //       else if ([[NSUserDefaults standardUserDefaults]boolForKey:@"Plan"]==true)
//        {
//            [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"IncWidth"];
            
//            uiTableView = [[UITableView alloc] initWithFrame:CGRectMake(0,0,refFrame.size.width+40, (animationType == BOTH || animationType == BLENDIN)?heightTableView:1) style:UITableViewStylePlain];
//            uiTableView.layer.cornerRadius = 5.5f;
//        }
//        
//        else
//            
//        {
//            [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"IncWidth"];
//            [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"Plan"];
//            uiTableView = [[UITableView alloc] initWithFrame:CGRectMake(0,0,refFrame.size.width, (animationType == BOTH || animationType == BLENDIN)?heightTableView:1) style:UITableViewStylePlain];
//            uiTableView.layer.cornerRadius = 5.5f;
//        }
        
        
    }else{
        
        uiTableView = [[UITableView alloc] initWithFrame:CGRectMake(0,0,refFrame.size.width+paddingRight, (animationType == BOTH || animationType == BLENDIN)?heightTableView:1) style:UITableViewStylePlain];
        uiTableView.layer.cornerRadius = 5.5f;
    }
    
	
	
	uiTableView.dataSource = self;
	
	uiTableView.delegate = self;
	
	[self.view addSubview:uiTableView];
	
	self.view.hidden = YES;
	
	if(animationType == BOTH || animationType == BLENDIN)
		[self.view setAlpha:1];
	
	
}


- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    CGPoint p = [gestureRecognizer locationInView:self.view] ;
    if (CGRectContainsPoint(uiTableView.frame, p) ){
        return NO ;
    }
    return YES ;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isDescendantOfView:uiTableView]) {
        
        // Don't let selections of auto-complete entries fire the
        // gesture recognizer
        return NO;
    }
    
    return YES;
}



- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    
}


//- (void)dealloc {
   // [super dealloc];
	//[uiTableView release];
	//[arrayData,refView release];
	
//}

#pragma mark -
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	return heightOfCell;
	
	
}	

- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section{
	
	return [arrayData count];
	
}	

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
	

    
	static NSString *CellIdentifier = @"Cell";
     uiTableView.separatorStyle = UITableViewCellSelectionStyleNone ;
    uiTableView.backgroundColor = [UIColor colorWithRed:36/255.0f green:29/255.0f blue:36/255.0f alpha:1];
    
    cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
        
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
		
    }
    
    
    
    NSString *struser = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]objectForKey:@"IncWidth"]];
    
    if ([[NSUserDefaults standardUserDefaults]boolForKey:@"DropHome"] == true){
        
        cell.imageView.image =  [UIImage imageNamed:@"16x16.png"];

    }else{
        cell.imageView.image = nil ;
        
    }

    
    if ([struser isEqualToString:@"1"])
        
    {
        //cell.textLabel.font=[UIFont systemFontOfSize:10.0f];
        
      //  cell.imageView.image =  [UIImage imageNamed:@"16x16.png"];
        
    }

    cell.contentView.backgroundColor = [UIColor clearColor];
    
    cell.backgroundColor = [UIColor clearColor];
    
    cell.font = [UIFont systemFontOfSize:10];
    
    cell.textLabel.textColor = [UIColor whiteColor];
    
    
    
	cell.textLabel.text = [NSString stringWithFormat:@"%@",[arrayData objectAtIndex:indexPath.row]];
    
	return cell;
	

    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
	[delegate dropDownCellSelected:indexPath.row];
	
	[self closeAnimation];
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{

	return 0;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{

	return 0;
	
}	

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{

	return @"";
}	

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section{

	return @"";
	
}	

#pragma mark -
#pragma mark DropDownViewDelegate

-(void)dropDownCellSelected:(NSInteger)returnIndex{
    if ([arrayData lastObject]==nil)
    {
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        
    }
    
}	

#pragma mark -
#pragma mark Class Methods


-(void)openAnimation{
	
	self.view.hidden = NO;
	
	NSValue *contextPoint = [NSValue valueWithCGPoint:self.view.center] ;
	
	[UIView beginAnimations:nil context:(__bridge void * _Nullable)(contextPoint)];
	
	[UIView setAnimationDuration:open];
	
	[UIView setAnimationCurve:UIViewAnimationCurveLinear];
	
	[UIView setAnimationRepeatCount:1];
	
	[UIView setAnimationDelay:0];
	
	if(animationType == BOTH || animationType == GROW)
		self.uiTableView.frame = CGRectMake(uiTableView.frame.origin.x,uiTableView.frame.origin.y,uiTableView.frame.size.width, heightTableView);
	
	if(animationType == BOTH || animationType == BLENDIN)
		self.view.alpha = 1;
	
	[UIView commitAnimations];
	
	
	
	
	
}

-(void)closeAnimation{
	
	NSValue *contextPoint = [NSValue valueWithCGPoint:self.view.center] ;
	
	[UIView beginAnimations:nil context:(__bridge void * _Nullable)(contextPoint)];
	
	[UIView setAnimationDuration:close];
	
	[UIView setAnimationCurve:UIViewAnimationCurveLinear];
	
	[UIView setAnimationRepeatCount:1];
	
	[UIView setAnimationDelay:0];
	
	if(animationType == BOTH || animationType == GROW)
		self.uiTableView.frame = CGRectMake(uiTableView.frame.origin.x,uiTableView.frame.origin.y,uiTableView.frame.size.width, 1);
	
	if(animationType == BOTH || animationType == BLENDIN)
		self.view.alpha = 0;
	
	[UIView commitAnimations];
	
	[self performSelector:@selector(hideView) withObject:nil afterDelay:close];
	
	
		
}

	 
-(void)hideView{
	
	self.view.hidden = YES;

}	 




@end
