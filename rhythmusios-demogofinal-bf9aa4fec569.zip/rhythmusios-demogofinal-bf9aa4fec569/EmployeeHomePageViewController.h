//
//  EmployeeHomePageViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmployeeHomePageViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITableView *TableViewEditing;

@property (strong, nonatomic) IBOutlet UILabel *DateLabel;
@property (strong, nonatomic) IBOutlet UILabel *MonthNameLabel;
@property (strong, nonatomic) IBOutlet UILabel *DayLabel;

@end
