//
//  SAveDEtailsViewController.m
//  DemogoApplication
//
//  Created by Rhythmus on 05/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "SAveDEtailsViewController.h"

//#import "ADMINProfilePICViewController.h"

#import "EmplyeeMAnagementViewController.h"

@interface SAveDEtailsViewController ()<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>

{
    
    NSAttributedString *str;
    NSAttributedString *str2;
    NSAttributedString *str3;
    NSAttributedString *str4;
    NSAttributedString *str5;
    NSAttributedString *str6;
    
    EmplyeeMAnagementViewController *EMpManage;
    
    UITableViewCell *cell;
    
    
}


@property (strong, nonatomic) IBOutlet UITableView *SElectRoleTAbleView;
@property (strong, nonatomic) IBOutlet UITableView *SelctDepartmentTableview;


@property (strong, nonatomic) IBOutlet UIScrollView *ScrollView2;




- (IBAction)BAckButton:(UIButton *)sender;




@end

@implementation SAveDEtailsViewController

-(void)viewDidAppear:(BOOL)animated
{
    _ScrollView2.showsVerticalScrollIndicator=YES;
    _ScrollView2.scrollEnabled=YES;
    _ScrollView2.userInteractionEnabled=YES;
    
    _ScrollView2.contentSize = CGSizeMake(0,self.ScrollView2.frame.size.height+60);
    
    
    self.ADDButttonOutlet.layer .cornerRadius = 7;
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dissmisskeyboard:)];
    
    [self.view addGestureRecognizer:tap];
   
    
    // [self.scrollViewVertically setContentOffset: CGPointMake(0, self.scrollViewVertically.contentOffset.y)];
    // self.scrollViewVertically.directionalLockEnabled = YES;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

-(void)dissmisskeyboard:(UIGestureRecognizer *) sender
{
    [self.view endEditing:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.SElectRoleTAbleView.hidden = YES;
    
    self.SElectRoleTAbleView.layer.cornerRadius= 10.5;
    
     self.SelctDepartmentTableview.layer.cornerRadius= 10.5;
    
    
    self.SelctDepartmentTableview.hidden = YES;
    
    
    
    //  2.        ////////////            First name TextField PlaceHolder           /////////////////

    
        str=[[NSAttributedString alloc]initWithString:@"First Name"
         
                                       attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.FirstANmeTextfield.attributedPlaceholder=str;
    
    self.FirstANmeTextfield.tag= 1;
    
    
    
    
    
    //  2.        ////////////            last name TextField PlaceHolder           /////////////////
    
    
    str2=[[NSAttributedString alloc]initWithString:@"Last Name"
          
                                        attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.LastNAmeTextField.attributedPlaceholder=str2;
    
    
    self.LastNAmeTextField.tag= 2;
    
    
    //  3.          ////////////            mobile NUMBER TextField PlaceHolder           /////////////////
    
    
    str3=[[NSAttributedString alloc]initWithString:@"Mobile No"
          
                                        attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.MobileTextField.attributedPlaceholder=str3;
    
    self.MobileTextField.keyboardType =UIKeyboardTypeNumberPad;
    
    
    
    self.MobileTextField.tag= 3;
    
    //   4.             ////////////            email NAME TextField PlaceHolder           /////////////////
    
    
    
    str4=[[NSAttributedString alloc]initWithString:@"Email Id"
          
                                        attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.EmailTExtField.attributedPlaceholder=str4;
    
    
    
    self.EmailTExtField.tag= 4;
    
    //   5.           ////////////            emplyee id TextField PlaceHolder           /////////////////
    
    
    str5=[[NSAttributedString alloc]initWithString:@"Employee Id"
          
                                        attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.EMployeeIDTextField.attributedPlaceholder=str5;
    
   
    
   // self.EMployeeIDTextField.delegate=self;
    
    self.EMployeeIDTextField.tag= 5;
    
    
    
    
    // Do any additional setup after loading the view.
}




- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
//    if ([self.EMployeeIDTextField becomeFirstResponder]) {
//        [self animateTextField: textField up: YES];
//    }
//    else
    
        [self animateTextField: textField up: YES];
   
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField: textField up: NO];
}

- (void) animateTextField: (UITextField*) textField up: (BOOL) up
{
    //    if ([signupView needsUpdateConstraints]== YES) {
    //
    //        NSLog(@"uodat is needed");
    //
    //        [signupView setNeedsUpdateConstraints];ssss
    //    }
    
    const int movementDistance = 110; // tweak as needed
    
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"anim" context: nil];
    
    [UIView setAnimationBeginsFromCurrentState: YES];
    
    [UIView setAnimationDuration: movementDuration];
    
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    
    [UIView commitAnimations];
}









- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-( NSInteger) numberOfSectionsInTableView:(UITableView *)tableView

{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.SElectRoleTAbleView) {
        
        return 2;
    }
    else
    {
        return 5;
    }
    
    
    
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *cellid = @"cell";
    
   cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    
    if (cellid ==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
    }
    
    if (tableView == self.SElectRoleTAbleView) {
        
    
    cell.textLabel.text = @"role";
    
    }
    cell.textLabel.text = @"selectDepartment";
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

{

    if (tableView == self.SElectRoleTAbleView)
    
    {
         cell=[self.SElectRoleTAbleView cellForRowAtIndexPath:indexPath];
        
        [self.SelectRoleButtonOutlet setTitle:cell.textLabel.text forState:UIControlStateNormal];
        
        self.SElectRoleTAbleView.hidden =YES;
        
    }
    
    else if (tableView == self.SelctDepartmentTableview)
    
    {
     
        cell=[self.SelctDepartmentTableview cellForRowAtIndexPath:indexPath];
        
        [self.SelectDepartmentOutlet setTitle:cell.textLabel.text forState:UIControlStateNormal];
        
        self.SelctDepartmentTableview.hidden =YES;
        
    }
    
    
}
- (IBAction)SelctRoleButton:(id)sender
{
   
        
       // [self.RoleTAbleVIew reloadData];
        
        if (self.SElectRoleTAbleView.hidden==YES)
            
        {
            
            self.SElectRoleTAbleView.hidden=NO;
        }
        
        else
        {
            
            self.SElectRoleTAbleView.hidden=YES;
            
           
        }
        
        
        
   

    
    
}
- (IBAction)SelctDepartmentButton:(id)sender

{
  //  [self.SelectDepartmentTAbleView reloadData];
    
    if (self.SelctDepartmentTableview.hidden==YES)
        
    {
       
        self.SelctDepartmentTableview.hidden=NO;
    }
    
    else
    {
        
        self.SelctDepartmentTableview.hidden=YES;
        
    }

    
}
- (IBAction)ADDButton:(id)sender {
}
- (IBAction)BAckButton:(UIButton *)sender

{
    
    EMpManage = [self.storyboard instantiateViewControllerWithIdentifier:@"EM"];
    
    EMpManage.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    
     [self.navigationController pushViewController:EMpManage animated:YES];
    
    
    
    
}
@end
