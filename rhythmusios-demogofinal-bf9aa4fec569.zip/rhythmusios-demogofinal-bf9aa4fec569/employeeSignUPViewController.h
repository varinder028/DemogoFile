//
//  employeeSignUPViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"


@interface employeeSignUPViewController : UIViewController<DropDownViewDelegate,UIAlertViewDelegate>
{
    
    DropDownView *dropDownView;
    UIAlertView *alertEmail ;
    BOOL isError ;
    
}
@property (strong, nonatomic) IBOutlet UITextField *EmailIdMobileNumber;
@property (strong, nonatomic) IBOutlet UITextField *FirstName;
@property (strong, nonatomic) IBOutlet UITextField *LastName;

@property (strong, nonatomic) IBOutlet UITextField *MobileNumber;



- (IBAction)AgreeCheckButton:(id)sender;

- (IBAction)SIGNUPButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *SIGNUPButtonOutlet;

@property (strong, nonatomic) NSString *MobileString;

@property (strong, nonatomic) IBOutlet UITextField *txtCompanyName;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *imgCompanyLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtCompanylayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *lblHeightLayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *imgTopLayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *topCompanyLayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *topLblLayout;

@property (strong, nonatomic) IBOutlet UIView *detailView;

- (IBAction)backBtnClicked:(id)sender;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *topLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *viewHeightLayout;

@end
