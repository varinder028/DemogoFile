//
//  EMployeeTableViewCell.h
//  DemogoApplication
//
//  Created by Rhythmus on 28/02/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EMployeeTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *companyNameData;

@end
