//
//  CorporateHomeViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "CorporateHomeViewController.h"
#import "NotificationViewController.h"
#import <CoreLocation/CoreLocation.h>
#import "CorporateTableviewCellTableViewCell.h"

@interface CorporateHomeViewController ()<CLLocationManagerDelegate,UITextFieldDelegate,UITabBarControllerDelegate,UITabBarDelegate,UITableViewDataSource,UITableViewDelegate,UIPickerViewDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate,UIScrollViewDelegate>
{
    NSMutableDictionary *Dic;
    NSMutableArray *MeetingDetailReport;
    NSMutableArray *MeetingHeaderDetail;
    UIDatePicker *DateFormatPicker;
    NSMutableArray *celldata;
    
    UIImagePickerController *pickerImage;
    UIImage *IconPic;
    
    
    //////       ADMIN ADD ACCOunt OBJeCT MEMORY
    
    // NSMUtableDictionary object create
    
    NSMutableDictionary *GETIDRESONSE;
    NSMutableDictionary *PassedJSonArray;
    NSDictionary * USEREmailID;
    
    // NSMUtableArray object create
    
    NSMutableArray *otpNumber;
    NSArray *getResponse;
    NSMutableArray *CompanyDetailsArray;
    NSMutableArray *arrayID;
    NSMutableArray *cmpanyArrayID;
    
    NSMutableArray * GetADDACOUNTName;
    
    // NSString object create
    
    NSArray *dat;
    NSString *compId;
    NSString *passMobile;
    NSString *EMAILDATA;
    NSString *matchNum;
    NSString *fetchOTP;
    NSString *FirstFlag;
    NSString *passJSonArray;
    NSString *passResnedOTP;
    NSMutableString *versionNo;
    NSMutableString *OperatingNa;
    
    NSMutableString *hostname;
    
     NSMutableString *ParticipantName;
    
    NSMutableArray *arryAdd;
    
    
 //   NSMutableString *str;
    NSString *Base64encodePassword ;
    NSString * latitude;
    NSString * longitude;
    NSString *newDateString ;
    
    
    /////   tableview cell
    CorporateTableviewCellTableViewCell * cell;
}
- (IBAction)DateOrTimeChangeButton:(UIButton *)sender;

@property (strong, nonatomic) IBOutlet UITableView *ADDACCOUNtCOMPANYtableview;

- (IBAction)selctCompanyButton:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *SelectCompanyOutlet;
@property (strong, nonatomic)NSMutableArray *CompanydetailsArray;











@end

@implementation CorporateHomeViewController

@synthesize MonthNameLabel,DateLabel,DayLabel;






/// -       -   -           ADMIN add Account create multiple object details        ----------////

-(void)viewDidAppear:(BOOL)animated
{
    self.CompanydetailsArray=[[NSMutableArray alloc]init];

    [super viewWillAppear:animated];

    self.navigationController.navigationBarHidden = YES;

//    [self.navigationController.navigationBar setBackgroundColor:[self colorWithHexString:@"021e29"]];
//
//    self.navigationController.navigationBar.backgroundColor=[self colorWithHexString:@"021e29"];

    GETIDRESONSE = [[NSMutableDictionary alloc]init];
    
    arryAdd = [[NSMutableArray alloc]init];

    
    ParticipantName = [[NSMutableString alloc]init];
    
    dat = [[NSArray alloc]init];
    
    hostname = [[NSMutableString alloc]init];

    passMobile = [[NSString alloc]init];

    EMAILDATA =[[NSMutableString alloc]init];

    USEREmailID = [[NSDictionary alloc]init];

    matchNum = [[NSString alloc]init];

    fetchOTP = [[NSString alloc]init];

    FirstFlag = [[NSString alloc]init];

    passResnedOTP = [[NSString alloc]init];

    PassedJSonArray = [[NSMutableDictionary alloc]init];

    otpNumber = [[NSMutableArray alloc]init];

    CompanyDetailsArray = [[NSMutableArray alloc]init];

    arrayID = [[NSMutableArray alloc]init];

    cmpanyArrayID = [[NSMutableArray alloc]init];
    
    GetADDACOUNTName = [[NSMutableArray alloc]init];





}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    DateLabel.text=@"28";
    
  //  self.AdminTAbleView.hidden = YES;
    
    MonthNameLabel.text =@"may";
    DayLabel.text=@"sunday";
    
    
    self.AdminTAbleOrView.hidden=YES;
    self.ADDACOuntVIew.hidden = YES;
    celldata = [[NSMutableArray alloc]init];
    
    [self TableViewEditing];
    
    
    _IConButtonOutlet.layer.cornerRadius = 30.5;
    _adminImage.layer.cornerRadius =30.5;
    _adminImage.clipsToBounds=YES;

    self.BlurView.hidden=YES;
    
   
    
    
    self.TableViewEditing.tag=1;
    self.upcomingmeetingTableview.tag=2;
    self.AdminTAbleView.tag=3;
    
    
    [self upcomingmeetingTableview];
    self.upcomingmeetingTableview.delegate=self;
    self.upcomingmeetingTableview.dataSource= self;
    
    self.AdminTAbleView.delegate = self;
    self.AdminTAbleView.dataSource=self;
    
    
    
    
    
    
    /////////   ADMIN ADD ACCOUNT VERIFICATION WORK
    
    self.ADDACCOUNtCOMPANYtableview.delegate = self;
    self.ADDACCOUNtCOMPANYtableview.dataSource=self;
    
    self.ADDACOuntVIew.hidden=YES;
   
    
    self.PassAUtolayout.constant = 9;
    
    self.ADDACOuntVIew.layer.cornerRadius = 10;
    
    self.topLabelAddaccount.layer.cornerRadius = 10;
    
    self.VIewAutoLayout.constant = 185;
    
    
    //       .  . .. . . . . .     Place holder text in textfield  attribute .....
    
   NSAttributedString *email=[[NSAttributedString alloc]initWithString:@"Email/Mobile no"
         
                                       attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.EmailMobileNoTextField.attributedPlaceholder=email;
    
    NSAttributedString *Pass=[[NSAttributedString alloc]initWithString:@"Password"
                               
                                                             attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.ADMinADACCOUNtPasswordTextField.attributedPlaceholder=Pass;

    
    
    
    
    
    
    //  ..........       ADMIN CREATE ADD ACCOUNT FUNCTIONALITY DETAILS
    
    
    matchNum =@"user exist";
    
    
    
    [self.ADDACCOUNtCOMPANYtableview reloadData];
    
    self.ADDACCOUNtCOMPANYtableview.hidden=YES;
    
    self.ADDACCOUNtCOMPANYtableview.layer.cornerRadius = 20;
    
    self.SelectCompanyOutlet.hidden=YES;
    
  //  self.thirdauto.constant=6;
    
    //self.passwordImageAuto.constant=9;
    
    
    
    //////////////////////////////////////////////////////////   ------------------------------
    
    
    
    
    
    
    
    
    /////////>>>>>>>>      UserCurrentLocationFind ,Logtitude,longtitude       >>>>>>>>>////////
    
    
    
    versionNo= [[NSMutableString alloc]initWithFormat:@"%@",[UIDevice currentDevice].systemVersion];
    
    OperatingNa= [[NSMutableString alloc]initWithFormat:@"%@",[UIDevice currentDevice].systemName];
    
    NSLog(@"%@",versionNo);
    
    NSLog(@"%@",OperatingNa);
    
    
    
    CLLocationCoordinate2D coordinate = [self getLocation];
    
    latitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
    
    longitude = [NSString stringWithFormat:@"%f", coordinate.longitude];
    
    NSLog(@"*dLatitude : %@", latitude);
    
    NSLog(@"*dLongitude : %@",longitude);
    
    
    
    
    
    
    
    /////////>>>>>>>>      Current Location Time UserLogin       >>>>>>>>>////////
    
    
    NSDate * now = [NSDate date];
    
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    
    [outputFormatter setDateFormat:@"hh:mm:ss"];
    
    NSString * newDat = [outputFormatter stringFromDate:now];
    
    newDateString  = [NSString stringWithFormat:@"%ld", (long)[newDat longLongValue]];
    
    NSLog(@"newDateString %@", newDateString);
    
    
    
    
    
    
    
    
    //////////   UsertextField    placeholder edit textfield     /////////
    

    
    
    
    
    
    
    ///////// button redius , UserTextField,passtextField size edit  /////////
    
    self.ADDACCOuntSignInButton.layer.cornerRadius = 12;
    
    //self.loginButtonOutlet.layer.cornerRadius = 5.5;
    
//    self.usernameTextfield.frame = CGRectMake(56, 234, 302, 50);
//    
//    self.passwordtextfeild.frame = CGRectMake(56, 338, 302, 50);
    
    
    
    
    
    
    
    ///////// button redius , User,pass image   size edit  /////////
    
    
    //self. usernameTextfield.layer.shadowRadius = 35.0;
    
//    self.usericonView .layer.cornerRadius= 10.0;
//    
//    self.passView .layer.cornerRadius= 10.0;
//    
//    self.companyview.layer.cornerRadius = 10.0;
    
    
}






//////////.......... Current Location Find Method  (Get Location)  ...........//////

-(CLLocationCoordinate2D) getLocation


{
    
    
    CLLocationManager *locationManager = [[CLLocationManager alloc] init] ;
    
    locationManager.delegate = self;
    
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    
    locationManager.distanceFilter = kCLDistanceFilterNone;
    
    [locationManager startUpdatingLocation];
    
    CLLocation *location = [locationManager location];
    
    CLLocationCoordinate2D coordinate = [location coordinate];
    
    return coordinate;
}






    









- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.TableViewEditing)
    
    {
        return 1;
    }
    else if (tableView == self.upcomingmeetingTableview)
    {
        return 1;
    }else if (tableView == self.ADDACCOUNtCOMPANYtableview)
    {
        return [self.CompanydetailsArray count];
    }
    
    
    
    return [arryAdd count];
}


-(CorporateTableviewCellTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    NSString *str =@"cell";
    
    cell=[tableView dequeueReusableCellWithIdentifier:str forIndexPath:indexPath];
    
    if (cell==nil)
    
    {
        cell =[[CorporateTableviewCellTableViewCell alloc]init];
        
        cell.selectedBackgroundView.backgroundColor = [UIColor colorWithRed:0.01 green:0.12 blue:0.16 alpha:1.0];
    }
    
    if (tableView == self.TableViewEditing) {
        
  
    cell.ModeEnteryLbael.text=@"Deal";
        
    celldata = [NSMutableArray arrayWithObject:cell];
        
    cell.ChairPersonEnteryLabel.text =@"Vijay";
        
    cell.CompanyEnteryLabel.text =@"rhythmus";
        
    cell.DateEnteryLabel.text =@"8/1/2017";
        
    cell.TimeEntryLabel.text =@"12:30pm";
    
    }
    
    else if (tableView == self.upcomingmeetingTableview)

    {
                cell.textLabel.textColor = [UIColor whiteColor];
        
                cell.textLabel.text = @"Upcomming Rows";
    }
    else if (tableView== self.ADDACCOUNtCOMPANYtableview)
    {
        NSDictionary *dictionary = [self.CompanydetailsArray objectAtIndex:indexPath.row];
        
        cell.textLabel.text = [dictionary objectForKey:@"cmpNm"] ;
        
        return cell;

    }
    else
    {
        //cell.selectedBackgroundView.backgroundColor = [UIColor colorWithRed:0.01 green:0.12 blue:0.16 alpha:1.0];
        
        
       
        
        cell.textLabel.textColor = [UIColor whiteColor];
        
        
        cell.UsernameEntr.text =[NSString stringWithFormat:@"%@",[arryAdd objectAtIndex: indexPath.row]];
        
        
        cell.ACCOUntImage.image = [UIImage imageNamed:@"username.png"];
     
        
        
        //cell.textLabel.text = @"Devil";
    }
         return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    if (tableView == self.TableViewEditing)
        
        {
        
        
        }
    
    else if (tableView == self.upcomingmeetingTableview)
        
        {
        
        
        }
    
    else if (tableView== self.ADDACCOUNtCOMPANYtableview)
        
        {
        
            if (tableView==self.ADDACCOUNtCOMPANYtableview) {
                
                
                
                
                [self.ADMinADACCOUNtPasswordTextField resignFirstResponder];
                
                [self.EmailMobileNoTextField resignFirstResponder];
                
                
                
                
                NSDictionary *dictionary = [self.CompanydetailsArray objectAtIndex:indexPath.row];
                
                NSString *companyName = [dictionary objectForKey:@"cmpNm"];
                
                compId = [dictionary objectForKey:@"cmpId"];
                
                NSLog(@"%@ = %@",companyName,compId);
                
                
                
                
                
                cell=[self.ADDACCOUNtCOMPANYtableview cellForRowAtIndexPath:indexPath];
                
                [self.SelectCompanyOutlet setTitle:cell.textLabel.text forState:UIControlStateNormal];
                
                self.ADDACCOUNtCOMPANYtableview.hidden =YES;
                
                
            }
            
            

        
        }
    
    else
        
        {
            if (indexPath.row==0)
            
            {
                
                NSLog(@"sucess");
            }
        
        }
    
    
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath;
{
    if (tableView==self.TableViewEditing)
    {
        
    
        if (editingStyle==UITableViewCellEditingStyleDelete)
            
            { //NSIndexPath *row;
                
                
                    [celldata removeObjectAtIndex:indexPath.row];
                
                    [self.TableViewEditing deleteRowsAtIndexPaths:[NSMutableArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationRight];
        
            }
        
    } else if (tableView == self.upcomingmeetingTableview)
    {
        
    }else
    {
        
    }

        
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section;
{
    
    if (tableView==self.TableViewEditing) {
         return 1;
    }
    else if (tableView== self.upcomingmeetingTableview)
        
    {
         return 1;
    }
    
    return 1;
}



- (IBAction)DateOrTimeChangeButton:(UIButton *)sender {
    //////////////////////// Set Day Data//////////////////////
    
    NSDate *dateData =[NSDate date];
    NSDateFormatter *DateFormatter = [[NSDateFormatter alloc]init];
    [DateFormatter setDateFormat:@"EEEE"];
    DayLabel.text =[NSString stringWithFormat:@"%@",[DateFormatter stringFromDate:dateData]];
    
    ////////////////////////  Set Month Data /////////////////////
    NSDate *MonthData =[NSDate date];
    NSDateFormatter *monthFormatter = [[NSDateFormatter alloc]init];
    [monthFormatter setDateFormat:@"MMMM"];
    MonthNameLabel.text =[NSString stringWithFormat:@"%@",[monthFormatter stringFromDate:MonthData]];
    
    ////////////////////////   Set Date Data  /////////////////////
    
    NSDate *DayData =[NSDate date];
    NSDateFormatter *DayFormatter = [[NSDateFormatter alloc]init];
    [DayFormatter setDateFormat:@"dd"];
    DateLabel.text =[NSString stringWithFormat:@"%@",[DayFormatter stringFromDate:DayData]];
    
    

}









        

    
    
    


- (IBAction)TodayDropDownButton:(UIButton *)sender

{
    
    if (self.TableViewEditing.hidden==YES)
        
    {
        
        self.TableViewEditing.hidden=NO;
        self.UpCmAutoLayout.constant = 205;
        self.UPCmTableviewAutolayout.constant = 2;
    }
    
    else
    {
        
        self.TableViewEditing.hidden=YES;
        self.UpCmAutoLayout.constant = 3;
       // self.UPCmTableviewAutolayout.constant = 2;
        
    }

    
    
}

- (IBAction)NotificationButton:(UIButton *)sender
{
    
    NotificationViewController *Notify = [self.storyboard instantiateViewControllerWithIdentifier:@"NVC"];
    
    [self.navigationController pushViewController:Notify animated:YES];
    
    
    
}

- (IBAction)AdminBUtton:(UIButton *)sender

{
    
    if (self.AdminTAbleOrView.hidden==YES)
    {
        self.AdminTAbleOrView.hidden=NO;
        
    }
    
    else
    {
        self.AdminTAbleOrView.hidden = YES;
        
    }
    

    
    
    
    
    //self.AdminTAbleView.tag = 3;
    
//   if (self.AdminTAbleView.hidden==YES)
//   {
//       self.AdminTAbleView.hidden=NO;
//       
//   }
//    
//    else
//        {
//            self.AdminTAbleView.hidden = YES;
//            
//        }
//    
    
    
}

- (IBAction)UpcomingButton:(UIButton *)sender
{
    
    self.upcomingmeetingTableview.tag = 2;
    
   if (self.upcomingmeetingTableview.hidden == YES)
   {
       self.upcomingmeetingTableview.hidden=NO;
   } else
   {
       self.upcomingmeetingTableview.hidden=YES;
   }
    
}
- (IBAction)ICONButton:(UIButton *)sender

{
    
    pickerImage = [[UIImagePickerController alloc]init];
    
    pickerImage .delegate =self;
    
    [pickerImage  setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    
    [self presentViewController:pickerImage animated:YES completion:nil];
    

    
    
}


-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    
    
        IconPic = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    
        [self.adminImage setImage:IconPic];
    
        [self dismissViewControllerAnimated:YES completion:NULL];
 }

-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker

{
    [self dismissViewControllerAnimated:YES completion:NULL];
}






- (IBAction)ADACCountCancelButton:(UIButton *)sender
{
    self.ADDACOuntVIew.hidden=YES;
    
    self.BlurView.hidden = YES;
    
}

- (IBAction)SiginInButton:(id)sender



{
    
    
    
    
    
    if ([self.EmailMobileNoTextField.text isEqualToString:@""] || [self.ADMinADACCOUNtPasswordTextField.text isEqualToString:@""])
    {
        UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"ACCOUNT DETAILS" message:
                                              
                                              @"Username or Password is Empty Fill Correct details " preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                    
                                    {
                                        
                                        
                                    }];
        
        [TextFieldError3 addAction:errorPass];
        
        [self presentViewController:TextFieldError3 animated:YES completion:nil];
        
        
        
        
    }
    else
    {
        [self FirstAPIPostMethodUSed ];
        
        [self.AdminTAbleView reloadData];

    }
    
    if ([self.SelectCompanyOutlet.titleLabel.text isEqualToString:@"Select Company"])
    {
        
        UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"COMPANY" message:
                                              
                                              @"please select company" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                    
                                    {
                                        
                                        
                                    }];
        
        [TextFieldError3 addAction:errorPass];
        
        [self presentViewController:TextFieldError3 animated:YES completion:nil];

        
        
        
    }else
    {
//        UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"Company" message:
//                                              
//                                              @"You not selected company , please select company" preferredStyle:UIAlertControllerStyleAlert];
//        
//        UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
//                                    
//                                    {
//                                        
//                                        
//                                    }];
//        
//        [TextFieldError3 addAction:errorPass];
//        
//        [self presentViewController:TextFieldError3 animated:YES completion:nil];

    }

    
    
    

}

- (IBAction)ADDACcountFOrgetPassButton:(UIButton *)sender

{
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:
                                          
                                          @"ForgetPassword" message:@"this Button is not correctly perform than programe is not write & work is pending"preferredStyle:UIAlertControllerStyleAlert];
    
    
    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    
    
    [alertController addAction:ok];
    
    [self presentViewController:alertController animated:YES completion:nil];
    

    
    
}
- (IBAction)ADDACOOUNTButton:(id)sender

{
    if (self.ADDACOuntVIew.hidden==YES)
    {
        self.ADDACOuntVIew.hidden=NO;
        
        self.BlurView.hidden=NO;
        self.AdminTAbleOrView.hidden=YES;
        
    }
    
    else
    {
        self.ADDACOuntVIew.hidden = YES;
        
    }
    

    
    
    
    
    
}









































        ////                            ADMIN CREATE ADD ACCOUNT BUTTON EDIT HIT API                            ////





//////////////    Email send Second Api ////////////////
-(void)ADDAccountTableViewAPi;

{
    
  NSString *urlstr  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/getemaildetails?email=%@",self.EmailMobileNoTextField.text];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *urlAunt = [NSURL URLWithString:urlstr];
    
    
    
    
    
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:urlAunt cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    
    
    
    
    
//   NSMutableDictionary * GetDic = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.EmailMobileNoTextField.text,@"email",nil];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
                                              NSLog(@" the databse theXml is  =====  %@",theXML);
                                              
                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
                                              USEREmailID = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                              
                                              
                                              
                                              NSLog(@" the email deatils is  =   %@",EMAILDATA);
                                              
                                              NSLog(@"the email response is = %@",USEREmailID);
                                              
                                              EMAILDATA = [USEREmailID valueForKey:@"message"];
                                              
                                              
                                              if ([EMAILDATA isEqualToString:@"Email ID Do not exist"])
                                              {
                                                  UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"ACCOUNT DETAILS" message:
                                                                                        
                                                                                        @"Your Email ID is Invalid" preferredStyle:UIAlertControllerStyleAlert];
                                                  
                                                  UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                              
                                                                              {
                                                                                  
                                                                                  
                                                                              }];
                                                  
                                                  [TextFieldError3 addAction:errorPass];
                                                  
                                                  [self presentViewController:TextFieldError3 animated:YES completion:nil];
                                                  
                                                  
                                                  
                                                  
                                              }
                                              

                                              
                                              else if ([EMAILDATA isEqualToString:@"success"])
                                                  
                                                  
                                              {
                                                  
                                                  
                                                  self.CompanydetailsArray = [USEREmailID objectForKey:@"cmpList"];
                                                  
                                                  
                                                  
                                                  NSLog(@" SSS  SSSS  S S S S S  USUU U     UUUU  U U U  U");
                                              }
                                              
                                              
                                              
                                              
                                              
                                              
                                              
                                              
                                          }];
    
    
    
    
    
    [self.ADDACCOUNtCOMPANYtableview reloadData];
    
    [postDataTask resume];
    
    
    
    
    
    
    
}










/////////           Table Cell Select Row Method             ////////////


//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
//{
//    
//    
//    if (tableView==self.ADDACCOUNtCOMPANYtableview) {
//        
//    
//    
//    
//    [self.ADMinADACCOUNtPasswordTextField resignFirstResponder];
//    
//    [self.EmailMobileNoTextField resignFirstResponder];
//    
//    
//    
//    
//    NSDictionary *dictionary = [self.CompanydetailsArray objectAtIndex:indexPath.row];
//    
//    NSString *companyName = [dictionary objectForKey:@"cmpNm"];
//    
//    compId = [dictionary objectForKey:@"cmpId"];
//    
//    NSLog(@"%@ = %@",companyName,compId);
//    
//    
//    
//    
//    
//    cell=[self.ADDACCOUNtCOMPANYtableview cellForRowAtIndexPath:indexPath];
//    
//    [self.SelectCompanyOutlet setTitle:cell.textLabel.text forState:UIControlStateNormal];
//    
//    self.ADDACCOUNtCOMPANYtableview.hidden =YES;
//    
//    
//    }
//    
//    
//    
//    
//}




////////////                UITableViewCell           //////////////



- (BOOL)textFieldShouldReturn:(UITextField *)textField


{
    
    [self.EmailMobileNoTextField resignFirstResponder];
    
    [self.ADMinADACCOUNtPasswordTextField resignFirstResponder];
    
    [self ADDAccountTableViewAPi];
    
    
    
    
    
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Select Company Name\n Your UserId Is"
                                          
                                                                             message:self.EmailMobileNoTextField.text preferredStyle:UIAlertControllerStyleAlert];
    
    
    
    
    ////////    ......................Create Button On alert Notification ......................
    
    UIAlertAction* SelectCompany = [UIAlertAction actionWithTitle:@"CompanyName" style:UIAlertActionStyleDefault
                                    
                                                          handler:^(UIAlertAction * action)
                                    
                                    {
                                        
                                        //[self SaveDataSecondApi];
                                        
                                        if ([EMAILDATA isEqualToString:@"Email ID Do not exist"])
                                            
                                            
                                        {
                                            NSLog(@"email is not successfully");
                                            
                                            
                                            UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"USERNAME" message:
                                                                                  
                                                                                  @"USERNAME IS NOT CORRECT,PLEASE FILL CORRECT DETAILS" preferredStyle:UIAlertControllerStyleAlert];
                                            
                                            UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                        
                                                                        {
                                                                            
                                                                            
                                                                        }];
                                            
                                            [TextFieldError3 addAction:errorPass];
                                            
                                            [self presentViewController:TextFieldError3 animated:YES completion:nil];
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                        }
                                        
                                        
                                        
                                        
                                        else if ([EMAILDATA isEqualToString:@"success"])
                                            
                                            
                                        {
                                            
                                            
                                            NSLog(@" Alert Activate You Work it ");
                                            
                                            [self.ADDACCOUNtCOMPANYtableview reloadData];
                                            
                                            self.SelectCompanyOutlet.hidden=NO;
                                            
                                            
                                            self.PassAUtolayout.constant=49;
                                            
                                            self.VIewAutoLayout.constant=226;
                                            
                                            //self.NameCmpBT.hidden=NO;
                                        }
                                        
                                        else {
                                            
                                            
                                            UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"ACCOUNT DETAILS" message:
                                                                                  
                                                                                  @"Your Email ID is Invalid" preferredStyle:UIAlertControllerStyleAlert];
                                            
                                            UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                        
                                                                        {
                                                                            
                                                                            
                                                                        }];
                                            
                                            [TextFieldError3 addAction:errorPass];
                                            
                                            [self presentViewController:TextFieldError3 animated:YES completion:nil];
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            NSLog(@"ERROR EMAIL ID LINK");
                                        }
                                        
                                        
                                        
                                    }];
    
    
    
    
    [alertController addAction:SelectCompany];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
    
    
    
    
    return YES;
    
    
}











//



-(void)FirstAPIPostMethodUSed;
{
    NSString *urlstr  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/checklogin"];//?add=%@&cmpId=%@&latitude=%@&logintym=%@&longitude=%@&os=%@&username=%@&password=%@&version=%@",@"false",compId,latitude,newDateString ,longitude,OperatingNa,self.EmailMobileNoTextField.text,Base64encodePassword,versionNo];
    
    
    NSError *error;
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    // NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
    
    NSURL * urll = [NSURL URLWithString:urlstr];
    
    NSMutableURLRequest * requestUrl = [NSMutableURLRequest requestWithURL:urll
                                                               cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                           timeoutInterval:60.0];
    
    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [requestUrl setHTTPMethod:@"POST"];
    
    
    
    
    
//    for (NSDictionary *dicId in [getResponse valueForKey:@"cmpList"] ) {
//        
//        
//        strids = [NSString stringWithFormat:@"%@",dicId];
//        
//        //  NSLog(@"Company Id Is == %@",strids );
//    }
    
    
    
    
    /////////   Password convert in Base64Encoding   ./////////////
    
    
   NSString * strPassword= self.ADMinADACCOUNtPasswordTextField.text;
    
    NSLog(@"%@",strPassword);
    
    NSData *dataTake2 = [strPassword dataUsingEncoding:NSUTF8StringEncoding];
    
    // Convert to Base64 data
    
    NSData *base64Data = [dataTake2 base64EncodedDataWithOptions:0];
    
    Base64encodePassword = [NSString stringWithFormat:@"%@",[NSString stringWithUTF8String:[base64Data bytes]]];
    
    NSLog(@"%@", Base64encodePassword);
    
    
    
    
   NSDictionary* mapData = [[NSDictionary alloc] initWithObjectsAndKeys:@"true",@"add",compId,@"cmpId",latitude,@"latitude",
               
               newDateString ,@"logintym",longitude,@"longitude",OperatingNa,@"os",self.EmailMobileNoTextField.text,@"username",
               
               Base64encodePassword,@"password",@"3714",@"personId",versionNo,@"version",nil];
    
    
    
    // newDateString,@"logintym",
    
    
    
    
    
    NSLog(@" %@",mapData);
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:mapData options:0 error:&error];
    
    [requestUrl setHTTPBody:postData];
    
    
    
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:requestUrl completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
    {
                                              
                                              
                                              
    dispatch_async(dispatch_get_main_queue(),^{
                                                  
                                                  
    NSError *jsonError;
        
    NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        
    NSLog(@" the databse theXml is  =====  %@",theXML);
        
        
    NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                                  
        
   NSMutableArray * USEREmail = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&jsonError];
                                                  
                                                  
                                   // NSLog(@" the email deatils is  =   %@",EMAILDATA);
        
        NSLog(@"Dictionary: %@",USEREmail);
        NSLog(@"Dictionary: %i",[USEREmail count]);
        
        NSString *respo=[USEREmail valueForKey:@"message"];
        NSLog(@"Ticket_Id: %@",respo);
        
        
        
    if ([respo isEqualToString:@"user exist"])
            
        {
            NSArray *name=[USEREmail valueForKey:@"result"];
            
            NSLog(@"Ticket_Id: %@",name);

            for(dat in name)
            
                {
               
                    if([[dat valueForKey:@"role"] isEqualToString:@"ROLE_HOST"])
            
                {
                
                
                    NSString *HAlfStr=[dat valueForKey:@"firstName"];
                
                    NSString *cmpname = [dat valueForKey:@"cmpNm"];
                
                    hostname =[NSMutableString stringWithFormat:@"%@(%@)",HAlfStr,cmpname];
               
                    NSLog(@"Posted BY: %@", hostname);
                    
                    [arryAdd addObject:hostname];
                
                    [self.AdminTAbleView reloadData];
                }
            
                    else if([[dat valueForKey:@"role"] isEqualToString:@"ROLE_PARTICIPANT"])
                        
                        {
                
                            NSString *HAlfStr=[dat valueForKey:@"firstName"];
                
                            NSString *cmpname = [dat valueForKey:@"cmpNm"];
                
                            ParticipantName =[NSMutableString stringWithFormat:@"%@(%@)",HAlfStr,cmpname];
                
                            NSLog(@"Posted BY: %@", ParticipantName);
                            [arryAdd addObject:ParticipantName];
                
                            [self.AdminTAbleView reloadData];
                        }
                
                }
        
        }
        
        else if ([respo isEqualToString:@"Accounts already Merged"])
        {
            
        }
    else
    {
        NSLog(@" all details is not correct");
    }
        
        
        
        
            });
        
    }];
    
    
    
    [postDataTask resume];
    
    
    
    
}


-(void)reloadView

{
    UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"ADD ACCOUNT" message:
                                          
                                          @"The User Account is already Merged" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                
                                {
                                    
                                    
                                }];
    
    [TextFieldError3 addAction:errorPass];
    
    [self presentViewController:TextFieldError3 animated:YES completion:nil];
    

}

- (IBAction)selctCompanyButton:(id)sender
{
    
    if (self.ADDACCOUNtCOMPANYtableview.hidden==YES)
    {
        self.ADDACCOUNtCOMPANYtableview.hidden=NO;
        
        
        
    }
    
    else
    {
        self.ADDACCOUNtCOMPANYtableview.hidden = YES;
        
    }
    

    
}
@end
