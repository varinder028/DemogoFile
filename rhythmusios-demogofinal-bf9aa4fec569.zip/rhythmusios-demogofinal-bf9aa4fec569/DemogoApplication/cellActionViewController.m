//
//  cellActionViewController.m
//  DemogoApplication
//
//  Created by Rhythmus on 31/03/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "cellActionViewController.h"

#import "CompCellTableViewCell.h"
#import "EditAccountSaveViewController.h"
#import "ADMINProfilePICViewController.h"
#import "CorporateTabBarViewController.h"

@interface cellActionViewController ()<UITableViewDelegate,UITableViewDataSource,NSURLSessionDelegate,NSURLSessionDataDelegate>
{
    NSMutableDictionary *userEmailID ;
    NSMutableDictionary *userEmailID2 ;
    NSString* rolename;
    NSString* rolename2;
    UIRefreshControl *refreshctrl ;
    CompCellTableViewCell * cell ;
    
    NSString *cmpNameFetch;
    
    NSString *RoleNameFetch;
    
    NSString *AccNameFetch;
}



- (IBAction)BAckButton:(id)sender;




- (IBAction)SaveButton:(UIButton *)sender;
- (IBAction)CancelButton:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIButton *SaveButtonOutlet;
@property (strong, nonatomic) IBOutlet UIButton *CancelButtonOutlet;


@end

@implementation cellActionViewController



-(void)viewWillAppear:(BOOL)animated

{
    
//    refreshctrl = [[UIRefreshControl alloc]init];
//    
//    [refreshctrl addTarget:self action:@selector(refreshButton) forControlEvents:UIControlEventValueChanged];
    
    //[self.TableCompanyList addSubview:refreshctrl];
    
  //  [self.TableCompanyList reloadData];
    
   
  
    

    self.tabBarController.tabBar.hidden = NO;
    
    _ScrollView2.showsVerticalScrollIndicator=YES;
    _ScrollView2.scrollEnabled=YES;
    _ScrollView2.userInteractionEnabled=YES;
    
    _ScrollView2.contentSize = CGSizeMake(0,self.ScrollView2.frame.size.height+60);
    
    [self PersonIdSetInServer2];
    
}


-(void)PersonIdSetInServer2;

{
    
    NSString * urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/getprofile?personId=%@",@"3713"];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *url = [NSURL URLWithString:urlstring];
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
                                              NSLog(@" the databse theXml is  =====  %@",theXML);
                                              
                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
                                              userEmailID2 = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                              
                                              NSLog(@"The State Response is  ===  %@" , userEmailID2);
                                              
                                              NSLog(@"The State Response is  ===  %@" , [userEmailID2 valueForKey:@"responseCode"]);
                                              
                                              NSString* str =[userEmailID2 valueForKey:@"role"];
                                              
                                              if ([str isEqualToString:@"ROLE_SUPER_ADMIN"])
                                                  
                                              {
//                                                  self.NameLabel.text =[userEmailID valueForKey:@"firstName"];
//                                                  
//                                                  self.CountryNameLabel.text = [userEmailID valueForKey:@"location"];
//                                                  
//                                                  self.EmailNameLAbel.text = [userEmailID valueForKey:@"pemail"];
//                                                  
//                                                  self.MobileNumberLAbel.text = [userEmailID valueForKey:@"pmobile"];
                                                  
                                                  NSString *replace = [userEmailID2 valueForKey:@"role"];
                                                  
                                                  NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"ROLE_SUPER_"];
                                                  
                                                  rolename2 =  [replace stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
                                                  
                                                  rolename2 = [[rolename2 componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString:@""];
                                                  
                                                  NSLog(@"%@",rolename2);
                                                  
                                                  
                                                  
                                                 // self.AdminOrHostNameLAbel.text = rolename;
                                                  
                                                  
                                                  
                                                  
                                              }
                                              
                                              else if(str ==nil)
                                                  
                                              {
                                                  
                                                  NSLog(@"error");
                                                  
                                              }
                                              
                                              
                                          }];
    
    [self.TableCompanyList reloadData];
    
    [postDataTask resume];
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    userEmailID = [[NSMutableDictionary alloc]init];
    
    [self PersonIdSetInServer];
    
    self.BlurView2.hidden =YES;
    
    self.SaveButtonOutlet.hidden = YES;
    
    self.CancelButtonOutlet.hidden=YES;
    
    self.ScrollView2.hidden =YES;
    
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dissmisskeyboard:)];
    
    [self.view addGestureRecognizer:tap];
  

    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)dissmisskeyboard:(UIGestureRecognizer *) sender
{
    [self.view endEditing:YES];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView

{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    return 3;
}

- (CompCellTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;

{
    NSString *cellid = @"cell";
    
    cell= [tableView dequeueReusableCellWithIdentifier:cellid];
    
    if (cell ==nil) {
        cell = [[CompCellTableViewCell alloc]init];
    }
    
    
    
    
    cell.CmpTextView.text = [userEmailID2 valueForKey:@"cmpNm"];//_CountryName;
    
    cell.RoleNAme.text = rolename2;//_roleNAmedata;
    
    cell.AccountName.text = @"Primary";//_Accountname;
    
    
    
    cell.udateButton.tag = indexPath.row;
    
    [cell.udateButton addTarget:self action:@selector(detailsView) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    if (indexPath.row) {
        NSLog(@"sucess");
        
    
        
//        EditAccountSaveViewController *editdata = [self.storyboard instantiateViewControllerWithIdentifier:@"Edit"];
//        
//        editdata.MobileString = _MobileNUmberString;
//        
//        editdata.FirstLAbel =[userEmailID valueForKey:@"firstName"] ;
//        
//        editdata.LAstLAbel = [userEmailID valueForKey:@"lastName"] ;
//        
//        editdata.LocationL= [userEmailID valueForKey:@"location"] ;
//        
//        editdata.AdminLAbel = rolename ;
//        
//        editdata.DepartLabel = [userEmailID valueForKey:@"depName"] ;
//        
//        editdata.EmailLabel = [userEmailID valueForKey:@"pemail"];
//        
//        
//        
//        [self.navigationController pushViewController:editdata animated:YES];
//        
//        
//        
        
    }
}
-(void)detailsView
{
    NSLog(@"success");
    
    
    
    EditAccountSaveViewController *editdata = [self.storyboard instantiateViewControllerWithIdentifier:@"Edit"];
    
    editdata.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    
    editdata.MobileString = [userEmailID2 valueForKey:@"pmobile"];
    
    editdata.FirstLAbel =[userEmailID2 valueForKey:@"firstName"] ;
    
    editdata.LAstLAbel = [userEmailID2 valueForKey:@"lastName"] ;
    
    editdata.LocationL= [userEmailID2 valueForKey:@"location"] ;
    
    editdata.AdminLAbel = rolename ;
    
    editdata.DepartLabel = [userEmailID2 valueForKey:@"depName"] ;
    
    editdata.EmailLabel = [userEmailID2 valueForKey:@"pemail"];
    
    
        
    [self.navigationController pushViewController:editdata animated:YES];
    
    
}

-(void)PersonIdSetInServer;

{
    
    NSString * urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/getprofile?personId=%@",@"3713"];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *url = [NSURL URLWithString:urlstring];
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
                                              NSLog(@" the databse theXml is  =====  %@",theXML);
                                              
                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
                                               userEmailID = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                              
                                              NSLog(@"The State Response is  ===  %@" , userEmailID);
                                              
                                              NSLog(@"The State Response is  ===  %@" , [userEmailID valueForKey:@"responseCode"]);
                                              
                                              NSString *replace = [userEmailID valueForKey:@"role"];
                                              
                                              NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"ROLE_SUPER_"];
                                              
                                              rolename =  [replace stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
                                              
                                              rolename = [[rolename componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString:@""];
                                              
                                              NSLog(@"%@",rolename);
                                              
                                              
                                              
                                            //  self.AdminOrHostNameLAbel.text = rolename;
                                              

                                              
                                          }];
    
    [self.TableCompanyList reloadData];
    
    [postDataTask resume];
    
}





- (IBAction)BAckButton:(id)sender

{
    
    CorporateTabBarViewController * adp = [self.storyboard instantiateViewControllerWithIdentifier:@"CTabBar"];
    
   // adp.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    
    [self.navigationController pushViewController:adp animated:YES];
    

}

- (IBAction)SaveButton:(UIButton *)sender
{
    
    [self saveDataInServerApi];
}

- (IBAction)CancelButton:(UIButton *)sender
{
    
    self.BlurView2.hidden =YES;
        
    self.SaveButtonOutlet.hidden = YES;
    
    self.CancelButtonOutlet.hidden=YES;
    
    self.ScrollView2.hidden =YES;
    

    
    
}
- (IBAction)UPloadPictureButton:(UIButton *)sender
{
    
}



-(void)saveDataInServerApi;

{
    
    NSError *error;
    NSString * urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/editperson"];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *url = [NSURL URLWithString:urlstring];
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [SendingRequest setHTTPMethod:@"PUT"];
    
    
    
    
    
    NSMutableDictionary *emailDicDta = [[NSMutableDictionary alloc]
                                        initWithObjectsAndKeys:@"PRIMARY",@"type",self.EmsilSaveTextField.text,@"value", nil];
    
    
    NSMutableArray * emailArray =[[NSMutableArray alloc]init];
    
    [emailArray addObject:emailDicDta];
    
    
    NSMutableDictionary *mobileDicDta =
    [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"PRIMARY",@"type",self.MobileSaveTExtField.text,@"value", nil];
    
    
    
    
    NSMutableArray *mobileArray =[[NSMutableArray alloc]init];
    
    [mobileArray addObject:mobileDicDta];
    
    
    NSDictionary *alldetails = [[NSDictionary alloc]initWithObjectsAndKeys:@"1752",@"cmpId",self.FirstNAmeSaveTextField.text,@"firstName",self.LAstNAmeSaveTextField.text,@"lastName",emailArray,@"email",mobileArray,@"mobile",
    self.LocationSaveTextField.text,@"location",self.DepartmentSaveTEXtField.text,@"depName",
    @"3713",@"personId",@"true",@"empSts",@"3713",@"loginId",
    @"3713",@"hostId",@"ROLE_SUPER_ADMIN",@"role", nil];
    
    
   
    
   
    
    NSLog(@"%@",alldetails);
    
    NSData* SendData= [NSJSONSerialization dataWithJSONObject:alldetails options:kNilOptions error:&error];
    
    [SendingRequest setHTTPBody:SendData];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
                                              NSLog(@" the databse theXml is  =====  %@",theXML);
                                              
                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
                                              NSMutableDictionary * SaveResponseGet = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                              
                                              NSLog(@"The State Response is  ===  %@" , SaveResponseGet);
                                              
                                              NSLog(@"The State Response is  ===  %@" , [SaveResponseGet valueForKey:@"responseCode"]);
                                              
                                              
                                              
                                          }];
    
    [self.TableCompanyList reloadData];
    
    [postDataTask resume];
    
}




- (IBAction)backClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
@end
