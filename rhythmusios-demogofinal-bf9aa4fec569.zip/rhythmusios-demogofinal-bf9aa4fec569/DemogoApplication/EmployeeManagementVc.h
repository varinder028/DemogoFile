//
//  EmployeeManagementVc.h
//  DemogoApplication
//
//  Created by katoch on 26/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmployeeManagementVc : UIViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UIAlertViewDelegate,UIDocumentPickerDelegate,UIDocumentMenuDelegate>{
    
    NSMutableArray* listArray;
    
    int i ;
    NSArray *allItems;
    
    NSMutableArray *DisplayItems;
    //UIButton *btnTag ;
    NSString *strProfileid ;
    id profileData;
    NSMutableArray *listProfiles;
    NSString*companyId;
     NSString*Tokenid;
    
    NSMutableArray *userListArray ;
    
    NSString *blockPersonId ;
    NSMutableArray *blockCheckedArray ;
    
    NSMutableArray *indexArr ;
    
    BOOL isUser ;
    
    id getGroupDetails;
    NSMutableArray *groupArray;
    
    id unblkUser ;
    
    id unblockUser ;
    id blockUser ;
    NSMutableArray*groupcheckmarkArray ;
    NSMutableArray*totalcheckmarkArray;
    
    NSMutableArray *selectedGroups;
    NSMutableArray *selectedUsers ;
    
    NSMutableArray*blockedArray;
    NSMutableArray*BlockedGroups ;
    UIAlertView*alertBlock ;
    UIAlertView*alertUnBlock ;
    
    NSMutableArray *search_tableContents;
 
     id isVarified ;
    
    id allData;
    NSString*pmobile;
   
    
    
    
}
@property (strong, nonatomic) IBOutlet UIView *viewSubSubcribe;
@property (strong, nonatomic) IBOutlet UIView *viewSubscribe;
@property (strong, nonatomic) IBOutlet UIButton *btnsubscribe;
- (IBAction)subscribeClicked:(id)sender;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *xLblLayout;
@property (strong, nonatomic) IBOutlet UITableView *employeeTableView;
@property (strong, nonatomic) IBOutlet UIButton *BtnCheckAll;
- (IBAction)CheckAllClicked:(id)sender;
- (IBAction)userClicked:(id)sender;
- (IBAction)groupClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
- (IBAction)btnAdd:(id)sender;
- (IBAction)bulkUpload:(id)sender;
- (IBAction)btnBlock:(id)sender;
- (IBAction)btnUnblock:(id)sender;
- (IBAction)backClicked:(id)sender;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *bulkUploadWidth;
@property (strong, nonatomic) IBOutlet UIView *selectionView;
@property (strong, nonatomic) IBOutlet UIView *searchView;

@property (strong, nonatomic) IBOutlet UILabel *lblMobile;
@property (strong, nonatomic) IBOutlet UILabel *lblName;
@property (strong, nonatomic) IBOutlet UILabel *lblRole;

@end
