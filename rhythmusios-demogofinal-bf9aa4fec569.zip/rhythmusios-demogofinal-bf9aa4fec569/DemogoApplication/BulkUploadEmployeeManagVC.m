//
//  BulkUploadEmployeeManagVC.m
//  DemogoApplication
//
//  Created by Rhythmus on 03/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "BulkUploadEmployeeManagVC.h"
#import <AFNetworking/AFNetworking.h>
#import "KVNProgress.h"



@interface BulkUploadEmployeeManagVC ()

@end

@implementation BulkUploadEmployeeManagVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.btnSubmit.layer.cornerRadius = 5.5f;
    
    _viewColour.layer.borderColor = [UIColor colorWithRed:0.01 green:0.50 blue:1.00 alpha:1.0].CGColor;
    _viewColour.layer.borderWidth = 3.0f;
    
    
    hostId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    NSLog(@"%@",hostId);
    
    CompId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];

    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnDownlaod:(id)sender {
    
    [self openDocumentMenu];
    
}

- (IBAction)btnSUBMIT:(id)sender {
    
    [self csvUploadingToServer];
    
}

-(void)openDocumentMenu{
    UIDocumentMenuViewController *objMenuView = [[UIDocumentMenuViewController alloc]initWithDocumentTypes:@[@"public.data"] inMode:UIDocumentPickerModeImport];
    
    //Create Custom option to display
    [objMenuView addOptionWithTitle:@"My Custom option" image:nil order:UIDocumentMenuOrderFirst handler:^{
        //Call when user select the option
        
    }];
    //Set the delegate
    objMenuView.delegate = self;
    
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
        objMenuView.modalTransitionStyle = UIModalPresentationPopover ;
        objMenuView.popoverPresentationController.sourceView = self.view ;
        [self presentViewController:objMenuView animated:YES completion:nil];
    }
    else{
        [self presentViewController:objMenuView animated:YES completion:nil];
        
    }

}

- (void)documentMenu:(UIDocumentMenuViewController *)documentMenu didPickDocumentPicker:(UIDocumentPickerViewController *)documentPicker {
    documentPicker.delegate = self;
    [self presentViewController:documentPicker animated:YES completion:nil];
}

-(void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentAtURL:(NSURL *)url
{
    if (controller.documentPickerMode == UIDocumentPickerModeImport)
    {
        documentsDirectory = [url path];
        extensionFile = [documentsDirectory pathExtension];
        NSLog(@"%@",extensionFile);
        
        NSUserDefaults *defaults = [[NSUserDefaults alloc]init];
        NSData *dictionaryData = [defaults objectForKey:@"dictDTA"];
        
        downloadedFileName = [NSString stringWithFormat:@"%@", [url lastPathComponent]];

        
        
        fileData = [[NSFileManager defaultManager] contentsAtPath:documentsDirectory];
        if ([extensionFile isEqualToString:@"csv"]||[extensionFile isEqualToString:@"xls"]||[extensionFile isEqualToString:@"CSV"]|| [extensionFile isEqualToString:@"xls"]||[extensionFile isEqualToString:@"xlsx"]) {
            // Condition called when user download the file
            _txtDocumentName.text = downloadedFileName ;
            _txtDocumentName.textColor = [UIColor whiteColor];
            

            
            NSBundle *mainBundle = [NSBundle mainBundle];
            NSString *myFile = [mainBundle pathForResource: documentsDirectory ofType: @"pdf"];
            
            
            
            NSString *content = [NSString stringWithContentsOfURL:url encoding:NSASCIIStringEncoding error:nil];
            
            
            
            NSArray *arracontent = [[NSArray alloc]init];
            
            
            NSLog(@"%@",content);
            
            
            
            
        }else{
            UIAlertController *alertController = [UIAlertController
                                                  alertControllerWithTitle:nil
                                                  message:@"Please select csv/xls file"
                                                  preferredStyle:UIAlertControllerStyleAlert];
            [alertController addAction:[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:alertController animated:YES completion:nil];
            
        }
        
    }
    
}
- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {
    
    NSLog(@"cencelled");
    
    
}



//-(void)csvUploadingToServer{
//
//    long comId = [CompId longLongValue];
//    long hosId = [hostId longLongValue];
//    NSString *apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/importexcel?comId=%ld&hosId=%ld",comId,hosId];
//
////    NSMutableDictionary *getUpdates= [[NSMutableDictionary alloc]init];
////    long comId = [CompId longLongValue];
////    long hosId = [hostId longLongValue];
////    
////    [getUpdates setObject:[NSString stringWithFormat:@"%ld",comId] forKey:@"cmpId"];
////    [getUpdates setObject:[NSString stringWithFormat:@"%ld",hosId]  forKey:@"hostId"];
//
//
//       //  NSString * getUpdates = [NSString stringWithFormat: @"cmpId=%ld&hostId=%ld",comId,hosId];
//    
//
//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//    manager.requestSerializer = [AFJSONRequestSerializer serializer];
//    manager.responseSerializer = [AFJSONResponseSerializer serializer];
//    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
//
//    [manager.requestSerializer setValue:@"multipart/form-data" forHTTPHeaderField:@"Content-Type"];
//    
//    
//    [manager POST:apiURLStr parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
//        if (fileData!=nil){
//            NSDictionary *jsonHeaders = @{@"Content-Disposition":@"attachment;filename=FileName.csv",
//                                          @"Content-Type": @"application/vnd.ms-excel"};
//
//            [formData appendPartWithHeaders:jsonHeaders body:fileData];
//
//
//            [formData appendPartWithFileData:fileData name:@"fileData" fileName:@"someFile.csv" mimeType:@"application/vnd.ms-excel"];
//
//
//        }
//
//    } success:^(NSURLSessionDataTask *operation, id responseObject) {
//        NSLog(@"Success: %@", responseObject);
//
//
//        //            block(responseObject,nil);
//
//        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
//
//        dataAll = responseObject ;
//        [self performSelectorOnMainThread:@selector(AllData) withObject:nil waitUntilDone:YES];
//
//
//
//    } failure:^(NSURLSessionDataTask *operation, NSError *error) {
//        NSLog(@"Error: %@", error);
//        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
//
//    }];
//}



-(void)KvnPerform{
    
    [KVNProgress dismiss];
    
}

-(void)AllData{
    
    if ( [[dataAll valueForKey:@"message"] isEqualToString:@"success"]) {
        
        _txtDocumentName.text = @"" ;
        
        alertUpload = [[UIAlertView alloc]initWithTitle:nil message:[dataAll valueForKey:@"message"]  delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alertUpload show];
        

    }else{
        
        
        _txtDocumentName.text = @"" ;

        
        UIAlertView*alert = [[UIAlertView alloc]initWithTitle:nil message:[dataAll valueForKey:@"message"]  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
    }
    

}

-(void)csvUploadingToServer{
    
    NSDictionary *headers = @{ @"content-type": @"multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
                               @"token": Tokenid,
                               @"cache-control": @"no-cache",
                               @"postman-token": @"785bb863-42cc-6b04-c153-6637ae377e10" };
    NSArray *parameters = @[ @{ @"name": @"fileData", @"fileName": downloadedFileName } ];
    NSString *boundary = @"----WebKitFormBoundary7MA4YWxkTrZu0gW";
    
    NSError *error;
    NSMutableString *body = [NSMutableString string];
    for (NSDictionary *param in parameters) {
        [body appendFormat:@"--%@\r\n", boundary];
        if (param[@"fileName"]) {
            [body appendFormat:@"Content-Disposition:form-data; name=\"%@\"; filename=\"%@\"\r\n", param[@"name"], param[@"fileName"]];
            [body appendFormat:@"Content-Type: %@\r\n\r\n", param[@"contentType"]];
            [body appendFormat:@"%@", [NSString stringWithContentsOfFile:param[@"fileName"] encoding:NSUTF8StringEncoding error:&error]];
            if (error) {
                NSLog(@"%@", error);
            }
        } else {
            [body appendFormat:@"Content-Disposition:form-data; name=\"%@\"\r\n\r\n", param[@"name"]];
            [body appendFormat:@"%@", param[@"value"]];
        }
    }
    [body appendFormat:@"\r\n--%@--\r\n", boundary];
    NSData *postData = [body dataUsingEncoding:NSUTF8StringEncoding];
    
    long comId = [CompId longLongValue];
        long hosId = [hostId longLongValue];
        NSString *apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/importexcel?comId=%@&hosId=%@",CompId,hostId];
    
    NSString*api=  [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/importexcel?cmpId=%@&hostId=%@",CompId,hostId];
    
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:api]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:100.0];
    
    
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
                                                        
                                                        dataAll =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                                        
                                                        
                                                                [self performSelectorOnMainThread:@selector(AllData) withObject:nil waitUntilDone:YES];

                                                    }
                                                }];
    [dataTask resume];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == alertUpload) {
       
        [self.navigationController popViewControllerAnimated:YES];
        

    }
   }
@end
