//
//  MyPlanViewController.m
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "MyPlanViewController.h"
#import "ViewController.h"
#import "KVNProgress.h"

@interface MyPlanViewController ()

@end

@implementation MyPlanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CompanyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];

    [KVNProgress show];
    
    [self MyCurrentPlan];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)BAckButton:(id)sender {
           
    [self.navigationController popViewControllerAnimated:YES];
    
  }



-(void)MyCurrentPlan{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/plan/secure/mycurrentplan?cmpid=%@",CompanyId];
    
    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
    
    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
    [urlrequest setHTTPMethod:@"GET"];
    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
                                            completionHandler:
                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
                                      
                                      [self performSelectorOnMainThread:@selector(kvndismiss) withObject:nil waitUntilDone:YES];
                                      
                                      
                                      myPlans=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
                                      
                                      [self performSelectorOnMainThread:@selector(myPlansData) withObject:nil waitUntilDone:YES];
                                      
                                      
                                  }];
    [task resume];
    
    
}


-(void)kvndismiss{
    
    [KVNProgress dismiss];
    
}



-(void)myPlansData{
    
    NSLog(@"%@",myPlans);
    NSMutableArray*arrData = [[NSMutableArray alloc]init];
    
    
    if ([[myPlans valueForKey:@"message"] isEqualToString:@"success"]) {
        
        if ([[myPlans valueForKey:@"postpaidplan"] count] >0) {
             arrData = myPlans[@"postpaidplan"];
        }
        else if ([[myPlans valueForKey:@"prepaidplan"] count] >0){
            arrData = myPlans[@"prepaidplan"];
            
        }
        
        
      
        
       
        
        
        
        self.LabelMRV.text = [NSString stringWithFormat:@"%@",[arrData[0] valueForKey:@"mrv"]];
        self.LAbelFcvRate.text = [NSString stringWithFormat:@"%@",[arrData[0] valueForKey:@"fcv"]];
        self.LabelPortRate.text = [NSString stringWithFormat:@"%@",[arrData[0] valueForKey:@"port"]];
       
        self.LAbelINDRate.text =[NSString stringWithFormat:@"%@",[arrData[0] valueForKey:@"dialinPulse"]];
        self.LabelPlanNameHeader.text = [NSString stringWithFormat:@"%@",[arrData[0] valueForKey:@"planName"]];
        
        

    }
    
    
}



@end
