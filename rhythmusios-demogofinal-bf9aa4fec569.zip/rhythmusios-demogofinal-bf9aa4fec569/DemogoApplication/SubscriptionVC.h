//
//  SubscriptionVC.h
//  DemogoApplication
//
//  Created by katoch on 22/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubscriptionVC : UIViewController<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate>{
    
     BOOL closeSection;
   
     NSInteger lastIndex;
BOOL reloadTblVw;
    NSMutableDictionary *dataDict ;
    UIImageView *img;
    NSArray *arrr ;
    
    NSString *checkPlan ;
    
    NSMutableArray *smartMinutesArray ;
    
    id prepaidData ;
    id PostpaidData ;
    id topUpData ;
    NSMutableArray *dataSubscription;
    NSString *CompanyId;
    NSString *personId;
    NSString*planid ;
    
    id prepaidSubscribe ;
    
   BOOL isPostpaid ;
    BOOL IsProceed ;
    
    NSString *PlanName ;
    id TopUp ;
    
    id isVarified ;
    
    NSString *planNameCHeck;
    
    UIAlertView*migratePrepaidAlert ;
    
    id dueAmount ;
    
    NSString*Tokenid;
    
    
    
}
@property (strong, nonatomic) IBOutlet UITableView *subscriptionTableView;

- (IBAction)segmentBtn:(id)sender;

@property (strong, nonatomic) IBOutlet UIView *subscriptionSelectionView;
- (IBAction)btnPrepaid:(id)sender;
- (IBAction)btnPostpaid:(id)sender;
- (IBAction)btnSmartMinutes:(id)sender;


@property (strong, nonatomic) IBOutlet UIButton *btnSmartMinutes;
@property (strong, nonatomic) IBOutlet UIButton *btnPostpaid;
@property (strong, nonatomic) IBOutlet UIButton *btnPrepaid;
- (IBAction)backClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UILabel *txtName;
@property (strong, nonatomic) IBOutlet UILabel *txtType;
@property (strong, nonatomic) IBOutlet UILabel *txtId;
@property (strong, nonatomic) IBOutlet UIView *viewPlanDetail;
- (IBAction)buyClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnBuyNow;
@property (strong, nonatomic) IBOutlet UITextField *txtPlanName;
@property (strong, nonatomic) IBOutlet UITextField *txtPlanId;

@property (strong, nonatomic) IBOutlet UITextField *txtPlanType;
@property (strong, nonatomic) IBOutlet UITextField *txtCompanyName;
@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtOrderDate;
- (IBAction)PayClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnPay;
@property (strong, nonatomic) IBOutlet UITextField *txtAmount;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;

@property (strong, nonatomic) IBOutlet UIView *viewPay;
@property (strong, nonatomic) IBOutlet UIButton *backPayClicked;
- (IBAction)backPay:(id)sender;
- (IBAction)closeClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *prepaidView;
@property (strong, nonatomic) IBOutlet UIButton *btnPostpaidProceed;
- (IBAction)proceedClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnCancelPostpaid;
- (IBAction)btnCancelClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *viewPostPaidProceed;


@end
