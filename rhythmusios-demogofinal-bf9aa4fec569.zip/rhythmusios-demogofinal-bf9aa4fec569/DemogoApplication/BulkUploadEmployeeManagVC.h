//
//  BulkUploadEmployeeManagVC.h
//  DemogoApplication
//
//  Created by Rhythmus on 03/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BulkUploadEmployeeManagVC : UIViewController<UIDocumentPickerDelegate,UIDocumentMenuDelegate,UIAlertViewDelegate>
{
    
    NSString*documentsDirectory;
    NSString*extensionFile;
    NSData*fileData ;
    NSString*  CompId ;
    NSString*hostId;
    id dataAll;
    NSString*Tokenid ;
    NSString *downloadedFileName;
    UIAlertView*alertUpload;
    
    
    
}
- (IBAction)btnBack:(id)sender;
- (IBAction)btnDownlaod:(id)sender;
- (IBAction)btnSUBMIT:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnSubmit;
@property (strong, nonatomic) IBOutlet UIView *viewColour;
@property (strong, nonatomic) IBOutlet UILabel *txtDocumentName;

@end
