//
//  AcknowledgementViewController.h
//  nbng
//
//  Created by Rhythmus on 28/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AcknowledgementViewController : UIViewController{
    
    NSString*companyId;
    NSString*Tokenid;
    id acceptRejectData;
    NSString*ConfId ;
    NSString*personId;
    id controlConferernce ;
    id getConfDetail ;
    NSMutableArray *totalContacts;
    NSMutableArray*companyArray ;
    NSMutableArray*NameArray;
    NSMutableArray*ResponseArray ;
    
    NSMutableArray*cmpNm ;
    NSMutableArray*perSts ;
    NSMutableArray*name ;
    
    
}

@property (strong, nonatomic) IBOutlet UILabel *txtInviteValue;

@property (strong, nonatomic) IBOutlet UILabel *txtAccpetedValue;

@property (strong, nonatomic) IBOutlet UILabel *txtRejectedValue;

@property (strong, nonatomic) IBOutlet UILabel *txtPendingVlaue;

@property (strong, nonatomic) IBOutlet UILabel *labelPending;

@property (strong, nonatomic) IBOutlet UILabel *labelRejected;

@property (strong, nonatomic) IBOutlet UILabel *labelAccpted;

@property (strong, nonatomic) IBOutlet UILabel *labelInvite;

@property (strong, nonatomic) IBOutlet UIView *ViewInvite;
@property (strong, nonatomic) IBOutlet UIView *viewRejected;

@property (strong, nonatomic) IBOutlet UIView *viewPending;
@property (strong, nonatomic) IBOutlet UIView *viewAccepted;

- (IBAction)bckBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *acknowledgeTableView;

@end
