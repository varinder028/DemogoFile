//
//  CorporateSignupViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CorporateSignupViewController : UIViewController<UITextFieldDelegate>

{
    NSString *CmpString;
}


- (IBAction)bckclicked:(id)sender;


@property (strong, nonatomic) IBOutlet UIButton *radiobutton;
@property (strong, nonatomic) IBOutlet UILabel *agreeLabel;

@property (strong, nonatomic) IBOutlet UITextField *CompanyName;
@property (strong, nonatomic) IBOutlet UITextField *officialEmailId;
@property (strong, nonatomic) IBOutlet UITextField *OfficialContactNum;
@property (strong, nonatomic) IBOutlet UITextField *FirstName;
@property (strong, nonatomic) IBOutlet UITextField *Number;
@property (strong, nonatomic) IBOutlet UITextField *EmailID;
- (IBAction)AgreeCheckButton:(id)sender;
- (IBAction)SignUPButton:(id)sender;
@property (strong, nonatomic) NSString *MobileString;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *topLayout;

@end
