//
//  planSumaryViewController.m
//  excelSheetUpload
//
//  Created by Rhythmus on 29/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "planSumaryViewController.h"

#import "PieChart.h"


@interface planSumaryViewController ()<PieChartDelegate,PieChartDataSource,UITextFieldDelegate,DropDownViewDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate>
{
    NSString *strignmonth;
    NSString *Tokenstr;
    NSMutableArray *totalValueArray;
    
}
@property (strong, nonatomic) IBOutlet UIView *viewBackButtons;

@end

@implementation planSumaryViewController
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
//    [self.piechart reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"IncWidth"];
    
    [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"Plan"];
    
    Tokenstr = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    CompanyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
   
    UITapGestureRecognizer *gesRecognizer4 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gestureRecog)]; // Declare the Gesture.
    gesRecognizer4.delegate = self;
    [self.view addGestureRecognizer:gesRecognizer4];
    
    UIImageView *imgfo=[[UIImageView alloc] initWithFrame:CGRectMake(10, 0, 25, 25)]; // Set
    [imgfo setImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    [imgfo setContentMode:UIViewContentModeCenter];// Set content mode centre or fit
    _txtselectDepartmentOrHost.rightView=imgfo;
    _txtselectDepartmentOrHost.rightViewMode=UITextFieldViewModeAlways;
    
    
    UIImageView *imgfo1=[[UIImageView alloc] initWithFrame:CGRectMake(10, 0, 25, 25)]; // Set
    [imgfo1 setImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    [imgfo1 setContentMode:UIViewContentModeCenter];// Set content mode centre or fit
    _txtMonth.rightView=imgfo1;
    _txtMonth.rightViewMode=UITextFieldViewModeAlways;

    
    UIImageView *imgfo2=[[UIImageView alloc] initWithFrame:CGRectMake(10, 0, 25, 25)]; // Set
    [imgfo2 setImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    [imgfo2 setContentMode:UIViewContentModeCenter];// Set content mode centre or fit
    _txtYears.rightView=imgfo2;
    _txtYears.rightViewMode=UITextFieldViewModeAlways;

    

//    _txtselectDepartmentOrHost.rightViewMode = UITextFieldViewModeAlways;
//    _txtselectDepartmentOrHost.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
//    _txtMonth.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
//    
//    _txtYears.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
//    
//    [self.view bringSubviewToFront:_txtYears.rightView];
//    [self.view bringSubviewToFront:_txtMonth.rightView];
//    [self.view bringSubviewToFront:_txtselectDepartmentOrHost.rightView];
    

  
    allKeydata =[[NSMutableArray alloc]init];
   
     NSMutableArray *array = [[NSMutableArray alloc]init];
    dropDownListArray = [NSMutableArray new];
    totalValueArray  = [[NSMutableArray alloc]init];
   
    _txtMonth .text = @"jan";
    
    _txtYears.text = @"2017";

    monthsCount = [NSMutableArray new];
    
    
    
    SelctDpOrHostArray = [[NSMutableArray alloc]initWithObjects:@"Plan used by Department",@"Plan used by Host", nil];
    
    _txtselectDepartmentOrHost.text = @"Department";
    
    SelctMonthArray = [[NSMutableArray alloc]initWithObjects:@"Jan",@"Feb",@"Mar",@"Apr",@"May",@"Jun",@"Jul",@"Aug",@"Sep",@"Oct",@"Nov",@"Dec", nil];
    
    

    
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:[NSDate date]];
    int year = (int)[components year];
    int month = (int)[components month];
    
    NSLog(@"%d",month);
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    NSString *monthName = [[df monthSymbols] objectAtIndex:(month-1)];
    
    _txtMonth.text = [NSString stringWithFormat:@"%@",monthName];
    
    _txtYears.text = [NSString stringWithFormat:@"%d",year]; ;
    
    
    
    selectYearArray = [[NSMutableArray alloc]init];
    
    for (int i =0; i<=5; i++) {
        
        
        int yearr = year -i ;
        NSLog(@"%d",yearr);
        
        
        [selectYearArray addObject:[NSString stringWithFormat:@"%d",yearr]];
        
        
    }
    
    
   
    
    
    
    
  //  selectYearArray = [NSMutableArray arrayWithObjects:@"2017",@"2016",@"2015",@"2014",@"2013",@"2012", nil];
    
    _lablSelectValue.text = [NSString stringWithFormat:@"Plan used by %@ in %@ month",_txtselectDepartmentOrHost.text,_txtMonth.text];
    strignmonth = [NSString stringWithFormat:@"%d",month];
    

    
    
    [self pieChart];
    
    [self yearData];
    
    
    
    
    // Do any additional setup after loading the view.
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isDescendantOfView:dropDownView.view]) {
        
        // Don't let selections of auto-complete entries fire the
        // gesture recognizer
        // gesture recognizer
       
        return NO;
    }
    
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)yearData
{
   
   // NSString *CompanyId = @"1770";
    NSString *MonthYear = [NSString stringWithFormat:@"%@-%@",strignmonth,_txtYears.text];
    NSString *filter = _txtselectDepartmentOrHost.text;
    
    filter = [filter stringByReplacingOccurrencesOfString:@"Plan used by " withString:@""];
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/dashboard/secure/departmentplanusesbymonth?cmpId=%@&monthyear=%@&filter=%@",CompanyId,MonthYear,filter];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    NSURL*LinkUrl = [NSURL URLWithString:apiURLStr];
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:LinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    [SendingRequest addValue:Tokenstr forHTTPHeaderField:@"token"];
    
    
    [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    
    NSURLSessionDataTask *postData = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                      
                                      {
                                          dispatch_async(dispatch_get_main_queue(),^
                                                         {
                                                          
                                           NSError* error;
                                                             NSString *nilvalue;
                                                             if (data != nil) {
                                                                 
                                                             
                                              
                                              cities =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                                              NSLog(@"%@",cities);
                                                                 
                                                                 allValuedata = [[cities valueForKey:@"departmentuses"]allValues];
                                                                 
                                                                 allKeydata = [[cities valueForKey:@"departmentuses"]allKeys];
                                                               
                                                                 [chart reloadPieChart];
                                                                
//                                                                     UIAlertView *alertd = [[UIAlertView alloc]initWithTitle:@"Plan Graph" message:[NSString stringWithFormat:@"%@ is not take any plan",filter] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//                                                                        [alertd show];
                                                                
                                                                 
                                                                 

                                                             }
                                                             else{
                                                                 NSLog(@"error data");
                                                             }
                                                         });
 
                                          
                                      }];
    [postData resume];
}

    
    
    

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (textField == self.txtselectDepartmentOrHost)
    {
        
        [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"DropHome"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        self.dropDownTxtfield = textField ;
        
        [self SelectChoiceMethod];
        
    }
    
    else if(textField == self.txtYears)
        
    {
        
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
            self.dropDownTxtfield = textField ;
            
            
            [self YearMethod];
        }else
            
        {
            
            [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
            [[NSUserDefaults standardUserDefaults]synchronize];

            self.dropDownTxtfield = textField ;
            
            
            [self MonthMethod];
        }
    
    
    
    
    //
    return NO ;
    
}


-(void)SelectChoiceMethod
{
    if (dropDownView != nil) {
       
        [dropDownView.view removeFromSuperview];
       
        dropDownView = nil;
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:SelctDpOrHostArray cellHeight:40 heightTableView:80 paddingTop:self.viewBackButtons.frame.origin.y  paddingLeft:self.viewBackButtons.frame.origin.x paddingRight:self.viewBackButtons.frame.origin.y-20 refView:self.txtselectDepartmentOrHost animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    
    
}

-(void)YearMethod
{
    if (dropDownView != nil) {
      
        [dropDownView.view removeFromSuperview];
       
        dropDownView = nil;
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:selectYearArray cellHeight:40 heightTableView:210 paddingTop:self.viewBackButtons.frame.origin.y  paddingLeft:self.viewBackButtons.frame.origin.x paddingRight:0 refView:_txtYears animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    
    
}

-(void)MonthMethod{
    
    if (dropDownView != nil)
    
    {
      
        [dropDownView.view removeFromSuperview];
        
        dropDownView = nil;
        
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:SelctMonthArray cellHeight:40 heightTableView:280 paddingTop:self.viewBackButtons.frame.origin.y  paddingLeft:self.viewBackButtons.frame.origin.x paddingRight:0 refView:_txtMonth animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    
}

-(void)dropDownCellSelected:(NSInteger)returnIndex{
    
    allValuedata = [[NSMutableArray alloc]init];
    
  
    
    
    if (_dropDownTxtfield == self.txtselectDepartmentOrHost)
        
    {
        [dropDownView openAnimation];
        
        self.txtselectDepartmentOrHost.text = [SelctDpOrHostArray objectAtIndex:returnIndex];
//       //  _txtselectDepartmentOrHost.text = @"Department";
        
        if ([_txtselectDepartmentOrHost.text isEqualToString:@"Plan used by Department"])

        {
         
        _lablSelectValue.text = [NSString stringWithFormat:@"%@ in %@ month",_txtselectDepartmentOrHost.text,_txtMonth.text];
        
        _txtselectDepartmentOrHost.text = @"Department";
            
            [chart removeFromSuperview];
        
            [self pieChart];
            
        
            
        [self yearData];
            
        }else if ([_txtselectDepartmentOrHost.text isEqualToString:@"Plan used by Host"])
            
        {
            
            _lablSelectValue.text = [NSString stringWithFormat:@"%@ in %@ month",_txtselectDepartmentOrHost.text,_txtMonth.text];
            
            _txtselectDepartmentOrHost.text = @"Host";
            
            [chart removeFromSuperview];
            
            [self pieChart];

            [self yearData];
            
        }
        
        
    }
    
    else if(_dropDownTxtfield == self.txtYears)
        
    {
        [dropDownView openAnimation];
        
        self.txtYears.text = [selectYearArray objectAtIndex:returnIndex];
        
        [chart removeFromSuperview];
        
        [self pieChart];

        [self yearData];
        
    }
    
    else if(_dropDownTxtfield == self.txtMonth)
        
    {
        [dropDownView openAnimation];
        
               self.txtMonth.text = [SelctMonthArray objectAtIndex:returnIndex];
        
        _lablSelectValue.text = [NSString stringWithFormat:@"Plan used by %@ in %@ month",_txtselectDepartmentOrHost.text,_txtMonth.text];
        
        for (int i = 1; i<= [SelctMonthArray count] ; i++)
            
        {
            
          NSString *strMonth   = [NSString stringWithFormat:@"0%d",i];
            NSLog(@"%@",strMonth);
            
            
            [monthsCount addObject:strMonth];
            
            ///  [array addObject:[NSString stringWithFormat:@"%d",i]];
            
        }
        
         strignmonth= [monthsCount objectAtIndex:returnIndex];
        NSLog(@"%@",strignmonth);
        [chart removeFromSuperview];
        
        [self pieChart];

        [self yearData];

    }

    [dropDownView closeAnimation];
    
    }

- (void)pieChart{
    
    
    chart = [[PieChart alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, self.graphViews.frame.size.height/2+100)];
    [chart setDataSource:self];
    [chart setDelegate:self];

    [chart setShowLegend:true];
    [chart setLegendViewType:LegendTypeHorizontal];
    
    [chart setTextFontSize:12];
    [chart setTextColor:[UIColor blackColor]];
    [chart setTextFont:[UIFont systemFontOfSize:chart.textFontSize]];

    [chart setShowValueOnPieSlice:YES];
    [chart setShowCustomMarkerView:YES];
    
    [chart drawPieChart];
    
    [self.graphViews addSubview:chart];
    
    
}
- (NSInteger)numberOfValuesForPieChart{
    
    return [allValuedata count];
}

- (UIColor *)colorForValueInPieChartWithIndex:(NSInteger)lineNumber{
    NSInteger aRedValue = arc4random()%255;
    NSInteger aGreenValue = arc4random()%255;
    NSInteger aBlueValue = arc4random()%255;
    UIColor *randColor = [UIColor colorWithRed:aRedValue/255.0f green:aGreenValue/255.0f blue:aBlueValue/255.0f alpha:1.0f];
    return randColor;
}

- (NSString *)titleForValueInPieChartWithIndex:(NSInteger)index{
    
    return [allKeydata objectAtIndex:index];//[NSString stringWithFormat:@"%@",allKeydata];
}

- (NSNumber *)valueInPieChartWithIndex:(NSInteger)index{
    return [allValuedata objectAtIndex:index]; //[NSNumber numberWithLong:random() % 100];
}

- (UIView *)customViewForPieChartTouchWithValue:(NSNumber *)value{
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor:[UIColor whiteColor]];
    [view.layer setCornerRadius:4.0F];
    [view.layer setBorderWidth:1.0F];
    [view.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
    [view.layer setShadowColor:[[UIColor blackColor] CGColor]];
    [view.layer setShadowRadius:2.0F];
    [view.layer setShadowOpacity:0.3F];
    
    UILabel *label = [[UILabel alloc] init];
    [label setFont:[UIFont systemFontOfSize:12]];
    [label setTextAlignment:NSTextAlignmentCenter];
    //[label setTextColor:[UIColor whiteColor]];
    [label setText:[NSString stringWithFormat:@"PlanData : %@", value]];
    [label setFrame:CGRectMake(0, 0, 120, 30)];
    [view addSubview:label];
    
    [view setFrame:label.frame];
    return view;
}


- (IBAction)btnBAck:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)gestureRecog{
    
    [dropDownView closeAnimation];
    
    
}
@end
