//
//  smartMinutesCell.h
//  DemogoApplication
//
//  Created by katoch on 24/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface smartMinutesCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *txtPlanName;
@property (strong, nonatomic) IBOutlet UILabel *txtMRV;
@property (strong, nonatomic) IBOutlet UIImageView *imgIcon;
@property (strong, nonatomic) IBOutlet UIButton *btnSubscribe;
@property (strong, nonatomic) IBOutlet UILabel *lblCount;

@end
