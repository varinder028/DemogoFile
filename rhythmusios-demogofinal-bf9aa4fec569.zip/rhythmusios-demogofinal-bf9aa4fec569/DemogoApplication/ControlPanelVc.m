//
//  ControlPanelVc.m
//  DemogoApplication
//
//  Created by katoch on 25/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ControlPanelVc.h"
#import "AppDelegate.h"
#import "AcknowledgementViewController.h"
#import "LiveParticipantViewController.h"
#import "KVNProgress.h"
#import "HomeVC.h"
#import <AFNetworking/AFNetworking.h>
#import <AVFoundation/AVFoundation.h>
#import "QACell.h"
#import "ManageQACell.h"
@interface ControlPanelVc ()<UIGestureRecognizerDelegate, UITextFieldDelegate, AVAudioRecorderDelegate, AVAudioPlayerDelegate, UITextViewDelegate>
{
    AVAudioRecorder *recordered;
    AVAudioPlayer *player;
    int rec_time;
    NSTimer *myTimer;
    NSURL *outputFileURL;
    NSString *time;
    AppDelegate *delegate;
    UIVisualEffectView *visualEffectView;
    BOOL ChooseTxtField;
    
}

@end

@implementation ControlPanelVc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    ChooseTxtField = true;
    
    self.txtDetails.delegate = self;
   // [self.txtUrl addTarget:selfaction:@selector(TxtUrlAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.txtMobile.userInteractionEnabled = NO;
    
    self.listenView.hidden = YES;
    
    
    [self.searchBar setBackgroundImage:[[UIImage alloc]init]];
    _searchBar.delegate = self;
    [_adminQAView setHidden:YES];
    ifManage = true ;
    [_manageView setHidden:NO];
    [_unManageView setHidden:YES];

    self.btnManage.backgroundColor = [UIColor colorWithRed:26/255.0f green:51/255.0f blue:66/255.0f alpha:1];
    self.btnUnmanage.backgroundColor = [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:1];


    
    [self.textQAView setHidden:YES];
    [self.audioQAView setHidden:YES];
    [self.txtAudioSelectView setHidden:NO];
    [self.qaView setHidden:YES];
    self.qaView.backgroundColor = [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:0.8];
    
     ///////////////   audio RecoderPlayer View Radius  Corner   ////////////////////////
    
    
    _viewAudio.layer.cornerRadius = 10.5f; //_viewAudio.frame.size.height/2 ;
    
    
    
    ////////////                PlaceHolder Color White code
    
   NSAttributedString * str=[[NSAttributedString alloc]
         
         initWithString:@"Enter host/IP Address"
         
         attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    NSAttributedString * str2=[[NSAttributedString alloc]initWithString:@"Select File from local storage" attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.txtUrl.attributedPlaceholder=str;
    [self.txtUrl setFont:[UIFont systemFontOfSize:10]];
    
//    self.txtIp.attributedPlaceholder=str;
//    [self.txtIp setFont:[UIFont systemFontOfSize:10]];
    
    
    self.txtMobile.attributedPlaceholder=str2;
    [self.txtMobile setFont:[UIFont systemFontOfSize:10]];
    
    //////////////////////////////////////
    
    
    UITapGestureRecognizer * gestureBtn = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(GestureGoLiveView:)];
    
    gestureBtn.delegate = self;
     [self.goLiveView addGestureRecognizer:gestureBtn];
    
    UITapGestureRecognizer * gestureSelection = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(SelectTextVideo:)];
    gestureSelection.delegate = self;
    [self.qaView addGestureRecognizer:gestureSelection];
    
    
    
   
    
    self.subLiveView.layer.cornerRadius = 5.5;
    self.fileSelectionView.layer.cornerRadius = 5.5f;
    self.btnSubmit.layer.cornerRadius = 5.5f;
    self.SelectFileView.layer.cornerRadius=5.5f;
    
    self.goLiveView.hidden = YES;
    self.streamingView.hidden = YES;
    
    
     if ([UIScreen mainScreen].bounds.size.width == 320) {
         _panelHeightLayout.constant = 90;
         
         [self.view layoutIfNeeded];
         
         
     }else{
         _panelHeightLayout.constant = 100;
         
         [self.view layoutIfNeeded];
         
     }
    
     if ([UIScreen mainScreen].bounds.size.width == 768) {
         _bottomLayout.constant = 0 ;
          _panelHeightLayout.constant = 170;
         
         ////////  stramingView ControllPPanel2 Button Outlet /// first Font & Title Set
         [self.btnAcknowledement2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnActiveParticipent2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnSelfmute2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnParticipantMute2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnRecord2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnAddon2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnDialme2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnQA2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnGolive2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnPolling2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnEndcall2 setFont:[UIFont systemFontOfSize:12]];
         
          /////////  Title Set
         
         [self.btnAcknowledement2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-172, -60, -12)];
         [self.btnActiveParticipent2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-190, -60, -25)];
         [self.btnSelfmute2 setTitleEdgeInsets:UIEdgeInsetsMake(75,-153, -60, 12)];
         [self.btnParticipantMute2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-175, -60, -12)];
         [self.btnRecord2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-153, -60, 12)];
         [self.btnAddon2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-153, -60, 12)];
         [self.btnDialme2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-153, -60, 12)];
         [self.btnQA2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-153, -60, 12)];
         [self.btnGolive2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-153, -60, 12)];
         [self.btnPolling2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-153, -60, 12)];
         [self.btnEndcall2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-153, -60, 12)];
         

         
         
         
         [self.btnAcknowledgement  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 40)];
         [self.btnGoLive  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 40)];
         [self.btnQA  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 40)];
         [self.btnPolling  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 40)];
         [self.btnAddOn  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 40)];
         [self.btnParticipants  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 40)];
         [self.btnDialMe  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 40)];
         [self.btnRecord  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 40)];
         [self.btnSelfMute  setTitleEdgeInsets:UIEdgeInsetsMake(0,-130, -150, 40)];
         [self.btnEndConfernce  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 40)];
         [self.btnParticipantMute  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 40)];
         [self.btnAcknowledgement  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];
         [self.btnAddOn  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];
         [self.btnParticipants  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];
         [self.btnDialMe  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];
         [self.btnRecord  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];
         [self.btnSelfMute  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];
         [self.btnEndConfernce  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];
         [self.btnParticipantMute  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];
          [self.btnPolling  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];
          [self.btnGoLive  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];
          [self.btnQA  setImageEdgeInsets:UIEdgeInsetsMake(0, 5, -10, 5)];

         
         
     }else if ([UIScreen mainScreen].bounds.size.width == 1024 ) {
         _bottomLayout.constant = 0 ; //135 ;
         _panelHeightLayout.constant = 170;
         
         
         ////////  stramingView ControllPPanel2 Button Outlet /// first Font & Title Set
         [self.btnAcknowledement2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnActiveParticipent2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnSelfmute2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnParticipantMute2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnRecord2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnAddon2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnDialme2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnQA2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnGolive2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnPolling2 setFont:[UIFont systemFontOfSize:12]];
         [self.btnEndcall2 setFont:[UIFont systemFontOfSize:12]];
         
         /////////  Title Set
         
         [self.btnAcknowledement2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-240, -70, -12)];
         [self.btnActiveParticipent2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-240, -70, -25)];
         [self.btnSelfmute2 setTitleEdgeInsets:UIEdgeInsetsMake(75,-190, -70, 12)];
         [self.btnParticipantMute2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-240, -70, -12)];
         [self.btnRecord2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-190, -70, 12)];
         [self.btnAddon2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-190, -70, 12)];
         [self.btnDialme2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-190, -70, 12)];
         [self.btnQA2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-190, -70, 12)];
         [self.btnGolive2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-190, -70, 12)];
         [self.btnPolling2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-190, -70, 12)];
         [self.btnEndcall2  setTitleEdgeInsets:UIEdgeInsetsMake(75,-190, -70, 12)];
         
         
         
         
         
         
         [self.btnAcknowledgement  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 90)];
         [self.btnAddOn  setTitleEdgeInsets:UIEdgeInsetsMake(0,-100, -150, 90)];
         [self.btnParticipants  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 90)];
         [self.btnDialMe  setTitleEdgeInsets:UIEdgeInsetsMake(0,-100, -150, 90)];
         [self.btnRecord  setTitleEdgeInsets:UIEdgeInsetsMake(0,-100, -150, 90)];
         [self.btnSelfMute  setTitleEdgeInsets:UIEdgeInsetsMake(0,-100, -150, 90)];
         [self.btnEndConfernce  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 90)];
         [self.btnParticipantMute  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 90)];
         
          [self.btnGoLive  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 90)];
          [self.btnPolling  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 90)];
          [self.btnQA  setTitleEdgeInsets:UIEdgeInsetsMake(0,-120, -150, 90)];
         
     }
     else{
         
         _bottomLayout.constant = 0; //55 ;
   
     }
    
    pmobile = [[NSUserDefaults standardUserDefaults]valueForKey:@"pmobile"];
    _btnDone.layer.cornerRadius = 5.0f ;
    [_btnDone clipsToBounds];
    _txtView.layer.cornerRadius = 5.0f ;
    [_txtView clipsToBounds];
    
    
    pmobile = [[NSUserDefaults standardUserDefaults]valueForKey:@"pmobile"];
    
    
    role = [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
    
    
    tapper = [[UITapGestureRecognizer alloc]
              initWithTarget:self action:@selector(handleSingleTap:)];
    tapper.cancelsTouchesInView = NO;
    [self.openParticipantView addGestureRecognizer:tapper];
    [self.openParticipantView setHidden:YES];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    ConfId = [[NSUserDefaults standardUserDefaults]valueForKey:@"ConfId"];
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    NSLog(@"%@",Tokenid);

    
    
    
    /////////////////////      Recording Programming
    
    
    [_btnQAEndRecord setEnabled:NO];
    [_btnListen setEnabled:NO];
    
    // Set the audio file
    NSArray *pathComponents = [NSArray arrayWithObjects:
                               [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject],
                               @"MyAudioMemo.m4a",
                               nil];
    outputFileURL = [NSURL fileURLWithPathComponents:pathComponents];
    
    // Setup audio session
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    
    // Define the recordered setting
    NSMutableDictionary *recordSetting = [[NSMutableDictionary alloc] init];
    
    [recordSetting setValue:[NSNumber numberWithInt:kAudioFormatMPEG4AAC] forKey:AVFormatIDKey];
    [recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey];
    [recordSetting setValue:[NSNumber numberWithInt: 2] forKey:AVNumberOfChannelsKey];
    
    // Initiate and prepare the recordered
    recordered = [[AVAudioRecorder alloc] initWithURL:outputFileURL settings:recordSetting error:NULL];
    recordered.delegate = self;
    recordered.meteringEnabled = YES;
    [recordered prepareToRecord];
    
    NSError *playerError;
    
    player = [[AVAudioPlayer alloc] initWithContentsOfURL:outputFileURL error:&playerError];
    
    NSLog(@"%f",player.duration);
    
    
    self.listenSliderBar.minimumValue = 0;
    self.listenSliderBar.maximumValue = player.duration;
    
    [self.listenSliderBar setThumbImage:[[UIImage alloc]init] forState:UIControlStateNormal];
    
    
   
    // Do any additional setup after loading the view.
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField;
{
    [self.view endEditing:YES];
    return NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)aTime{
    
  
    if (isSessionNil) {
        return ;
    }else{
        
        [self   GetControlConferenceDetailsconference];
        
    }

    
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
   isSessionNil = NO;
    aTimer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(aTime) userInfo:nil repeats:YES];
    delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView removeFromSuperview];
    
    NSArray *myNibsArray = [[NSBundle mainBundle] loadNibNamed:@"Tab" owner:self options:nil];
    delegate.tabView = [myNibsArray objectAtIndex:0];
    
    if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 90, self.view.frame.size.width, 90);
        
    }else if ([UIScreen mainScreen].bounds.size.width == 1024) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 130, self.view.frame.size.width, 130);
        
    }else{

    delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height-delegate.tabView.frame.size.height, self.view.frame.size.width, delegate.tabView.frame.size.height);
        
    }
    [delegate.tabView.btnToday setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnSchedule setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnControlPanel setBackgroundColor: [UIColor colorWithRed:0/255.0f green:32/255.0f blue:41/255.0f alpha:1]];
    
    [delegate.tabView.btnDashboard setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnMenu setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    [self.view addSubview:delegate.tabView];

    RoleStr =   [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
    NSLog(@"%@",RoleStr);
    
    if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
        
        
        if ([UIScreen mainScreen].bounds.size.width == 768){
            delegate.tabView.btnScheduleWidth.constant = -200 ;
             delegate.tabView.btnSchedule.hidden = YES;
            
        }else if ([UIScreen mainScreen].bounds.size.width == 1024) {
            delegate.tabView.btnScheduleWidth.constant = -270 ;
            delegate.tabView.btnSchedule.hidden = YES;
            
        }else{
        delegate.tabView.btnScheduleWidth.constant = -77 ;
        }
        
        [delegate.tabView.btnSchedule setImage:nil forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setTitle:nil forState:UIControlStateNormal];
        
        
    }else{
        delegate.tabView.btnScheduleWidth.constant = 0 ;
        [delegate.tabView.btnSchedule setImage:[UIImage imageNamed:@"schedule-call.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setTitle:@"Schedule Meeting" forState:UIControlStateNormal];
        
    }

    [self insets];

  NSString* ConfIdd = [[NSUserDefaults standardUserDefaults]valueForKey:@"ConfId"];
    NSLog(@"%@",ConfIdd);
    
    
    
   


    if ([role isEqualToString:@"ROLE_SUPER_ADMIN"]) {
        if (ConfId == nil) {
            self.btnAcknowledgement.enabled = NO ;
            self.btnAddOn.enabled = NO ;
            self.btnDialMe.enabled = NO ;
            self.btnRecord.enabled = NO ;
            self.btnSelfMute.enabled = NO ;
            self.btnEndConfernce.enabled = NO ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            self.txtNoConference.hidden = NO;
            
            
        }else{
            
            self.btnAcknowledgement.enabled = YES;
            self.btnAddOn.enabled = NO ;
            self.btnDialMe.enabled = NO ;
            self.btnRecord.enabled = NO ;
            self.btnSelfMute.enabled = NO ;
            self.btnEndConfernce.enabled = NO ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            
            self.txtNoConference.hidden = YES;
        }
    }else if ([role isEqualToString:@"ROLE_HOST"]){
        if (ConfId == nil) {
            self.btnAcknowledgement.enabled = NO ;
            self.btnAddOn.enabled = NO ;
            self.btnDialMe.enabled = NO ;
            self.btnRecord.enabled = NO ;
            self.btnSelfMute.enabled = NO ;
            self.btnEndConfernce.enabled = NO ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            self.txtNoConference.hidden = NO;
            
        }else{
            
            self.btnAcknowledgement.enabled = YES;
            self.btnAddOn.enabled = NO ;
            self.btnDialMe.enabled = NO ;
            self.btnRecord.enabled = NO ;
            self.btnSelfMute.enabled = NO ;
            self.btnEndConfernce.enabled = NO ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            self.txtNoConference.hidden = YES;
            
        }
        
    }else{
        
        if (ConfId == nil) {
            self.btnAcknowledgement.enabled = NO ;
            self.btnAddOn.enabled = NO ;
            self.btnDialMe.enabled = NO ;
            self.btnRecord.enabled = NO ;
            self.btnSelfMute.enabled = NO ;
            self.btnEndConfernce.enabled = NO ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            self.txtNoConference.hidden = NO;
            
        }else{
            
            self.btnAcknowledgement.enabled = YES;
            self.btnAddOn.enabled = NO ;
            self.btnDialMe.enabled = NO ;
            self.btnRecord.enabled = NO ;
            self.btnSelfMute.enabled = NO ;
            self.btnEndConfernce.enabled = NO ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            self.txtNoConference.hidden = YES;
    }
    
    }
    
    
    
    
     [self GetControlConferenceDetailsconference];
    

  

    
}



- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [sessionControltask  cancel];
    sessionControlConf= nil;
    managerAf = nil;
    isSessionNil = YES;
    [aTimer invalidate];
    aTimer = nil ;
    
    if ([status isEqualToString:@"End"] && [Endstatus isEqualToString:@"1"]) {
        
        
        [[NSUserDefaults standardUserDefaults]setValue:nil forKey:@"ConfId"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
    }
    
    
}


- (IBAction)participantsClicked:(id)sender {
    [sessionControltask  cancel];
    sessionControlConf= nil;
    isSessionNil = YES;
     managerAf = nil;
    
    
    
    LiveParticipantViewController *ackVc = [[ LiveParticipantViewController alloc]init];
    ackVc = [self.storyboard instantiateViewControllerWithIdentifier:@"LiveParticipantViewController"];
    
    [self.navigationController pushViewController:ackVc animated:YES];

}

- (IBAction)acknowledgementClicked:(id)sender {
    
      [sessionControltask  cancel];
    sessionControlConf= nil;
    isSessionNil = YES;
 managerAf = nil;
    
   
    AcknowledgementViewController *ackVc = [[ AcknowledgementViewController alloc]init];
    ackVc = [self.storyboard instantiateViewControllerWithIdentifier:@"AcknowledgementViewController"];
    
    [self.navigationController pushViewController:ackVc animated:YES];
    
    
}

- (IBAction)muteClicked:(id)sender {
       [sessionControltask  cancel];
    sessionControlConf= nil;
    isSessionNil = YES;
 managerAf = nil;
  
    
    if (!_btnSelfMute.isSelected) {
        
        [self ConfSelfMute];
        
        
        
    }else{
        [self ConfSelfUnMute];
      
    }
   
    
    
}

- (IBAction)participantMuteClicked:(id)sender {
    
    [sessionControltask  cancel];
    sessionControlConf= nil;
    isSessionNil = YES;
 managerAf = nil;

    
    
    if (!_btnParticipantMute.isSelected) {
        
        [_btnParticipantMute setSelected:YES];
        
        [self.btnSelfMute setEnabled:NO];
        
         [self ConfAllMute];
        
        
        
    }else{
        [_btnParticipantMute setSelected:NO];
         [self ConfAllUNMute];
         [self.btnSelfMute setEnabled:YES];
    }
   
    
}

- (IBAction)recordClicked:(id)sender {
    [sessionControltask  cancel];
    sessionControlConf= nil;
    isSessionNil = YES;
     managerAf = nil;

    
    
    if (!_btnRecord.isSelected ) {
        [KVNProgress show];
        
        [self ConfRecordApi];
        
    }else{
        
        RecordingAlert = [[UIAlertView alloc]initWithTitle:@"Are you sure want to stop recording?" message:@"You will not be able to start the recording again for this meeting" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
       
        
        [RecordingAlert show];
        
        
        
        
    }
    
    
}

- (IBAction)addOnclicked:(id)sender {
  
        
//    [sessionControltask  cancel];
//    sessionControlConf= nil;
//    isSessionNil = YES;
    
    _txtView.text = @"";
    
    [self.openParticipantView setHidden:NO];
    [self.view bringSubviewToFront:self.openParticipantView];
    
    
}

- (IBAction)dialMeClicked:(id)sender {
  
        
    [sessionControltask  cancel];
    sessionControlConf= nil;
    isSessionNil = YES;
     managerAf = nil;
    
    [self dialMeParticipant];
    

   
}

- (IBAction)endConferanceClicked:(id)sender {
    
    endConfalert= [[UIAlertView alloc]initWithTitle:nil message:@"Do you want to end the conference" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
    
    [endConfalert show];
    
    
    
}

-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}

-(void)GetControlConferenceDetailsconference{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/getControlConferenceDetails?confId=%@&personId=%@",ConfId,personId];


    managerAf = [AFHTTPSessionManager manager];
    managerAf.requestSerializer = [AFJSONRequestSerializer serializer];
    [managerAf.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [managerAf GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        controlConferernce = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(controlConferceData) withObject:nil waitUntilDone:YES];
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        [_btnParticipants setEnabled:NO];
        self.btnAddOn.enabled = NO ;
        
          
        
        self.btnAcknowledgement.enabled = NO;
        self.txtNoConference.hidden = NO;

        self.btnRecord.enabled = NO ;
        self.btnSelfMute.enabled = NO ;
        self.btnEndConfernce.enabled = NO ;
        self.btnParticipants.enabled = NO ;
        self.btnParticipantMute.enabled = NO ;

        NSLog(@"Error: %@", error);
        
    }];

    

    
}

-(void)controlConferceData{
    
    status = [[controlConferernce valueForKey:@"controlres"]valueForKey:@"confStatus"];
    NSLog(@"%@",status);
   Endstatus = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"end"]];
    NSLog(@"%@",Endstatus);

    
    NSString *confDialType =   [[[controlConferernce valueForKey:@"confData"] objectAtIndex:0] valueForKey:@"confDialType"];
    NSLog(@"%@",confDialType);
    
     NSString *duration =   [[[controlConferernce valueForKey:@"confData"] objectAtIndex:0] valueForKey:@"duration"];
    int dur = [duration intValue];
    
    
    hostId =   [[[controlConferernce valueForKey:@"confData"] objectAtIndex:0] valueForKey:@"hostId"];
    
    NSTimeInterval secondsInEightHours = dur * 60 ;
    //NSDate *endOffdate = [Ofdate dateByAddingTimeInterval:secondsInEightHours];

    
    
    
    dialMe = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"selfactive"]];
    
    [[NSUserDefaults standardUserDefaults]setValue:confDialType forKey:@"confDialType"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    allParticipantsMute = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"allparticipantmute"]];
    NSLog(@"%@",allParticipantsMute);
    
    end = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"end"]];
    NSLog(@"%@",end);
    
    liverecording = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"liverecording"]];
    NSLog(@"%@",liverecording);
    
  
    
    selfmute = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"selfmute"]];
    NSLog(@"%@",selfmute);

    
    
    
    
    if ([role isEqualToString:@"ROLE_SUPER_ADMIN"]){
    if ([status isEqualToString:@"Running"]) {
        
        
        double host = [hostId doubleValue];
        double person = [personId doubleValue];
        
        
        if ( host != person) {
            if ([selfmute isEqualToString:@"0"]) {
                
                self.btnSelfMute.enabled = YES ;
                
                [self.btnSelfMute setSelected:NO] ;
                
                
            }
            else if ([selfmute isEqualToString:@"2"]) {
                
                self.btnSelfMute.enabled = NO ;
                
            }
            else{
                
                //        [_btnSelfMute setEnabled: NO];
                [self.btnSelfMute setSelected:YES];
                self.btnSelfMute.enabled = YES ;
                
            }

            
            if ([dialMe isEqualToString:@"0"]) {
                
                
                [_btnDialMe setEnabled: YES];
                
            }
            else{
                
                [_btnDialMe setEnabled: NO];
            }
            
            self.btnEndConfernce.enabled = YES ;
            
            self.btnRecord.enabled = NO ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            self.btnAcknowledgement.enabled = NO ;
        }else{
        
        [_btnParticipants setEnabled:YES];
        self.btnAddOn.enabled = YES ;
        self.btnDialMe.enabled = YES ;
        self.btnRecord.enabled = YES ;
        if (_btnParticipantMute.isSelected) {
            
             self.btnSelfMute.enabled = YES ;
        }else{
            
            self.btnSelfMute.enabled = NO ;
        }
        
       
        self.btnEndConfernce.enabled = YES ;
        self.btnParticipants.enabled = YES ;
        self.btnParticipantMute.enabled = YES ;
        
         self.txtNoConference.hidden = YES;
        
        [self synchonizing];
        }
        
    }
    else{
        
        double host = [hostId doubleValue];
        double person = [personId doubleValue];
        

        if ( host != person) {
            self.btnSelfMute.enabled = NO ;
            
            _btnAddOn.enabled = NO;
            [_btnDialMe setEnabled: NO];
            
            self.btnEndConfernce.enabled = NO ;
            
            self.btnRecord.enabled = NO ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            self.btnAcknowledgement.enabled = NO ;
            
            
        }else{
        
        [_btnParticipants setEnabled:NO];
        self.btnAddOn.enabled = NO ;
        if ([status isEqualToString:@"End"]) {
        
            self.btnAddOn.enabled = NO ;
            
            if ([Endstatus isEqualToString:@"0"]) {
                self.btnDialMe.enabled = YES ;
                self.btnAcknowledgement.enabled = YES;
                 self.txtNoConference.hidden = YES;

            }else{
                
                self.btnDialMe.enabled = NO ;
                 self.btnAcknowledgement.enabled = NO;
                 self.txtNoConference.hidden = NO;
            }
            
        }
        
        self.btnRecord.enabled = NO ;
        self.btnSelfMute.enabled = NO ;
        self.btnEndConfernce.enabled = NO ;
        self.btnParticipants.enabled = NO ;
        self.btnParticipantMute.enabled = NO ;
            
        }
    }
    }else if ([role isEqualToString:@"ROLE_HOST"]){
        if ([status isEqualToString:@"Running"]) {
            
            double host = [hostId doubleValue];
        double person = [personId doubleValue];
            
            
            if ( host != person) {
//                self.btnSelfMute.enabled = YES ;
                
                if ([selfmute isEqualToString:@"0"]) {
                    
                    self.btnSelfMute.enabled = YES ;
                    
                    [self.btnSelfMute setSelected:NO] ;
                    
                    
                }
                else if ([selfmute isEqualToString:@"2"]) {
                    
                    self.btnSelfMute.enabled = NO ;
                    
                }
                else{
                    
                    //        [_btnSelfMute setEnabled: NO];
                    [self.btnSelfMute setSelected:YES];
                    self.btnSelfMute.enabled = YES ;
                    
                }

                
                if ([dialMe isEqualToString:@"0"]) {
                    
                    
                    [_btnDialMe setEnabled: YES];
                    
                }
                else{
                    
                    [_btnDialMe setEnabled: NO];
                }
                
                self.btnEndConfernce.enabled = YES ;
                
                self.btnRecord.enabled = NO ;
                self.btnParticipants.enabled = NO ;
                self.btnParticipantMute.enabled = NO ;
                self.btnAcknowledgement.enabled = NO ;
                
                
            }
            else{
            
            [_btnParticipants setEnabled:YES];
            self.btnAddOn.enabled = YES ;
            self.btnDialMe.enabled = YES ;
            self.btnRecord.enabled = YES ;
            if (_btnParticipantMute.isSelected) {
                
                self.btnSelfMute.enabled = YES ;
            }else{
                
                self.btnSelfMute.enabled = NO ;
            }
           // self.btnSelfMute.enabled = YES ;
            self.btnEndConfernce.enabled = YES ;
            self.btnParticipants.enabled = YES ;
            self.btnParticipantMute.enabled = YES ;
            
            [self synchonizing];
            
            }
        }
        else{
            
            double host = [hostId doubleValue];
            double person = [personId doubleValue];
            
            
            if ( host != person) {
                self.btnSelfMute.enabled = NO ;
                
                _btnAddOn.enabled = NO;
                [_btnDialMe setEnabled: NO];

                self.btnEndConfernce.enabled = NO ;
                
                self.btnRecord.enabled = NO ;
                self.btnParticipants.enabled = NO ;
                self.btnParticipantMute.enabled = NO ;
                self.btnAcknowledgement.enabled = NO ;
                
                
            }else{

            
            [_btnParticipants setEnabled:NO];
            self.btnAddOn.enabled = NO ;
            if ([status isEqualToString:@"End"]) {
                
                self.btnAddOn.enabled = NO ;
                
                if ([Endstatus isEqualToString:@"0"]) {
                    self.btnDialMe.enabled = YES ;
                    self.btnAcknowledgement.enabled = YES;
                     self.txtNoConference.hidden = YES;

                }else{
                    
                    self.btnDialMe.enabled = NO ;
                    self.btnAcknowledgement.enabled = NO;
                     self.txtNoConference.hidden = NO;
                }
                
            }

            
            self.btnRecord.enabled = NO ;
            self.btnSelfMute.enabled = NO ;
            self.btnEndConfernce.enabled = NO ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            
            
            }
        }
    }
    
    else{
        if ([status isEqualToString:@"Running"]) {
            
            double host = [hostId doubleValue];
            double person = [personId doubleValue];
            
            
            if ( host != person) {
                if ([selfmute isEqualToString:@"0"]) {
                    
                    self.btnSelfMute.enabled = YES ;
                    
                    [self.btnSelfMute setSelected:NO] ;
                    
                    
                }
                else if ([selfmute isEqualToString:@"2"]) {
                    
                    self.btnSelfMute.enabled = NO ;
                    
                }
                else{
                    
                    //        [_btnSelfMute setEnabled: NO];
                    [self.btnSelfMute setSelected:YES];
                    self.btnSelfMute.enabled = YES ;
                    
                }

                
               // self.btnSelfMute.enabled = YES ;
                
                if ([dialMe isEqualToString:@"0"]) {
                    
                    
                    [_btnDialMe setEnabled: YES];
                    
                }
                else{
                    
                    [_btnDialMe setEnabled: NO];
                }
                
                self.btnEndConfernce.enabled = YES ;
                
                self.btnRecord.enabled = NO ;
                self.btnParticipants.enabled = NO ;
                self.btnParticipantMute.enabled = NO ;
                self.btnAcknowledgement.enabled = NO ;
                
                
            }
            else{

            
            
            [_btnParticipants setEnabled:YES];
            self.btnAddOn.enabled = NO ;
            self.btnDialMe.enabled = NO ;
            self.btnRecord.enabled = NO ;
            if (_btnParticipantMute.isSelected) {
                
                self.btnSelfMute.enabled = YES ;
            }else{
                
                self.btnSelfMute.enabled = NO ;
            }
          //  self.btnSelfMute.enabled = YES ;
            self.btnEndConfernce.enabled = YES ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            
            NSString *dialMe = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"selfactive"]];
            NSLog(@"%@",confDialType);
            
            if ([dialMe isEqualToString:@"0"]) {
                
                
                [_btnDialMe setEnabled: YES];
                
            }
            else{
                
                [_btnDialMe setEnabled: NO];
            }
            
            
            [self synchonizing];
            
            }

        }
        else{
            double host = [hostId doubleValue];
            double person = [personId doubleValue];
            
            if ( host != person) {
                self.btnSelfMute.enabled = NO ;
                
                _btnAddOn.enabled = NO;
                [_btnDialMe setEnabled: NO];
                
                self.btnEndConfernce.enabled = NO ;
                
                self.btnRecord.enabled = NO ;
                self.btnParticipants.enabled = NO ;
                self.btnParticipantMute.enabled = NO ;
                self.btnAcknowledgement.enabled = NO ;
                
                
            }else{

            
            [_btnParticipants setEnabled:NO];
            self.btnAddOn.enabled = NO ;
            if ([status isEqualToString:@"End"]) {
                
                self.btnAddOn.enabled = NO ;
                
                if ([Endstatus isEqualToString:@"0"]) {
                    self.btnDialMe.enabled = YES ;
                    self.btnAcknowledgement.enabled = YES;
                     self.txtNoConference.hidden = YES;

                }else{
                    
                    self.btnDialMe.enabled = NO ;
                    self.btnAcknowledgement.enabled = NO;
                     self.txtNoConference.hidden = NO;
                }
                
            }

          
            self.btnRecord.enabled = NO ;
            self.btnSelfMute.enabled = NO ;
            self.btnEndConfernce.enabled = NO ;
            self.btnParticipants.enabled = NO ;
            self.btnParticipantMute.enabled = NO ;
            
            NSString *dialMe = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"selfactive"]];
            NSLog(@"%@",confDialType);
            
            
            
            }
            
        }
        
    }
    
    
   
    if ([status isEqualToString:@"End"]) {
        
        
        self.btnAddOn.enabled = NO ;
        if ([status isEqualToString:@"End"]) {
            
            self.btnAddOn.enabled = NO ;
            
            if ([Endstatus isEqualToString:@"0"]) {
                self.btnDialMe.enabled = YES ;
                self.btnAcknowledgement.enabled = YES;
                 self.txtNoConference.hidden = YES;

            }else{
                
                self.btnDialMe.enabled = NO ;
                self.btnAcknowledgement.enabled = NO;
                 self.txtNoConference.hidden = NO;
            }
            
        }

        
        self.btnRecord.enabled = NO ;
        self.btnSelfMute.enabled = NO ;
        self.btnEndConfernce.enabled = NO ;
        self.btnParticipants.enabled = NO ;
        self.btnParticipantMute.enabled = NO ;
       // self.btnAcknowledgement.enabled = NO;
        

    }
    
    if ([status isEqualToString:@"End"] && [Endstatus isEqualToString:@"1"]) {
        
        
        [[NSUserDefaults standardUserDefaults]setValue:nil forKey:@"ConfId"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
    }
    
    
}


-(void)synchonizing{
    
    
    if ([dialMe isEqualToString:@"0"]) {
        
        
        [_btnDialMe setEnabled: YES];
        
    }
    else{
        
        [_btnDialMe setEnabled: NO];
    }
    
    
    
    if ([selfmute isEqualToString:@"0"]) {
        
        self.btnSelfMute.enabled = YES ;
        
      [self.btnSelfMute setSelected:NO] ;
        
        
    }
    else if ([selfmute isEqualToString:@"2"]) {
        
        self.btnSelfMute.enabled = NO ;
        
    }
     else{
        
//        [_btnSelfMute setEnabled: NO];
        [self.btnSelfMute setSelected:YES];
 self.btnSelfMute.enabled = YES ;
        
    }
    
    
    if ([liverecording isEqualToString:@"0"]) {
        
      //  self.btnRecord.enabled = YES ;
        [self.btnRecord setSelected:NO] ;
        
        
        
    }else if ([selfmute isEqualToString:@"2"]) {
        
        self.btnSelfMute.enabled = NO ;
      //  self.btnRecord.enabled = NO ;

        
    }else{
        
      //  self.btnRecord.enabled = YES ;

       [self.btnRecord setSelected:YES] ;
        
    }
    
    
    if ([end isEqualToString:@"0"]) {
        
       [self.btnEndConfernce setSelected:NO] ;
        
        
        
    }else{
        
        [self.btnEndConfernce setSelected:YES];
    }
    
    
    if ([status isEqualToString:@"End"]) {
        
        
        
        
        self.btnAddOn.enabled = NO ;
        
        if ([Endstatus isEqualToString:@"0"]) {
            self.btnDialMe.enabled = YES ;
            self.btnAcknowledgement.enabled = YES;
             self.txtNoConference.hidden = YES;
            
            
        }else{
            
            self.btnDialMe.enabled = NO ;
            self.btnAcknowledgement.enabled = NO;
             self.txtNoConference.hidden = NO;
        }
        
        self.btnRecord.enabled = NO ;
        self.btnSelfMute.enabled = NO ;
        self.btnEndConfernce.enabled = NO ;
        self.btnParticipants.enabled = NO ;
        self.btnParticipantMute.enabled = NO ;
        self.btnAcknowledgement.enabled = NO;
        

        
    }
    if (_btnParticipantMute.isSelected) {
        
        
        
        [self.btnSelfMute setEnabled:NO];
        
        
        
    }else{
        [self.btnSelfMute setEnabled:YES];
    }
    
    
    if ([allParticipantsMute isEqualToString:@"1"]) {
        
        [self.btnParticipantMute setSelected:YES] ;
        
        
        
        
    }else{
        
         [self.btnParticipantMute setSelected:NO] ;
        
      
        
    }

}
////////////////////////////////////////// End Conference ////////////////////////////////////


-(void)ConfDRopApi{
    
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confdrop?confId=%@",ConfId];
  
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        confDrop = responseObject ;
        [self performSelectorOnMainThread:@selector(DropConf) withObject:nil waitUntilDone:YES];
        
        
        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    

}


-(void)DropConf{
    
    if ([[confDrop valueForKey:@"message"]isEqualToString:@"success"]) {
        
        [_btnEndConfernce setSelected:YES];
       
        
    }else{
        
    }
    
    isSessionNil = NO ;
    [self GetControlConferenceDetailsconference];
    
}

///////////////////////////////// Conference Recording/Unrecording //////////////////////////////

-(void)ConfRecordApi{
    
//    NSDictionary *headers = @{ @"token": Tokenid,
//                               @"cache-control": @"no-cache",
//                               @"postman-token": @"d35daf96-e707-9136-1eac-340a8d628055" };
   NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confrecord?confId=%@&status=RecordStart",ConfId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        confRecord = responseObject ;
        [self performSelectorOnMainThread:@selector(RecordingResult) withObject:nil waitUntilDone:YES];
        
        
        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    


    

}

-(void)RecordingResult{
    if ([[confRecord valueForKey:@"message"]isEqualToString:@"success"]) {
        
        [_btnRecord setSelected:YES];
        
        
       
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[confRecord valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetControlConferenceDetailsconference];
    
    
}

-(void)ConfRecordStopApi{
//    NSDictionary *headers = @{ @"token": Tokenid,
//                               @"cache-control": @"no-cache",
//                               @"postman-token": @"d35daf96-e707-9136-1eac-340a8d628055" };
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confrecord?confId=%@&status=recordstop",ConfId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        confRecordStop = responseObject ;
       
        
        isSessionNil = NO ;
        
            [self GetControlConferenceDetailsconference];

        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    
    

    
    
}

-(void)RecordingStopResult{
    if ([[confRecordStop valueForKey:@"message"]isEqualToString:@"success"]) {
        
        [_btnRecord setSelected:NO];
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[confRecordStop valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetControlConferenceDetailsconference];
    
    
}


//////////////////////////////////////   SELF MUTE/ UN-MUTE ///////////////////////////////////////


-(void)ConfSelfMute{
    
    
    
    
//    NSDictionary *headers = @{ @"token": Tokenid,
//                               @"cache-control": @"no-cache",
//                               @"postman-token": @"d35daf96-e707-9136-1eac-340a8d628055" };
     NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confselfmute?confId=%@&personId=%@&status=mute",ConfId,personId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        confSelfMute = responseObject ;
        [self performSelectorOnMainThread:@selector(selfMuteResult) withObject:nil waitUntilDone:YES];
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];


}

-(void)selfMuteResult{
    
    if ([[confSelfMute valueForKey:@"message"]isEqualToString:@"success"]) {
        
        [_btnSelfMute setSelected:YES];
       
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[confSelfMute valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetControlConferenceDetailsconference];
    
    
}

-(void)ConfSelfUnMute{
    
//    NSDictionary *headers = @{ @"token": Tokenid,
//                               @"cache-control": @"no-cache",
//                               @"postman-token": @"d35daf96-e707-9136-1eac-340a8d628055" };
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confselfmute?confId=%@&personId=%@&status=un-mute",ConfId,personId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        confSelfunMute = responseObject ;
        [self performSelectorOnMainThread:@selector(selfUnMuteResult) withObject:nil waitUntilDone:YES];
        
    }
          failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

}
-(void)selfUnMuteResult{
    
    if ([[confSelfunMute valueForKey:@"message"]isEqualToString:@"success"]) {
        
        [_btnSelfMute setSelected:NO];
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[confSelfunMute valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetControlConferenceDetailsconference];
    
    
}

//////////////////////////////////////////// Participant Mute/////////////////////////////////////

-(void)ConfAllMute{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confallmute?confId=%@&status=mute",ConfId];
    
  
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        confAllMute = responseObject ;
        [self performSelectorOnMainThread:@selector(ParticipantMuteResult) withObject:nil waitUntilDone:YES];
        
    }
    failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

   
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"POST"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    
//    
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                            [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
//                                        confAllMute=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
//                                       [self performSelectorOnMainThread:@selector(ParticipantMuteResult) withObject:nil waitUntilDone:YES];
//                                    
//                                      
//                                  }];
//    [task resume];
    
}
-(void)ParticipantMuteResult{
    
    if ([[confAllMute valueForKey:@"message"]isEqualToString:@"success"]) {
        
        [_btnParticipantMute setSelected:YES];
        
        [self  ConfSelfUnMute];
        
        
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[confAllMute valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetControlConferenceDetailsconference];
    
    
}




-(void)ConfAllUNMute{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confallmute?confId=%@&status=un-mute",ConfId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        confAllUnMute = responseObject ;
        [self performSelectorOnMainThread:@selector(ParticipantUnMuteResult) withObject:nil waitUntilDone:YES];
        
        
        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

//    NSString *strpostlength=[NSString stringWithFormat:@"%lu",(unsigned long)[apiURLStr length]];
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"POST"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    
//    
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
//                                        confAllUnMute=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
//                                      
//                                       [self performSelectorOnMainThread:@selector(ParticipantUnMuteResult) withObject:nil waitUntilDone:YES];
//                                    
//                                      
//                                  }];
//    [task resume];
}

-(void)ParticipantUnMuteResult{
    
    if ([[confAllUnMute valueForKey:@"message"]isEqualToString:@"success"]) {
        
        [_btnParticipantMute setSelected:NO];
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[confAllUnMute valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetControlConferenceDetailsconference];
    
    
}

//////////////////////////////////////////// Add More Participant ////////////////////////////////

-(void)addMoreParticipant{
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/addMoreParticipant?confId=%@&moreParticipant=%@",ConfId,strNumbers];
  
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        addMoreParticipant = responseObject ;
        isSessionNil = NO ;
      [self GetControlConferenceDetailsconference];
        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
//    NSString *strpostlength=[NSString stringWithFormat:@"%lu",(unsigned long)[apiURLStr length]];
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"POST"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    
//    
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      
//                                        addMoreParticipant=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
//                                      NSLog(@"%@",addMoreParticipant);
//                                      
//                                      isSessionNil = NO ;
//                                       [self GetControlConferenceDetailsconference];
//                                  }];
//    [task resume];
}


- (IBAction)bckOPClicked:(id)sender {
    [self.openParticipantView setHidden:YES];
    
}
- (IBAction)doneOPClicked:(id)sender {
    
    NSString *str = _txtView.text ;
    
    
    NSMutableArray *arrDigits = [[NSMutableArray alloc]init];
    
    
    NSArray*ar = [str componentsSeparatedByString:@","];
    [arrDigits addObjectsFromArray:ar];
    
    
 NSMutableArray* addOnArray = [[NSMutableArray alloc]init];
    
    if (arrDigits.count > 1) {
        NSString*strDigit;
        int i = 0 ;
        for (NSArray*arr in arrDigits) {
            i = i + 1 ;
            int count = i - 1 ;
            
            strDigit = [arrDigits objectAtIndex:count];
            
            
            NSLog(@"%@",str);
            
            if (strDigit.length!=10) {
                
                
                break ;
                
                
            }else{
                [addOnArray addObject:strDigit];
                
            }
        }
        
        
        
    }else if (arrDigits.count == 1){
        if (str.length != 10){
            
            
        }else{
            
            [addOnArray addObjectsFromArray:arrDigits];
            
            
        }
        
    }
    else{
        
    }
    
    
    
    if (addOnArray.count != arrDigits.count) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Enter mobile no. in given format" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
    }
    else{
        
        [[NSUserDefaults standardUserDefaults]setObject:arrDigits forKey:@"AO"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [self.openParticipantView setHidden:YES];
        
        NSMutableArray *ADDON = [[NSUserDefaults standardUserDefaults]valueForKey:@"AO"];
        NSLog(@"%@",ADDON);
        
        strNumbers = [ADDON componentsJoinedByString:@","];
        
        NSLog(@"%@",strNumbers);
        
        
        [self addMoreParticipant];
        
    }

}



- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text;
{
    
    NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
    
    NSString *filtered = [[text componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
    
    if ([text isEqualToString:@"\n"])
    {
        [_txtDetails resignFirstResponder];
    }
    return YES;
    
    return [text isEqualToString:filtered];
    
}

- (void)handleSingleTap:(UITapGestureRecognizer *) sender
{
    [self.txtView resignFirstResponder];
    
    [self.view endEditing:YES];
}


-(void)dialMeParticipant{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confparticipantdialout?confId=%@&mobile=%@",ConfId,pmobile];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
       
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        dialMe = responseObject ;
        [self performSelectorOnMainThread:@selector(DialMeResult) withObject:nil waitUntilDone:YES];
        

        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    

    
    
}
-(void)DialMeResult{
    if ([[dialMe valueForKey:@"message"]isEqualToString:@"success"]) {
        
        //  [_btn setSelected:YES];
        NSLog(@"Success");
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[dialMe valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];

        
        
    }else{
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[dialMe valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
   [self GetControlConferenceDetailsconference];
    
    
}


-(void)insets{
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:NO];
    
    
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 14, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 17, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
            [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];

            
        }else{
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 14, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 17, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            
        }
        
        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 375) {
        
//        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -40, 0, 0)];
//        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
//        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -42, 0, 0)];
//        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -42, 0, 0)];
//        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -41, 0, 0)];
        if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
            [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
            [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            
            
            
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 25, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 25, 0, 0)];
            
            
        }else{

        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        
        
        [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
        [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
        [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
        [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
        [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
        }
        
    }else if ([UIScreen mainScreen].bounds.size.width == 414) {
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -40, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -28, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        
        
        
        if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 23, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 27, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 27, 0, 0)];
            
            
        }else{
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 23, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 24, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 24, 0, 0)];
            
        }
        
    }    else if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        
        [delegate.tabView.btnToday setImage: [UIImage imageNamed:@"ipad-today.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnControlPanel setImage: [UIImage imageNamed:@"ipad-control-panel.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnDashboard setImage: [UIImage imageNamed:@"ipad-dashboard.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setImage: [UIImage imageNamed:@"ipad-schedule-meeting.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnMenu setImage: [UIImage imageNamed:@"ipad-menu.png"] forState:UIControlStateNormal];
        
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:12]];
        
        
        
        
        
        
        if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 43, 20, 83)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(65, -183, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 53, 20, 93)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 63, 20, 73)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(10, 63, 25, 73)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 63, 20, 73)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            
            
        }else{
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 20, 45)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(10, 50, 25, 55)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 40, 20, 45)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            
        }
        
    } else if ([UIScreen mainScreen].bounds.size.width == 1024){
        
        [delegate.tabView.btnToday setImage: [UIImage imageNamed:@"ipad-today.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnControlPanel setImage: [UIImage imageNamed:@"ipad-control-panel.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnDashboard setImage: [UIImage imageNamed:@"ipad-dashboard.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setImage: [UIImage imageNamed:@"ipad-schedule-meeting.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnMenu setImage: [UIImage imageNamed:@"ipad-menu.png"] forState:UIControlStateNormal];
        
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:12]];
        
        if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 43, 20, 83)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(95, -183, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 53, 20, 93)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(95, -157, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 63, 20, 73)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(85, -157, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(20, 93, 35, 103)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(95, -157, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 63, 20, 73)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(85, -157, 0, 0)];
            
            
            
        }else{
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 20, 45)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 50, 20, 55)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(20, 63, 35, 73)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(8, 50, 22, 55)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            
        }
        
        
    }


    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == endConfalert) {
        if (buttonIndex == 1) {
            
            
            [sessionControltask  cancel];
            sessionControlConf= nil;
            isSessionNil = YES;
            managerAf = nil;
            
            double host = [hostId doubleValue];
            double person = [personId doubleValue];
            
            
            if ( host != person) {
                
                [self  singleParticipantEndCall];
                

            }else{
            [self ConfDRopApi];
                
            }

            
        }
    }else if (alertView == RecordingAlert) {
        if (buttonIndex == 1) {
    {
        
        [KVNProgress show];
        
        
        [self ConfRecordStopApi];
        

    }
            
        }
    
}
    
}

-(void)singleParticipantEndCall{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confparticipantdrop?confId=%@&mobile=%@",ConfId,pmobile];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        singleParticipantEndCall = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(singleParticipantEndCallResult) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    
    
    
}
-(void)singleParticipantEndCallResult{
    
    NSLog(@"%@",singleParticipantEndCall);
    
    isSessionNil = NO ;
    [self GetControlConferenceDetailsconference];
    
    
}

- (IBAction)documentClicked:(id)sender
{
    
//    self.fileSelectionView.hidden = NO;
//    self.subLiveView.hidden = YES;
}

- (IBAction)audioCicked:(id)sender
{
    self.fileSelectionView.hidden = NO;
    
    self.txtUrl.text = @"";
    
    self.txtMobile.text = @"";
    
    self.subLiveView.hidden = YES;
    
  
    
}

- (IBAction)btnVideo:(id)sender
{
    
    
    self.fileSelectionView.hidden = NO;
    
    self.subLiveView.hidden = YES;
    
    self.txtUrl.text = @"";
    
    self.txtMobile.text = @"";
    
}

- (IBAction)attachmentClicked:(id)sender
{
    
//    _btnAttachment.userInteractionEnabled = YES;
//
//        _txtMobile.userInteractionEnabled = NO ;
//        _txtUrl.userInteractionEnabled = NO;
    _txtUrl.text = @"";
    
    
    
    
}

- (IBAction)txtSubmit:(id)sender
{
    self.streamingView.hidden = NO;
    self.fileSelectionView.hidden = YES;
    self.goLiveView.hidden = YES;
    
    [self.view bringSubviewToFront:self.streamingView];
    
    
}
- (IBAction)closeClicked:(id)sender
{
    self.streamingView.hidden = YES;
    self.goLiveView.hidden = YES;
    
}
- (IBAction)ClickedQA:(UIButton *)sender {
   
    [self.goLiveView setHidden:YES];
    
    [self.qaView setHidden:NO];
    
    [self.view bringSubviewToFront:self.qaView];
    
    self.goLiveView.hidden = YES;
    
    if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
        
        [self.qaView setHidden:NO];
        [self.txtAudioSelectView setHidden:NO];
        [_adminQAView setHidden:YES];
 
       
        
    }else if ([RoleStr isEqualToString:@"ROLE_ADMIN"])
    {
        [self.view bringSubviewToFront:self.adminQAView];
        
        [_adminQAView setHidden:NO];
        [self.qaView setHidden:YES];
        [self.txtAudioSelectView setHidden:YES];
    
    
//
    }else
    {
        
            [self.qaView setHidden:NO];
                [self.txtAudioSelectView setHidden:NO];
                [_adminQAView setHidden:YES];
        
    }
}
- (IBAction)ClickedGoLive:(UIButton *)sender
{
    
    [self.goLiveView setHidden:NO];
    
    [self.qaView setHidden:YES];
    
    
    
    [_adminQAView setHidden:YES];
  
    
    [self.view bringSubviewToFront:self.goLiveView];

    
    self.subLiveView.hidden = NO;
    self.fileSelectionView.hidden = YES;
   
    self.goLiveView.backgroundColor = [UIColor colorWithRed:0.0/255 green:0.0/255 blue:0.0/255 alpha:0.7f];
 
}


-(void)GestureGoLiveView:(UITapGestureRecognizer*)Recongnizer
{
    
    if (self.fileSelectionView.hidden == NO)
    {
        self.goLiveView.hidden =  YES;
        
    }
//    if (self.fileSelectionView.hidden == YES)
//    {
//        self.goLiveView.hidden = NO;
//        
//    }
}

-(void)SelectTextVideo:(UITapGestureRecognizer*)Recongnizer{
    
    
    [self.qaView setHidden:YES];
    
    
}

////////////////  File Selection View   txtUrlAction Method
-(void)TxtUrlAction
{
    
    
//     _txtMobile.userInteractionEnabled = NO;
//    [_btnAttachment setUserInteractionEnabled:NO];
       // _txtUrl.userInteractionEnabled = YES;
    
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField;
{
    if (textField == _txtUrl) {
        
        if (![_txtMobile.text isEqualToString:@""]) {
            _txtMobile.text = @"";
            return YES;
        }
    }else if (textField == _txtMobile) {
    
    return NO;
    
}
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
//    self.txtUrl.text = @"";
//    self.txtMobile.text = @"";
    
    
    
    if ([touch.view isDescendantOfView:self.fileSelectionView]) {
        
       
         self.goLiveView.hidden =  NO;
        
        return NO;
    } else if ([touch.view isDescendantOfView:self.subLiveView])
    {
        self.goLiveView.hidden = NO;
        return NO;
    }else if ([touch.view isDescendantOfView:self.audioQAView])
        
    {
        self.goLiveView.hidden = NO;
        
        return NO;
    }else if ([touch.view isDescendantOfView:self.textQAView])
        
    {
        self.qaView.hidden = NO;
        
        return NO;
    }
    
    
    self.goLiveView.hidden = YES;
    
    
    return YES;
    
    
    
}


- (IBAction)ClickedPolling:(UIButton *)sender {
}
- (IBAction)txtQAclicked:(id)sender {
    
    
    
     [self.textQAView setHidden:NO];
     [self.txtAudioSelectView setHidden:YES];
    
    
    
}

- (IBAction)txtAudioClicked:(id)sender {
    
   
     [self.qaView setHidden:NO];
    [self.audioQAView setHidden:NO];
    self.fileSelectionView.hidden = YES;
    [self.txtAudioSelectView setHidden:YES];

}

- (IBAction)closeTextViewClicked:(id)sender {
      [self.textQAView setHidden:YES];
    
    [self.txtAudioSelectView setHidden:YES];
    
       [self.qaView setHidden:YES];
    
    self.txtDetails.text = @"";
    
}

- (IBAction)saveTextClicked:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Text Message"
                                                    message: @"Question submitted sucessfully"
                                                   delegate: nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
    
    
}


- (IBAction)backTxtClicked:(id)sender {
    
     [self.textQAView setHidden:YES];
    [self.qaView setHidden:YES];
    [self.txtAudioSelectView setHidden:YES];
    
    self.txtDetails.text = @"";
    
    [self resignFirstResponder];

    
}

////////////////////   QA Button Click Recording btn

- (IBAction)btnRecordClicked:(id)sender
{
    
    [self.lblEndTime setHidden:YES];
    
    if (player.playing) {
        [player stop];
    }
    
    if (!recordered.recording) {
        
        
        if (!_btnQARecord.isSelected) {
        
        AVAudioSession *session = [AVAudioSession sharedInstance];
        [session setActive:YES error:nil];
        
        // Start recording
        [recordered record];
       
       // [_btnRecord setTitle:@"" forState:UIControlStateNormal];
        [_btnQARecord setImage:[UIImage imageNamed: @"HPauseRec.png"] forState:UIControlStateNormal];
        
        myTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateTime) userInfo:nil repeats:YES];
            
             [self.btnQARecord setSelected:YES];
        }
        
        
        
    } else {
        
      [self.btnQARecord setSelected:NO];
        
        [recordered pause];
        
     [_btnQARecord setImage:[UIImage imageNamed:@"hRec.png"] forState:UIControlStateNormal];
        
    }
    
    [_btnQAEndRecord setEnabled:YES];
    [_btnListen setEnabled:NO];
    
}

-(void)updateTime
{
    if([recordered isRecording])
    {
        
        float minutes = floor(recordered.currentTime/60);
        float seconds = recordered.currentTime - (minutes * 60);
        
        time = [[NSString alloc]
                initWithFormat:@"%0.0f.%0.0f",
                minutes, seconds];
        
        self.LblStartTime.text = time;
        
        NSTimeInterval playTime = [recordered currentTime];
        
        NSTimeInterval duration = 120;
        
            float progress = playTime/duration;
            
            [self.QAprogressBar setProgress:progress];
            
            NSLog(@"%@",time);
    }
    else
    {
        self.lblEndTime.text = time;
    }
    
}


- (IBAction)endRecordClicked:(id)sender {
    
     [_btnQARecord setImage:[UIImage imageNamed:@"hRec.png"] forState:UIControlStateNormal];
   
    [self.lblEndTime setHidden:NO];
    
    [recordered stop];
    
    self.LblStartTime.text = [NSString stringWithFormat:@"0:0"];
    
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    
    [audioSession setActive:NO error:nil];
    
    [self listenMusicRecordingFile];
    
    
}

-(void)listenMusicRecordingFile
{
    self.listenSubView.layer.cornerRadius =  10;
    self.listenSubView.clipsToBounds = YES;
    
    self.listenMusicIMG.layer.cornerRadius = 10;
    self.listenMusicIMG.clipsToBounds = YES;
    
    self.listenView.hidden = NO;
    
    UIVisualEffect *blurEffect;
    blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    
    
    visualEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
    
    visualEffectView.frame = self.listenView.bounds;
    [self.listenView addSubview:visualEffectView];
    
    [self.listenView bringSubviewToFront:self.listenSubView];
    
    player.currentTime = _listenSliderBar.value;
    
    [self PlayListenRecordFile];
}




- (IBAction)listenClicked:(id)sender
{
    
    /*
    self.listenSubView.layer.cornerRadius =  10;
    self.listenSubView.clipsToBounds = YES;
    
    self.listenMusicIMG.layer.cornerRadius = 10;
    self.listenMusicIMG.clipsToBounds = YES;
    
    self.listenView.hidden = NO;
    
    UIVisualEffect *blurEffect;
    blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    
    
    visualEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
    
    visualEffectView.frame = self.listenView.bounds;
    [self.listenView addSubview:visualEffectView];
    
    [self.listenView bringSubviewToFront:self.listenSubView];
    
    player.currentTime = _listenSliderBar.value;
    
    [self PlayListenRecordFile];
    
    
    */
    
//    if (!recordered.recording){
//
//       // self.lblEndTimer.text = time;
//
//        player = [[AVAudioPlayer alloc] initWithContentsOfURL:recordered.url error:nil];
//
//        [player setDelegate:self];
//
//        [player play];
//
//
//    }
    
}

- (IBAction)btnAudioSave:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Send Audio File" message:@"Audio File successfully send! " delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    
    [alert show];
    
}

- (IBAction)btnAudioClose:(id)sender {
   
     [self.audioQAView setHidden:YES];
    [self.txtAudioSelectView setHidden:YES];

    [self.goLiveView setHidden:YES];
     [self.qaView setHidden:YES];
    
    
    
    
}
- (IBAction)backAudioViewClicked:(id)sender {
    
  
    [self.audioQAView setHidden:YES];
    
    [self.qaView setHidden:YES];
    
    [self.txtAudioSelectView setHidden:YES];
    
    [self.goLiveView setHidden:YES];
    
    [self.subLiveView setHidden:YES];

}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4 ;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
        
        if (tableView == _manageTableView){
            
            if (ifManage == false) {
                QACell *cell = [tableView dequeueReusableCellWithIdentifier:@"QACell"];
                if (cell==nil) {
                    NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"QACell" owner:self options:nil];
                    cell= arr[0];
                    
                }
                cell.txtHome.text = @"Manage";
                
                return cell;

            }else{
                
                ManageQACell *cell = [tableView dequeueReusableCellWithIdentifier:@"ManageQACell"];
                if (cell==nil) {
                    NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"ManageQACell" owner:self options:nil];
                    cell= arr[0];
                    
                }
                cell.txtManageHome.text = @"Home";
                
                return cell;
                
            }
            
        }
    
    return 0;

    
    }


- (IBAction)btnBackAdminQA:(id)sender {
    _adminQAView.hidden = YES ;
    
}
- (IBAction)ManageClicked:(id)sender {
    ifManage = true;
     self.btnManage.backgroundColor = [UIColor colorWithRed:26/255.0f green:51/255.0f blue:66/255.0f alpha:1];
    self.btnUnmanage.backgroundColor = [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:1];
    [self.manageView setHidden:NO];
     [self.unManageView setHidden:YES];
    [_manageTableView reloadData];
    
}

- (IBAction)unmanageClicked:(id)sender {
    ifManage = false ;
     self.btnUnmanage.backgroundColor = [UIColor colorWithRed:26/255.0f green:51/255.0f blue:66/255.0f alpha:1];
     self.btnManage.backgroundColor = [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:1];
    [self.manageView setHidden:YES];
    [self.unManageView setHidden:NO];
    [_manageTableView reloadData];

}


////////////////////   QA Button Click Recording delegate Method
- (void) audioRecorderDidFinishRecording:(AVAudioRecorder *)avrecorder successfully:(BOOL)flag{
    
    [_btnQAEndRecord setEnabled:NO];
    
    [_btnListen setEnabled:YES];
}

- (void) audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Done"
                                                    message: @"Finish playing the recording!"
                                                   delegate: nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
    
    visualEffectView.hidden = YES;
    
     [_btnQARecord setImage:[UIImage imageNamed:@"hRec.png"] forState:UIControlStateNormal];
    
    [player stop];
    
    self.listenView.hidden = YES;
    
    
    
}



////////////////////////////        LIsten Button Click Functionality


- (IBAction)listenCloseBtn:(UIButton *)sender
    {
   
        visualEffectView.hidden = YES;
       
        [player stop];
      
        self.listenView.hidden = YES;
    
    }

-(void)PlayListenRecordFile;
{
    if (!recordered.recording)
        
    {
        self.lbllistenEndTime.text = time;
        player = [[AVAudioPlayer alloc] initWithContentsOfURL:recordered.url error:nil];                [player setDelegate:self];
        [player prepareToPlay];
        [player play];
        _listenSliderBar.maximumValue = [player duration];
        _listenSliderBar.value = 0.0;
        [player setCurrentTime:_listenSliderBar.value];
        [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(ListenTimer:) userInfo:nil repeats:YES];
        
    }
}




- (IBAction)listenclickedPlay:(UIButton *)sender
{
    
    if (!_listenPlayBTn.isSelected) {
        
        [_listenPlayBTn setSelected:YES];
        [player pause];
        
        
    }else{
        
         [_listenPlayBTn setSelected:NO];
        [player play];
        
        
    }
   
  
}
- (void)ListenTimer:(NSTimer *)timer
{

    _listenSliderBar.value = player.currentTime;
    
    NSString *time = [self timeFormatted:_listenSliderBar.value];
    self.LbllistenStartTime.text = time;
    
}

- (NSString *)timeFormatted:(int)totalSeconds

{
    int seconds = totalSeconds % 60;
    int minutes = (totalSeconds / 60) % 60;
    //int hours = totalSeconds / 3600;        //return [NSString stringWithFormat:@"%02d:%02d:%02d",hours, minutes, seconds];
    return [NSString stringWithFormat:@"%02d:%02d", minutes, seconds];
    
}

- (IBAction)sliderChanged : (UISlider *)sender
{
        // skips music with slider changged
        [player pause];
    
        [player setCurrentTime:_listenSliderBar.value];    //
        [player prepareToPlay];
        [player play];
    
}

- (IBAction)listenclickedForward:(UIButton *)sender;
{
    NSTimeInterval timeCurrent = player.currentTime;
    timeCurrent += 05.0f;
    if (timeCurrent > player.duration)
    {
        [player stop];
        
    }else    {
        player.currentTime = timeCurrent;
        
    }
    
}
- (IBAction)listenClickedReverse:(UIButton *)sender
{
    NSTimeInterval timeCurrent = player.currentTime;
    timeCurrent -= 05.0f;
    if (timeCurrent > player.duration)
    {
        [player stop];
        
    }else
    {
        player.currentTime = timeCurrent;
        
    }

    
}




@end
