//
//  MapVc.h
//  excelSheetUpload
//
//  Created by Rhythmus on 20/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
@interface MapVc : UIViewController<UIAlertViewDelegate>
{
    double latitude ;
    double longitude;
    NSDictionary *JSON ;
    UIAlertView *ALERTMAP ;
    
}

@property (strong, nonatomic) IBOutlet MKMapView *mapkit;

- (IBAction)locationfindButton:(id)sender;

- (IBAction)btnBckClicked:(id)sender;

@end
