//
//  ViewController.m
//  UserSavedDetails
//
//  Created by Rhythmus on 27/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "UpdateAccountViewController.h"
#import <QuartzCore/QuartzCore.h>
#import <AFNetworking/AFNetworking.h>
#import "KVNProgress.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/Photos.h>



@interface UpdateAccountViewController ()

@end

@implementation UpdateAccountViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIColor *color = [UIColor colorWithRed:168/255.0f green:168/255.0f blue:168/255.0f alpha:1];
    
    _txtName.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"First Name" attributes:@{NSForegroundColorAttributeName: color}];
    _txtAdmin.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Select Department" attributes:@{NSForegroundColorAttributeName: color}];
    _txtEmail.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Email id" attributes:@{NSForegroundColorAttributeName: color}];
    _txtPhone.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Contact Number" attributes:@{NSForegroundColorAttributeName: color}];
        _txtLocation.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Address" attributes:@{NSForegroundColorAttributeName: color}];
            _txtLastName.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"last Name" attributes:@{NSForegroundColorAttributeName: color}];
    

    
    
    NSLog(@"%@",_detailsArray);
    
    
    _btnSave.layer.cornerRadius = 5.0f ;
    [_btnSave clipsToBounds];
    
    
    _btnCancel.layer.cornerRadius = 5.0f ;
    [_btnCancel clipsToBounds];
    
    
    _imgProfile.layer.cornerRadius = _imgProfile.frame.size.width/2 ;
    
    [_imgProfile.layer masksToBounds];
    
    
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    self.imgProfile.layer.cornerRadius = self.imgProfile.frame.size.width/2 ;
    [self.imgProfile clipsToBounds];
 _imgProfile.layer.masksToBounds = YES;
    
    
    [self setAlertCtrl];
    
    self.txtName.text = [_detailsArray[0] valueForKey:@"firstName"];
    self.txtLastName.text = [_detailsArray[0] valueForKey:@"lastName"];
     self.txtLocation.text = [_detailsArray[0] valueForKey:@"location"];
    self.txtEmail.text = [_detailsArray[0] valueForKey:@"pemail"];
    
     self.txtPhone.text = [_detailsArray[0] valueForKey:@"pmobile"];
    NSString*roleee = [_detailsArray[0] valueForKey:@"role"];
    if ([roleee isEqualToString:@"ROLE_SUPER_ADMIN"]) {
        self.txtAdmin.text = @"Admin" ;
        
    }else if ([roleee isEqualToString:@"ROLE_HOST"]) {
        self.txtAdmin.text = @"Host" ;
        
    }else if ([roleee isEqualToString:@"ROLE_PARTICIPANT"]) {
        self.txtAdmin.text = @"Participant" ;
        
    }
    
    personId = [_detailsArray[0] valueForKey:@"personId"];

    
    [self GetProfileFromServer];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event

{
    
    NSLog(@"touchesBegan:withEvent:");
    
    [self.view endEditing:YES];
    
    [super touchesBegan:touches withEvent:event];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)cancelClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}





- (IBAction)saveClickedd:(id)sender {
    
    [KVNProgress show];
    
    [self updateDataFromServer];
}

- (IBAction)uploadClicked:(id)sender {
    
    [self presentViewController:self.AlertCtrl animated:YES completion:nil];
}

- (IBAction)backClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)selectPhoto {
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];
    
    
    
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    chosenImage = nil ;
    
        
     chosenImage = info[UIImagePickerControllerEditedImage];

    
   
    
    
//        NSURL *refURL = [info valueForKey:UIImagePickerControllerReferenceURL];
//        PHFetchResult *result = [PHAsset fetchAssetsWithALAssetURLs:@[refURL] options:nil];
//        NSString *filename = [[result firstObject] filename];
//        self.txtPancardName.text = filename ;
    
    
    
    self.imgProfile.image = chosenImage ;
    
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
    
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}
-(void)camera{
    
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                              message:@"Device has no camera"
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles: nil];
        
        [myAlertView show];
        
    } else {
        
        
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        
        [self presentViewController:picker animated:YES completion:nil];
        
    }
    
    
}
-(void)setAlertCtrl;
{
    
    self.AlertCtrl = [UIAlertController alertControllerWithTitle:@"selectImage" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction *camera = [UIAlertAction actionWithTitle:@"Camera" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                             
                             {
                                 [self camera];
                             }];
    
    UIAlertAction *Library  = [UIAlertAction actionWithTitle:@"Image Gallery" style:UIAlertActionStyleDefault handler:^(UIAlertAction *  action)
                               
                               {
                                   
                                   [self selectPhoto];
                               }];
    
    UIAlertAction *Cancel  = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *  action) {
        
    }];
    
    [self.AlertCtrl addAction:camera];
    [self.AlertCtrl addAction:Library];
    [self.AlertCtrl addAction:Cancel];
    
}

-(void)kvnDismiss{
    [KVNProgress dismiss];
    
    
}

-(void)updateDataFromServer{
    
    
     NSString *strComId = [_detailsArray[0] valueForKey:@"cmpId"];
    NSString *depName = [_detailsArray[0] valueForKey:@"depName"];
    
    
    
    
    NSArray *arr2 = [NSArray arrayWithArray:[[_detailsArray[0] valueForKey:@"email"] valueForKey:@"type"]];
    NSArray *arr3 = [NSArray arrayWithArray:[[_detailsArray[0] valueForKey:@"email"] valueForKey:@"value"]];

    NSString *emailtype = arr2[0];
    NSString *emailvalue = arr3[0];
    

    NSString *empId = [_detailsArray[0] valueForKey:@"empId"];

    NSString *empSts = [_detailsArray[0] valueForKey:@"empSts"];

    NSString *hostId = [_detailsArray[0] valueForKey:@"hostId"];

    NSString *loginId = @"0";
    
    NSArray *arr = [NSArray arrayWithArray:[[_detailsArray[0] valueForKey:@"mobile"] valueForKey:@"type"]];
     NSArray *arr1 = [NSArray arrayWithArray:[[_detailsArray[0] valueForKey:@"mobile"] valueForKey:@"value"]];
    
    
    
    NSString *mobiletype = arr[0];
    NSString *mobilevalue = arr1[0];
    

        NSString *portCount = [_detailsArray[0] valueForKey:@"portCount"];

    NSString*roleee = self.txtAdmin.text ;
    
    if ([roleee isEqualToString:@"Admin"]) {
        roleee = @"ROLE_SUPER_ADMIN" ;
        
    }else if ([roleee isEqualToString:@" Host"]) {
        roleee = @"ROLE_HOST" ;
        
    }else if ([roleee isEqualToString:@"Participant"]) {
        roleee = @"ROLE_PARTICIPANT" ;
        
    }
    
    
    
    NSDictionary *headers = @{ @"content-type": @"application/json",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"114064f8-851c-fbfd-d2a4-1d246fcf7aec" };
    NSDictionary *parameters = @{ @"cmpId": strComId,
                                  @"depName": depName,
                                  @"email": @[ @{ @"type": emailtype, @"value": emailvalue } ],
                                  @"empId": empId,
                                  @"empSts": empSts,
                                  @"firstName": self.txtName.text,
                                  @"hostId": personId,
                                  @"lastName": self.txtLastName.text,
                                  @"location": self.txtLocation.text,
                                  @"loginId": loginId,
                                  @"mobile": @[ @{ @"type": mobiletype, @"value": mobilevalue } ],
                                  @"pemail": self.txtEmail.text,
                                  @"personId": personId,
                                  @"pmobile": self.txtPhone.text,
                                  @"portCount": portCount,
                                  @"role": roleee };
    
    
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/person/secure/editperson"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"PUT"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    [request setValue:Tokenid forHTTPHeaderField:@"token"];
    
     NSString*apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/editperson"];
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager PUT:apiURLStr parameters:parameters success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
          profileData  = responseObject ;
        if ([[profileData valueForKey:@"responseCode"] isEqual:[NSNumber numberWithInteger:200]] ) {
            
            
            [self performSelectorOnMainThread:@selector(DataGET) withObject:nil waitUntilDone:YES];
            
            
    }
        
        
    }
          failure:^(NSURLSessionTask *operation, NSError *error) {
              [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
              NSLog(@"Error: %@", error);
              
          }];

//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
//                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
//                                                    if (error) {
//                                                        NSLog(@"%@", error);
//                                                    } else {
//                                                     id  profileData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//                                                        
//                                                        
//                                                        NSLog(@"%@",profileData);
//                                                        
//                                                        if ([[profileData valueForKey:@"message"] isEqualToString:@"success"] ) {
//                                                            
//                                                            if (self.imgProfile.image!=nil) {
//                                                                [self ImageSavingToserver];
//                                                                
//                                                            }else{
//                                                                
//                                                                alertSave = [[UIAlertView alloc]initWithTitle:nil message:@"Successfully Updated" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
//                                                                [alertSave show];
//
//                                                            }
//                                                            
//                                                            
//                                                            
//                                                        }
//                                                        
//                                                        
//                                                    }
//                                                }];
//    [dataTask resume];
    
    
}
-(void)DataGET{
    if (self.imgProfile.image!=nil) {
        
        [self ImageSavingToserver];
        
    }else{
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        alertSave = [[UIAlertView alloc]initWithTitle:nil message:[profileData valueForKey:@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alertSave show];
        
    }
    
    
    
}

    


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    
    if (alertView == alertSave) {
        if (buttonIndex == 0) {

            [self.navigationController popViewControllerAnimated:YES];
            
        }
    }else if (alertView == alertImage) {
        if (buttonIndex == 0) {
            
            [self.navigationController popViewControllerAnimated:YES];
            
        }
    }
    
}

-(void)ImageSavingToserver {
    
   
    
    NSString *urlString=[NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/addprofimg?personId=%@",personId ];
    
    
    NSString *BoundaryConstant = @"----------V2ymHFg03ehbqgZCaKO6jy";
    
    // string constant for the post parameter 'file'. My server uses this name: `file`. Your's may differ
    NSString* Filelogo = @"profImg";
    
    
    // the server url to which the image (or the media) is uploaded. Use your server url here
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:urlString]];
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:100];
    
    [request setHTTPMethod:@"POST"];
    
    
    
    // set Content-Type in HTTP header
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", BoundaryConstant];
    [request setValue:contentType forHTTPHeaderField: @"Content-Type"];
     [request setValue:Tokenid forHTTPHeaderField: @"token"];
    
    // post body
    NSMutableData *body = [NSMutableData data];
    
  
    
    NSData *imagelogo = UIImageJPEGRepresentation(chosenImage, 1.0);
            [body appendData:[[NSString stringWithFormat:@"--%@\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"profImg\"; filename=\"image.jpg\"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:imagelogo];
        [body appendData:[[NSString stringWithFormat:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // setting the body of the post to the reqeust
    [request setHTTPBody:body];
    
    // set the content-length
    NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[body length]];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
     [request setValue:Tokenid forHTTPHeaderField:@"token"];
    
    // set URL
    [request setHTTPBody:body];
    
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request
                                            completionHandler:
                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
                                      NSLog(@"%@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
                                      
                                      [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];

                                      
                                      savedData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                      
                                      NSLog(@"%@",savedData);
                                      
                                      if ([[savedData valueForKey:@"responseCode"] isEqual:[NSNumber numberWithInteger:200]]) {
                                           [self performSelectorOnMainThread:@selector(suuceessful) withObject:nil waitUntilDone:YES];
                                      }
                                      
                                      
                                     

                                     
                                      
                                      
                                     
                                      
                                      // [self.tumblrHUD hide];
                                  }];
    
    [task resume];
    
}

-(void)suuceessful{
    
    alertImage = [[UIAlertView alloc]initWithTitle:nil message:[savedData valueForKey:@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alertImage show];
}
-(void)GetProfileFromServer{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getprofile?personId=%@",personId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        profileData = responseObject ;
       
            listCompanies = [[profileData valueForKey:@"accountdata"]valueForKey:@"cmpNm"];
   [self performSelectorOnMainThread:@selector(getProfileData) withObject:nil waitUntilDone:YES];
            
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
    
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      
//                
//                // NSError* error;
//                if (data != nil) {
//                    profileData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//                }
//                
//                
//                NSLog(@"%@",profileData);
//                
//                
//               // listCompanies = [[profileData valueForKey:@"accountdata"]valueForKey:@"cmpNm"];
//                
//                [self performSelectorOnMainThread:@selector(getProfileData) withObject:nil waitUntilDone:YES];
//                
//                
//                                  }];
//    
 //  [task resume];
    
}

-(void)getProfileData{
    NSString*compnyImg = [profileData valueForKey:@"proImg"];
    
    if ([compnyImg isEqualToString:@"no image"]) {
        
        self.imgProfile.image =[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"];
        
        
    }else{
        SDImageCache *imageCache = [SDImageCache sharedImageCache];
        [imageCache clearMemory];
        [imageCache clearDisk];

        
        [self.imgProfile sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://182.76.44.135:8080/%@",compnyImg]]placeholderImage:[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"]];
        
    }
    
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
    
    return YES;
    
}

@end
