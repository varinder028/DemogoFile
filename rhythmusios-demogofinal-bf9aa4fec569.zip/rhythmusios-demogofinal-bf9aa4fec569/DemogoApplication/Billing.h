//
//  Billing.h
//  DemogoApplication
//
//  Created by katoch on 24/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Billing : UIViewController<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate>{
    
     NSMutableArray * cellArrayName;
    NSString*CompanyId;
    NSString*personId;
    NSString*checkPlan;
    NSString*isVarified;
    NSString*planNameCHeck;
    NSString*Tokenid;
    
    id prePaidValididy;
    id PostpaidValidity;
    
    NSString*isPrepaid ;
    NSString*subScrStr;
    UIAlertView *NoPlanAlert;
    
    
    
}
@property (strong, nonatomic) IBOutlet UILabel *txtTotalValue;
@property (strong, nonatomic) IBOutlet UILabel *txtValidity;
@property (strong, nonatomic) IBOutlet UILabel *txtBalnce;

@property (strong, nonatomic) IBOutlet UILabel *customerId;
@property (strong, nonatomic) IBOutlet UILabel *txtPlanName;

@property (strong, nonatomic) IBOutlet UIView *PrepaidView;
@property (strong, nonatomic) IBOutlet UISegmentedControl *segmentcontroller;
- (IBAction)segmentAction:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *postPaidView;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *segmentHeightLayout;
- (IBAction)backBtn:(id)sender;




@end
