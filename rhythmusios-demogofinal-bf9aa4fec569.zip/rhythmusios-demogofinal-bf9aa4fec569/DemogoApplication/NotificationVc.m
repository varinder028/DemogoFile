//
//  NotificationVc.h
//  excelSheetUpload
//
//  Created by Rhythmus on 05/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "NotificationVc.h"
#import <PhotosUI/PhotosUI.h>
#import "NotifcationTableViewCell.h"
#import "Reachability.h"


@interface NotificationVc ()<UIDocumentInteractionControllerDelegate,UIScrollViewDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate,UITableViewDelegate,UITableViewDataSource>

{
    UIRefreshControl *refreshctrl ;
    NSString *  Tokenstr;
    NSMutableArray *inviteSMS;
    NSMutableArray *inviteTodaySMS;
    NSString *get;
    NSMutableArray * PreviewDataArray;
    NSMutableArray * TodayDataArray;
    NSString *dateString;
    NSDate* takeTM;
    
    UIDocumentInteractionController *docController;
    NotifcationTableViewCell *cell;

}
- (IBAction)GET:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btn;
@property (strong, nonatomic) IBOutlet UIWebView *webview;

@end

@implementation NotificationVc


-(UIColor*)colorWithHexString:(NSString*)hex
{
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor whiteColor];
    
    // strip 0X if it appears
    if ([cString hasSuffix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor whiteColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}




- (void)viewDidLoad {
    [super viewDidLoad];
    
    _txtVerifyAccount.text = @"No Notification available";
    _txtToday.text = @"No Notification available";
    _txtPrevious.text = @"No Notification available";
    todayFinalArray = [[NSMutableArray alloc]init];
    
    variFyArray = [[NSMutableArray alloc]init];
    pmobile = [[NSUserDefaults standardUserDefaults]valueForKey:@"pmobile"];
    NSLog(@"%@",pmobile);
    
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    CompanyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    allDataArray = [[NSMutableArray alloc]init];
    verifyArrayData  = [[NSMutableArray alloc]init];
    
    takeTM = [[NSDate alloc]init];
    dictData = [[NSMutableDictionary alloc]init];
    PreviousFinalArray = [[NSMutableArray alloc]init];
    
    todayArray = [[NSMutableArray alloc]init];
    messageTdayArray = [[NSMutableArray alloc]init];
    
    messagePreviousArray = [[NSMutableArray alloc]init];
    previousArray = [[NSMutableArray alloc]init];

    NotifyStausArray= [[NSMutableArray alloc]init];
    NotifyTime= [[NSMutableArray alloc]init];
    
    
    
    inviteSMS = [[NSMutableArray alloc]init];
    
    TodayDataArray = [[NSMutableArray alloc]init];
    inviteTodaySMS = [[NSMutableArray alloc]init];
    self.TodayTableView.delegate=self;
    
    self.TodayTableView.dataSource=self;


    
    [self OtpEqualDataWithNumber];
    
    
    PreviewDataArray = [[NSMutableArray alloc]init];
    
    
    
    
    self.ViewVerifyAccount.hidden = YES;
    
    self.ViewTodayConference.hidden =YES;
    
    self.ConferenceDetailsView.hidden = YES;
    
    
    
    
    self.BtnApprove.layer.cornerRadius = 10.5f;
    self.BtnReject.layer.cornerRadius = 10.5f;
    
    [self.TableViewVerifyAccount reloadData];
    
   //  _scrollview.contentSize = CGSizeMake(self.view.frame.size.width, self.view.frame.size.height);
    
    _scrollview.delegate =self;
    
   //  [self OtpEqualDataWithNumber];
    
    NSDate *currDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"dd-MMM-yyyy"];
    dateString = [dateFormatter stringFromDate:currDate];
    NSLog(@"%@",dateString);
    
   // Do any additional setup after loading the view, typically from a nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    
    self.ViewTodayConference.alpha =0.90;
    self.ConferenceDetailsView.alpha=1;
    
    
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = _ViewConfDetailsNew.bounds;
    gradient.startPoint = CGPointZero;
    gradient.endPoint = CGPointMake(1, 1);
    gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:34.0/255.0 green:111/255.0 blue:144/255.0 alpha:1.0] CGColor],(id)[[UIColor colorWithRed:145/255.0 green:72.0/255.0 blue:203/255.0 alpha:6.0] CGColor], nil];
    [_ViewConfDetailsNew.layer addSublayer:gradient];
    
    [_ViewConfDetailsNew addSubview:_labelSubject];
    [_ViewConfDetailsNew addSubview:_labelCOnferenceDate];
    
    [_ViewConfDetailsNew addSubview:_labelMode];
    
    [_ViewConfDetailsNew addSubview:_labelConferenceTime];
    
    [_ViewConfDetailsNew addSubview:_BtnJoin];
    
    // [_ConferenceDetailsView addSubview:_];
    
    [_ConferenceDetailsView addSubview:_ViewConfDetailsNew];
    
    [_ViewConfDetailsNew addSubview:_Subject];
    [_ViewConfDetailsNew addSubview:_time];
    [_ViewConfDetailsNew addSubview:_date];
    [_ViewConfDetailsNew addSubview:_mode];
    
    
    
    
    
    [_ViewConfDetailsNew addSubview:_BtnDecline];
    
    [_ViewConfDetailsNew addSubview:_BtnMayBe];
    
    
    
    
    
    //    [self.TodayTableView reloadData];
    //    [self.PreviewTableView reloadData];
    //    [self.TableViewVerifyAccount reloadData];
    
}



-( NSInteger )numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1 ;

}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if (tableView == self.TodayTableView)
   
    {
        
        return [todayFinalArray count];
   
    }
    
    else if (tableView == self.PreviewTableView)
        
        {
            return [PreviousFinalArray count];
            
        }
    
    else
    {
        return [variFyArray count];
    }
   
    
    
}

-(NotifcationTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    
    NSString *CellId = @"cell";
    
    cell = [tableView dequeueReusableCellWithIdentifier:CellId];
    
    if (cell ==nil)
    
    {
        cell = [[NotifcationTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellId];
    }
    
    
    if (tableView == _TodayTableView){

        if (todayFinalArray.count>0)
            
        {
            
            
        cell.Todayinvite.text = [NSString stringWithFormat:@"%@",[[[todayFinalArray valueForKey:@"ntfyMsg" ]valueForKey:@"msg"] objectAtIndex:indexPath.row]];
            
            confIdString = [NSString stringWithFormat:@"%@",[[[todayFinalArray valueForKey:@"ntfyMsg" ]valueForKey:@"confId"] objectAtIndex:indexPath.row]];
            NSLog(@"the coonference id is  =  %@",confIdString);
        
          NSString*strtimedate   =[NSString stringWithFormat:@"%@",[[todayFinalArray valueForKey:@"Date" ] objectAtIndex:indexPath.row]];
            
            strtimedate = [strtimedate stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
            
           ////
            
            cell.TodayTime.text = [NSString stringWithFormat:@"%@",strtimedate];
            
            
        }else{
            
            UIAlertView *alertshhow=[[UIAlertView alloc]initWithTitle:@"TODAY MEETING" message:@"Today meeting is not Fix" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alertshhow show];
        }

        
        return cell;
        
        
    
    }
    
    else if (tableView == _PreviewTableView)
    
    {
        if (PreviousFinalArray.count>0)
            
        {

            NSString *strPreviewdate= [NSString stringWithFormat:@"%@",[[PreviousFinalArray valueForKey:@"Date"] objectAtIndex:indexPath.row]];
            
            strPreviewdate = [strPreviewdate stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
            
            
             cell.PreviewTime.text = [NSString stringWithFormat:@"%@",strPreviewdate];

            
            cell.PreviewInvite.text =[NSString stringWithFormat:@"%@",[[[PreviousFinalArray valueForKey:@"ntfyMsg" ]valueForKey:@"msg"] objectAtIndex:indexPath.row]];
            
        
        
        }else{
            
            UIAlertView *alertshhow=[[UIAlertView alloc]initWithTitle:@"PREVIOUS MEETING" message:@"No previous meeting" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alertshhow show];
        }

        return cell ;
        
            
    }else if (tableView == _TableViewVerifyAccount)
        
    {
        
        if (variFyArray.count>0)
        
        {
            
            
            
            cell.Verifyinvite.text = [NSString stringWithFormat:@"%@",[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"msg"] objectAtIndex:indexPath.row]];
            
             NSString *strVerifyDate=[NSString stringWithFormat:@"%@",[[variFyArray valueForKey:@"Date"] objectAtIndex:indexPath.row]];
        
            strVerifyDate=[strVerifyDate stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
            
            cell.VerifyTime.text=[NSString stringWithString:strVerifyDate];
        
        }else{
            
            UIAlertView *alertshhow=[[UIAlertView alloc]initWithTitle:@"Account Verify Details" message:@"No editing" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alertshhow show];
        }
        
       
        
        return cell;
        
        
        
    }
    
        return 0;
    
        
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == _TodayTableView)
        
    {
        NSDate *confDtTm;
        NSLog(@"meeting deatils");
        
        self.ViewTodayConference.hidden = NO;
        
        self.ConferenceDetailsView.hidden = NO;
        
        self.BtnJoin.layer.cornerRadius = 5.5f;
        
        self.BtnDecline.layer.cornerRadius = 5.5f;
        
        self.BtnMayBe.layer.cornerRadius = 5.5f;
        
        
        NSString* strTime = [[[todayFinalArray valueForKey:@"ntfyMsg"]valueForKey:@"confDateTime"]objectAtIndex:indexPath.row];
        
      
        double miliSecend = strTime.doubleValue;
        confDtTm = [NSDate dateWithTimeIntervalSince1970:miliSecend/1000];
        NSLog(@"%@",confDtTm);
        
        NSDictionary *dictionary =[todayFinalArray objectAtIndex:indexPath.row];
        
         NSString* ConferenceTime = [[dictionary objectForKey:@"ntfyMsg"]valueForKey:@"confDateTime"];
        
        NSString* statusData = [[dictionary objectForKey:@"ntfyMsg"]valueForKey:@"msg"];
        
        NSString * ModeData = [[dictionary objectForKey:@"ntfyMsg"]valueForKey:@"confType"];
        
        TodayNotifyID = [[dictionary objectForKey:@"ntfyMsg"]valueForKey:@"ntfyId"];
        
        TodayStatus = [dictionary objectForKey:@"ntfyStatus"];
        
        NSLog(@" today date = %@ \n today subject  = %@\n today ConfType  = %@",ConferenceTime,statusData,ModeData);

        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        //
        [dateFormat setDateFormat:@"dd-MMM-yyyy"];
        
        //dateFormat.dateFormat = @"yyyy-MM-dd";
        
        finalDate = [dateFormat stringFromDate:confDtTm];
        
        NSDateFormatter *TimeFormat = [[NSDateFormatter alloc] init];
        
        [TimeFormat setDateFormat:@"HH:mm:ss"];
        
        finalTime = [TimeFormat stringFromDate:confDtTm];
        

        self.labelSubject.text = statusData;
        self.labelConferenceTime.text = finalTime;
        self.labelCOnferenceDate.text =finalDate;
        self.labelMode.text =ModeData;
        
        
        
        
        
    }
    else if (tableView == _TableViewVerifyAccount)
        
        {

            self.ViewVerifyAccount.hidden =NO;
            
            self.LabelcurrentDetail.layer.cornerRadius=10.5f;
            self.LabelRequestedDetails.layer.cornerRadius=10.5f;
            
            _LabelcurrentDetail.layer.masksToBounds = YES;
            
            _LabelRequestedDetails.layer.masksToBounds = YES;
            
            
            NSDictionary *dictionary = [variFyArray objectAtIndex:indexPath.row];
            
            strda = [dictionary objectForKey:@"ntfyStatus"];
            
            strdata = [dictionary objectForKey:@"ntfyId"];
            
            NSLog(@" the notify id = %@ \n the status id is  = %@",strdata,strda);
            
            
            self.LabelCurrentName.text =[NSString stringWithFormat:@"%@",[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"currentDetail"]valueForKey:@"firstName" ] objectAtIndex:indexPath.row]];
            
            self.LabelCurrentLastName.text = [NSString stringWithFormat:@"%@",[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"currentDetail"]valueForKey:@"lastName" ] objectAtIndex:indexPath.row]];
            
            self.LabelCurrentDepartment.text = [NSString stringWithFormat:@"%@",[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"currentDetail"]valueForKey:@"depName" ] objectAtIndex:indexPath.row]];
            
            self.LabelCurrentLocation.text = [NSString stringWithFormat:@"%@",[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"currentDetail"]valueForKey:@"location" ] objectAtIndex:indexPath.row]];
            
            
            NSMutableArray * Mobiledetail = [[NSMutableArray alloc]initWithArray:[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"currentDetail"]valueForKey:@"mobile"] objectAtIndex:indexPath.row]];
            
            
            NSString *value = [Mobiledetail[0] valueForKey:@"value"];
            
                             
            NSMutableArray * Emailedetail = [[NSMutableArray alloc]initWithArray:[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"currentDetail"]valueForKey:@"email"] objectAtIndex:indexPath.row]];
            
            
            NSString *Emailvalue = [Emailedetail[0] valueForKey:@"value"];
            
            
            
            self.LabelCurrentMobileNumber.text = value;
            self.LabelCurrentEmailId.text = Emailvalue;
            
            
            /////////  reques
            
            self.LabelRequestedName.text = [NSString stringWithFormat:@"%@",[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"requestDetail"]valueForKey:@"firstName" ] objectAtIndex:indexPath.row]];
            
            self.LabelRequestedLastName.text = [NSString stringWithFormat:@"%@",[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"requestDetail"]valueForKey:@"lastName" ] objectAtIndex:indexPath.row]];
            
            self.LabelRequestedDepartment.text = [NSString stringWithFormat:@"%@",[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"requestDetail"]valueForKey:@"depName" ] objectAtIndex:indexPath.row]];
            
            self.LabelRequestedLocation.text =[NSString stringWithFormat:@"%@",[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"requestDetail"]valueForKey:@"location" ] objectAtIndex:indexPath.row]];
            
            NSMutableArray * ReqMobiledetail = [[NSMutableArray alloc]initWithArray:[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"currentDetail"]valueForKey:@"mobile"] objectAtIndex:indexPath.row]];
            
            
            NSString *Mobilevalue = [ReqMobiledetail[0] valueForKey:@"value"];
            
            
            NSMutableArray * ReqEmailedetail = [[NSMutableArray alloc]initWithArray:[[[[variFyArray valueForKey:@"ntfyMsg" ]valueForKey:@"currentDetail"]valueForKey:@"email"] objectAtIndex:indexPath.row]];
            
            
            NSString *ReqEmailvalue = [ReqEmailedetail[0] valueForKey:@"value"];

            
            self.LabelRequestedMobileNumber.text = Mobilevalue;
            self.LabelRequestedEmailId.text = ReqEmailvalue;
            
            
            
            
            NSLog(@"ffvd");
            
            
            
            
    
        }else
        {
            NSLog(@"dcx");
        }


}



- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    
     pageNo = round(_scrollview.contentOffset.x / self.scrollview.frame.size.width);
    NSLog(@"Page number is %i", pageNo);
    
    if (pageNo==1) {
        
        
        _leadingConstant.constant = self.BtnToday.frame.size.width;
        
    }else if (pageNo==2)
    {
        
        _leadingConstant.constant = self.BtnToday.frame.size.width + self.BtnToday.frame.size.width ;

        
    }else{
        
        _leadingConstant.constant = 0;
    }

}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
  
    
}
//- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate;
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)GET:(id)sender
{
    NSURL * documentsDirectory = [NSFileManager.defaultManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].lastObject;
    NSURL *file = [documentsDirectory URLByAppendingPathComponent:@"text" isDirectory:YES];
    NSString* string = @"<table><tr><td>FOO</td><td>BAR</td></tr></table>";
    [string writeToFile:file.path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
 }
- (IBAction)btnToday:(id)sender

{
  
    
    [_scrollview setContentOffset:CGPointMake(0, 0)animated:YES];
    
    [UIView animateWithDuration:0.5 animations:^{
     //  _leadingConstant.constant = 0;
    }];
   
}


- (IBAction)btnPreviews:(id)sender
{
    
    
    
    [_scrollview setContentOffset:CGPointMake(_scrollview.frame.size.width, 0)animated:YES];
    NSLog(@"%f",_scrollview.frame.origin.x);
    
    [UIView animateWithDuration:0.5 animations:^{
       // _leadingConstant.constant = self.BtnToday.frame.size.width;
        
    }];
    
    
}
-(void)reloadtable
{
    [self.TableViewVerifyAccount reloadData];
    
    [refreshctrl endRefreshing];
    
}

- (IBAction)btnVerifyAccount:(id)sender
{
    
    [_scrollview setContentOffset:CGPointMake(_scrollview.frame.size.width*2, 0)animated:YES];
    
    [UIView animateWithDuration:0.5 animations:^{
//        _leadingConstant.constant = self.BtnToday.frame.size.width + self.BtnToday.frame.size.width ;

        
    }];

    
}

-(void)OtpEqualDataWithNumber;
{
    NSString *otdat;
   // NSError *linkError;
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    
    otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/notification/secure/receive?personId=%@",personId];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    
    [SendingRequest addValue:Tokenid forHTTPHeaderField:@"token"];
    
    
    [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
    
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
    
    
    
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              dispatch_async(dispatch_get_main_queue(),^
                                              {
                                                  
                                                  NSError *jsonError;
                                                  
                                                  if (data!= nil) {
                                                      allData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                      
                                                      
                                                      
                                                      [self performSelectorOnMainThread:@selector(GettingMeeting) withObject:nil waitUntilDone:YES];
                                                  }
                                                  
                                                  
                                                  
                                                  
                                                  
                                              });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
}

-(void)GettingMeeting{
    
    [self currentDayValidation];
    
    PassedJSon = [[NSArray alloc]init];
    dateArr = [[NSMutableArray alloc]init];
    mesgArr = [[NSMutableArray alloc]init];
    
    
    PassedJSon = allData[@"list"];
    
    dateArr = [PassedJSon valueForKey:@"sndTm"];
   
      mesgArr = [[PassedJSon valueForKey:@"ntfyMsg"]valueForKey:@"msg"];
   
    
    
    
    int count = 0 ;
    allDatesArray = [[NSMutableArray alloc]init];
    
    
    NSMutableArray *arrayToday = [[NSMutableArray alloc]init];
    
    NSMutableArray*dates = [[NSMutableArray alloc]init];
    for (NSDictionary*dict in dateArr)
        
    {
        count = count + 1;
        
        i = count - 1 ;
        
        NSString *str = [dateArr objectAtIndex:i];
        mesg = [mesgArr objectAtIndex:i];
        
        double miliSecend = str.doubleValue;
        takeTM = [NSDate dateWithTimeIntervalSince1970:miliSecend/1000];
        NSLog(@"%@",takeTM);
        NSTimeInterval sec = 5.51 * 60 * 60 ;
        takeTM = [takeTM dateByAddingTimeInterval:sec];
        
        [dates addObject:takeTM];
        
        
        

    }
    
    
     int cou = 0 ;
    
    for (NSMutableDictionary*dict in PassedJSon) {
        
        cou = cou + 1;
        
        int j = cou - 1 ;
        
        [dict setValue:dates[j] forKey:@"Date"];
        
        [allDataArray addObject:dict];
        
        [verifyArrayData addObject:dict];
            
        
        
        
        
        NSString *str = [dateArr objectAtIndex:j];
        mesg = [mesgArr objectAtIndex:j];
        
        double miliSecend = str.doubleValue;
        takeTM = [NSDate dateWithTimeIntervalSince1970:miliSecend/1000];
        NSLog(@"%@",takeTM);
        NSTimeInterval sec = 5.51 * 60 * 60 ;
        takeTM = [takeTM dateByAddingTimeInterval:sec];
        
       
        
        
        
        if ([takeTM  compare:startToday]>0 && [takeTM compare:endToday]<0)
        {
            
           [todayArray addObject:dict];
         NSPredicate *predicate = [NSPredicate predicateWithFormat:@"ntfyTyp == 1"];
            NSArray*arr = [todayArray filteredArrayUsingPredicate:predicate];
            if (arr.count>0) {
                 todayFinalArray = [[NSMutableArray alloc]initWithArray:arr];
                
            }else{
               
                
                
                
            }
            
            
            NSPredicate *predicate1 = [NSPredicate predicateWithFormat:@"ntfyTyp == 2"];
            NSArray*arr1 = [todayArray filteredArrayUsingPredicate:predicate1];
            if (arr1.count>0)
                
            {
                
                variFyArray = [[NSMutableArray alloc]initWithArray:arr1];
                
            }

             [self.TodayTableView reloadData];

            
        }
        else
            
        {
            
            NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
            
            [dateFormat setDateFormat:@"dd-MMM-yyyy HH:mm"];
            
            NSString *finalDate = [dateFormat stringFromDate:takeTM];
            
            NSLog(@"finalDate==%@",finalDate);
            [previousArray addObject:dict];
            
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"ntfyTyp == 1"];
            NSArray*arr = [previousArray filteredArrayUsingPredicate:predicate];
            if (arr.count>0)
            {
                
                PreviousFinalArray = [[NSMutableArray alloc]initWithArray:arr];
                

                
            }else{
                
               
                
            }

            
            NSPredicate *predicate1 = [NSPredicate predicateWithFormat:@"ntfyTyp == 2"];
            NSArray*arr1 = [previousArray filteredArrayUsingPredicate:predicate1];
            if (arr1.count>0)
                
            {
                
                variFyArray = [[NSMutableArray alloc]initWithArray:arr1];
                
            }
            
            
            
            
        }

        
                
    }
    
    
    
    if (todayFinalArray.count > 0) {
        [self.txtToday setHidden:YES];
        [self.TodayTableView setHidden:NO];

        
    }else{
        
        [self.txtToday setHidden:NO];
        [self.TodayTableView setHidden:YES];
    }
    
    
    
    
    if (PreviousFinalArray.count > 0) {
        [self.txtPrevious setHidden:YES];
        [self.PreviewTableView setHidden:NO];
        
        
    }else{
        
        [self.txtPrevious setHidden:NO];
        [self.PreviewTableView setHidden:YES];
    }

    
    
    if (variFyArray.count > 0) {
        [self.txtVerifyAccount setHidden:YES];
        [self.TableViewVerifyAccount setHidden:NO];
        
        
    }else{
        
        [self.txtVerifyAccount setHidden:NO];
        [self.TableViewVerifyAccount setHidden:YES];
    }
    
    
    
    [_TodayTableView reloadData];
    
    [_PreviewTableView reloadData];
    
    [_TableViewVerifyAccount reloadData];

    
}








-(void)currentDayValidation{
    
    
    
    NSDate* today = [[NSDate alloc] init];
    
    NSCalendar* currentCalendar = [NSCalendar currentCalendar];
    [currentCalendar setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    
    NSDateComponents* dateComponents = [currentCalendar components:NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitYear fromDate:today];
    
    NSInteger thisMonth = [dateComponents month];
    NSInteger thisDay = [dateComponents day];
    NSInteger thisYear = [dateComponents year];
    NSDateComponents* startDayComponents = [[NSDateComponents alloc] init];
    [startDayComponents setDay:thisDay];
[startDayComponents  setMonth:thisMonth];
    [startDayComponents setYear:thisYear];
    [startDayComponents setHour:00];
    [startDayComponents setMinute:00];
    [startDayComponents setSecond:00];
    
    
    startToday  = [currentCalendar dateFromComponents:startDayComponents];
    NSLog(@"%@",startToday);
    
    
    NSDateComponents* endOdDayComponents = [[NSDateComponents alloc] init];
    [endOdDayComponents setDay:thisDay];
    [endOdDayComponents setMonth:thisMonth];
    [endOdDayComponents setYear:thisYear];
    [endOdDayComponents setHour:23];
    [endOdDayComponents setMinute:59];
    [endOdDayComponents setSecond:59];
    
    endToday  = [currentCalendar dateFromComponents:endOdDayComponents];
    NSLog(@"%@",endToday);
    
    
}


- (IBAction)btnBack:(id)sender

{
    
    self.ViewVerifyAccount.hidden =YES;
    
}

- (IBAction)btnApprove:(id)sender
{
    
    
    [self accpetRequestAPI];
    
    
    
}

- (IBAction)btnReject:(id)sender
{
    
    [self RejectRequestAPI];
    
}

-(void)accpetRequestAPI
{
    NSString *otdat;
    
     NSError *linkError;
   
    
    
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    
    otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/editprofileacccept"];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    Tokenstr =@"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MDExMDU2MTg3OlJPTEVfU1VQRVJfQURNSU46MTc3MCIsImlhdCI6MTQ5NDgzNDE4OH0.YrwI-7Ma2bqZE58yTRjB79rgXn0g8jzyi58aK_C3DXg";
    
    //@"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI4MDU0NTExMDMxOlJPTEVfSE9TVDoxNzcwIiwiaWF0IjoxNDk0OTI3NDQ1fQ.2KxqeAE4Ju6EQRlM1MLTJbWN0ZpGdfht3Ff8b9Dno14";
    //@"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MDExMDU2MTg3OlJPTEVfU1VQRVJfQURNSU46MTc3MCIsImlhdCI6MTQ5NDgzNDE4OH0.YrwI-7Ma2bqZE58yTRjB79rgXn0g8jzyi58aK_C3DXg";
    
    [SendingRequest addValue:Tokenid forHTTPHeaderField:@"token"];
    
    
    [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
    
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    NSMutableDictionary *dataSend = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"accept",@"edtSts",strdata,@"ntfyId",nil];
    NSLog(@" %@",dataSend);
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:dataSend options:0 error:&linkError];
    
    [SendingRequest setHTTPBody:postData];

    
    
    
    
    [SendingRequest setHTTPMethod:@"POST"];
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              dispatch_async(dispatch_get_main_queue(),^
                                                             {
                                                                 
                                                                 NSError *jsonError;
                                                                 
                                                                 
                                                                 AcceptData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                                 
                                                                 NSLog(@"%@",AcceptData);
                                                                 
                                                                 NSString *strResult = [NSString stringWithFormat:@"success"];
                                                                 
                                                                 if ([strResult isEqualToString:[AcceptData valueForKey:@"message"]]) {
                                                                     
                                                                     UIAlertController * alertData= [UIAlertController alertControllerWithTitle: @"" message:@"Request is Approved" preferredStyle:UIAlertControllerStyleAlert];
                                                                     
                                                                     UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                                                 
                                                                                                 {
                                                                                                     
                                                                                                     [self performSelectorOnMainThread:@selector(reloadpage) withObject:nil waitUntilDone:YES];
                                                                                                     
                                                                                                 
                                                                                                 }];
                                                                     
                                                                     [alertData addAction:errorPass];
                                                                     
                                                                     [self presentViewController:alertData animated:YES completion:nil];
                                                                     
                                                                     
                                                                     
                                                                     
                                                                 }
;
                                                                 
                                                                 
                                                                 
                                                             });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
}
-(void)reloadpage
{
    [self OtpEqualDataWithNumber];
    
    
    self.ViewVerifyAccount .hidden =YES;
    
}




-(void)RejectRequestAPI
{
    
    NSString *otdat;
    NSError *linkError;
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    
    otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/editprofileacccept"];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    Tokenstr =@"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MDExMDU2MTg3OlJPTEVfU1VQRVJfQURNSU46MTc3MCIsImlhdCI6MTQ5NDgzNDE4OH0.YrwI-7Ma2bqZE58yTRjB79rgXn0g8jzyi58aK_C3DXg";
    
    //@"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI4MDU0NTExMDMxOlJPTEVfSE9TVDoxNzcwIiwiaWF0IjoxNDk0OTI3NDQ1fQ.2KxqeAE4Ju6EQRlM1MLTJbWN0ZpGdfht3Ff8b9Dno14";
    //@"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MDExMDU2MTg3OlJPTEVfU1VQRVJfQURNSU46MTc3MCIsImlhdCI6MTQ5NDgzNDE4OH0.YrwI-7Ma2bqZE58yTRjB79rgXn0g8jzyi58aK_C3DXg";
    
    [SendingRequest addValue:Tokenid forHTTPHeaderField:@"token"];
    
    
    [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
    
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    NSMutableDictionary *dataSend = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"reject",@"edtSts",strdata,@"ntfyId",nil];
    NSLog(@" %@",dataSend);
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:dataSend options:0 error:&linkError];
    
    [SendingRequest setHTTPBody:postData];
    
    
    
    
    
    [SendingRequest setHTTPMethod:@"POST"];
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              dispatch_async(dispatch_get_main_queue(),^
                                                             {
                                                                 
                                                                 NSError *jsonError;
                                                                 
                                                                 
                                                                 RejectData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                                 
                                                                 NSLog(@"%@",RejectData);
                                                                 
                                                                 NSString *strResult = [NSString stringWithFormat:@"success"];
                                                                 
                                                                 if ([strResult isEqualToString:[RejectData valueForKey:@"message"]]) {
                                                                     
                                                                     UIAlertController * alertData= [UIAlertController alertControllerWithTitle: @"" message:@"Request is rejected" preferredStyle:UIAlertControllerStyleAlert];
                                                                     
                                                                     UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                                                 
                                                                    {
                                                                                                     
                                                                        [self performSelectorOnMainThread:@selector(RejectReload) withObject:nil waitUntilDone:YES];
                                                                        
                                                                    }];
                                                                     
                                                                     [alertData addAction:errorPass];
                                                                     
                                                                     [self presentViewController:alertData animated:YES completion:nil];
                                                                     
                                                                     
                                                                     
                                                                     
                                                                 }
                                                                 
                                                                 
                                                                 //                                                                 [self performSelectorOnMainThread:@selector(GettingMeeting) withObject:nil waitUntilDone:YES];
                                                                 
                                                                 
                                                                 
                                                             });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
}
-(void)RejectReload
{
    [self OtpEqualDataWithNumber];
    
    
    self.ViewVerifyAccount.hidden =YES;
    
    
   }
    
    
    



- (IBAction)btnJoin:(id)sender

{
    
    [self JoinAPI];

    
}

-(void)JoinAPI

{
    NSString *otdat;
    NSError *linkError;
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    NSLog(@"%@",TodayNotifyID);
    NSLog(@"%@",TodayStatus);
    

    
    
    
    otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/perstatus?confId=%@&mobile=%@&personId=%@&perSts=%@&comment=%@",confIdString,pmobile,personId,@"accept",@"APP"];

    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    Tokenstr =@"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MDExMDU2MTg3OlJPTEVfU1VQRVJfQURNSU46MTc3MCIsImlhdCI6MTQ5NDgzNDE4OH0.YrwI-7Ma2bqZE58yTRjB79rgXn0g8jzyi58aK_C3DXg";
    
    
    [SendingRequest addValue:Tokenid forHTTPHeaderField:@"token"];
    
    
    [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
    
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              dispatch_async(dispatch_get_main_queue(),^
                                                             {
                                                                 
                                                                 NSError *jsonError;
                                                                 
                                                                 
                                                                 AcceptData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                                 
                                                                 NSLog(@"%@",AcceptData);
                                                                 
                                                                 NSString *strResult = [NSString stringWithFormat:@"success"];
                                                                 
                                                                 if ([strResult isEqualToString:[AcceptData valueForKey:@"message"]]) {
                                                                     
                                                                     UIAlertController * alertData= [UIAlertController alertControllerWithTitle: @"" message:@"ConferenceCall is Accepted" preferredStyle:UIAlertControllerStyleAlert];
                                                                     
                                                                     UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                                                 
                                                                                                 {
                                                                                                     
                                                                                                     [self performSelectorOnMainThread:@selector(JoinUpdateMeeting) withObject:nil waitUntilDone:YES]; 
                                                                                                     
                                                                                                 }];
                                                                     
                                                                     [alertData addAction:errorPass];
                                                                     
                                                                     [self presentViewController:alertData animated:YES completion:nil];
                                                                     
                                                                     
                                                                     
                                                                     
                                                                 }
                                                                 
                                                                 
                                                                 //                                                                 [self performSelectorOnMainThread:@selector(GettingMeeting) withObject:nil waitUntilDone:YES];
                                                                 
                                                                 
                                                                 
                                                             });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
}


- (IBAction)btnDecline:(id)sender {
    
    NSString *otdat;
    NSError *linkError;
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    NSLog(@"%@",TodayNotifyID);
    NSLog(@"%@",TodayStatus);
    
    
    otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/perstatus?confId=%@&mobile=%@&personId=%@&perSts=%@&comment=%@",confIdString,pmobile,personId,@"reject",@"APP"];

    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    Tokenstr =@"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MDExMDU2MTg3OlJPTEVfU1VQRVJfQURNSU46MTc3MCIsImlhdCI6MTQ5NDgzNDE4OH0.YrwI-7Ma2bqZE58yTRjB79rgXn0g8jzyi58aK_C3DXg";
    
     [SendingRequest addValue:Tokenstr forHTTPHeaderField:@"token"];
    
    
    [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
    
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              dispatch_async(dispatch_get_main_queue(),^
                                                             {
                                                                 
                                                                 NSError *jsonError;
                                                                 
                                                                 
                                                                 AcceptData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                                 
                                                                 NSLog(@"%@",AcceptData);
                                                                 
                                                                 NSString *strResult = [NSString stringWithFormat:@"success"];
                                                                 
                                                                 if ([strResult isEqualToString:[AcceptData valueForKey:@"message"]]) {
                                                                     
                                                                     UIAlertController * alertData= [UIAlertController alertControllerWithTitle: @"" message:@"ConferenceCall is Rejected" preferredStyle:UIAlertControllerStyleAlert];
                                                                     
                                                                     UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                                                 
                                                                                                 {
                                                                                                     
                                                                                                   [self performSelectorOnMainThread:@selector(JoinUpdateMeeting) withObject:nil waitUntilDone:YES];
                                                                                                     
                                                                                                 }];
                                                                     
                                                                     [alertData addAction:errorPass];
                                                                     
                                                                     [self presentViewController:alertData animated:YES completion:nil];
                                                                     
                                                                     
                                                                     
                                                                     
                                                                 }
                                                                 
                                                                 
                                                                 //                                                                 [self performSelectorOnMainThread:@selector(GettingMeeting) withObject:nil waitUntilDone:YES];
                                                                 
                                                                 
                                                                 
                                                             });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
}

    
    


- (IBAction)btnMayBe:(id)sender

{
    NSString *otdat;
    NSError *linkError;
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    NSLog(@"%@",TodayNotifyID);
    NSLog(@"%@",TodayStatus);
    
    
    otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/perstatus?confId=%@&mobile=%@&personId=%@&perSts=%@&comment=%@",confIdString,pmobile,personId,@"maybe",@"APP"];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
//    Tokenstr =@"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MDExMDU2MTg3OlJPTEVfU1VQRVJfQURNSU46MTc3MCIsImlhdCI6MTQ5NDgzNDE4OH0.YrwI-7Ma2bqZE58yTRjB79rgXn0g8jzyi58aK_C3DXg";
    
    
    [SendingRequest addValue:Tokenid forHTTPHeaderField:@"token"];
    
    
    [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
    
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              dispatch_async(dispatch_get_main_queue(),^
                                                             {
                                                                 
                                                                 NSError *jsonError;
                                                                 
                                                                 
                                                                 AcceptData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                                 
                                                                 NSLog(@"%@",AcceptData);
                                                                 
                                                                 NSString *strResult = [NSString stringWithFormat:@"success"];
                                                                 
                                                                 if ([strResult isEqualToString:[AcceptData valueForKey:@"message"]]) {
                                                                     
                                                                     UIAlertController * alertData= [UIAlertController alertControllerWithTitle: @"" message:@"ConferenceCall is MayBe" preferredStyle:UIAlertControllerStyleAlert];
                                                                     
                                                                     UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                                                 
                                                                                                 {
                                                                                                     
                                                                                                   [self performSelectorOnMainThread:@selector(JoinUpdateMeeting) withObject:nil waitUntilDone:YES];
                                                                                                     
                                                                                                 }];
                                                                     
                                                                     [alertData addAction:errorPass];
                                                                     
                                                                     [self presentViewController:alertData animated:YES completion:nil];
                                                                     
                                                                     
                                                                     
                                                                     
                                                                 }
                                                                 
                                                             });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
}


- (IBAction)BtnCrossConference:(id)sender

{
    
    self.ConferenceDetailsView.hidden=YES;
    
    self.ViewTodayConference.hidden=YES;
    
    
}


-(void)JoinUpdateMeeting
{
    NSString*strNum ;
    strNum =@"2";
    
    //6678
    NSLog(@"%@",TodayNotifyID);
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/notification/secure/update?ntfyId=%@&ntfyStatus=%@",TodayNotifyID,strNum];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];

    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    NSURL*LinkUrl = [NSURL URLWithString:apiURLStr];
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:LinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    [SendingRequest addValue:Tokenid forHTTPHeaderField:@"token"];
    
    
    [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
    
    [SendingRequest setHTTPMethod:@"POST"];
    
    
    NSURLSessionDataTask *postData = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
    
     {
                
                // NSError* error;
                if (data != nil) {
                   
                    cities =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                    
                    
                    [self performSelectorOnMainThread:@selector(relaodTable) withObject:nil waitUntilDone:YES];
                    
                   
                    
                   
                }
                
                
              //  NSLog(@"%@",cities);
                
                
            }];
    [postData resume];
}
-(void)relaodTable
{
    
    if ([[cities valueForKey:@"message"] isEqualToString:@"success"]) {
        
        self.ConferenceDetailsView.hidden=YES;
        
        self.ViewTodayConference.hidden=YES;
        //  [self.TodayTableView reloadData];
        
        [self viewDidLoad];
        
    }
    
    
    
}
    
    

    

    
    
//    refresh = [[UIRefreshControl alloc]init];
//    
//    [refresh addTarget:self action:@selector(reloadTableData) forControlEvents:UIControlEventValueChanged];
//    
//   // [self.view addSubview:refresh];
// [self.TodayTableView addSubview:refresh];
    //[self.view addSubview:refresh];
    



- (IBAction)NotBackClicked:(id)sender {
    
    
    [self.navigationController popViewControllerAnimated:YES];

    
}


@end
