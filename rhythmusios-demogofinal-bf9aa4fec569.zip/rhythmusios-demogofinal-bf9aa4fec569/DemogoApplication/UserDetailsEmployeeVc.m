//
//  UserDetailsEmployeeVc.m
//  DemogoApplication
//
//  Created by katoch on 26/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "UserDetailsEmployeeVc.h"
#import "AppDelegate.h"
#import "KVNProgress.h"
#define ACCEPTABLE_CHARACTERS @"0123456789"
#define ACCEPTABLE_alphabets @"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
#import "Reachability.h"


@interface UserDetailsEmployeeVc ()<NSURLSessionDelegate,NSURLSessionDataDelegate>

@end

@implementation UserDetailsEmployeeVc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UITapGestureRecognizer *gesRecognizer4 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchScreen)]; // Declare the Gesture.
    gesRecognizer4.delegate = self;
    [self.view addGestureRecognizer:gesRecognizer4];
    
    
    
    self.txtAddbtn.layer.cornerRadius = 5.5f;
    
 UIColor *color = [UIColor colorWithRed:148/255.0f green:148/255.0f blue:148/255.0f alpha:1];
    
    _txtEmployeeId.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Employee ID (minimum 4 digits)" attributes:@{NSForegroundColorAttributeName: color}];
        _txtDepartment.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Select Department" attributes:@{NSForegroundColorAttributeName: color}];
    
    
    
    
    _lbleditUser.layer.cornerRadius = 5.0f ;
    [_lbleditUser clipsToBounds];
    
    NSLog(@"%@",_EditStr);
    
    if ([_EditStr isEqualToString:@"EditDetails"]) {
        
        _txtRoleheight.constant = 0 ;
        _txtRoleTop.constant = 0 ;
        _lblRoleHeight.constant = 0;
        _lblRoleTop.constant = 0 ;
        
        _txtPortTop.constant = 0 ;
        _txtPortHeight.constant = 0 ;
        _lblPortTop.constant = 0;
        _lblPortHeight.constant = 0;
        
        self.lblUserDetails.hidden= YES;
        self.lbleditUser.hidden = NO;
        
        [self.txtAddbtn setTitle:@"Update" forState:UIControlStateNormal];
        
        
        self.DetailHeightLayout.constant = 564 ;
        [self.view layoutIfNeeded];
        
        
        NSLog(@"%@",_editDetailArray);
        
        self.firstName.text =  [_editDetailArray valueForKey:@"firstName"];
        
        self.lastName.text = [_editDetailArray valueForKey:@"lastName"];
        self.mobileNo.text = [_editDetailArray valueForKey:@"pmobile"];
        self.emailId.text =[_editDetailArray valueForKey:@"pemail"];
        self.txtLocation.text = [_editDetailArray valueForKey:@"location"];
        self.txtEmployeeId.text = [_editDetailArray valueForKey:@"empId"];
        self.txtDepartment.text =[_editDetailArray valueForKey:@"depName"];
       
    }
    else{
        
        _txtRoleheight.constant = 35 ;
        _txtRoleTop.constant = 28 ;
        _lblRoleHeight.constant = 1;
        _lblRoleTop.constant = 2 ;
        
        _txtPortTop.constant = 0 ;
        _txtPortHeight.constant = 0 ;
        _lblPortTop.constant = 0;
        _lblPortHeight.constant = 0;
        
        self.lblUserDetails.hidden= NO;
        self.lbleditUser.hidden = YES;
        
        self.DetailHeightLayout.constant = 627 ;
        [self.view layoutIfNeeded];

        
         [self.txtAddbtn setTitle:@"Add" forState:UIControlStateNormal];
        
    }
    
    
    
                ///////   Cmpid ,personId, tokenID
    
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personid = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:YES];
    
    
    roleArray = [[NSMutableArray alloc]initWithObjects:@"PARTICIPANT",@"HOST", nil];
    
    
    _txtRole.rightViewMode = UITextFieldViewModeAlways;
    _txtRole.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    
    _txtRole.leftViewMode = UITextFieldViewModeAlways;
    _txtRole.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pr.png"]];
    
    _firstName.leftViewMode = UITextFieldViewModeAlways;
    _firstName.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pr.png"]];
    
    _lastName.leftViewMode = UITextFieldViewModeAlways;
    _lastName.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pr.png"]];
    
    _mobileNo.leftViewMode = UITextFieldViewModeAlways;
    _mobileNo.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"iPhone.png"]];
    
    _emailId.leftViewMode = UITextFieldViewModeAlways;
    _emailId.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"EmailnewPic.png"]];
    
    _txtLocation.leftViewMode = UITextFieldViewModeAlways;
    _txtLocation.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"LocationNew.png"]];
    
    _txtRole.leftViewMode = UITextFieldViewModeAlways;
    _txtRole.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pr.png"]];
    
    _txtEmployeeId.leftViewMode = UITextFieldViewModeAlways;
    _txtEmployeeId.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pr.png"]];
    
    _txtEmployeeId.leftViewMode = UITextFieldViewModeAlways;
    _txtEmployeeId.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pr.png"]];


    _txtDepartment.rightViewMode = UITextFieldViewModeAlways;
    _txtDepartment.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    
    
    
    
    // Do any additional setup after loading the view.
}

-(void)touchScreen{
    
    [self.firstName  resignFirstResponder];
    [self.lastName resignFirstResponder];
    [self.mobileNo resignFirstResponder];
    [self.emailId resignFirstResponder];
    [self.txtLocation resignFirstResponder];
    [_txtRole resignFirstResponder];
    [_txtPort resignFirstResponder];
    [_txtEmployeeId resignFirstResponder];
    
    self.scrollView.contentOffset = CGPointMake(0, 0);

    [dropDownView closeAnimation];
    
    
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
   
    if ([touch.view isDescendantOfView:dropDownView.view]) {
        
        
        
        return NO;
    }
    
    
    
    return YES;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)txtEmployeeId:(UITextField *)sender {
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
//     if ([_EditStr isEqualToString:@"EditDetails"]) {
//         
//         self.DetailHeightLayout.constant = 564 ;
//         [self.view layoutIfNeeded];
//
//         
//     }
//     else{
//         
//         
//            self.DetailHeightLayout.constant = 627 ;
//             [self.view layoutIfNeeded];
//             
//             
//      
//     }
    
 
    
    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    
    int y = 0 ;
    


    
    
    if (textField == self.firstName) {
        
        [_lblFirstName setBackgroundColor:[UIColor colorWithRed:0/255.0f green:171/255.0f blue:226/255.0f alpha:1]];
        
        [self.lblLastName setBackgroundColor:[UIColor whiteColor]];
         [self.lblMobile setBackgroundColor:[UIColor whiteColor]];
         [self.lblEMPLOYEE setBackgroundColor:[UIColor whiteColor]];
         [self.lblRole setBackgroundColor:[UIColor whiteColor]];
         [self.lblPorts setBackgroundColor:[UIColor whiteColor]];
         [self.lblLocation setBackgroundColor:[UIColor whiteColor]];
        [self.lblEmail setBackgroundColor:[UIColor whiteColor]];
        
         y = 0 ;
//        [UIView animateWithDuration:0.5 animations:^{
//            
//            self.topLayout.constant = 0 ;
//            [self.view layoutIfNeeded];
//
//        }];

        
        
        
    }
   else if (textField == self.lastName) {
        
        [_lblLastName setBackgroundColor:[UIColor colorWithRed:0/255.0f green:171/255.0f blue:226/255.0f alpha:1]];
       [self.lblFirstName setBackgroundColor:[UIColor whiteColor]];
       [self.lblMobile setBackgroundColor:[UIColor whiteColor]];
       [self.lblEMPLOYEE setBackgroundColor:[UIColor whiteColor]];
       [self.lblRole setBackgroundColor:[UIColor whiteColor]];
       [self.lblPorts setBackgroundColor:[UIColor whiteColor]];
       [self.lblLocation setBackgroundColor:[UIColor whiteColor]];
       [self.lblEmail setBackgroundColor:[UIColor whiteColor]];
       

       y = 0 ;
       
       
//       [UIView animateWithDuration:0.5 animations:^{
//
//       self.topLayout.constant = 0 ;
//       [self.view layoutIfNeeded];
//           
//            }];

       
   }else if (textField == self.mobileNo) {
       
       [_lblMobile setBackgroundColor:[UIColor colorWithRed:0/255.0f green:171/255.0f blue:226/255.0f alpha:1]];
//       [UIView animateWithDuration:0.5 animations:^{
//
//       self.topLayout.constant = 0 ;
//       [self.view layoutIfNeeded];
//           
//            }];
       
       
       y = 80 ;
       
       [self.lblFirstName setBackgroundColor:[UIColor whiteColor]];
       [self.lblLastName setBackgroundColor:[UIColor whiteColor]];
       [self.lblEMPLOYEE setBackgroundColor:[UIColor whiteColor]];
       [self.lblRole setBackgroundColor:[UIColor whiteColor]];
       [self.lblPorts setBackgroundColor:[UIColor whiteColor]];
       [self.lblLocation setBackgroundColor:[UIColor whiteColor]];
       [self.lblEmail setBackgroundColor:[UIColor whiteColor]];

       
       
   }else if (textField == self.emailId) {
       
       [_lblEmail setBackgroundColor:[UIColor colorWithRed:0/255.0f green:171/255.0f blue:226/255.0f alpha:1]];
       [self.lblFirstName setBackgroundColor:[UIColor whiteColor]];
       [self.lblLastName setBackgroundColor:[UIColor whiteColor]];
       [self.lblEMPLOYEE setBackgroundColor:[UIColor whiteColor]];
       [self.lblRole setBackgroundColor:[UIColor whiteColor]];
       [self.lblPorts setBackgroundColor:[UIColor whiteColor]];
       [self.lblLocation setBackgroundColor:[UIColor whiteColor]];
       [self.lblMobile setBackgroundColor:[UIColor whiteColor]];
       
       
       
       y = 150 ;
       
//       [UIView animateWithDuration:0.5 animations:^{
//
//       self.topLayout.constant = -170 ;
//       [self.view layoutIfNeeded];
//            }];

       
   }else if (textField == self.txtLocation) {
       
       [_lblLocation setBackgroundColor:[UIColor colorWithRed:0/255.0f green:172/255.0f blue:226/255.0f alpha:1]];
       
       [self.lblFirstName setBackgroundColor:[UIColor whiteColor]];
       [self.lblLastName setBackgroundColor:[UIColor whiteColor]];
       [self.lblEMPLOYEE setBackgroundColor:[UIColor whiteColor]];
       [self.lblRole setBackgroundColor:[UIColor whiteColor]];
       [self.lblPorts setBackgroundColor:[UIColor whiteColor]];
       [self.lblEmail setBackgroundColor:[UIColor whiteColor]];
       [self.lblMobile setBackgroundColor:[UIColor whiteColor]];
       
       
       y = 230 ;
     //  [UIView animateWithDuration:0.5 animations:^{
//       self.topLayout.constant = -240 ;
//       [self.view layoutIfNeeded];
//           
//            }];

       
   }else if (textField == self.txtRole) {
       
         [_txtLocation resignFirstResponder];
       
       [_lblRole setBackgroundColor:[UIColor colorWithRed:0/255.0f green:172/255.0f blue:226/255.0f alpha:1]];
       [self.lblFirstName setBackgroundColor:[UIColor whiteColor]];
       [self.lblLastName setBackgroundColor:[UIColor whiteColor]];
       [self.lblEMPLOYEE setBackgroundColor:[UIColor whiteColor]];
       [self.lblLocation setBackgroundColor:[UIColor whiteColor]];
       [self.lblPorts setBackgroundColor:[UIColor whiteColor]];
       [self.lblEmail setBackgroundColor:[UIColor whiteColor]];
       [self.lblMobile setBackgroundColor:[UIColor whiteColor]];

       y = 300 ;
       
//       [UIView animateWithDuration:0.5 animations:^{
//
//       self.topLayout.constant = -300 ;
//       [self.view layoutIfNeeded];
//        }];
       
       
       dropDownView = [[DropDownView alloc] initWithArrayData: roleArray  cellHeight:30 heightTableView:60 paddingTop:0 paddingLeft:0 paddingRight:0 refView:textField animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
       
       
       
       dropDownView.delegate = self;
       
       [self.scrollSubView addSubview:dropDownView.view];
       self.dropDownTxtfield = textField ;
       [dropDownView openAnimation];
       
       return NO;
       
       
       
   }
   else if (textField == self.txtPort) {
//       [UIView animateWithDuration:0.5 animations:^{
 [_lblPorts setBackgroundColor:[UIColor colorWithRed:0/255.0f green:172/255.0f blue:226/255.0f alpha:1]];
           
           [self.lblFirstName setBackgroundColor:[UIColor whiteColor]];
           [self.lblLastName setBackgroundColor:[UIColor whiteColor]];
           [self.lblEMPLOYEE setBackgroundColor:[UIColor whiteColor]];
           [self.lblLocation setBackgroundColor:[UIColor whiteColor]];
           [self.lblRole setBackgroundColor:[UIColor whiteColor]];
           [self.lblEmail setBackgroundColor:[UIColor whiteColor]];
           [self.lblMobile setBackgroundColor:[UIColor whiteColor]];
           
       y = 370 ;
       
       self.DetailHeightLayout.constant = 690 ;
       [self.view layoutIfNeeded];
       
//       self.topLayout.constant = -370 ;
//       [self.view layoutIfNeeded];
//           
//            }];
       
   }
    
  
   else if (textField == self.txtEmployeeId) {
       
       [_lblEMPLOYEE setBackgroundColor:[UIColor colorWithRed:0/255.0f green:172/255.0f blue:226/255.0f alpha:1]];
       
       
       [self.lblFirstName setBackgroundColor:[UIColor whiteColor]];
       [self.lblLastName setBackgroundColor:[UIColor whiteColor]];
       [self.lblPorts setBackgroundColor:[UIColor whiteColor]];
       [self.lblLocation setBackgroundColor:[UIColor whiteColor]];
       [self.lblRole setBackgroundColor:[UIColor whiteColor]];
       [self.lblEmail setBackgroundColor:[UIColor whiteColor]];
       [self.lblMobile setBackgroundColor:[UIColor whiteColor]];
       
       
       
       if ([_txtRole.text isEqualToString:@"HOST"]) {
           self.DetailHeightLayout.constant = 690 ;
           [self.view layoutIfNeeded];
           
           y = 400 ;
           
       }else{
           
           y =  400 ;
           self.DetailHeightLayout.constant = 627 ;
           [self.view layoutIfNeeded];
           
           
       }

//           if ( self.DetailHeightLayout.constant == 564) {
//               
//               
//               y = 270 ;
//               
////               [UIView animateWithDuration:0.5 animations:^{
////               self.topLayout.constant = -270 ;
////                   [self.view layoutIfNeeded];
////                   
////               }];
//
//           }
//           else{
//               
//               y = 400 ;
//               
////               [UIView animateWithDuration:0.5 animations:^{
////               self.topLayout.constant = -400 ;
////               [self.view layoutIfNeeded];
////               
////           }];
//               
//           }
//       

       
   }
    
   else if (textField == self.txtDepartment) {
   //    [UIView animateWithDuration:0.5 animations:^{
       if (dropDownView != nil) {
           [dropDownView.view removeFromSuperview];
           dropDownView = nil;
       }
       
           [self userDetailsFromServer];
           
           
           [_txtEmployeeId resignFirstResponder];
           
           [self.lblEMPLOYEE setBackgroundColor:[UIColor whiteColor]];
           [self.lblFirstName setBackgroundColor:[UIColor whiteColor]];
           [self.lblLastName setBackgroundColor:[UIColor whiteColor]];
           [self.lblPorts setBackgroundColor:[UIColor whiteColor]];
           [self.lblLocation setBackgroundColor:[UIColor whiteColor]];
           [self.lblRole setBackgroundColor:[UIColor whiteColor]];
           [self.lblEmail setBackgroundColor:[UIColor whiteColor]];
           [self.lblMobile setBackgroundColor:[UIColor whiteColor]];
           
           y = 350 ;
           
//       self.topLayout.constant = -350;
           
            self.DetailHeightLayout.constant = 800 ;
       [self.view layoutIfNeeded];
          
//            }];

       return NO;
       
   }
    
    [UIView animateWithDuration:0.5 animations:^{
        self.scrollView.contentOffset = CGPointMake(0, y);
        
    }];
    
    
    return YES ;
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{

    
//    self.scrollView.contentOffset = CGPointMake(0, self.scrollView.contentSize.height + 67 - self.view.frame.size.height);
    
    [textField resignFirstResponder];
    
    return  YES;
    
    
}

-(void)dropDownCellSelected:(NSInteger)returnIndex{
    
    int y = 0 ;
    
    
    if (_dropDownTxtfield == _txtRole) {
        
       
        
        self.dropDownTxtfield.text = [roleArray objectAtIndex:returnIndex];
        
        if ([self.dropDownTxtfield.text isEqualToString:@"HOST"]) {
            
            
            
            _txtPortTop.constant = 28 ;
            _txtPortHeight.constant = 35 ;
            _lblPortTop.constant = 2;
            _lblPortHeight.constant = 1;

                self.DetailHeightLayout.constant = 690 ;
                [self.view layoutIfNeeded];
                
         //   }];
        }else{
            
            _txtPortTop.constant = 0 ;
            _txtPortHeight.constant = 0 ;
            _lblPortTop.constant = 0;
            _lblPortHeight.constant = 0;

  
                self.DetailHeightLayout.constant = 627 ;


            
        }
        
        
    }else if (_dropDownTxtfield == _txtDepartment) {
        
        
        self.dropDownTxtfield.text = [[[departmentData valueForKey:@"dept"] valueForKey:@"depName"] objectAtIndex:returnIndex];
        
         if ([_EditStr isEqualToString:@"EditDetails"]) {
             //self.topLayout.constant =-250;
             
             y = 250 ;
             self.DetailHeightLayout.constant = 564 ;
           //  [self.view layoutIfNeeded];
             
         }else{
        
        if ([self.txtRole.text isEqualToString:@"HOST"]) {
            _txtPortTop.constant = 28 ;
            _txtPortHeight.constant = 35 ;
            _lblPortTop.constant = 2;
            _lblPortHeight.constant = 1;
            
            self.DetailHeightLayout.constant = 690 ;
          //  y = 250 ;
            
            

        }else{
            
            _txtPortTop.constant = 0 ;
            _txtPortHeight.constant = 0 ;
            _lblPortTop.constant = 0;
            _lblPortHeight.constant = 0;
            
         //   y = -250 ;
            
             self.DetailHeightLayout.constant = 627 ;
            

            
        }

         }
        
       


        self.scrollView.contentOffset = CGPointMake(0, self.scrollView.contentSize.height + 67 - self.view.frame.size.height);
        
    
    }
    
}

-(void)userDetailsFromServer{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/department"];
    
    
    
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithURL:[NSURL URLWithString:apiURLStr]
            completionHandler:^(NSData *data,
                                NSURLResponse *response,
                                NSError *error) {
                
                // NSError* error;
                if (data != nil) {
                    departmentData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                }
                
                
                NSLog(@"%@",departmentData);
                
                
                
                // listCompanies = [[profileData valueForKey:@"accountdata"]valueForKey:@"cmpNm"];
                
                [self performSelectorOnMainThread:@selector(showDepartmentList) withObject:nil waitUntilDone:YES];
                
                
            }] resume];
    
}

-(void)showDepartmentList{
    
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    
    
    dropDownView = [[DropDownView alloc] initWithArrayData: [[departmentData valueForKey:@"dept"] valueForKey:@"depName"]   cellHeight:30 heightTableView:150 paddingTop:0 paddingLeft:0 paddingRight:0 refView:self.txtDepartment animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    [self.scrollSubView addSubview:dropDownView.view];
    self.dropDownTxtfield = self.txtDepartment ;
    [dropDownView openAnimation];

}

- (IBAction)backClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)btnADD:(id)sender
{
    
    
    
    NSLog(@"%@",_firstName.text);
    NSLog(@"%@",_lastName.text);
    NSLog(@"%@",_mobileNo.text);
    NSLog(@"%@",_emailId.text);
    NSLog(@"%@",_txtLocation.text);
    NSLog(@"%@",_txtRole.text);
    
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable) {
        UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message: @"No Network Connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        [alert show];
        return;
        
        
    }else{
        

    
    
    if ([_EditStr isEqualToString:@"EditDetails"]) {
        
      //  || [_txtRole.text isEqualToString:@""]
        
        if ([_firstName.text isEqualToString:@""] || [_lastName.text isEqualToString:@""] || [_mobileNo.text isEqualToString:@""] || [_emailId.text isEqualToString:@""] || [_txtLocation.text isEqualToString:@""] ) {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Specify the Field" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alert show];
            
        }else if (!([_txtEmployeeId.text length]>=4)){
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Specify the Field" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alert show];
            
        }else{
            
            
            [KVNProgress show];
            
            
            [self updateDataFromServer];

        }
        
        
    }
    else{
        
        if ([_firstName.text isEqualToString:@""] ||[_lastName.text isEqualToString:@""]||[_mobileNo.text isEqualToString:@""] || [_emailId.text isEqualToString:@""] || [_txtLocation.text isEqualToString:@""] || [_txtRole.text isEqualToString:@""] ) {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Specify the Field" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alert show];
            
        }else if (!([_txtEmployeeId.text length]>=4)){
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Enter valid employee id" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alert show];
            
        }else{

            [KVNProgress show];
            
         [self PersonIdSetInServer];
            
        }
        
    }
        
    }
   
}


-(void)PersonIdSetInServer;

{
    
    NSError *error;
    NSString * urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/addperson"];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *url = [NSURL URLWithString:urlstring];
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
     [SendingRequest addValue:tokenid forHTTPHeaderField:@"token"];
    
    [SendingRequest setHTTPMethod:@"POST"];
    
    
    NSMutableDictionary *emailDicDta = [[NSMutableDictionary alloc]
                                        initWithObjectsAndKeys:@"PRIMARY",@"type",self.emailId.text,@"value", nil];
    
    
    NSMutableArray * emailArray =[[NSMutableArray alloc]init];
    
    [emailArray addObject:emailDicDta];
    
    
    NSMutableDictionary *mobileDicDta =
    [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"PRIMARY",@"type",self.mobileNo.text,@"value", nil];
    
    
    
    
    NSMutableArray *mobileArray =[[NSMutableArray alloc]init];
    
    [mobileArray addObject:mobileDicDta];
    
    NSString*roleee = self.txtRole.text ;
     if ([roleee isEqualToString:@"HOST"]) {
        roleee = @"ROLE_HOST" ;
        
    }else if ([roleee isEqualToString:@"PARTICIPANT"]) {
        roleee = @"ROLE_PARTICIPANT" ;
        
    }
    
    
    
    
    NSMutableDictionary *GetDicDta = [[NSMutableDictionary alloc]initWithObjectsAndKeys:
                                      companyId,@"cmpId",emailArray,@"email",mobileArray,@"mobile",
                                      self.firstName.text,@"firstName",
                                      self.lastName.text,@"lastName",
                                      self.txtLocation.text,@"location",
                                      self.txtDepartment.text,@"depName",
                                      roleee,@"role",
                                       self.txtPort.text,@"portCount",
                                      self.txtEmployeeId.text,@"empId",
                                      personid,@"hostId",
                                                                             nil];
    
    //NSLog(@"%@",cmp);
    
    NSLog(@"%@",GetDicDta);
    
    NSData* SendData= [NSJSONSerialization dataWithJSONObject:GetDicDta options:kNilOptions error:&error];
    
    [SendingRequest setHTTPBody:SendData];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                               [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
                                              
                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
                                              NSLog(@" the databse theXml is  =====  %@",theXML);
                                              
                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
                                              userEmailID = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                              NSLog(@"%@",userEmailID);
                                              NSLog(@"The State Response is  ===  %@" , userEmailID);
                                              
                                              NSLog(@"The State Response is  ===  %@" , [userEmailID valueForKey:@"responseCode"]);
                                              
                                               [self performSelectorOnMainThread:@selector(pushBackview) withObject:nil waitUntilDone:YES];
                                              
                                          }];
    
   // [self.TableCompanyList reloadData];
    
    [postDataTask resume];
    
}

-(void)pushBackview {
    
    if ([[userEmailID valueForKey:@"message"] isEqualToString:@"success"] ) {
        
        [self.navigationController popViewControllerAnimated:YES];
        
        
        
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message: [userEmailID valueForKey:@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
        
    }
    
}



-(void)updateDataFromServer{
    
    

    
    NSArray *arr = [NSArray arrayWithArray:[[_editDetailArray valueForKey:@"email"] valueForKey:@"type"]];
    NSArray *arr1 = [NSArray arrayWithArray:[[_editDetailArray valueForKey:@"email"] valueForKey:@"value"]];
    
    NSString *emailtype = arr[0];
    NSString *emailvalue = arr1[0];
    
    NSArray *ar = [NSArray arrayWithArray:[[_editDetailArray valueForKey:@"mobile"] valueForKey:@"type"]];
    NSArray *arr2 = [NSArray arrayWithArray:[[_editDetailArray valueForKey:@"mobile"] valueForKey:@"value"]];
    
    NSString *mobiletype = ar[0];
    NSString *mobilevalue = arr2[0];
    
    
    
    
    NSDictionary *headers = @{ @"content-type": @"application/json",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"114064f8-851c-fbfd-d2a4-1d246fcf7aec" };
    
    
    
    NSDictionary *parameters = @{ @"cmpId": [_editDetailArray valueForKey:@"cmpId"],
                                  @"depName": [_editDetailArray valueForKey:@"depName"],
                                  @"email": @[ @{ @"type": emailtype, @"value": emailvalue } ],
                                  @"empId": [_editDetailArray valueForKey:@"empId"],
                                  @"empSts": [_editDetailArray valueForKey:@"empSts"],
                                  @"firstName": self.firstName.text,
                                  @"hostId":  [_editDetailArray valueForKey:@"personId"],
                                  @"lastName": self.lastName.text,
                                  @"location": self.txtLocation.text,
                                  @"loginId": personid,
                                  @"mobile": @[ @{ @"type": mobiletype, @"value": mobilevalue } ],
                                  @"pemail": self.emailId.text,
                                  @"personId": [_editDetailArray valueForKey:@"personId"],
                                  @"pmobile": self.mobileNo.text,
                                  @"portCount": [_editDetailArray valueForKey:@"portCount"],
                                  @"role": [_editDetailArray valueForKey:@"role"]};
    
    
    NSLog(@"%@",parameters);
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/person/secure/editperson"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"PUT"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    [request setValue:tokenid forHTTPHeaderField:@"token"];
    
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                     [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
                                                    
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                         updateUser =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                                        
                                                        
                                                        NSLog(@"%@",updateUser);
                                                      
                                                        
                                                        [self performSelectorOnMainThread:@selector(pushBack) withObject:nil waitUntilDone:YES];
                                                        
                                                    }
                                                }];
    [dataTask resume];
}


-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}

-(void)pushBack {
    
    if ([[updateUser valueForKey:@"message"] isEqualToString:@"success"] ) {
        
        [self.navigationController popViewControllerAnimated:YES];
        
        
    }else{
        
        NSString * alertmessage = [NSString stringWithFormat:@"%@",[userEmailID valueForKey:@"message"]];
        NSLog(@"%@",alertmessage);
        
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:alertmessage delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alert show];

}
    
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if ( textField == _firstName) {
        NSCharacterSet *invalidCharSet = [[NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"] invertedSet];
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:invalidCharSet] componentsJoinedByString:@""];
        return [string isEqualToString:filtered];
    
    
    }
    else  if ( textField == _lastName) {
        NSCharacterSet *invalidCharSet = [[NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"] invertedSet];
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:invalidCharSet] componentsJoinedByString:@""];
        return [string isEqualToString:filtered];
        
    }
    else  if ( textField == _mobileNo) {
        NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
        
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
        if (textField.text.length == 10 && range.length == 0)
        {
            return NO; // return NO to not change text
        }
        
        return [string isEqualToString:filtered];
    }   else  if ( textField == _txtPort) {
        NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
        
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
        if (textField.text.length == 4 && range.length == 0)
        {
            return NO; // return NO to not change text
        }
        
        return [string isEqualToString:filtered];
    }
    

    else  if ( textField == _txtEmployeeId) {
        
        if (textField.text.length == 10 && range.length == 0)
        {
            return NO; // return NO to not change text
        }
    }

    return YES ;
    
    
}




@end
