//
//  corporateLOginPAgeViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "corporateLOginPAgeViewController.h"
#import "CorporateTabBarViewController.h"
#import "CorporateSignupViewController.h"
@interface corporateLOginPAgeViewController ()

@end

@implementation corporateLOginPAgeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}



- (IBAction)LOGINButton:(UIButton *)sender {
    CorporateTabBarViewController *tab = [self.storyboard instantiateViewControllerWithIdentifier:@"CTabBar"];
    [self.navigationController pushViewController:tab animated:YES];
    
    
    
}
- (IBAction)forgotPassword:(id)sender {
}

- (IBAction)SIGNUPbutton:(id)sender {
    for (id controller in [self.navigationController viewControllers])
    {
        
        if ([controller isKindOfClass:[CorporateSignupViewController class]])
        {
            [self.navigationController popToViewController:controller animated:YES];
            break;
        }
    }
}
@end
