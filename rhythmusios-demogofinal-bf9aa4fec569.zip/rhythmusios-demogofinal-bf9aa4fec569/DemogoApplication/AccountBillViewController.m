//
//  AccountBillViewController.m
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "AccountBillViewController.h"
#import "ViewController.h"
#import "AccountCell.h"
#import "UpdateAccountViewController.h"
#import <AFNetworking/AFNetworking.h>
#import "KVNProgress.h"

@interface AccountBillViewController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation AccountBillViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _tableAccountDetails.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
    infoArray = [[NSMutableArray alloc]init];
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    NSLog(@"%@",Tokenid);
    CompanyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];

    
  //  CompanyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    
    [self AccountDetailsFromServer];

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    
    return [Roledetails count]  ;
        
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    AccountCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AccountCell"];
    if (cell==nil) {
        NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"AccountCell" owner:self options:nil];
        
        cell= arr[0];
        
    }
    
    cell.selectionStyle = UITableViewCellSeparatorStyleNone ;
    
    
    
//    if (indexPath.row == 0) {
//        cell.txtType.text = @"Primary" ;
//        cell.widthDelete.constant = 0;
//        
//        cell.txtRole.text = [NSString stringWithFormat:@"%@",[[Roledetails  objectAtIndex:0]valueForKey:@"role"]];
//
//
//        cell.txtName.text = [NSString stringWithFormat:@"%@",[[Roledetails  objectAtIndex:0]valueForKey:@"cmpNm"]];
//
//        
//        [cell.btnUpdate addTarget:self action:@selector(UpdateRows:) forControlEvents:UIControlEventTouchUpInside];
//        
//        cell.btnUpdate.tag = indexPath.row;
//
//        cell.btnDelete.hidden = YES;
//        
//        
//     
//    }else{
    
         cell.btnDelete.hidden = NO;
        
        cell.txtType.text = @"Secondary";
        cell.widthDelete.constant = 25;

       NSString*roleee = [NSString stringWithFormat:@"%@",[[Roledetails  objectAtIndex:indexPath.row]valueForKey:@"role"]];
        
        cell.txtName.text = [NSString stringWithFormat:@"%@",[[Roledetails  objectAtIndex:indexPath.row]valueForKey:@"cmpNm"]];
        
        
        [cell.btnDelete addTarget:self action:@selector(deleteRows:) forControlEvents:UIControlEventTouchUpInside];
        
        [cell.btnUpdate addTarget:self action:@selector(UpdateRows:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.btnDelete.tag = indexPath.row;
        cell.btnUpdate.tag = indexPath.row;
        
    
    
    if ([roleee isEqualToString:@"ROLE_SUPER_ADMIN"]) {
        roleee = @"Admin" ;
        
    }else if ([roleee isEqualToString:@"ROLE_HOST"]) {
        roleee = @"Host" ;
        
    }else if ([roleee isEqualToString:@"ROLE_PARTICIPANT"]) {
        roleee = @"Participant" ;
        
    }
    
    cell.txtRole.text = roleee ;
    
    
    [self.view layoutIfNeeded];
    if (indexPath.row == 0) {
        cell.txtType.text = @"Primary" ;
        
        cell.btnDelete.hidden = YES;

        
        if ([roleee isEqualToString:@"Participant"]) {
            
            cell.txtType.text = @"Secondary" ;
            cell.btnDelete.hidden = NO;

        }
       
        
    }else{
        
        
        cell.btnDelete.hidden = NO;
        cell.txtType.text = @"Secondary";
        
        if ([roleee isEqualToString:@"Admin"]) {
            
            cell.txtType.text = @"Primary" ;
            cell.btnDelete.hidden = YES;
            
        }

        
        
    }

    
    if (indexPath.row == 0) {
        cell.btnDelete.hidden = YES;

    }else{
        
        cell.btnDelete.hidden = NO;
        
        
    }
    
    
    
    return cell;
    
}
-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.row) {
        NSLog(@"Sucess");
    }
}

-(void)deleteRows:(id)sender
{
    btn = (UIButton *)sender;
    
    NSLog(@"%ld",(long)btn.tag);
    
  deleteAlert= [[UIAlertView alloc]initWithTitle:nil message:@"Do you want to remove" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
    
    [deleteAlert show];

}

-(void)UpdateRows:(id)sender
{
    btnUpdate = (UIButton *)sender;
    
    NSLog(@"%ld",(long)btnUpdate.tag);
    
    strPersonID = [[Roledetails objectAtIndex:btnUpdate.tag]valueForKey:@"personId"];
    
    NSString *str = [NSString stringWithFormat:@"%ld",(long)btnUpdate.tag];
    
    count = [str intValue];
    
    [KVNProgress show];
    
    
    [self getPersonDetailsFromServer];
    
  
    
   

}



- (IBAction)BAckBUtton:(id)sender

{
   
    
    [self.navigationController popViewControllerAnimated:YES];

    
}

-(void)AccountDetailsFromServer{
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getprofile?personId=%@",personId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
      
        detailData = responseObject ;
        
        Roledetails = [detailData valueForKey:@"accountdata"];
        
//        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:Roledetails];
//        [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"Accounts"];
//        [[NSUserDefaults standardUserDefaults]synchronize];

        
        
        [self performSelectorOnMainThread:@selector(detailsData) withObject:nil waitUntilDone:YES];
        
        
        [self.tableAccountDetails performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        
        
        NSLog(@"%@",detailData);

        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    

    
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//    
////    NSURLSession *session = [NSURLSession sharedSession];
////    [[session dataTaskWithURL:[NSURL URLWithString:apiURLStr]
////            completionHandler:^(NSData *data,
////                                NSURLResponse *response,
////                                NSError *error)
////      {
//          if (data != nil) {
//              detailData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//          }
//          
//          Roledetails = [detailData valueForKey:@"accountdata"];
//
//          
//          [self performSelectorOnMainThread:@selector(detailsData) withObject:nil waitUntilDone:YES];
//          
//          
//          [self.tableAccountDetails performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
//
//          
//          NSLog(@"%@",detailData);
//          
//          
//          
//          
//          
//                                  }];
//   [task resume];
    
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 55 ;
}


-(void)detailsData{
   
    
    
}

-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}

-(void)deleteApiFromServer{
    
        NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/secure/removeaccount?personId=%@&removeId=%@",personId,DeleteRowStr];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        deleteData = responseObject ;
      
        Roledetails = [deleteData valueForKey:@"result"];
        
        [self AccountDetailsFromServer];

        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
 //   NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    
//    
//        [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//       [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//
//        [urlrequest setHTTPMethod:@"POST"];
//    
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      
//                                      if (data ==nil) {
//                                          
//                                      }else{
//                                deleteData=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
//                                            NSLog(@"%@",deleteData);
//                                          
//                                          //Roledetails = [deleteData valueForKey:@"result"];
//                                          
//                                         [self AccountDetailsFromServer];
//                                          
//                                     
//                                          
//                                      }
//                                      
//                                  }];
//    
//    
//    [task resume];
    
}

///getPersonDetails

-(void)getPersonDetailsFromServer{
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getpersondetails?personId=%@",strPersonID];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        personDetails = responseObject ;
        
        
         [self performSelectorOnMainThread:@selector(pushToGetInfo) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
    
    
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
//
//          if (data != nil) {
//              personDetails =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//          }
//                                    
//
//          
//           [self performSelectorOnMainThread:@selector(pushToGetInfo) withObject:nil waitUntilDone:YES];
//          
//          NSLog(@"%@",personDetails);
//          
//          
//          
//          
//                                  }];
//    
//   [task resume];
    
    
}


-(void)pushToGetInfo{
        
    infoArray = [personDetails valueForKey:@"prsnData"];
                 
    
    
    
    UpdateAccountViewController *getDetails = [[UpdateAccountViewController alloc]init];
    getDetails = [self.storyboard instantiateViewControllerWithIdentifier:@"UpdateAccountViewController"];
    
    getDetails.detailsArray = infoArray ;
    
    
    [self.navigationController pushViewController:getDetails animated:YES];
    
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == deleteAlert) {
        if (buttonIndex == 1) {
            
            
            DeleteRowStr  =  [[Roledetails objectAtIndex:btn.tag]valueForKey:@"personId"];
            [self deleteApiFromServer];

            
            
        }
    }
    
}


@end
