//
//  CsvVc.m
//  DemogoApplication
//
//  Created by katoch on 15/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "CsvVc.h"
#import "AppDelegate.h"

#import <PhotosUI/PhotosUI.h>



@interface CsvVc ()

@end

@implementation CsvVc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self csvFiles];
    
    
    
    
    csvFileArray = [[NSMutableArray alloc]init];
    arrayCsv = [[NSMutableArray alloc]init];
    _checkArray = [[NSMutableArray alloc]init];
    

    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory & NSDownloadsDirectory, NSUserDomainMask, YES);
    
    
    
    if([paths count] > 0)
    {
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSError *error = nil;
        documentArray = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:documentsDirectory error:&error];
        
        NSLog(@"%@",documentArray);
        if(error)
        {
            NSLog(@"Could not get list of documents in directory, error = %@",error);
        }
    }
    
   csvFileArray = [NSMutableArray arrayWithArray:documentArray];
    
    
    
//    if ([documentArray containsObject:@".csv"]) {
//        
//        csvFileArray = [NSMutableArray arrayWithArray:documentArray];
//        NSLog(@"%@",csvFileArray);
//        
//        
//    }

    
    
    
    
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:YES];
    
    
    
    
    
//    [_checkArray addObjectsFromArray:[[NSUserDefaults standardUserDefaults]
//                                      objectForKey:@"CSVChecked"]];
//    
//    [arrayCsv addObjectsFromArray:[[NSUserDefaults standardUserDefaults]
//                                        objectForKey:@"CSV"]];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  csvFileArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static  NSString *strCell = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:strCell];
    if(cell==nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:strCell];
    }
    
    if([self.checkedIndexPath isEqual:indexPath])
    {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    else
    {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    
    
//     self.csvTableView.allowsMultipleSelection = NO;
//    
//        if ( indexPath.row== selectedIndex) {
//    
//           cell.accessoryType = UITableViewCellAccessoryCheckmark;
//        }
//        else{
//    
//             cell.accessoryType = UITableViewCellAccessoryNone;
//        
//        }
    
    cell.textLabel.textColor= [UIColor blueColor];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@",[csvFileArray objectAtIndex:indexPath.row] ];
  
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
   
    if(self.checkedIndexPath)
    {
        UITableViewCell* uncheckCell = [tableView
                                        cellForRowAtIndexPath:self.checkedIndexPath];
        uncheckCell.accessoryType = UITableViewCellAccessoryNone;
    }
    if([self.checkedIndexPath isEqual:indexPath])
    {
        self.checkedIndexPath = nil;
    }
    else
    {
        UITableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        self.checkedIndexPath = indexPath;
    }
    
    
//    selectedIndex =  indexPath.row;
//
//        [self.csvTableView reloadData];

    
    
//    if ([self.checkArray containsObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]]) {
//        
//        
//        [self.checkArray removeObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
//        cell.accessoryType = UITableViewCellAccessoryNone;
//        [arrayCsv removeObject:csvFileArray[indexPath.row]];
//        
//        
//    }else{
//        
//        
//        [self.checkArray addObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
//        [arrayCsv addObject:csvFileArray[row]];
//        cell.accessoryType = UITableViewCellAccessoryCheckmark;
//        
//    }
    
    
    
//    [[NSUserDefaults standardUserDefaults]setInteger:selectedIndex forKey:@"CSVChecked"];
//    [[NSUserDefaults standardUserDefaults]synchronize];
//    
//    
//    [[NSUserDefaults standardUserDefaults]setValue:arrayCsv forKey:@"CSV"];
//    [[NSUserDefaults standardUserDefaults]synchronize];
//    
    
    
    
}


- (IBAction)btnBack:(id)sender {
     [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)doneClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
-(void)readTitleFromCSV:(NSString*)path AtColumn:(int)column
{

    
   NSMutableArray* titleArray=[[NSMutableArray alloc]init];
    
    NSString *fileDataString=[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSArray *linesArray=[fileDataString componentsSeparatedByString:@"\n"];
    
    
    int k=0;
    for (id string in linesArray)
        if(k<[linesArray count]-1){
            
            NSString *lineString=[linesArray objectAtIndex:k];
            NSArray *columnArray=[lineString componentsSeparatedByString:@";"];
            [titleArray addObject:[columnArray objectAtIndex:column]];
            k++;
            
        }
    
    NSLog(@"%@",titleArray);
    
}




-(void)csvFiles {
NSString *searchFilename = @".pdf"; // name of the PDF you are searching for

NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
NSString *documentsDirectory = [paths objectAtIndex:0];
NSDirectoryEnumerator *direnum = [[NSFileManager defaultManager] enumeratorAtPath:documentsDirectory];

NSString *documentsSubpath;
while (documentsSubpath = [direnum nextObject])
{
    if (![documentsSubpath.lastPathComponent isEqual:searchFilename]) {
        continue;
    }
    
    NSLog(@"found %@", documentsSubpath);
}
    
}

@end
