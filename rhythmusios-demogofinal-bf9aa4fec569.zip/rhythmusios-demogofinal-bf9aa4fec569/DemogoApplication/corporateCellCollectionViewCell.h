//
//  corporateCellCollectionViewCell.h
//  DemogoApplication
//
//  Created by varinder singh on 1/30/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface corporateCellCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imageViewData;
@property (strong, nonatomic) IBOutlet UILabel *TExtData;

@property (strong, nonatomic) IBOutlet UIView *ViewImageBAck;

@end
