
#import "ViewController.h"

@interface VerifyAccountViewController : ViewController
{
    
    UIImage *PANimage;
}

@property (strong, nonatomic) IBOutlet UIButton *StateverifyOUtlet;

- (IBAction)stateVerifyButton:(id)sender;

@property (strong, nonatomic) IBOutlet UITableView *tableview;

@property (strong, nonatomic) IBOutlet UIButton *cityOUtlet;

@property (strong, nonatomic) IBOutlet UITableView *CityTableview;

- (IBAction)cityButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *pin;

- (IBAction)pinbutton:(id)sender;

@property (strong, nonatomic) IBOutlet UITableView *pinTableView;

@property (strong, nonatomic) IBOutlet UIButton *uploadimageOUTLET;

- (IBAction)uploadImage:(id)sender;

@property (strong, nonatomic) IBOutlet UIImageView *CompanyImage;

- (IBAction)ProfilePicFetchButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *CompanyImageOutlet;






@property (strong, nonatomic) IBOutlet NSLayoutConstraint *billingAddressAutolayout;


@property (strong, nonatomic) IBOutlet NSLayoutConstraint *saveButonAutolayout;


@property (strong, nonatomic) IBOutlet UITextField *Billingaddress;


@property (strong, nonatomic) IBOutlet UITextField *BillingState;

@property (strong, nonatomic) IBOutlet UITextField *BillingCity;


@property (strong, nonatomic) IBOutlet UITextField *BillingPinCode;


@property (strong, nonatomic) IBOutlet UIButton *SAVEbutton;


- (IBAction)SaveButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIImageView *BADDImg;

@property (strong, nonatomic) IBOutlet UIImageView *BSatImg;

@property (strong, nonatomic) IBOutlet UIImageView *BCITimg;

@property (strong, nonatomic) IBOutlet UIImageView *BPINimg;


- (IBAction)BillingButton:(id)sender;


@property (strong, nonatomic) IBOutlet UIImageView *BillingCheckBox;

@property (strong, nonatomic)NSString *CMpid;



@end
