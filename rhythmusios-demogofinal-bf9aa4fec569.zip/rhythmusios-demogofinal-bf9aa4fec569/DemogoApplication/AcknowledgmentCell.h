//
//  AcknowledgmentCell.h
//  nbng
//
//  Created by Rhythmus on 28/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AcknowledgmentCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *txtName;
@property (strong, nonatomic) IBOutlet UILabel *txtCompany;
@property (strong, nonatomic) IBOutlet UILabel *txtMobile;

@property (strong, nonatomic) IBOutlet UIButton *btnAccpeted;

@property (strong, nonatomic) IBOutlet UILabel *lblStatus;

@end
