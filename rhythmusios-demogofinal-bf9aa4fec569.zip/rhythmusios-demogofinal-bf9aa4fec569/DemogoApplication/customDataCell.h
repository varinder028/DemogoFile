//
//  customDataCell.h
//  DemogoApplication
//
//  Created by katoch on 09/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface customDataCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblTxt;
- (IBAction)closeBlk:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnCloseBlk;

@end
