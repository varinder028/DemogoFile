//
//  EmplyeeMAnagementViewController.m
//  DemogoApplication
//
//  Created by Rhythmus on 04/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "EmplyeeMAnagementViewController.h"
#import "SAveDEtailsViewController.h"
#import "ADMINProfilePICViewController.h"
#import "CorporateTabBarViewController.h"
#import "GroupScrollViewController.h"
#import <AFNetworking/AFNetworking.h>



//#import "ADDPersonTableViewController.h"
#import "CompCellTableViewCell.h"

@interface EmplyeeMAnagementViewController ()<UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate>

{
    CompCellTableViewCell *cell;
    SAveDEtailsViewController *Views;
    
    NSArray *allItems;
    
    NSMutableArray *DisplayItems;
}

- (IBAction)BAckButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIView *GroupVIew;

@property (strong, nonatomic) IBOutlet UISegmentedControl *segment;

- (IBAction)segmentC:(id)sender;

@end

@implementation EmplyeeMAnagementViewController



    ///   . .. . . . . . . . . . . . ..  .       Emplement MAnagement User Details 

- (IBAction)CheckButton:(id)sender {
}

- (IBAction)SelectPersonButton:(UIButton *)sender {
}

- (IBAction)BlockPersonButton:(id)sender {
}
- (IBAction)UnblockPersonButton:(id)sender {
}

- (IBAction)ADDButtonNew:(UIButton *)sender
{
    
    NSLog(@"hello sir");
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Storyboard" bundle:nil];
    
    
    Views = [story instantiateViewControllerWithIdentifier:@"SDETAILS"];
    
    Views.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    
    [self presentViewController:Views animated:YES completion:nil];
    
}


- (IBAction)BAckButton:(id)sender
{
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Storyboard" bundle:nil];
    
    CorporateTabBarViewController * adp = [story instantiateViewControllerWithIdentifier:@"CTabBar"];
    
    adp.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    
    [self presentViewController:adp animated:YES completion:nil];
    
}



-(void)ADDCheckBox;

{
    
}


- (void)viewDidLoad

{
    
    [super viewDidLoad];
    
    self.GroupVIew.hidden = YES;
    
    
    //UITableViewDataSource,UITableViewDelegate
    
    self.navigationController.navigationBarHidden = YES;
    
    self.ADDbuttonOutlet.layer.cornerRadius = 5;
    
    self.SelectPersonGroupOutlet.layer.cornerRadius = 5;
    
    self.BlockPersonOutlet.layer.cornerRadius = 5;
    
    self.UnblockPersonOutlet.layer.cornerRadius = 5;
    
    self.SearchBar.layer.cornerRadius = 20;
    
    self.CheckButtonOutlet.layer.cornerRadius = 5;
    
    //self..layer.cornerRadius = 10;
    
    
    
    
    /////           .....  Keyboard upper tableview cell
//    
//    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(KeyBoardShow:) name:UIKeyboardDidShowNotification object:nil];
//    
//    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(KeyBoardHide:) name:UIKeyboardDidHideNotification object:nil];
//    
    
    
    
    
    
    //     ..  .       ..  .   .   .   .   .   Group Add Segment view Details  or attributes
    

    allItems = [[NSArray alloc]initWithObjects:@"one",@"two",@"three",@"four",@"five",@"six",@"seven",@"eight",@"nine",@"ten",@"elevan", nil];
    
    DisplayItems = [[NSMutableArray alloc]initWithArray:allItems];
    
    
    self.AddGroupOutlet.layer.cornerRadius = 5;
    
    self.GoupAllCheckBoxOUtlet.layer.cornerRadius = 5;
    
    self.SearchBar.layer.cornerRadius = 20;

    
    
    
 
}

/////////  .    .   .   .   .   ..      Keybord SHow Method Declare

-(void)KeyBoardShow:(NSNotification *)note

{
    
    
    CGRect keyboardFrame ;
    
    CGRect keyboardFrame2;

    
    [[[note userInfo]objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&keyboardFrame];
    
    CGRect TbaleviewFrame = self.tableViewADDPerson.frame;
    
    TbaleviewFrame.size.height -= keyboardFrame.size.height;
    
    [self.tableViewADDPerson setFrame:TbaleviewFrame];
    
    /////.. ..  .   .   .   .   .  SecoNd Group SerachBar
    
    [[[note userInfo]objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&keyboardFrame2];
    
    CGRect TbaleviewFrame2 = self.GroupTabelViewData.frame;
    
    TbaleviewFrame2.size.height -= keyboardFrame2.size.height;
   
    
    [self.GroupTabelViewData setFrame:TbaleviewFrame2];
    

    
}

-(void)KeyBoardHide:(NSNotificationCenter *)note

{
    
    
    [self.tableViewADDPerson setFrame:self.tableViewADDPerson.bounds];
    
    [self.GroupTabelViewData setFrame:self.GroupTabelViewData.bounds];
    
    
    
}





- (IBAction)segmentC:(id)sender

    {
    
        if ([_segment selectedSegmentIndex]==0)
        
            {
        
                self.GroupVIew .hidden =YES;
            }
        
                else if ([_segment selectedSegmentIndex]==1)
            
                {
        
                    self.GroupVIew .hidden =NO;
                }
    
    }


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView == self.tableViewADDPerson)
    
    {
        return 1;
    }
    
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    
    if (tableView == self.tableViewADDPerson)
        
        {
            return DisplayItems .count;
        }
    
            else
   
                {
        
                    return DisplayItems .count;
        
                }
    
    
}

-(CompCellTableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    NSString * cellIdentifier = @"cell";
    
     cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell)
    
        {
            cell = [[CompCellTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            
             cell.selectedBackgroundView.backgroundColor = [UIColor colorWithRed:0.01 green:0.12 blue:0.16 alpha:1.0];
        
        }
    
    if (tableView == self.tableViewADDPerson)
        
    {
        cell.MobileNAmeCell.text = [DisplayItems objectAtIndex:indexPath.row];
        
        cell.NameCell.text = [DisplayItems objectAtIndex:indexPath.row];
        
        cell.RoleCell.text = [DisplayItems objectAtIndex:indexPath.row];
        
        [cell.CheckCellButtonOutlet addTarget:self action:@selector(ADDCheckBox) forControlEvents:UIControlEventTouchUpInside];
        
        
        cell.CheckCellButtonOutlet.layer.cornerRadius = 10.5;

    }
    
    else
        
    {
        
        cell.GroupLabelNAme.text = [DisplayItems objectAtIndex:indexPath.row];
        
        cell.GroupMembersLAbelName.text = [DisplayItems objectAtIndex:indexPath.row];
        
        cell.GroupCnterDatelabel.text = [DisplayItems objectAtIndex:indexPath.row];
        
        [cell.GroupCheckBoxCell addTarget:self action:@selector(groupCHeckButton) forControlEvents:UIControlEventTouchUpInside];
        
        cell.GroupCheckBoxCell.layer.cornerRadius = 10.5;
    }
    
    
    
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

{
    
    
    if (tableView==self.tableViewADDPerson)
    
        {
            
            NSLog(@"Select Cell completly");
    
            
        }
    
            else if (tableView == self.GroupTabelViewData)
    
                {
                    
                    NSLog(@"Select Cell completly");

    
                }


}





            /////.....  .   .   .   .   .   .  SearchBar Tool Working with searchBarDelegate Details  ...........      .   .   ..

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText

{
    if (searchBar == self.SearchBar)
    
        {
            if ([searchText length]==0)
            
                {
                    [DisplayItems  removeAllObjects];
                    
                    [DisplayItems addObjectsFromArray:allItems];
                }
            
                    else
                
                        {
                            [DisplayItems removeAllObjects];
                            
                            for (NSString *stringData in allItems)
                         
                                {
                                    
                                    NSRange List = [stringData rangeOfString:searchText options:NSCaseInsensitiveSearch];
                                    
                                    if (List.location!= NSNotFound)
                                   
                                        {
                                            
                                            [DisplayItems addObject:stringData];
                                            
                                        }
                                    
                                }
                
                        }
            
            [self.tableViewADDPerson reloadData];
            
            
        }
    
    /////////       .   .   ..  .       .   .   Group SearchBar Details Or Working
    
   else if (searchBar == self.GroupSearchBar)
        
    {
        if ([searchText length]==0)
            
        {
            [DisplayItems  removeAllObjects];
            
            [DisplayItems addObjectsFromArray:allItems];
        }
        
        else
            
        {
            [DisplayItems removeAllObjects];
            
            for (NSString *stringData in allItems)
                
            {
                
                NSRange List = [stringData rangeOfString:searchText options:NSCaseInsensitiveSearch];
                
                if (List.location!= NSNotFound)
                    
                {
                    
                    [DisplayItems addObject:stringData];
                    
                }
                
            }
            
        }
        
        [self.GroupTabelViewData reloadData];
        
        
    }

    
    
    
    
    
    
}




-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar

{
             [self.SearchBar resignFirstResponder];
        
       
   
}



///     ..  .       ..  .   .   .   .   .   Group Add Segment view Details  or attributes


-(void)groupCHeckButton;
{
    
}


- (IBAction)ADDGroup:(id)sender {
}
- (IBAction)GroupAllCheckBox:(id)sender {
}
@end
