//
//  LiveParticipantCell.h
//  nbng
//
//  Created by Rhythmus on 28/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LiveParticipantCell : UITableViewCell


@property (strong, nonatomic) IBOutlet UILabel *txtLiveName;

@property (strong, nonatomic) IBOutlet UILabel *txtLiveMobile;

@property (strong, nonatomic) IBOutlet UILabel *txtLiveResponse;

@property (strong, nonatomic) IBOutlet UIButton *btnSelfMute;

@property (strong, nonatomic) IBOutlet UIButton *btnSelfEndCall;

@property (strong, nonatomic) IBOutlet UIButton *btnRefresh;
@property (strong, nonatomic) IBOutlet UIButton *btnRed;

@end
