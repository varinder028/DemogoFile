//
//  CorporateMobileOTPViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CorporateMobileOTPViewController : UIViewController<UIAlertViewDelegate>{
    
    id  PassedJS;
    UIAlertView *alertOtp;
    
    }


@property (strong, nonatomic) NSString *CmpString;

@property (strong, nonatomic) NSString *CmpString2;

@property (strong, nonatomic) NSMutableString *CmpOTP;

//@property (strong, nonatomic) NSString *getOtpData;
@property (strong, nonatomic) IBOutlet UITextField *OtpNumberCodeTextField;


- (IBAction)bckClicked:(id)sender;


@end
