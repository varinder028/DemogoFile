//
//  EmployeeManagementVc.m
//  DemogoApplication
//
//  Created by katoch on 26/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "EmployeeManagementVc.h"
#import "EmployeeManagementCell.h"
#import "UserDetailsEmployeeVc.h"
#import "AppDelegate.h"
#import "AddGroupEmployeeMangVC.h"
#import "BulkUploadEmployeeManagVC.h"
#import "KVNProgress.h"
#import <AFNetworking/AFNetworking.h>
#import "SubscriptionVC.h"
#import "UIImageView+Letters.h"
#import "UIImageView+WebCache.h"



@interface EmployeeManagementVc ()

@end

@implementation EmployeeManagementVc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self.viewSubscribe setHidden:YES ];

    pmobile = [[NSUserDefaults standardUserDefaults]valueForKey:@"pmobile"];
   

    
    isUser = true ;
    
    _btnsubscribe.layer.cornerRadius = 5.0f ;
    [_btnsubscribe clipsToBounds];
    
    
    
    self.employeeTableView.separatorStyle = UITableViewCellSeparatorStyleNone ;
    self.employeeTableView.backgroundColor = [UIColor clearColor];
     
    
    totalcheckmarkArray =[[NSMutableArray alloc]init];
    groupcheckmarkArray = [[NSMutableArray alloc]init];
    blockedArray = [[NSMutableArray alloc]init];
    BlockedGroups = [[NSMutableArray alloc]init];
    
    
    selectedGroups = [[NSMutableArray alloc]init];
    selectedUsers = [[NSMutableArray alloc]init];
    
    
    
    groupArray = [[NSMutableArray alloc]init];
    
    indexArr = [[NSMutableArray alloc]init];
    
     blockCheckedArray = [[NSMutableArray alloc]init];
    
    strProfileid = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    NSLog(@"%@",strProfileid);
    
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];

    NSLog(@"%@",Tokenid);
    
    
    
    
  //  [delegate.tabView setHidden:YES];
    
    [self.searchBar setBackgroundImage:[[UIImage alloc]init]];
     _searchBar.delegate = self ;
    
    allItems = [[NSArray alloc]initWithObjects:@"one",@"two",@"three",@"four",@"five",@"six",@"seven",@"eight",@"nine",@"ten",@"elevan", nil];
    
    DisplayItems = [[NSMutableArray alloc]initWithArray:allItems];
    
    [self.searchBar setReturnKeyType:UIReturnKeyDone];
    [self.searchBar setEnablesReturnKeyAutomatically:NO];
    
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    [KVNProgress show];
    
    [self  GetProfileFromServer];

    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView removeFromSuperview];
    
    
    i = 0 ;
    
    isUser = true ;
    
    
    self.lblMobile.text  = @"Mobile No.";
    self.lblName.text = @"Name";
    self.lblRole.text = @"Image";
    
    if ([UIScreen mainScreen].bounds.size.width == 768 || [UIScreen mainScreen].bounds.size.width == 1024 ) {
        _lblRole.textAlignment = NSTextAlignmentCenter;
        
        
    }else{
        _lblRole.textAlignment = NSTextAlignmentCenter;
        
    }
    
    _xLblLayout.constant = 0 ;
    [self.view layoutIfNeeded];
    _bulkUploadWidth.constant = 30;
    [self.view layoutIfNeeded];
    _viewSubscribe.backgroundColor = [UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:0.6];
    _viewSubSubcribe.backgroundColor = [UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:0.6];
    [self varifiyingPlans];
    
    
     }

-(void)KvnPerform{
    
    [KVNProgress dismiss];
    
}


-(void)varifiyingPlans{
    
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/secure/isverify?cmpId=%@",companyId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        
        
        
        isVarified = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(planType) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
}
-(void)planType{
    
    
    if ([[isVarified valueForKey:@"message"] isEqualToString:@"success"]) {
        
        NSString*strVarify = [NSString stringWithFormat:@"%@",[isVarified valueForKey:@"isverify"]];
         NSString*planType = [NSString stringWithFormat:@"%@",[isVarified valueForKey:@"planType"]];
        
        if ([strVarify isEqualToString:@"0"]) {
            
                
                [self.viewSubscribe setHidden:NO ];
                
            

            
                       
        }else{
            if ([planType isEqualToString:@"No plan selected"]) {
                [self.viewSubscribe setHidden:NO];
            }else{
                
                [self.viewSubscribe setHidden:YES ];
                
            }
            
        }
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}




-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
         return userListArray.count;
   
}




-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    EmployeeManagementCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EmployeeManagementCell"];
    if (cell==nil) {
        NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"EmployeeManagementCell" owner:self options:nil];
        
        cell= arr[0];
        
    }
    cell.selectionStyle = UITableViewCellEditingStyleNone ;
    
    
    if (isUser == true) {
        
        NSString*blockedStatus = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"empSts"]objectAtIndex:indexPath.row]];
        
        cell.txtRole.hidden = YES;
        cell.imgEmpyee.hidden = NO;
        
        
        NSString *str = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"checked"]objectAtIndex:indexPath.row]];
        
        if (userListArray.count >0) {
            if(![str  isEqualToString:@"NO"])
            {
                
                [cell.btnCheck setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                
                
                //  [cell.btnCheck setSelected:YES];
                
            }
            
            else
            
                
                if ([[userListArray valueForKey:@"checked"] containsObject:[userListArray objectAtIndex:indexPath.row]])
            {
                
                [cell.btnCheck setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
            }
            else
            {
                
                
                [cell.btnCheck setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
                
                
            }
            
            
            [cell.btnCheck addTarget:self action:@selector(checkedClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.btnCheck.tag = indexPath.row ;
            
            
            
            cell.txtMobile.text = [[userListArray valueForKey:@"pmobile"]objectAtIndex:indexPath.row];
            
            NSString*firstName = [NSString stringWithFormat:@"%@", [[userListArray valueForKey:@"firstName"]objectAtIndex:indexPath.row]];
            
           NSString*endName = [NSString stringWithFormat:@"%@", [[userListArray valueForKey:@"lastName"]objectAtIndex:indexPath.row]];
            
            cell.textName.text = [NSString stringWithFormat:@"%@ %@",firstName,endName];
            
            
            
            NSString*roleee = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"role"]objectAtIndex:indexPath.row]];
            
            cell.imgEmpyee.layer.cornerRadius = cell.imgEmpyee.frame.size.width/2; //
            
            [cell.imgEmpyee.layer masksToBounds];
            
            cell.imgEmpyee.layer.borderWidth = 1.0f;
            
            cell.imgEmpyee.layer.masksToBounds = YES;
            
            cell.imgEmpyee.clipsToBounds = YES;
            
            
              NSString*proImg = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"proImg"]objectAtIndex:indexPath.row]];
            
            if ([proImg isEqualToString:@"no image"]) {
                
                 [cell.imgEmpyee setImageWithString:cell.textName.text color:nil circular:YES];
                
            }else{
                
                [cell.imgEmpyee sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://182.76.44.135:8080/%@",[userListArray valueForKey:@"proImg"]]]placeholderImage:[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"]];
               
            }
            
           http://182.76.44.135:8080/profimg/3780.jpg
            
            
            
           // [cell.imgEmpyee setImageWithString:cell.textName.text color:nil circular:YES];

            
            
            
            if ([roleee isEqualToString:@"ROLE_SUPER_ADMIN"]) {
                roleee = @"Admin" ;
                
            }else if ([roleee isEqualToString:@"ROLE_HOST"]) {
                roleee = @"Host" ;
                
            }else if ([roleee isEqualToString:@"ROLE_PARTICIPANT"]) {
                roleee = @"Participant" ;
                
            }

            
            cell.txtRole.text = roleee ;
            
            if ([blockedStatus isEqualToString:@"0"]) {
                cell.textName.textColor = [UIColor redColor];
                
               
                
            }else{
                cell.textName.textColor = [UIColor whiteColor];

                
            }
            
        }
        
        
    }
    else{
        
        cell.txtRole.hidden = NO;
        cell.imgEmpyee.hidden = YES;
        
 NSString *str = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"checked"]objectAtIndex:indexPath.row]];
        
         NSString*blockedGroupStatus = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"grpSts"]objectAtIndex:indexPath.row]];
        
        if ([blockedGroupStatus isEqualToString:@"0"]) {
            cell.txtRole.textColor = [UIColor redColor];
            
            
        }else{
            cell.txtRole.textColor = [UIColor whiteColor];
            
        }
        
        cell.textName.textColor = [UIColor whiteColor];
        
        
        
        if (userListArray.count >0) {
            
            if(![str isEqualToString:@"NO"])
            {
                
                [cell.btnCheck setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                
                
                //  [cell.btnCheck setSelected:YES];
                
            }
            
            else if ([[userListArray valueForKey:@"checked"] containsObject:[userListArray objectAtIndex:indexPath.row]])
            {
                
                [cell.btnCheck setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
            }
            else
            {
                
                
                [cell.btnCheck setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
            }
            
            [cell.btnCheck addTarget:self action:@selector(checkedClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            
            
            cell.btnCheck.tag = indexPath.row ;
            
            cell.txtMobile.text = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"grpName"]objectAtIndex:indexPath.row]];
            

            
            cell.textName.text = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"totalmember"]objectAtIndex:indexPath.row]];
            
            
            
            cell.txtRole.text = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"grpDesc"]objectAtIndex:indexPath.row]];
            
            
            
        }
        
        cell.backgroundColor = [UIColor clearColor];
        
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        int countRed = 0 ;
        
    
        


    }
    
     return cell;
}

-(void)checkedClicked:(id)sender{
    
    [_BtnCheckAll setSelected:NO];
    
    
    UIButton* btnTag  = (UIButton*)sender ;
    NSLog(@"%ld",(long)btnTag.tag);
    
    
    NSString* indexx = [NSString stringWithFormat:@"%ld",(long)btnTag.tag];
    
    if (isUser == true) {
        
        if (userListArray.count>0) {
            if(![[[userListArray valueForKey:@"checked"] objectAtIndex:btnTag.tag] isEqualToString:@"NO"])
            {
                
                [btnTag setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
                
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:btnTag.tag]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"NO" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:btnTag.tag withObject:dictt];
                
                NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
                
                [arrCheck addObject:dictt];
                for (int h = 0; h < [search_tableContents count]; h++) {
                    if ([[arrCheck[0] valueForKey:@"firstName"] isEqualToString:[[search_tableContents  objectAtIndex:h] valueForKey:@"firstName"]]) {
                        
                        [search_tableContents replaceObjectAtIndex:h withObject:arrCheck[0]];
                        
                        
                    }
                    
                }
                

                
//                [totalcheckmarkArray replaceObjectAtIndex:btnTag.tag withObject:@"NO"];
                [selectedUsers removeObject: [[userListArray valueForKey:@"personId"] objectAtIndex:btnTag.tag]];
                NSLog(@"%@",selectedUsers);
                 [blockedArray removeObject: [[userListArray valueForKey:@"personId"] objectAtIndex:btnTag.tag]];
                
            }
            else
            {
                [btnTag setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:btnTag.tag]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"YES" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:btnTag.tag withObject:dictt];
                
                NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
                
                [arrCheck addObject:dictt];
                for (int h = 0; h < [search_tableContents count]; h++) {
                    if ([[arrCheck[0] valueForKey:@"firstName"] isEqualToString:[[search_tableContents  objectAtIndex:h] valueForKey:@"firstName"]]) {
                        
                        [search_tableContents replaceObjectAtIndex:h withObject:arrCheck[0]];
                        
                        
                    }
                    
                }

                
               // [totalcheckmarkArray replaceObjectAtIndex:btnTag.tag withObject:@"YES"];
                
                [selectedUsers addObject: [[userListArray valueForKey:@"personId"] objectAtIndex:btnTag.tag]];
                NSLog(@"%@",selectedUsers);
                
                [blockedArray addObject: [[userListArray valueForKey:@"personId"] objectAtIndex:btnTag.tag]];
                
            }
            
            [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
            
            
        }
        
        
    }else{
        
        if (userListArray.count>0) {
            if(![[[userListArray valueForKey:@"checked"] objectAtIndex:btnTag.tag] isEqualToString:@"NO"])
            {
                
                [btnTag setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
                
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:btnTag.tag]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"NO" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:btnTag.tag withObject:dictt];
                
                NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
                
                [arrCheck addObject:dictt];
                for (int h = 0; h < [search_tableContents count]; h++) {
                    if ([[arrCheck[0] valueForKey:@"grpName"] isEqualToString:[[search_tableContents  objectAtIndex:h] valueForKey:@"grpName"]]) {
                        
                        [search_tableContents replaceObjectAtIndex:h withObject:arrCheck[0]];
                        
                        
                    }
                    
                }

                //[groupcheckmarkArray replaceObjectAtIndex:btnTag.tag withObject:@"NO"];
                [selectedGroups removeObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:btnTag.tag]];
                NSLog(@"%@",selectedGroups);
                [BlockedGroups removeObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:btnTag.tag]];
            }
            else
            {
                [btnTag setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:btnTag.tag]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"YES" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:btnTag.tag withObject:dictt];
                
                NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
                
                [arrCheck addObject:dictt];
                for (int h = 0; h < [search_tableContents count]; h++) {
                    if ([[arrCheck[0] valueForKey:@"grpName"] isEqualToString:[[search_tableContents  objectAtIndex:h] valueForKey:@"grpName"]]) {
                        
                        [search_tableContents replaceObjectAtIndex:h withObject:arrCheck[0]];
                        
                        
                    }
                    
                }

                
               // [groupcheckmarkArray replaceObjectAtIndex:btnTag.tag withObject:@"YES"];
                
                [selectedGroups addObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:btnTag.tag]];
                NSLog(@"%@",selectedGroups);
                 [BlockedGroups addObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:btnTag.tag]];
                
            }
            
            [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
            
            
        }
        
        
    }
    
}

    
- (IBAction)CheckAllClicked:(id)sender{
    

    if (!_BtnCheckAll.isSelected) {
        
        [_BtnCheckAll setSelected:YES];
        
        if (isUser == true) {
             selectedUsers = [NSMutableArray new];
        }else{
            selectedGroups = [NSMutableArray new];
            
        }
        
        for (int j=0; j<[userListArray count]; j++)
        {
            
            if (isUser == true) {
                
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:j]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"YES" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:j withObject:dictt];
                
//                NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
//
//                
//                [[userListArray valueForKey:@"checked"] replaceObjectAtIndex:j withObject:@"YES"];
                
                
                [selectedUsers addObject: [[userListArray valueForKey:@"personId"] objectAtIndex:j]];
                NSLog(@"%@",selectedUsers);
                
                [blockedArray addObject: [[userListArray valueForKey:@"personId"] objectAtIndex:j]];
               // NSLog(@"%@",blockedArray);
            }
            else{
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:j]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"YES" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:j withObject:dictt];

                
                //[[userListArray valueForKey:@"checked"] replaceObjectAtIndex:j withObject:@"YES"];
                [selectedGroups addObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:j]];
                [BlockedGroups addObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:j]];
            }
           
            
        }
        
        
    }else{
        
        [_BtnCheckAll setSelected:NO];
        for (int j=0; j<[userListArray count]; j++) // Number of Rows count
        {
            
            for (int j=0; j<[userListArray count]; j++)
            {
                if (isUser == true) {
                    
                    NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                    
                    NSMutableArray *array = [NSMutableArray new];
                    [array addObject:[userListArray objectAtIndex:j]];
                    for (NSDictionary *dicts in array) {
                        
                        [dictt addEntriesFromDictionary:dicts];
                        
                    }
                    
                    [dictt setObject:@"NO" forKey:@"checked"];
                    [userListArray  replaceObjectAtIndex:j withObject:dictt];

                    
                  //  [[userListArray valueForKey:@"checked"] replaceObjectAtIndex:j withObject:@"NO"];
                    
                    [selectedUsers removeObject: [[userListArray valueForKey:@"personId"] objectAtIndex:j]];
                    NSLog(@"%@",selectedUsers);
                    
                    [blockedArray removeObject: [[userListArray valueForKey:@"personId"] objectAtIndex:j]];

                }else{
                    
                    NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                    
                    NSMutableArray *array = [NSMutableArray new];
                    [array addObject:[userListArray objectAtIndex:j]];
                    for (NSDictionary *dicts in array) {
                        
                        [dictt addEntriesFromDictionary:dicts];
                        
                    }
                    
                    [dictt setObject:@"NO" forKey:@"checked"];
                    [userListArray  replaceObjectAtIndex:j withObject:dictt];
                    

                    
                   // [[userListArray valueForKey:@"checked"] replaceObjectAtIndex:j withObject:@"NO"];
                    
                    [selectedGroups removeObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:j]];
                    NSLog(@"%@",selectedUsers);
                    
                    [BlockedGroups removeObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:j]];

                }
                
                
                
            }
            
            
            
        }
        
    }
    
    
    [self.employeeTableView reloadData];
    
    
}

 
//    if (userListArray.count >0) {
//        if (isUser == true) {
//
//            cell.txtMobile.text = [[userListArray valueForKey:@"pmobile"]objectAtIndex:indexPath.row];
//
//            cell.textName.text =  [[userListArray valueForKey:@"firstName"]objectAtIndex:indexPath.row];
//
//            cell.txtRole.text =  [[userListArray valueForKey:@"role"]objectAtIndex:indexPath.row];
//            
//            
//        }
//        else{
//            cell.txtMobile.text = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"grpName"]objectAtIndex:indexPath.row]];
//            
//            cell.textName.text = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"totalmember"]objectAtIndex:indexPath.row]];
//            
//            cell.txtRole.text = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"grpDesc"]objectAtIndex:indexPath.row]];
//            
//            
//
//        }
    
        
        
        
//        if (!_BtnCheckAll.isSelected) {
//            
//            [cell.btnCheck setSelected:NO];
//            
//        }else{
//            
//            [cell.btnCheck setSelected:YES];
//        }
        
        //  cell.arrowImg.image = @"" ;
        
        
    

  //  }
    
    
    
    
//    if (indexArr.count > 0) {
//        
//    
//        for (int j = 0; i > indexArr.count; j++) {
//            
//            NSString *str =[indexArr objectAtIndex:j];
//            
//             countRed =   [str intValue];
//            
//            
//            
//        }
//        
//        if (indexPath.row == countRed) {
//            
//            cell.txtRole.backgroundColor = [UIColor redColor];
//            
//        }else{
//            
//            cell.txtRole.backgroundColor = [UIColor whiteColor];
//        }
//
//
//        
//        }
    
        

        

    
    
    
    
//}

//-(void)checkedClicked:(id)sender{
//    
//    btnTag  = (UIButton*)sender ;
//    NSLog(@"%ld",(long)btnTag.tag);
//    
//    
//    NSString* indexx = [NSString stringWithFormat:@"%ld",(long)btnTag.tag];
//    
//    
//    
//    if (!btnTag.selected) {
//        [btnTag setSelected:YES];
//        if (isUser == true) {
//            [blockCheckedArray addObject: [[userListArray valueForKey:@"personId"] objectAtIndex:btnTag.tag]];
//            [indexArr addObject:  [NSString stringWithFormat:@"%@",indexx]];
//        }else{
//            [blockCheckedArray addObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:btnTag.tag]];
//            
//            [indexArr addObject:  [NSString stringWithFormat:@"%@",indexx]];
//            
//        }
//        
//        
//        
//        
//        
//    }else{
//        
//         [btnTag setSelected:NO];
//        
//        if (isUser == true) {
//            [blockCheckedArray removeObject: [[userListArray valueForKey:@"personId"] objectAtIndex:btnTag.tag]];
//            [indexArr removeObject:  [NSString stringWithFormat:@"%@",indexx]];
//        }else{
//               [blockCheckedArray removeObject:[[userListArray valueForKey:@"grpId"] objectAtIndex:btnTag.tag]];
//            
//             [indexArr removeObject:  [NSString stringWithFormat:@"%@",indexx]];
//        }
//        
//    
//
//        
//        
//       
//        
//        NSLog(@"%@",indexArr);
//
//      
//    
//    }
//    
//    
//}
//- (IBAction)CheckAllClicked:(id)sender {
//    
//   
//
//    if (!_BtnCheckAll.isSelected) {
//        [_BtnCheckAll setSelected:YES];
//        
//        
//        
//    }else{
//        
//        [_BtnCheckAll setSelected:NO];
//        
//       
//        
//    }
//    
//    [_employeeTableView reloadData];
//                            
//}



- (IBAction)userClicked:(id)sender {
    [KVNProgress show];
    isUser = true ;
   totalcheckmarkArray = [[NSMutableArray alloc]init];
    selectedUsers = [[NSMutableArray alloc]init];
    blockedArray = [[NSMutableArray alloc]init];
    userListArray = [[NSMutableArray alloc]init];
     [_BtnCheckAll setSelected:NO];
    
    self.lblMobile.text  = @"Mobile No.";
    self.lblName.text = @"Name";
    self.lblRole.text = @"Image";
    if ([UIScreen mainScreen].bounds.size.width == 768 || [UIScreen mainScreen].bounds.size.width == 1024 ) {
        _lblRole.textAlignment = NSTextAlignmentCenter;
        
        
    }else{
        _lblRole.textAlignment = NSTextAlignmentCenter;
        
    }
    
    _xLblLayout.constant = 0 ;
    [self.view layoutIfNeeded];
    _bulkUploadWidth.constant = 30;
    [self.view layoutIfNeeded];
    
     [self  GetProfileFromServer];
    
    
}


- (IBAction)groupClicked:(id)sender {
   
    groupcheckmarkArray = [[NSMutableArray alloc]init];
    selectedGroups = [[NSMutableArray alloc]init];
    BlockedGroups = [[NSMutableArray alloc]init];
  userListArray = [[NSMutableArray alloc]init];
    
    [_BtnCheckAll setSelected:NO];
    isUser = false ;
    self.lblName.text  = @"Members";
    self.lblRole.text = @"Group des.";
    self.lblMobile.text = @"Group Name";
    
    if ([UIScreen mainScreen].bounds.size.width == 768 || [UIScreen mainScreen].bounds.size.width == 1024 ) {
        _lblRole.textAlignment = NSTextAlignmentCenter;
        
        
    }else{
        _lblRole.textAlignment = NSTextAlignmentCenter;
        
    }
    _bulkUploadWidth.constant = 0;
    [self.view layoutIfNeeded];
    _xLblLayout.constant = self.view.frame.size.width/2 ;
    [self.view layoutIfNeeded];
    
    [KVNProgress show];
    
    [self GettingGroupsFromServer];
    
}

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText

{
    if (isUser == true) {
    
    NSMutableArray *arrSearch = [[NSMutableArray alloc]init];
   // arrSearch = [[NSMutableArray alloc]initWithArray: [userListArray valueForKey:@"firstName"]];
    
    NSString *searchTextt = self.searchBar.text ;
    
    
 
    userListArray = [[NSMutableArray alloc] initWithArray:search_tableContents];
    
    if ([searchText isEqualToString:@""]) {
        [self.employeeTableView reloadData];

        
       
    }else{
        NSPredicate *predicate = [NSPredicate
                                  predicateWithFormat:@"SELF.firstName contains %@",
                                  searchText];
        
        userListArray = [NSMutableArray arrayWithArray:[userListArray filteredArrayUsingPredicate:predicate]];
        NSLog(@"filtered count %lu ",(unsigned long)userListArray.count);
        
        [self.employeeTableView reloadData];
    }
        


      
        
        
    }
    else{
   
    
    
    
    userListArray = [[NSMutableArray alloc] initWithArray:search_tableContents];
    
    if ([searchText isEqualToString:@""]) {
        [self.employeeTableView reloadData];
        
        
        
    }else{
        NSPredicate *predicate = [NSPredicate
                                  predicateWithFormat:@"SELF.grpName contains %@",
                                  searchText];
        
        userListArray = [NSMutableArray arrayWithArray:[userListArray filteredArrayUsingPredicate:predicate]];
        NSLog(@"filtered count %lu ",(unsigned long)userListArray.count);
        
        [self.employeeTableView reloadData];
    }
    
    }
    
}




-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar

{
    
   
        [self.searchBar resignFirstResponder];
        
        
    
}


- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    
    //hide keyboard
    
    [_searchBar resignFirstResponder];
    
}

- (IBAction)btnAdd:(id)sender {
    
    if (isUser == true) {
        UserDetailsEmployeeVc *userDetails = [[UserDetailsEmployeeVc alloc]init];
        
        userDetails = [self.storyboard instantiateViewControllerWithIdentifier:@"UserDetailsEmployeeVc"];
        userDetails.EditStr =@"";
        
        [self.navigationController pushViewController:userDetails animated:YES];

    }else{
        AddGroupEmployeeMangVC *userDetails = [[AddGroupEmployeeMangVC alloc]init];
        
        userDetails = [self.storyboard instantiateViewControllerWithIdentifier:@"AddGroupEmployeeMangVC"];
       
        
        [self.navigationController pushViewController:userDetails animated:YES];
        
        
    }
    
    
    
}

- (IBAction)bulkUpload:(id)sender {
    

    
    BulkUploadEmployeeManagVC *bulkUpload = [[BulkUploadEmployeeManagVC alloc]init];
    
    bulkUpload = [self.storyboard instantiateViewControllerWithIdentifier:@"BulkUploadEmployeeManagVC"];
    
    
    [self.navigationController pushViewController:bulkUpload animated:YES];
    
    
    
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView == alertBlock) {
        
        if (buttonIndex== 1) {
            [KVNProgress show];
            
            if (isUser == true) {
                
                [_BtnCheckAll setSelected:NO];
                
                [self blockPersonAPI];
                
            }
            else{
                
                [_BtnCheckAll setSelected:NO];

                [self blockGroupPersonAPI];
            }
        }
    }else if (alertView == alertUnBlock) {
        
        if (buttonIndex== 1) {
            [KVNProgress show];
            
            if (isUser == true) {
                
                [_BtnCheckAll setSelected:NO];

                
                
                [self UnblockPersonAPI];
                
            }else{
                
                [_BtnCheckAll setSelected:NO];

                
                [self  UnblockGroupPersonAPI];
                
            }
        }
    }

    
}
- (IBAction)btnBlock:(id)sender {
    
    alertBlock = [[UIAlertView alloc]initWithTitle:nil message:@"Are you sure you want to Block" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
    
    [alertBlock show];
    
   
}

- (IBAction)btnUnblock:(id)sender {
    
    alertUnBlock = [[UIAlertView alloc]initWithTitle:nil message:@"Are you sure you want to unblock" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
    
    [alertUnBlock show];

    
    }

- (IBAction)backClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}





-(void)GetProfileFromServer{
   
    
    NSString *apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getperson?cmpId=%@&filterType=ALL&page=20&limit=20",companyId];
    
 
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
     manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
        
       
        
        allData = responseObject ;
        
        
        
       // userListArray = [responseObject valueForKey:@"prsnData"];
      //  search_tableContents =[[NSMutableArray alloc]initWithArray: [responseObject valueForKey:@"prsnData"]];

        NSLog(@"%@",userListArray);

        
                                                            [self performSelectorOnMainThread:@selector(getuserDetails) withObject:nil waitUntilDone:YES];
        
        

        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    

    
    
}

-(void)kvnProgress{
    
     [KVNProgress dismiss];
    
}


-(void)getuserDetails{
    
    
    int count = 0 ;
    NSString*personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    double idPerson = [personId doubleValue];
    
    
   NSMutableArray*listArrayy = [[NSMutableArray alloc]init];
     userListArray = [[NSMutableArray alloc]init];
    listArrayy = allData[@"prsnData"];
    
    
    
    
    
    for (NSDictionary *dict in listArrayy){
        
        NSMutableDictionary *dicData = [[NSMutableDictionary alloc]init];
        
        [dicData addEntriesFromDictionary:dict];
        [dicData setValue:@"NO" forKey:@"checked"];

        
        count = count + 1 ;
        
        int i = count - 1 ;
        NSString*list = [NSString stringWithFormat:@"%@",[dict valueForKey:@"empSts"]];
        NSString*roleNme = [NSString stringWithFormat:@"%@",[dict valueForKey:@"role"]];
        
        
        
            
            if ([[dict valueForKey:@"personId"] isEqual:[NSNumber numberWithDouble:idPerson]]) {
                
            }else{
                
                [userListArray addObject:dicData];
                
                
            }
        
    }
    
    search_tableContents = [[NSMutableArray alloc]initWithArray:userListArray];

    
    
    for (int i=0; i<[userListArray count]; i++) // Number of Rows count
    {
        [totalcheckmarkArray addObject:@"NO"];
        
        
    }
    
    
    
    [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];


}

//-(void)getuserDetails{
//    
//    //    [KVNProgress dismiss];
//    userListArray = [[NSMutableArray alloc]init];
//    
//    userListArray = [profileData valueForKey:@"prsnData"];
//    NSLog(@"%@",userListArray);
//    
//    int count = 0 ;
//     
//    for (NSDictionary *dict in userListArray){
//        
//        count = count + 1 ;
//        
//         i = count - 1 ;
//        
//        if ([[userListArray[i] valueForKey:@"role"]  isEqualToString: @"ROLE_SUPER_ADMIN"])
//             [userListArray removeObject: dict];
//            
//            }
//    
//   
//    NSLog(@"%@",userListArray);
//
//    
//     [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
//    
//    
//}



-(void)blockPersonAPI{
    
    
    
    NSDictionary *headers = @{ @"content-type": @"application/json",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"1205bea1-a991-d07d-3bc5-37128ed1eb9a" };
    NSDictionary *parameters = @{ @"personId": selectedUsers };
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/person/secure/blockperson"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:100.0];
    [request setHTTPMethod:@"PUT"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    [request setValue:Tokenid forHTTPHeaderField:@"token"];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                        
                                                         [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
                                                        
                                                        if (data != nil) {
                                                          blockUser =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                                            
                                                            [self performSelectorOnMainThread:@selector(userSuccessBlocked) withObject:nil waitUntilDone:YES];
                                                            
                                                           // [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
                                                            
                                                            
                                                        }

                                                    }
                                                }];
    [dataTask resume];
}
-(void)userSuccessBlocked{
    
    selectedUsers = [NSMutableArray new];

    
    if ([[blockUser valueForKey:@"message"] isEqualToString:@"success"]) {
        
//        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Successfully blocked" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
//        
//        [alert show];
        
        [self GetProfileFromServer];
        
        
        
        NSLog(@"unblocked");
        
        
    }
    
}

-(void)UnblockPersonAPI{
    
    
    NSDictionary *headers = @{ @"content-type": @"application/json",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"1205bea1-a991-d07d-3bc5-37128ed1eb9a"
                               };
    NSDictionary *parameters = @{ @"personId": selectedUsers };
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/person/secure/unblockPerson"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:100.0];
    [request setHTTPMethod:@"PUT"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    [request setValue:Tokenid forHTTPHeaderField:@"token"];
   
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                        
                                    [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
                                                        if (data != nil) {
                                                             unblockUser =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                                            
                                                    [self performSelectorOnMainThread:@selector(userSuccessunBlocked) withObject:nil waitUntilDone:YES];
                                                            
                                                           // [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
                                                            
                                                        }
                                                        
                                                    }
                                                }];
    [dataTask resume];
}

-(void)userSuccessunBlocked{
    selectedUsers = [NSMutableArray new];
    
    if ([[unblockUser valueForKey:@"message"] isEqualToString:@"success"]) {
                
        [self GetProfileFromServer];
        
        
        NSLog(@"unblocked");
        
        
    }

}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (isUser == true) {
        selectedUsers = [[NSMutableArray alloc]init];
        
        UserDetailsEmployeeVc *userDetails = [[UserDetailsEmployeeVc alloc]init];
        
        userDetails = [self.storyboard instantiateViewControllerWithIdentifier:@"UserDetailsEmployeeVc"];
        
        
        i = i -1 ;
        
        NSString*strRole =  [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"role"]objectAtIndex:indexPath.row]];
        
        NSString*hostId = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"hostId"]objectAtIndex:indexPath.row]];
        
        NSString*role = [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
        
        
        double host = [hostId doubleValue];
        double person = [strProfileid doubleValue];
        
        if ([role isEqualToString:@"ROLE_SUPER_ADMIN"] ) {
            if ([strRole isEqualToString:@"ROLE_SUPER_ADMIN"]) {
                
                
            }else{
                userDetails.editDetailArray = [userListArray objectAtIndex:indexPath.row] ;
                userDetails.EditStr =@"EditDetails";
                
                
                [self.navigationController pushViewController:userDetails animated:YES];
                
                
            }

        }
        else{
      
         if ([strRole isEqualToString:@"ROLE_SUPER_ADMIN"] || host != person) {
            
            
        }else{
            userDetails.editDetailArray = [userListArray objectAtIndex:indexPath.row] ;
            userDetails.EditStr =@"EditDetails";
            
            
            [self.navigationController pushViewController:userDetails animated:YES];
             
        
        }
 }

    }else{
        
        
        AddGroupEmployeeMangVC *userDetails = [[AddGroupEmployeeMangVC alloc]init];
        
        userDetails = [self.storyboard instantiateViewControllerWithIdentifier:@"AddGroupEmployeeMangVC"];
        userDetails.isGroup = @"isGroup" ;
        i = i -1 ;
        
        userDetails.editDetailArray = [userListArray objectAtIndex:indexPath.row];
        
        [self.navigationController pushViewController:userDetails animated:YES];
        

    }
    
    
    
}

-(void)GettingGroupsFromServer{
    
    

    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/group/secure/getgroup?cmpId=%@&personId=%@",companyId,strProfileid];
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
        
        getGroupDetails = responseObject ;
        
//        userListArray = [[NSMutableArray alloc]init];
//        userListArray = [responseObject valueForKey:@"prsngrp"];
//        
//     search_tableContents =[[NSMutableArray alloc]initWithArray: [responseObject valueForKey:@"prsngrp"]];
//        
        
        [self performSelectorOnMainThread:@selector(getData) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
        [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];

        NSLog(@"Error: %@", error);
        
    }];


}




-(void)getData {
    
    
    
    userListArray = [[NSMutableArray alloc]init];
    userListArray = [getGroupDetails valueForKey:@"prsngrp"];
    
    
    
    
    userListArray = [[NSMutableArray alloc]init];
    NSMutableArray* ListArray = [[NSMutableArray alloc]init];
    
    
    
    ListArray = getGroupDetails[@"prsngrp"];
    
    
    
    int count = 0 ;
    
    for (NSDictionary *dict in ListArray){
        NSMutableDictionary *dicData = [[NSMutableDictionary alloc]init];
        
        [dicData addEntriesFromDictionary:dict];
        [dicData setValue:@"NO" forKey:@"checked"];
        
        
        count = count + 1 ;
        
        int i = count - 1 ;
        NSString*list = [NSString stringWithFormat:@"%@",[dict valueForKey:@"grpSts"]];
        NSString*roleNme = [NSString stringWithFormat:@"%@",[dict valueForKey:@"role"]];
        
        
        
            
            [userListArray addObject:dicData];
            
            
        
        
    }
    
    search_tableContents = [[NSMutableArray alloc]initWithArray:userListArray];
    
    
    for (int i=0; i<[userListArray count]; i++) // Number of Rows count
    {
        [groupcheckmarkArray addObject:@"NO"];
        
        
    }
    
    
    
    [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    
}
    
    
//    for (int j=0; j<[userListArray count]; j++) // Number of Rows count
//    {
//        [groupcheckmarkArray addObject:@"NO"];
//        
//        
//    }
//    
//   
//    
//    [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
//    
//}
//

-(void)blockGroupPersonAPI{
    
    
    NSDictionary *headers = @{ @"content-type": @"application/json",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"1205bea1-a991-d07d-3bc5-37128ed1eb9a" };
    NSDictionary *parameters = @{ @"grpId": selectedGroups };
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/group/secure/blockgroup"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:100.0];
    [request setHTTPMethod:@"PUT"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    [request setValue:Tokenid forHTTPHeaderField:@"token"];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                        
                                                         [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
                                                        
                                                        if (data != nil) {
                                                             unblkUser =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                                            
                                                              [self performSelectorOnMainThread:@selector(showData) withObject:nil waitUntilDone:YES];
                                                            
                                                          //  [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
                                                        }
                                                        
                                                    }
                                                }];
    [dataTask resume];
}

-(void)UnblockGroupPersonAPI{
    
     
    NSDictionary *headers = @{ @"content-type": @"application/json",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"1205bea1-a991-d07d-3bc5-37128ed1eb9a" };
    NSDictionary *parameters = @{ @"grpId": selectedGroups };
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/group/secure/unblockgroup"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"PUT"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    [request setValue:Tokenid forHTTPHeaderField:@"token"];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
                                                    
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                        
                                                        
                                                        
                                                        
                                                        if (data != nil) {
                                                             unblkUser =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                                            
                                                            
                                                        [self performSelectorOnMainThread:@selector(UnBlockshowData) withObject:nil waitUntilDone:YES];
                                                            
                                                            
                                                            
                                                        }
                                                        
                                                    }
                                                }];
    [dataTask resume];
}

-(void)showData{
    
    selectedGroups = [NSMutableArray new];

    if ([[unblkUser valueForKey:@"message"] isEqualToString:@"success"]) {
        
//        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Successfully group blocked" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
//        
//        [alert show];
        
        [self GettingGroupsFromServer];
        
        
    }

}

-(void)UnBlockshowData{
    
    if ([[unblkUser valueForKey:@"message"] isEqualToString:@"success"]) {
        
//        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Successfully group unblocked" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
//        
//        [alert show];
        [self GettingGroupsFromServer];
        
    }
    
}



- (IBAction)subscribeClicked:(id)sender {
    SubscriptionVC*subVc = [[SubscriptionVC alloc]init];
    subVc = [self.storyboard instantiateViewControllerWithIdentifier:@"SubscriptionVC"];
    [self.navigationController pushViewController:subVc animated:YES];

}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([UIScreen mainScreen].bounds.size.width== 768 || [UIScreen mainScreen].bounds.size.width== 1024) {
        
        return 100 ;
    }else{
        return 44 ;
    }
}

@end
