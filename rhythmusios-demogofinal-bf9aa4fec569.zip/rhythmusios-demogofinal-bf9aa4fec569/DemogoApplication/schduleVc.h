//
//  schduleVc.h
//  schedulePAgeDesign
//
//  Created by Rhythmus on 26/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AddressBookUI/AddressBookUI.h>
#import <AddressBook/AddressBook.h>
#import "schduleVc.h"
#import "MyMeetingsVc.h"
#import <MobileCoreServices/MobileCoreServices.h>


@interface schduleVc : UIViewController<UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UINavigationControllerDelegate,UIPageViewControllerDelegate,ABPeoplePickerNavigationControllerDelegate,UITextViewDelegate,senddataProtocolDelegate,UITextFieldDelegate,UISearchBarDelegate,UIDocumentPickerDelegate,UIDocumentMenuDelegate,UIAlertViewDelegate>{
    
    UITapGestureRecognizer *tapScrollView;
    UITapGestureRecognizer *tapper;
    
    id cancelConf ;
    id dataAll ;
    id scheduleData ;
    NSString *DateStr ;
    NSString*dialOut ;
    NSString*Secure ;
    NSString*Manage ;
    NSString*Recording ;
    NSString*QA ;
    
    NSMutableArray *userListArray ;
    //UIButton *btnTag;
    NSMutableArray *selectUserArray;
    NSString *joinedString ;
    id profileData ;
    NSString*personIdStr;
    NSString*companyId;
    NSString*Tokenid ;
    id getGroupDetails;
    BOOL isUser;
     UIImage *profileImage;
    
    NSMutableArray *addValuesArray ;
    UIButton *btn ;
    
    NSMutableDictionary *dictData;
    
    
    NSMutableArray *totalcheckmarkArray;
     NSMutableArray *groupcheckmarkArray;
    NSMutableArray *selectedGroups;
    NSMutableArray *selectedUsers ;
    
    NSArray*addedData ;
    NSString*dialIn ;
    NSString *dialType;
    
    NSString *confId ;
    
    int personID ;
    long datee ;
    
    
    long strtTIME ;
    long ENDTIME ;
    
    int RECORDINGINT ;
    int ManageINT ;
    int SecureINT ;
    int QAINT ;
    id isVarified ;
    NSMutableArray* search_group;
    
    
    NSMutableArray *addOnArray ;
    
NSMutableDictionary* schededDataArray ;
    NSString* mobile ;
    NSString*bulkUploadString ;
    BOOL IsEditing ;
    NSString*checkPlan;
    NSString*planNameCHeck;
    
    NSMutableArray *arrayTableData;
    NSMutableArray *contactNumbersArray;
    
    NSString *phone;
    NSMutableDictionary *dict;
    NSMutableArray *nameList ;
    NSMutableArray *arrayContacts;
    NSMutableArray*search_tableContents ;
    NSMutableArray*search_phoneNAME ;
    NSMutableArray*contactImagesArray ;
    NSMutableArray*checkedConatcts;
    NSMutableDictionary* personDictt;
    
    NSMutableArray*contactsAlldata;
    NSMutableArray * addImage;
    NSMutableArray *aarayImage;
    NSMutableArray*groupListArray;
    
    BOOL isBULK ;
    NSString *extensionFile ;
    NSString*documentsDirectory ;
    NSData *fileData;
    
    
    NSString *grpIdd;
    NSString*mobileIdd;
    NSString*strpersonId;
     NSString *editFlag ;

    BOOL contactsSyched;
    NSMutableArray*contctInfo ;
    NSMutableArray*cnArray;
    NSMutableArray*sendingContacts;
    BOOL isContactsSt;
    
   
}

- (IBAction)refreshContactsClicked:(id)sender;

- (IBAction)bckPreviewClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *previewPage;
@property (strong, nonatomic) IBOutlet UIButton *bckPreview;

@property (strong, nonatomic) IBOutlet UILabel *txtDear;

@property (strong, nonatomic) IBOutlet UILabel *txtPrevHeaderDate;

@property (strong, nonatomic) IBOutlet UILabel *txtSubject;

@property (strong, nonatomic) IBOutlet UILabel *txtPrevDate;

@property (strong, nonatomic) IBOutlet UILabel *txtPrevConfCode;

@property (strong, nonatomic) IBOutlet UILabel *txtPrevDialOut;
@property (strong, nonatomic) IBOutlet UITextView *txtPrevDetails;
@property (strong, nonatomic) IBOutlet UILabel *txtPrevStart;

@property (strong, nonatomic) IBOutlet UILabel *txtPrevEnd;





@property(nonatomic,strong)NSMutableArray *checkArray ;
@property (nonatomic, retain) NSIndexPath* checkedIndexPath;

@property (strong, nonatomic) IBOutlet UITableView *contactsTableView;
@property (strong, nonatomic) IBOutlet UISearchBar *phoneSearchBar;
- (IBAction)phoneBckClicked:(id)sender;
- (IBAction)PhonedoneClicked:(id)sender;




@property (strong, nonatomic) IBOutlet UILabel *headerLabel;
@property (strong, nonatomic) IBOutlet UIButton *btnReschedule;
@property (strong, nonatomic) IBOutlet UIButton *btnRepreview;

- (IBAction)bckEditClicked:(id)sender;

////       Company Image View Name
@property (strong, nonatomic) IBOutlet UIButton *btnMeeting;
@property (strong, nonatomic) IBOutlet UIButton *bckEditConf;

@property (strong, nonatomic) IBOutlet UIImageView *CmpanyImageView;

/////  Back view  in EMployeeDirectory/Functional Group/Phone Directory/Bulk Upload/ Add on
@property (strong, nonatomic) IBOutlet UIView *AddBtnView;

                    // Button Acction or outlet on AddBtnView

- (IBAction)btnEmpDirectory:(id)sender;

- (IBAction)btnFuncGroup:(id)sender;

- (IBAction)btnPhoneDirectory:(id)sender;

- (IBAction)btnBulkUpload:(id)sender;

- (IBAction)btnAddOn:(id)sender;


///////                 ScrolcontactViews

@property (strong, nonatomic) IBOutlet UIView *ScrollContactView;



                    //btn outlet
@property (strong, nonatomic) IBOutlet UIButton *BtnEmpDir;

@property (strong, nonatomic) IBOutlet UIButton *BtnFucGroup;
@property (strong, nonatomic) IBOutlet UIButton *BtnPhoneDirectory;
@property (strong, nonatomic) IBOutlet UIButton *BtnBulkUpload;
@property (strong, nonatomic) IBOutlet UIButton *BtnAddOn;


/////   /   /   /          Text Field for Select Date,startTime,End Time

@property (strong, nonatomic) IBOutlet UITextField *txtSelectDate;

@property (strong, nonatomic) IBOutlet UITextField *txtStartTime;

@property (strong, nonatomic) IBOutlet UITextField *txtEndTime;

        ////  Schedule text Field  or Downlaod Button Action or outlet  or Labels

@property (strong, nonatomic) IBOutlet UILabel *lbldate;

@property (strong, nonatomic) IBOutlet UILabel *lblsatrtTime;

@property (strong, nonatomic) IBOutlet UILabel *lblendtime;



@property (strong, nonatomic) IBOutlet UITextField *txtSchedule;

@property (strong, nonatomic) IBOutlet UIButton *BtnDownload;

- (IBAction)btnDownload:(id)sender;


       ////     Check Box Button Action or Outlet

- (IBAction)btnDialOut:(id)sender;

- (IBAction)btnSecure:(id)sender;

- (IBAction)btnManage:(id)sender;

- (IBAction)btnRecording:(id)sender;

- (IBAction)btnQA:(id)sender;

            /// Check Box Button Outlet

@property (strong, nonatomic) IBOutlet UIButton *btnDialOut;

@property (strong, nonatomic) IBOutlet UIButton *btnSecure;

@property (strong, nonatomic) IBOutlet UIButton *btnManage;

@property (strong, nonatomic) IBOutlet UIButton *btnRecording;

@property (strong, nonatomic) IBOutlet UIButton *btnQA;




    /////       Preview , schedule  , Reset Button Action or outlet

- (IBAction)btnPreview:(id)sender;

- (IBAction)btnSchedule:(id)sender;

- (IBAction)btnReset:(id)sender;

                ///   pre.., sch.. reset Button outlet

@property (strong, nonatomic) IBOutlet UIButton *btnPreview;

@property (strong, nonatomic) IBOutlet UIButton *btnSchedlue;
@property (strong, nonatomic) IBOutlet UIButton *btnReset;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *bottomPicker;
@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
- (IBAction)doneClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *addEmployeeView;
@property (strong, nonatomic) IBOutlet UITableView *employeeTableView;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
- (IBAction)checkAllClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnCheckAll;
- (IBAction)backClicked:(id)sender;
- (IBAction)btnSaveClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *lblMobile;
@property (strong, nonatomic) IBOutlet UILabel *lblName;

@property (strong, nonatomic) IBOutlet UILabel *lblRole;
@property (strong, nonatomic) IBOutlet UITableView *pagingTableView;
@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (strong, nonatomic) IBOutlet UITextView *txtView;
- (IBAction)doneBtn:(id)sender;
- (IBAction)backOpenParticpants:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *openParticipantsView;
- (IBAction)opBckClicked:(id)sender;
- (IBAction)myMeetingsClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *txtNoEmployee;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;

@property (strong, nonatomic) IBOutlet UIView *viewSubscribe;

@property (strong, nonatomic) IBOutlet UIView *viewSubSubscribe;
- (IBAction)btnSubscribe:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnSubscribe;
@property (strong, nonatomic) IBOutlet UILabel *lblSchedule;
@property (strong, nonatomic) IBOutlet UIButton *addOnbutton;
@property (strong, nonatomic) IBOutlet UIButton *btnDonee;
@property (strong, nonatomic) IBOutlet UIView *PhoneContactsView;

@property (strong, nonatomic) IBOutlet UILabel *LabelQA;


- (IBAction)allContactsClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnCheckContacts;

@property (strong, nonatomic) IBOutlet UILabel *txtEmployeeCount;
@property (strong, nonatomic) IBOutlet UILabel *phoneContactCount;



@end

