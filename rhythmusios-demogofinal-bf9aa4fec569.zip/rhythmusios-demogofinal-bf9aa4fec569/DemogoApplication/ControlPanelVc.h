//
//  ControlPanelVc.h
//  DemogoApplication
//
//  Created by katoch on 25/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AFNetworking/AFNetworking.h>
#import <AVFoundation/AVFoundation.h>



#define ACCEPTABLE_CHARACTERS @"0123456789,"

@interface ControlPanelVc : UIViewController<UIAlertViewDelegate,UISearchBarDelegate,AVAudioRecorderDelegate,AVAudioPlayerDelegate>{
    
    NSString*companyId;
    NSString*Tokenid;
   
    NSString*ConfId ;
    NSString*personId;
    id controlConferernce ;
    NSString *status ;
    NSString *strNumbers ;
    UITapGestureRecognizer*tapper;

    NSURLSession *sessionControlConf ;
    NSURLSessionDataTask *sessionControltask;
    BOOL isSessionNil ;
    NSString *role;

    id  confSelfMute;
    id  confSelfunMute;
    id  confRecordStop ;
    id  confRecord ;
    id  confDrop ;
    
    id  confAllMute;
    id  confAllUnMute;
    id  addMoreParticipant ;
    id dialMe ;
    AFHTTPSessionManager *managerAf;
    NSTimer *aTimer;
    NSString*pmobile;
    NSString*RoleStr;
    NSString*hostId ;
    
    UIAlertView *endConfalert;
    
    NSString*allParticipantsMute;
    NSString*end;
    NSString*liverecording;
    NSString*selfmute;
   
    UIAlertView*RecordingAlert ;
    NSString* Endstatus ;
    id   singleParticipantEndCall ;
    NSString*pMobile;
    
    BOOL ifManage;
    
    NSMutableArray*  arrayListOfRecordSound ;
    
    AVAudioRecorder*   recorder;
    
}

@property (strong, nonatomic) IBOutlet UILabel *txtNoConference;

@property (strong, nonatomic) IBOutlet UIButton *btnDone;

@property (strong, nonatomic) IBOutlet UIButton *btnParticipants;
@property (strong, nonatomic) IBOutlet UIButton *btnAcknowledgement;
@property (strong, nonatomic) IBOutlet UIButton *btnSelfMute;
@property (strong, nonatomic) IBOutlet UIButton *btnParticipantMute;
@property (strong, nonatomic) IBOutlet UIButton *btnRecord;
@property (strong, nonatomic) IBOutlet UIButton *btnAddOn;
@property (strong, nonatomic) IBOutlet UIButton *btnDialMe;
@property (strong, nonatomic) IBOutlet UIButton *btnEndConfernce;



- (IBAction)participantsClicked:(id)sender;
- (IBAction)acknowledgementClicked:(id)sender;

- (IBAction)muteClicked:(id)sender;
- (IBAction)participantMuteClicked:(id)sender;
- (IBAction)recordClicked:(id)sender;
- (IBAction)addOnclicked:(id)sender;
- (IBAction)dialMeClicked:(id)sender;
- (IBAction)endConferanceClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *openParticipantView;
- (IBAction)bckOPClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UITextView *txtView;

- (IBAction)doneOPClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnQA;

- (IBAction)ClickedQA:(UIButton *)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnGoLive;

- (IBAction)ClickedGoLive:(UIButton *)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnPolling;

- (IBAction)ClickedPolling:(UIButton *)sender;

//golive
@property (strong, nonatomic) IBOutlet UIView *goLiveView;
@property (strong, nonatomic) IBOutlet UIButton *btnDocument;
@property (strong, nonatomic) IBOutlet UIButton *btnAudio;
@property (strong, nonatomic) IBOutlet UIButton *btnVideo;
@property (strong, nonatomic) IBOutlet UIView *subLiveView;
@property (strong, nonatomic) IBOutlet UIView *SelectFileView;

- (IBAction)documentClicked:(id)sender;
- (IBAction)audioCicked:(id)sender;
- (IBAction)btnVideo:(id)sender;


@property (strong, nonatomic) IBOutlet UIView *fileSelectionView;
@property (strong, nonatomic) IBOutlet UITextField *txtUrl;
@property (strong, nonatomic) IBOutlet UIButton *btnSubmit;
@property (strong, nonatomic) IBOutlet UITextField *txtMobile;
//@property (strong, nonatomic) IBOutlet UITextField *txtIp;
- (IBAction)attachmentClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnAttachment;






- (IBAction)txtSubmit:(id)sender;



@property (strong, nonatomic) IBOutlet NSLayoutConstraint *panelHeightLayout;
//////// music/video/Doc file View

@property (strong, nonatomic) IBOutlet UIView *streamingView;

@property (strong, nonatomic) IBOutlet UIButton *btnClose;

- (IBAction)closeClicked:(id)sender;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *bottomLayout;

//////// streaming view COntrolp panel Button Outlet




@property (strong, nonatomic) IBOutlet UIButton *btnAcknowledement2;

@property (strong, nonatomic) IBOutlet UIButton *btnActiveParticipent2;
@property (strong, nonatomic) IBOutlet UIButton *btnSelfmute2;

@property (strong, nonatomic) IBOutlet UIButton *btnParticipantMute2;
@property (strong, nonatomic) IBOutlet UIButton *btnRecord2;
@property (strong, nonatomic) IBOutlet UIButton *btnAddon2;
@property (strong, nonatomic) IBOutlet UIButton *btnDialme2;

@property (strong, nonatomic) IBOutlet UIButton *btnQA2;


@property (strong, nonatomic) IBOutlet UIButton *btnGolive2;

@property (strong, nonatomic) IBOutlet UIButton *btnPolling2;
@property (strong, nonatomic) IBOutlet UIButton *btnEndcall2;





//q&a
@property (strong, nonatomic) IBOutlet UIView *qaView;
@property (strong, nonatomic) IBOutlet UIView *txtAudioSelectView;
@property (strong, nonatomic) IBOutlet UIButton *btnTextQA;
@property (strong, nonatomic) IBOutlet UIButton *btnAudioQA;

- (IBAction)txtQAclicked:(id)sender;
- (IBAction)txtAudioClicked:(id)sender;

//textQA

@property (strong, nonatomic) IBOutlet UIView *textQAView;
- (IBAction)closeTextViewClicked:(id)sender;
- (IBAction)saveTextClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UITextView *txtDetails;
- (IBAction)backTxtClicked:(id)sender;



//audio
@property (strong, nonatomic) IBOutlet UIView *audioQAView;

@property (strong, nonatomic) IBOutlet UIView *viewAudio;
- (IBAction)btnRecordClicked:(id)sender;
- (IBAction)endRecordClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnListen;
- (IBAction)listenClicked:(id)sender;
- (IBAction)btnAudioSave:(id)sender;
- (IBAction)btnAudioClose:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *backAudioView;
- (IBAction)backAudioViewClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UITableView *manageTableView;

@property (strong, nonatomic) IBOutlet UIView *adminQAView;

- (IBAction)btnBackAdminQA:(id)sender;

@property (strong, nonatomic) IBOutlet UIView *manageView;

@property (strong, nonatomic) IBOutlet UIView *unManageView;

@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;


- (IBAction)ManageClicked:(id)sender;

- (IBAction)unmanageClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnManage;

@property (strong, nonatomic) IBOutlet UIButton *btnUnmanage;

@property (strong, nonatomic) IBOutlet UIButton *btnQARecord;

@property (strong, nonatomic) IBOutlet UIButton *btnQAEndRecord;

@property (strong, nonatomic) IBOutlet UIProgressView *QAprogressBar;

@property (strong, nonatomic) IBOutlet UILabel *LblStartTime;

@property (strong, nonatomic) IBOutlet UILabel *lblEndTime;




//////////////////     QA View recordFile Listen button View     ///////


@property (strong, nonatomic) IBOutlet UIView *listenSubView;

@property (strong, nonatomic) IBOutlet UIImageView *listenMusicIMG;

@property (strong, nonatomic) IBOutlet UILabel *LbllistenStartTime;

@property (strong, nonatomic) IBOutlet UILabel *lbllistenEndTime;

@property (strong, nonatomic) IBOutlet UISlider *listenSliderBar;

@property (strong, nonatomic) IBOutlet UIButton *listenForwardBtn;


@property (strong, nonatomic) IBOutlet UIButton *listenPlayBTn;


@property (strong, nonatomic) IBOutlet UIView *ListenReverseBTN;

- (IBAction)listenCloseBtn:(UIButton *)sender;

- (IBAction)listenclickedForward:(UIButton *)sender;

- (IBAction)listenclickedPlay:(UIButton *)sender;

- (IBAction)listenClickedReverse:(UIButton *)sender;

- (IBAction)sliderChanged : (UISlider *)sender;

@property (strong, nonatomic) IBOutlet UIView *listenView;


@end
