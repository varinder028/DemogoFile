//
//  LegendPlanSumryTableViewCell.h
//  DemogoApplication
//
//  Created by katoch on 02/06/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LegendPlanSumryTableViewCell : UITableViewCell


@property (strong, nonatomic) IBOutlet UILabel *lblLegendName;

@property (strong, nonatomic) IBOutlet UILabel *lbllegendColour;


@end
