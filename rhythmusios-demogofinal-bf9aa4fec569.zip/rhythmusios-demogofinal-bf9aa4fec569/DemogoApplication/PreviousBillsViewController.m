//
//  PreviousBillsViewController.m
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "PreviousBillsViewController.h"
#import "BillsCell.h"
#import "ViewController.h"
#import <AFNetworking/AFNetworking.h>
#import "KVNProgress.h"
@interface PreviousBillsViewController ()<UITableViewDelegate,UITableViewDataSource>

{
    NSMutableArray * entrydata;
    NSMutableArray * dateENtry;
    NSMutableArray * payENtry;
    
    NSMutableArray * imageentry;

    
}

@end

@implementation PreviousBillsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _tableview.separatorStyle = UITableViewCellSeparatorStyleNone ;
    
    
    if ([[NSUserDefaults standardUserDefaults]boolForKey:@"previousBills"] == true) {
        
        
        
        _txtHeader.text = @"Previous Bills" ;
        _txtID.text = @"Bill ID" ;
        _txtDate.text = @"Bill Date";
        _txtPayment.text = @"Payment Amount";
        _txtDownload.text = @"Download";
        
       
    }else{
        
        
        
        _txtHeader.text = @"Account Statement" ;
        _txtID.text = @"Date" ;
        _txtDate.text = @"Due Amount";
        _txtPayment.text = @"Amount Paid";
        _txtDownload.text = @"Balance left";
        

        
    }
    
    
    if ([_issub isEqualToString:@""]) {
        
    }else{
        _txtHeader.text = @"Subscrition History" ;
        
        
    }
    
    
//    _txtHeader.text = @"Subscrition History" ;
    
    UIColor *color = [UIColor whiteColor];
    _txtStartDate.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Start Date" attributes:@{NSForegroundColorAttributeName: color}];
    
    UIColor *color2= [UIColor whiteColor];
    _txtEndDate.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"End Date" attributes:@{NSForegroundColorAttributeName: color2}];
    
    

    CompanyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];

    
    entrydata  = [[NSMutableArray alloc]initWithObjects:@"September",@"October",@"November", nil];
    
     dateENtry = [[NSMutableArray alloc]initWithObjects:@"20-oct-2016",@"20-oct-2016",@"20-oct-2016", nil];
    
    payENtry = [[NSMutableArray alloc]initWithObjects:@"207",@"207",@"207", nil];
    
     imageentry = [[NSMutableArray alloc]initWithObjects:@"ruppes.png",@"ruppes.png",@"ruppes.png", nil];
    
    
    
    [self.tableview reloadData];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    
   
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dateENtry count];
    
}
-(BillsCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *cellid = @"BillsCell";
    
    BillsCell * cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    
    if (cell == nil) {
        
        NSArray *arra = [[NSBundle mainBundle]loadNibNamed:@"BillsCell" owner:self options:nil];
        
        cell = arra [0];
        
        
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone ;
    
    
    cell.monthsLAbel.text = [NSString stringWithFormat:@"%@",[entrydata objectAtIndex:indexPath.row]];
    
    cell.dateLAbel.text = [NSString stringWithFormat:@"%@",[dateENtry objectAtIndex:indexPath.row]];
    
    cell.RupeesImage.image=[UIImage imageNamed:[imageentry objectAtIndex:indexPath.row]];
    
    cell.paymentLabel.text = [NSString stringWithFormat:@"%@",[payENtry objectAtIndex:indexPath.row]];
    
    [cell.PDfDownloadButton addTarget:self action:@selector(Action) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    return cell;
    
}


-(void)Action
{
    UIAlertView *act = [[UIAlertView  alloc]initWithTitle:@"Pdf Download" message:@"Pdf is not valid" delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil];
    
    [act show];
}



- (IBAction)BAckButon:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];

}
-(void)kvnProgess{
    
    [KVNProgress dismiss];
    
}

-(void)previousBillsromServer{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/bill/secure/postpaidpreviousbill?cmpid=%@&tmPrd=%@",CompanyId,tmprd];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
        
        
        
        previousBills = responseObject ;
        [self performSelectorOnMainThread:@selector(previousBillsData) withObject:nil waitUntilDone:YES];
        NSLog(@"%@",previousBills);
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
        
    }];

    
    
    
}
-(void)accountStatementFromServer{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/bill/secure/postpaidpayment?cmpid=%@&tmPrd=%@",CompanyId,tmprd];
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
        
        
        
        accountStatement = responseObject ;
        [self performSelectorOnMainThread:@selector(accountStatementData) withObject:nil waitUntilDone:YES];
        NSLog(@"%@",previousBills);
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
    
}

-(void)previousBillsData{
    
    NSLog(@"%@",previousBills);
    
    
    
}

-(void)accountStatementData{
    
    NSLog(@"%@",accountStatement);
    
    
}


- (IBAction)doneClicked:(id)sender {
    [UIView animateWithDuration:0.5 animations:^{
        
        self.bottomPicker.constant = -232;
        [self.view layoutIfNeeded];
        
    }];
    
    [self ShowSelectedDate];
    
}


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (textField == _txtStartDate) {
        
        
        [UIView animateWithDuration:0.5 animations:^{
            [self.DatePicker setMaximumDate: [NSDate date]];
            
            DateStr = @"StartDate" ;
            self.bottomPicker.constant = 0 ;
            [self.view layoutIfNeeded];
            
            
            _DatePicker.datePickerMode = UIDatePickerModeDate;
            
            
            
        }];
        
        return NO;
        
    }  else if (textField == _txtEndDate) {
        
        if ([_txtStartDate.text isEqualToString:@""]) {
            UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message:@"" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            
            [alert show];
            
            
        }else{
        
        [UIView animateWithDuration:0.5 animations:^{
            [self.DatePicker setMaximumDate: [NSDate date]];
            
            DateStr = @"EndDate" ;
            self.bottomPicker.constant = 0 ;
            [self.view layoutIfNeeded];
            
            
            _DatePicker.datePickerMode = UIDatePickerModeDate;
            
            
            
        }];
            
        }
        
        return NO;
        
    }
    return YES;
    
}

-(void)ShowSelectedDate
{
    
    if ([DateStr isEqualToString:@"StartDate"]) {
        NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
        self.txtStartDate.font = [UIFont systemFontOfSize:12.0f];
        [formatter setDateFormat:@"dd-MMM-yyyy"];
        NSString *str=[NSString stringWithFormat:@"%@",[formatter stringFromDate:_DatePicker.date]];
        //  NSString *newString = [str stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
        self.txtStartDate.text = str;
        
       
        
    }else{
        NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
        self.txtEndDate.font = [UIFont systemFontOfSize:12.0f];
        [formatter setDateFormat:@"dd-MMM-yyyy"];
        NSString *str=[NSString stringWithFormat:@"%@",[formatter stringFromDate:_DatePicker.date]];
        //  NSString *newString = [str stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
        self.txtEndDate.text = str;
        
        tmprd = [NSString stringWithFormat:@"%@to%@",_txtStartDate.text,_txtEndDate.text];
        NSLog(@"%@",tmprd);
        
        
        if (![_issub isEqualToString:@""]) {
            
            [self subscritionHistory];
            
            
        }else{
        
        if ([[NSUserDefaults standardUserDefaults]boolForKey:@"previousBills"] == true){
            
            if ([_PrePaid isEqualToString:@"Pre"]) {
                
            }
            else{
                
                [self previousBillsromServer];
                
            }
            
        }
        
        else{
                        
                        if ([_PrePaid isEqualToString:@"Pre"]) {
                            
                        }
                        else{
                            
                           [self accountStatementFromServer];
                            
                        }
            
            
            
        }
        
        }
       
        
        
        
    }
        
    
    
}

-(void)subscritionHistory{
    
        NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile//bill/secure/subcription"];
    
    NSDictionary *parameters = @{ @"type": @"prepaid",
                                  @"cmpId": CompanyId,
                                  @"tmPrd":tmprd
                                  };

    
        
        AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
        
        [manager POST:apiURLStr parameters:parameters success:^(NSURLSessionTask *task, id responseObject) {
            NSLog(@"PLIST: %@", responseObject);
            [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
            
            
            
            subscriptionHistory = responseObject ;
            [self performSelectorOnMainThread:@selector(subHistory) withObject:nil waitUntilDone:YES];
            
            
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
            NSLog(@"Error: %@", error);
            
        }];
}

-(void)subHistory{
    
    NSLog(@"%@",subscriptionHistory);
    
}

//POST /bill/secure/subcription
@end
