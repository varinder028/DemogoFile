//
//  ManageQACell.h
//  DemogoApplication
//
//  Created by Rhythmus on 01/11/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManageQACell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIButton *btnManageType;
@property (strong, nonatomic) IBOutlet UIButton *btnMuteUnmute;
@property (strong, nonatomic) IBOutlet UILabel *txtManageHome;
@property (strong, nonatomic) IBOutlet UILabel *txtManageMobile;

@end
