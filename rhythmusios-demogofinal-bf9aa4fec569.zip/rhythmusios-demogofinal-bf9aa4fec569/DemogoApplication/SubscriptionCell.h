//
//  SubscriptionCell.h
//  DemogoApplication
//
//  Created by katoch on 22/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubscriptionCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *txtMRV;
@property (strong, nonatomic) IBOutlet UILabel *textFcv;
@property (strong, nonatomic) IBOutlet UILabel *txtFort;

@property (strong, nonatomic) IBOutlet UILabel *txtIND;
@property (strong, nonatomic) IBOutlet UILabel *txtInternational;

@end
