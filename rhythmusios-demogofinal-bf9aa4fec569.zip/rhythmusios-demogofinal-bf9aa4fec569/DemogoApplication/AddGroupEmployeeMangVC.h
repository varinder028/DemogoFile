//
//  AddGroupEmployeeMangVC.h
//  DemogoApplication
//
//  Created by Rhythmus on 03/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddGroupEmployeeMangVC : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>{
    
    NSMutableArray *userListArray;
    UIButton*btnTag ;
    id profileData;
    int i ;
    int k;
   
    NSString *companyId;
    NSString *Tokenid;
    NSMutableArray*blockCheckedArray;
    NSMutableArray*indexArr ;
    
    NSString *joinedString;
    NSString*personId ;
    NSMutableArray*groupcheckmarkArray;
    NSMutableArray *selectedGroups ;
    NSMutableArray*search_tableContents;
    NSArray*arrPersonId ;
    
    
    
}
@property (strong, nonatomic) NSMutableArray* editDetailArray;

@property (strong, nonatomic) NSString* isGroup;
@property (strong, nonatomic) IBOutlet UITextField *txtGroupName;
@property (strong, nonatomic) IBOutlet UITextField *txtGroupDescription;
- (IBAction)btnAddGroup:(id)sender;
@property (strong, nonatomic) IBOutlet UITextView *txtTextViewAddGroup;
@property (strong, nonatomic) IBOutlet UIButton *BtnCancel;
@property (strong, nonatomic) IBOutlet UIButton *BtnCreateGroup;



- (IBAction)btnCreateGroup:(id)sender;
- (IBAction)btnCancel:(id)sender;
- (IBAction)btnback:(id)sender;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (strong, nonatomic) IBOutlet UIButton *checkAllBtn;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
- (IBAction)backBtn:(id)sender;
- (IBAction)btnSave:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *addGroupView;
@property (strong, nonatomic) IBOutlet UILabel *lblEditGroup;
@property (strong, nonatomic) IBOutlet UILabel *lblAddUser;

@end
