//
//  billGraphVC.m
//  DemogoApplication
//
//  Created by katoch on 18/07/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "billGraphVC.h"
#import <PNChart/PNChart.h>
#import <AFNetworking/AFNetworking.h>
#import "KVNProgress.h"
#import "AppDelegate.h"

#if __IPHONE_OS_VERSION_MAX_ALLOWED < __IPHONE_9_0
#define supportedInterfaceOrientationsReturnType NSUInteger
#else
#define supportedInterfaceOrientationsReturnType UIInterfaceOrientationMask
#endif


@interface billGraphVC ()


@end

@implementation billGraphVC
@synthesize isPresented;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    UITapGestureRecognizer *gesRecognizer4 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismiss)]; // Declare the Gesture.
    gesRecognizer4.delegate = self;
    [self.view addGestureRecognizer:gesRecognizer4];

    
    [self.viewDetails setHidden: YES];
    [self.lineChart setUserInteractionEnabled:NO];
    
   
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    
    
    
    [delegate setShouldRotate:YES];

    
    self.viewDetails.layer.cornerRadius = 5.0f ;
    [_viewDetails clipsToBounds];
    
    
    
    
    
    // Do any additional setup after loading the view.
}

-(BOOL)shouldAutorotate
{
    return YES;
}

-(UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
    
    
}




-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
   
    
    
    NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationLandscapeLeft];
    
    [[UIDevice currentDevice] setValue:value forKey:@"orientation"];

    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    companyToken = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
   
    
    
     [KVNProgress show];
    [self getbillingGraph];
    

    
    
}





-(void)billGrpah{
    
    {
        self.view.backgroundColor= [UIColor blackColor];
        self.lineChart.backgroundColor = [UIColor whiteColor];
        self.lineChart.yGridLinesColor = [UIColor whiteColor];
        [self.lineChart.chartData enumerateObjectsUsingBlock:^(PNLineChartData *obj, NSUInteger idx, BOOL *stop) {
            obj.pointLabelColor = [UIColor whiteColor];
        }];
        
        
        if ([UIScreen mainScreen].bounds.size.width == 320 || [UIScreen mainScreen].bounds.size.width == 414 || [UIScreen mainScreen].bounds.size.width == 768 ) {
                    self.lineChart = [[PNLineChart alloc] initWithFrame:CGRectMake(0,70 ,[UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width - 60)];
            
        }
        else{
                                self.lineChart = [[PNLineChart alloc] initWithFrame:CGRectMake(0,70 , SCREEN_WIDTH, [UIScreen mainScreen].bounds.size.height - 60)];
            
            
        }
        
//        if  ([[UIDevice currentDevice] orientation] ==  UIDeviceOrientationLandscapeLeft || [[UIDevice currentDevice] orientation] ==  UIDeviceOrientationLandscapeRight)
//        {
//           
//                    self.lineChart = [[PNLineChart alloc] initWithFrame:CGRectMake(0,[UIScreen mainScreen].bounds.size.height/2 -30 , SCREEN_WIDTH, [UIScreen mainScreen].bounds.size.height/2)];
//            
//        }
//        else{
//            
//                    self.lineChart = [[PNLineChart alloc] initWithFrame:CGRectMake(0,[UIScreen mainScreen].bounds.size.width/2 -30 ,[UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width/2)];
//        }
        
       
        

        self.lineChart.showCoordinateAxis = YES;
        self.lineChart.yLabelFormat = @"%1.1f";
        self.lineChart.xLabelFont = [UIFont fontWithName:@"Helvetica-Light" size:8.0];
        self.lineChart.xLabelColor = [UIColor whiteColor];
        
        
        NSDictionary*data02Array =   [[billData valueForKey:@"billgraphdata"]valueForKey:@"datalist"];
        
        NSArray*arrKeys = [data02Array allKeys];
        NSArray*arrValues = [data02Array allValues];
        
        if (arrKeys.count > 0) {
            
            _backBtnClicked.hidden = NO;
            
            [self.lineChart setXLabels:arrKeys];
            self.lineChart.yLabelColor = [UIColor whiteColor];
            
            self.lineChart.axisColor = [UIColor whiteColor];
            
            
            
            // added an example to show how yGridLines can be enabled
            // the color is set to clearColor so that the demo remains the same
            self.lineChart.showGenYLabels = YES;
            self.lineChart.showYGridLines = YES;
            [self.lineChart setYGridLinesColor:[UIColor whiteColor]];
            
            
            //Use yFixedValueMax and yFixedValueMin to Fix the Max and Min Y Value
            //Only if you needed
            
            self.lineChart.yFixedValueMax = 300.0;
            self.lineChart.yFixedValueMin = 0.0;
            
            // [self.lineChart setYLabels: [billData valueForKey:@"datalist"]];
            [self.lineChart setYLabels:@[
                                         @"0",
                                         @"100",
                                         @"200",
                                         @"300",
                                         @"400",
                                         @"500",
                                         @"600",
                                         
                                         ]
             ];
            
            // Line Chart #1
            NSArray *data01Array = @[@15.1, @60.1, @110.4, @10.0, @186.2, @197.2, @276.2];
            data01Array = [[data01Array reverseObjectEnumerator] allObjects];
            PNLineChartData *data01 = [PNLineChartData new];
            
            
            //        data01.rangeColors = @[
            //                               [[PNLineChartColorRange alloc] initWithRange:NSMakeRange(10, 30) color:[UIColor redColor]],
            //                               [[PNLineChartColorRange alloc] initWithRange:NSMakeRange(100, 200) color:[UIColor purpleColor]]
            //                               ];
            data01.dataTitle = @"Alpha";
            data01.color = PNFreshGreen;
            data01.pointLabelColor = [UIColor whiteColor];
            data01.alpha = 0.3f;
            data01.showPointLabel = YES;
            data01.pointLabelFont = [UIFont fontWithName:@"Helvetica-Light" size:9.0];
            data01.itemCount = data01Array.count;
            data01.inflexionPointColor = PNRed;
            data01.inflexionPointStyle = PNLineChartPointStyleTriangle;
            data01.getData = ^(NSUInteger index) {
                CGFloat yValue = [data01Array[index] floatValue];
                return [PNLineChartDataItem dataItemWithY:yValue];
            };
            
            // Line Chart #2
            //NSArray *data02Array = @[@0.0, @180.1, @26.4, @202.2, @126.2, @167.2, @276.2];
            
            
            
            PNLineChartData *data02 = [PNLineChartData new];
            data02.dataTitle = @"Data List";
            data02.pointLabelColor = [UIColor whiteColor];
            data02.color = PNTwitterColor;
            data02.alpha = 0.5f;
            data02.itemCount = data02Array.count;
            data02.inflexionPointStyle = PNLineChartPointStyleCircle;
            data02.getData = ^(NSUInteger index) {
                CGFloat yValue = [arrValues[index] floatValue];
                return [PNLineChartDataItem dataItemWithY:yValue];
            };
            
            self.lineChart.chartData = @[ data02];
            [self.lineChart.chartData enumerateObjectsUsingBlock:^(PNLineChartData *obj, NSUInteger idx, BOOL *stop) {
                obj.pointLabelColor = [UIColor whiteColor];
            }];
            
            
            [self.lineChart strokeChart];
            self.lineChart.delegate = self;
            
            
            [self.view addSubview:self.lineChart];
            
            self.lineChart.backgroundColor = [UIColor blackColor];
            
            
            self.lineChart.legendStyle = PNLegendItemStyleStacked;
            self.lineChart.legendFont = [UIFont boldSystemFontOfSize:12.0f];
            self.lineChart.legendFontColor = [UIColor redColor];
            
            
            UIView *legend = [self.lineChart getLegendWithMaxWidth:320];
            [legend setFrame:CGRectMake(30, self.view.frame.size.height - 13, legend.frame.size.width, legend.frame.size.width)];
            legend.backgroundColor = [UIColor clearColor];
            [self.view addSubview:legend];
            
            
            NSString*strTotal = [NSString stringWithFormat:@"%@", [[billData valueForKey:@"billgraphdata"]valueForKey:@"grandTotalAmt"]];
            NSString*strAverg = [NSString stringWithFormat:@"%@", [[billData valueForKey:@"billgraphdata"] valueForKey:@"average"]];
            
            
            CGFloat total = [strTotal floatValue];
            CGFloat average = [strAverg floatValue];

            
            
              self.txtTotal.text =  [NSString stringWithFormat:@"%.2f",total];
              self.txtAverage.text =  [NSString stringWithFormat:@"%.2f",average];


            
            

        }
        else{
            
             _backBtnClicked.hidden = YES;
            
            alert = [[UIAlertView alloc]initWithTitle:nil message:@"No Data" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            alert.delegate = self;
            [alert show];

            
        }
    }
}

-(void)viewDidLayoutSubviews{
    
    [super viewDidLayoutSubviews];
    
  //  self.lineChart.xLabelColor = [UIColor whiteColor];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)getbillingGraph{
        
        NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/dashboard/secure/billgraph?cmpId=%@",companyId];
    
    
    
        AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setValue:companyToken forHTTPHeaderField:@"token"];
        
        [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
            NSLog(@"PLIST: %@", responseObject);
            
 [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
            billData = responseObject ;
            
            [self performSelectorOnMainThread:@selector(getData) withObject:nil waitUntilDone:YES];

            
            
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
            NSLog(@"Error: %@", error);
            
        }];
    
}

-(void)getData{
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    
  //   [delegate setShouldRotate:NO];
    
    if ([[billData valueForKey:@"message"] isEqualToString:@"success"]) {
        
        
        [self billGrpah];
        
        
//        if ([[[billData valueForKey:@"datalist"] valueForKey:@"message"] count]>0) {
//            
//
//        }else{
//            
//            alert = [[UIAlertView alloc]initWithTitle:nil message:@"No Data" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
//            alert.delegate = self;
//            [alert show];
//            
//        }

        
    }else{
        
        alert = [[UIAlertView alloc]initWithTitle:nil message:@"No Data" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        alert.delegate = self;
        [alert show];

        
        
    }
    
}


-(void)kvnProgress{
    
    [KVNProgress dismiss];
    
}
- (IBAction)bckButton:(id)sender {
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];

    NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    
    [[UIDevice currentDevice] setValue:value forKey:@"orientation"];

    [delegate setShouldRotate:NO];

    [self.navigationController popViewControllerAnimated:YES];
    
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == alert) {
        AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        
        NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
        
        [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        
        [delegate setShouldRotate:NO];
        
        [self.navigationController popViewControllerAnimated:YES];
        
    }
}


- (IBAction)btnDetailData:(id)sender {
    
    
    [self.viewDetails setHidden: NO];
    
    [self.view bringSubviewToFront: self.viewDetails];
    
    
}

- (IBAction)bckClicked:(id)sender {
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    
    NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    
    [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
    
    [delegate setShouldRotate:NO];
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)dismiss{
    
    [self.viewDetails setHidden: YES];

    
}

@end
