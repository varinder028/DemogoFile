//
//  schduleVc.m
//  schedulePAgeDesign
//
//  Created by Rhythmus on 26/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "schduleVc.h"
#import <QuartzCore/QuartzCore.h>
#import "EmployeeDirectoryViewController.h"
#import "openParticiapntsViewController.h"
#import "PhoneCOntactViewController.h"
#import "AppDelegate.h"
#import "EmployeeManagementCell.h"
#import "customDataCell.h"
#import <Contacts/Contacts.h>
#import <ContactsUI/ContactsUI.h>
#import "ContactsVc.h"
#import "KVNProgress.h"
#import "CsvVc.h"
#import "KVNProgress.h"
#import "MyMeetingsVc.h"
#import "SubscriptionVC.h"
#import "PreviewPageVc.h"
#import <AFNetworking/AFNetworking.h>
#import "HomeVC.h"
#import "contactsCell.h"
#import "UIImageView+Letters.h"
#import "Reachability.h"
#import <AddressBook/ABAddressBook.h>
#import <AddressBookUI/AddressBookUI.h>




#define ACCEPTABLE_CHARACTERS @"0123456789,"
@interface schduleVc ()

@end

@implementation schduleVc

- (void)viewDidLoad {
    [super viewDidLoad];
    contactsAlldata = [[NSMutableArray alloc]init];

    
//    if ([[NSUserDefaults standardUserDefaults]boolForKey:@"synchContacts"]== true) {
//        
//    }
//    else{
//        
//        contactsAlldata = [[NSMutableArray alloc]init];
//        
//    }

    
    addImage  =  [[NSMutableArray alloc]init];
    
    checkedConatcts = [[NSMutableArray alloc]init];
    
    contactImagesArray = [[NSMutableArray alloc]init];
    
    _phoneSearchBar.delegate = self;
    
    self.btnQA.hidden=YES;
    self.LabelQA.hidden=YES;
    
    
    if ([UIScreen mainScreen].bounds.size.width == 320) {
         [_BtnEmpDir setImageEdgeInsets:UIEdgeInsetsMake(12, -2, 12, 42)];
         [_BtnEmpDir setTitleEdgeInsets:UIEdgeInsetsMake(0, -28, 0, 0)];
        
        [_BtnFucGroup setImageEdgeInsets:UIEdgeInsetsMake(12, 2, 12, 37)];
        [_BtnFucGroup setTitleEdgeInsets:UIEdgeInsetsMake(0, -28, 0, 0)];
        
        [_BtnAddOn setImageEdgeInsets:UIEdgeInsetsMake(12, 8, 12, 30)];
        [_BtnAddOn setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        
        [_BtnPhoneDirectory setImageEdgeInsets:UIEdgeInsetsMake(12, 1, 12, 35)];
        [_BtnPhoneDirectory setTitleEdgeInsets:UIEdgeInsetsMake(0, -26, 0, 0)];
        
        [_BtnBulkUpload setImageEdgeInsets:UIEdgeInsetsMake(12, 5, 12, 35)];
        [_BtnBulkUpload setTitleEdgeInsets:UIEdgeInsetsMake(0, -26, 0, 0)];
        
    }else if ([UIScreen mainScreen].bounds.size.width == 375) {
        [_BtnEmpDir setImageEdgeInsets:UIEdgeInsetsMake(12, 2, 12, 45)];
        [_BtnEmpDir setTitleEdgeInsets:UIEdgeInsetsMake(0, -18, 0, 0)];
        
        [_BtnFucGroup setImageEdgeInsets:UIEdgeInsetsMake(12, 4, 12, 42)];
        [_BtnFucGroup setTitleEdgeInsets:UIEdgeInsetsMake(0, -22, 0, 0)];
        
        [_BtnAddOn setImageEdgeInsets:UIEdgeInsetsMake(12, 8, 12, 40)];
        [_BtnAddOn setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        
        [_BtnPhoneDirectory setImageEdgeInsets:UIEdgeInsetsMake(12, 2, 12, 45)];
        [_BtnPhoneDirectory setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        
        [_BtnBulkUpload setImageEdgeInsets:UIEdgeInsetsMake(12, 8, 12, 42)];
        [_BtnBulkUpload setTitleEdgeInsets:UIEdgeInsetsMake(0, -25, 0, 0)];
        
    }else if ([UIScreen mainScreen].bounds.size.width == 414) {
        [_BtnEmpDir setImageEdgeInsets:UIEdgeInsetsMake(12, 2, 12, 55)];
        [_BtnEmpDir setTitleEdgeInsets:UIEdgeInsetsMake(0, -18, 0, 0)];
        
        [_BtnFucGroup setImageEdgeInsets:UIEdgeInsetsMake(12, 4, 12, 50)];
        [_BtnFucGroup setTitleEdgeInsets:UIEdgeInsetsMake(0, -22, 0, 0)];
        
        [_BtnAddOn setImageEdgeInsets:UIEdgeInsetsMake(12, 8, 12, 48)];
        [_BtnAddOn setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        
        [_BtnPhoneDirectory setImageEdgeInsets:UIEdgeInsetsMake(12, 2, 12, 48)];
        [_BtnPhoneDirectory setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        
        [_BtnBulkUpload setImageEdgeInsets:UIEdgeInsetsMake(12, 8, 12, 48)];
        [_BtnBulkUpload setTitleEdgeInsets:UIEdgeInsetsMake(0, -22, 0, 0)];

        
//        [self.BtnEmpDir setFont:[UIFont fontWithName:@"System Semibold" size:7]];
//        [self.BtnFucGroup setFont:[UIFont fontWithName:@"System Semibold" size:7]];
//        [self.BtnAddOn setFont:[UIFont fontWithName:@"System Semibold" size:7]];
//        [self.BtnPhoneDirectory setFont:[UIFont fontWithName:@"System Semibold" size:7]];
//         [self.BtnBulkUpload setFont:[UIFont fontWithName:@"System Semibold" size:7]];
        

        
    }else if ([UIScreen mainScreen].bounds.size.width == 768 || [UIScreen mainScreen].bounds.size.width == 1024){
        
        [_BtnEmpDir setImageEdgeInsets:UIEdgeInsetsMake(4, -3, 4, 48)];
        [_BtnEmpDir setTitleEdgeInsets:UIEdgeInsetsMake(0, -12, 0, 0)];
        
        [_BtnFucGroup setImageEdgeInsets:UIEdgeInsetsMake(3, 4, 3, 50)];
        [_BtnFucGroup setTitleEdgeInsets:UIEdgeInsetsMake(0, -16, 0, 0)];
        
        [_BtnAddOn setImageEdgeInsets:UIEdgeInsetsMake(1, 8, 1, 48)];
        [_BtnAddOn setTitleEdgeInsets:UIEdgeInsetsMake(0, -12, 0, 0)];
        
        [_BtnPhoneDirectory setImageEdgeInsets:UIEdgeInsetsMake(6, 2, 6, 48)];
        [_BtnPhoneDirectory setTitleEdgeInsets:UIEdgeInsetsMake(0, -4, 0, 0)];
        
      
        
        [_BtnBulkUpload setImageEdgeInsets:UIEdgeInsetsMake(6, 2, 6, 48)];
        [_BtnBulkUpload setTitleEdgeInsets:UIEdgeInsetsMake(0, -4, 0, 0)];


        
        
        [self.BtnEmpDir setFont:[UIFont systemFontOfSize:15]];
         [self.BtnFucGroup setFont:[UIFont systemFontOfSize:15]];
         [self.BtnAddOn setFont:[UIFont systemFontOfSize:15]];
         [self.BtnPhoneDirectory setFont:[UIFont systemFontOfSize:15]];
         [self.BtnBulkUpload setFont:[UIFont systemFontOfSize:15]];
        
        
    }
    
    self.txtStartTime.backgroundColor = [UIColor colorWithRed:50/255.0f  green:45/255.0f blue:47/255.0f alpha:0.7];
    self.txtSelectDate.backgroundColor = [UIColor colorWithRed:50/255.0f  green:45/255.0f blue:47/255.0f alpha:0.7];
    self.txtEndTime.backgroundColor = [UIColor colorWithRed:50/255.0f  green:45/255.0f blue:47/255.0f alpha:0.7];
     self.txtSchedule.backgroundColor = [UIColor colorWithRed:50/255.0f  green:45/255.0f blue:47/255.0f alpha:0.7];
    self.ScrollContactView.backgroundColor = [UIColor colorWithRed:50/255.0f  green:45/255.0f blue:47/255.0f alpha:0.7];

    [_previewPage setHidden:YES];
    
    UIImageView *imgforLeft=[[UIImageView alloc] initWithFrame:CGRectMake(10, 0, 25, 25)]; // Set
    [imgforLeft setImage:[UIImage imageNamed:@"menu-1.png"]];
    
    [imgforLeft setContentMode:UIViewContentModeCenter];// Set content mode centre or fit
    
    self. txtSchedule.leftView=imgforLeft;
    self. txtSchedule.leftViewMode=UITextFieldViewModeAlways;
    
    
//    _txtSchedule.leftViewMode = UITextFieldViewModeAlways;
//    _txtSchedule.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"menu-1.png"]];
//    [self.view bringSubviewToFront:_txtSchedule.leftView];
//
    
    _searchBar.delegate = self;
    
    
    [_PhoneContactsView setHidden:YES];
    
    [ _PhoneContactsView setBackgroundColor: [UIColor blackColor]];
    
     
    
    _contactsTableView.separatorStyle = UITableViewCellSelectionStyleNone ;
    
    
    arrayContacts = [[NSMutableArray alloc]init];
    
    _checkArray = [[NSMutableArray alloc]init];
    nameList = [[NSMutableArray alloc]init];
    arrayContacts = [NSMutableArray new];
    contactNumbersArray = [[NSMutableArray alloc]init];
    //[self fetchContactsandAuthorization];
    
    
    
    
    
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 24, 24)];
    [_txtSelectDate setLeftViewMode:UITextFieldViewModeAlways];
    [_txtSelectDate setLeftView:paddingView];
    
    UIView *paddingView1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 24, 24)];
    [_txtEndTime setLeftViewMode:UITextFieldViewModeAlways];
    [_txtEndTime setLeftView:paddingView1];
    
    
    UIView *paddingView2 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 24, 24)];
    [_txtStartTime setLeftViewMode:UITextFieldViewModeAlways];
    [_txtStartTime setLeftView:paddingView2];
    
    
    
//    UIView *paddingView3 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 24, 24)];
//    [_txtSchedule setLeftViewMode:UITextFieldViewModeAlways];
//    [_txtSchedule setLeftView:paddingView3];
//    
    
    
    
    [self.searchBar setBackgroundImage:[[UIImage alloc]init]];
    [self.phoneSearchBar setBackgroundImage:[[UIImage alloc]init]];
    
     
    _searchBar.delegate = self ;

    
    _addOnbutton.layer.cornerRadius= 5.0f;
    [_addOnbutton clipsToBounds];
    
    
    _btnDonee.layer.cornerRadius= 5.0f;
    [_btnDonee clipsToBounds];
    
    _btnSubscribe.layer.cornerRadius= 5.0f;
    [_btnSubscribe clipsToBounds];
    
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"PD"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [KVNProgress show];
    [self.headerLabel setHidden:NO];
    
    
    _employeeTableView.backgroundColor = [UIColor clearColor];
    _pagingTableView.backgroundColor = [UIColor clearColor];
    

    self.bckEditConf.hidden = YES;
    self.btnMeeting.hidden = NO ;
  //  self.CmpanyImageView.hidden = NO;
    self.btnReset.hidden = NO;
    
    [_btnSchedlue setTitle:@"Schedule" forState:UIControlStateNormal];
    
    [self.viewSubscribe setHidden:YES];
    
    UIColor *color = [UIColor whiteColor];
    _txtStartTime.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Start Time" attributes:@{NSForegroundColorAttributeName: color}];
    _txtEndTime.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"End Time" attributes:@{NSForegroundColorAttributeName: color}];
    _txtSelectDate.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Select Date" attributes:@{NSForegroundColorAttributeName: color}];
    
    _txtSchedule.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"  Subject" attributes:@{NSForegroundColorAttributeName: color}];
    

    _btnReschedule.layer.cornerRadius = 5.0f ;
    [_btnReschedule clipsToBounds];
    
    _btnPreview.layer.cornerRadius = 5.0f ;
    [_btnPreview clipsToBounds];
    
    
    
    _viewSubSubscribe.backgroundColor = [UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:0.6];
    _lblSchedule.backgroundColor = [UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:0.8];

    
    _btnSubscribe.layer.cornerRadius = 8.0f ;
    [_btnSubscribe clipsToBounds];
    
    
tapScrollView = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(scrollTap)];
        [self.scrollView addGestureRecognizer:tapScrollView];
    
    IsEditing = false;
    
    MyMeetingsVc* Object=[[MyMeetingsVc alloc]init];
    Object.delegate=self;
    
    
    _txtView.layer.cornerRadius = 5.0 ;
    [_txtView clipsToBounds];
    
    
    addOnArray = [[NSMutableArray alloc]init];
    
    
    tapper = [[UITapGestureRecognizer alloc]
              initWithTarget:self action:@selector(handleSingleTap:)];
    tapper.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tapper];
    
    
      dialIn = @"1";
    dialType = @"dialin";
    Manage = @"0";
    Recording = @"0";
    QA = @"0";
    Secure = @"0";
    
    
    [_openParticipantsView setHidden:YES];
    
    
    self.employeeTableView.separatorStyle = UITableViewCellSeparatorStyleNone ;
    
    
     [self.collectionView registerNib:[UINib nibWithNibName:@"customDataCell" bundle:nil] forCellWithReuseIdentifier:@"customData"];
    
    
    
    CGRect frame = _pagingTableView.frame;
    _pagingTableView.transform = CGAffineTransformRotate(_pagingTableView.transform, M_PI / 2);
    _pagingTableView.frame = frame;
    
    
    
    totalcheckmarkArray =[[NSMutableArray alloc]init];
    groupcheckmarkArray = [[NSMutableArray alloc]init];
    
    selectedGroups = [[NSMutableArray alloc]init];
    selectedUsers = [[NSMutableArray alloc]init];
    
    dictData = [[NSMutableDictionary alloc]init];

    addValuesArray = [NSMutableArray new];
    
    
    _addEmployeeView.hidden = YES ;
    userListArray = [[NSMutableArray alloc]init];
    selectUserArray = [[NSMutableArray alloc]init];

    personIdStr = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    NSLog(@"%@",personIdStr);
    
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    NSLog(@"%@",Tokenid);
    
    
    /////    Add Contact Button Back Views Layer
    
    self.AddBtnView.layer.cornerRadius = 5.5;
    
    self.btnPreview.layer.cornerRadius = 5.5;
    
    self.btnSchedlue.layer.cornerRadius = 5.5;
    
    self.btnReset.layer.cornerRadius = 5.5;
    
    self.BtnDownload.layer.cornerRadius = 4;
    
    self.txtSchedule.layer.cornerRadius = 4;
    
    self.txtSelectDate.layer.cornerRadius = 4;
    
    self.txtStartTime.layer.cornerRadius = 4;
    
    self.txtEndTime.layer.cornerRadius = 4;
    
    self.ScrollContactView.layer.cornerRadius = 4;
  
    [self.searchBar setReturnKeyType:UIReturnKeyDone];
    [self.searchBar setEnablesReturnKeyAutomatically:NO];


    
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)scrollTap{
    
    if ([UIScreen mainScreen].bounds.size.width == 768 || [UIScreen mainScreen].bounds.size.width == 1024){
        
        [UIView animateWithDuration:0.5 animations:^{
            self.scrollView.contentOffset = CGPointMake(0, 0);
        }];

        [_txtSchedule resignFirstResponder];

    }else if ([UIScreen mainScreen].bounds.size.width == 414) {
        
        [UIView animateWithDuration:0.5 animations:^{
            self.scrollView.contentOffset = CGPointMake(0, 0);
        }];

         [_txtSchedule resignFirstResponder];
        
    }else{
    
    [UIView animateWithDuration:0.5 animations:^{
        self.scrollView.contentOffset = CGPointMake(0, self.scrollView.contentSize.height + 120 - self.view.frame.size.height);

    }];
    
       [_txtSchedule resignFirstResponder];
    
    }
}

-(void)getscheduledData{
    
    self.txtSelectDate.text = [NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"OnlyDate"]];

    
    NSString*StartTime =  [NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"date"]];
    
    StartTime = [StartTime stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
    
    //// / convertingTodate
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    dateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    NSDate *datecurrent = [dateFormatter dateFromString:StartTime];
    NSLog(@"%@",datecurrent);
    
    
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
    dateFormatter1.dateFormat = @"yyyy-MM-dd";
    dateFormatter1.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    NSString*dateSt = [dateFormatter1 stringFromDate:datecurrent];
    
    NSLog(@"%@",dateSt);
    
    NSDateFormatter *dateFormatter2 = [[NSDateFormatter alloc] init];
    dateFormatter2.dateFormat = @"HH:mm";
    dateFormatter2.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    NSString*StartTi = [dateFormatter2 stringFromDate:datecurrent];
    
    NSLog(@"%@",StartTi);
    
    
    NSString*EndTime = [NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"endOffDate"]];
    EndTime = [EndTime stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
    
    //// / convertingTodate
    NSDateFormatter *EnddateFormatter = [[NSDateFormatter alloc] init];
    EnddateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    EnddateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    NSDate *endDate = [EnddateFormatter dateFromString:EndTime];
    NSLog(@"%@",endDate);
    NSDateFormatter *endTimeFormatter = [[NSDateFormatter alloc] init];
    endTimeFormatter.dateFormat = @"HH:mm";
    endTimeFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    NSString*endTi = [endTimeFormatter stringFromDate:endDate];
    
    NSLog(@"%@",endTi);
    
    self.txtStartTime.text = StartTi ;
    self.txtEndTime.text = endTi ;
    
    dictData = [[NSMutableDictionary alloc]init];
    
    
    
     NSArray*grpIdArray = [[schededDataArray valueForKey:@"scheduled"]valueForKey:@"grpId"];
    
    if (grpIdArray.count >0) {
        
        [dictData setObject:grpIdArray forKey:@"GR"];
        
    }
    
    
    
    
     NSArray*personIdArray = [[schededDataArray valueForKey:@"scheduled"]valueForKey:@"personId"];
    if (personIdArray.count>0) {
        [dictData setObject:personIdArray forKey:@"ED"];
    }
    
     NSArray*openInviteeArray = [[schededDataArray valueForKey:@"scheduled"]valueForKey:@"openInviteeNo"];
    
    if (openInviteeArray.count>0) {
        [dictData setObject:openInviteeArray forKey:@"AO"];
    }
    
    
    
    
     NSString*confSub = [NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"confSub"]];
    _txtSchedule.text = confSub ;
    

   // dialin
    
    NSString*manage = [NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"manage"]];
    if ([manage isEqualToString:@"0"]) {
        [self.btnManage setSelected:NO];
        
    }else{
        
        [self.btnManage setSelected:YES];
        
    }
    
    
    NSString*recording = [NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"recording"]];
    if ([recording isEqualToString:@"0"]) {
        [self.btnRecording setSelected:NO];
        
    }else{
        
        [self.btnRecording setSelected:YES];
        
    }
    
    NSString*secure = [NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"secure"]];
    if ([secure isEqualToString:@"0"]) {
        [self.btnSecure setSelected:NO];
        
    }else{
        
        [self.btnSecure setSelected:YES];
        
    }
    
    NSString*qna = [NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"qna"]];
    if ([qna isEqualToString:@"0"]) {
        [self.btnQA setSelected:NO];
        
    }else{
        
        [self.btnQA setSelected:YES];
        
    }
    
    NSString*dialin = [NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"confDialType"]];
    
    if ([dialin isEqualToString:@"dialin"]) {
        [self.btnDialOut setSelected:NO];
      
        
    }
    else{
        
         [self.btnDialOut setSelected:YES];
        [_btnSecure setSelected:NO];
        
    }
    
    
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
//    NSUserDefaults *defaults = [[NSUserDefaults alloc]init];
//    NSData *dictionaryData = [defaults objectForKey:@"synchedContacts"];
//    contactsAlldata = [NSKeyedUnarchiver unarchiveObjectWithData:dictionaryData];
    
     [self.viewSubscribe setHidden:YES];
    
    if ([[NSUserDefaults standardUserDefaults]boolForKey:@"getScheduled"] == true) {
        
        self.bckEditConf.hidden = NO;
        self.btnMeeting.hidden = YES ;
        self.btnPreview.hidden = YES;
        self.btnSchedlue.hidden = YES;
        [_btnRepreview setHidden:NO];
        [_btnReschedule setHidden:NO];
        
         [self.headerLabel setHidden:YES];
        self.CmpanyImageView.hidden = YES;
        //[_btnSchedlue setTitle:@"Reschedule" forState:UIControlStateNormal];
        
        self.btnReset.hidden = YES;
        
        [self  getscheduledData];
        
        
        
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"getScheduled"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        IsEditing = true ;
        
        
        
        
        
    }else{
        
         [self.headerLabel setHidden:NO];
        self.bckEditConf.hidden = YES;
        self.btnMeeting.hidden = NO ;
        self.btnPreview.hidden = NO;
        self.btnSchedlue.hidden = NO;
        [_btnRepreview setHidden:YES];
        [_btnReschedule setHidden:YES];
     //   self.CmpanyImageView.hidden = NO;
        //   [_btnSchedlue setTitle:@"Schedule" forState:UIControlStateNormal];
        self.btnReset.hidden = NO;
        
        
        
        dictData = [[NSMutableDictionary alloc]init];
        self.txtSelectDate.text = @"";
        self.txtStartTime.text = @"";
        self.txtEndTime.text = @"";
        self.txtSchedule.text = @"";
        
        [self.btnRecording setSelected:NO];
        Recording = 0 ;
        
        
        [self.btnManage setSelected:NO];
        Manage= 0;
        [self.btnQA setSelected:NO];
        QA = 0 ;
        
        [self.btnSecure setSelected:NO];
        Secure = 0;
        
        [self.btnDialOut setSelected:NO];
        dialType = @"dialin";
        
        
        
    }

    
  
    
    if (dictData.count>0) {
          [self.txtNoEmployee setHidden:YES];
    }else{
        
          [self.txtNoEmployee setHidden:NO];
    }
    
    
    
    
    
    NSMutableArray *contacts = [[NSUserDefaults standardUserDefaults]valueForKey:@"PD"];
     NSLog(@"%@",contacts);
    
     //[self.view bringSubviewToFront:_viewSubscribe];
    
    
    if (contacts.count >0) {
        
        [dictData setValue:contacts forKey:@"PD"];
         NSLog(@"%@",dictData);
        
    }else{
        
        [[NSUserDefaults standardUserDefaults]setObject:contacts forKey:@"PD"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
     [dictData setValue:nil forKey:@"PD"];

    }
    
    [self  varifiyingPlans];
    
    [self tabView];
    
    
    
    
    [self.collectionView reloadData];
    
    
    NSLog(@"%@",dictData);
   
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    
    NSDate *currentDate = [NSDate date];
    _txtSelectDate.text = [formatter stringFromDate:currentDate];

    
}

-(void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:animated];
    
    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"synchContacts"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
}

-(void)tabView{
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView removeFromSuperview];
    
    NSArray *myNibsArray = [[NSBundle mainBundle] loadNibNamed:@"Tab" owner:self options:nil];
    delegate.tabView = [myNibsArray objectAtIndex:0];
    if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 90, self.view.frame.size.width, 90);
        
    }else if ([UIScreen mainScreen].bounds.size.width == 1024) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 130, self.view.frame.size.width, 130);
        
    }else{

    delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height-delegate.tabView.frame.size.height, self.view.frame.size.width, delegate.tabView.frame.size.height);
        
    }
    [self insets];
    
    [delegate.tabView.btnToday setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnSchedule setBackgroundColor: [UIColor colorWithRed:0/255.0f green:32/255.0f blue:41/255.0f alpha:1]];
    
    [delegate.tabView.btnControlPanel setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnDashboard setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnMenu setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [self.view addSubview:delegate.tabView];
    

}

-(void)cancelConferceFromServer{
    
    
        NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/cancelconference?confId=%@",confId];
        AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
        
        [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
            NSLog(@"PLIST: %@", responseObject);
            [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
            
            
            
            cancelConf = responseObject ;
            
            
            [self performSelectorOnMainThread:@selector(confCancel) withObject:nil waitUntilDone:YES];
            
            
            
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
            NSLog(@"Error: %@", error);
            
        }];
    
}

-(void)confCancel{
    
    NSLog(@"%@",cancelConf);
    [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Your balance is low please Subscribe another Plan" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
    [alert show];
    
    
    
}


-(void)varifiyingPlans{
    
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/secure/isverify?cmpId=%@",companyId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        
        
            
            isVarified = responseObject ;
            
            
            [self performSelectorOnMainThread:@selector(planType) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
}




-(void)planType{
    
    
    if ([[isVarified valueForKey:@"message"] isEqualToString:@"success"]) {
        
        NSString*strVarify = [NSString stringWithFormat:@"%@",[isVarified valueForKey:@"isverify"]];
        NSString*planType = [NSString stringWithFormat:@"%@",[isVarified valueForKey:@"planType"]];

        
        
        if ([strVarify isEqualToString:@"0"]) {
            
           
            
            [self.viewSubscribe setHidden:NO];
                
            
            
        }else{
            if ([planType isEqualToString:@"No plan selected"]) {
                [self.viewSubscribe setHidden:NO];
            }else{
                
                [self.viewSubscribe setHidden:YES ];
                
            }

            
            
        }
    }
    

    
}



- (void)handleSingleTap:(UITapGestureRecognizer *) sender
{
    [self.txtView resignFirstResponder];
    
    
    [self.view endEditing:YES];
}

-(void)viewDidLayoutSubviews{
    
    [super viewDidLayoutSubviews];
    
    self.lbldate.layer.cornerRadius = 8.0f;
    
//    UIColor *color = [UIColor grayColor];
//    
//    _lbldate.layer.shadowColor = [color CGColor];
//    _lbldate.layer.shadowRadius = 5.0f;
//    _lbldate.layer.shadowOpacity = 1;
//    _lbldate.layer.shadowOffset = CGSizeZero;
//    
    _lbldate.layer.masksToBounds = YES;
    
    [self.lbldate clipsToBounds];
    
    
    
    self.lblsatrtTime.layer.cornerRadius = 8.0f;
    
    _lblsatrtTime.layer.masksToBounds = YES;
    
    [self.lblsatrtTime clipsToBounds];
    
    
    
    
    self.lblendtime.layer.cornerRadius = 8.0f;
    
     _lblendtime.layer.masksToBounds = YES;
    
    [self.lblendtime clipsToBounds];

}

- (IBAction)btnEmpDirectory:(id)sender

{
    [_btnCheckAll setSelected:NO];
    
    [self empDirectory];
    
    
}


-(void)empDirectory{
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:YES];
    
    isUser = true ;
    userListArray = [[NSMutableArray alloc]init];
    
    self.lblMobile.text  = @"Mobile No.";
    self.lblName.text = @"Name";
    self.lblRole.text = @"Image";
    
    
        [KVNProgress show];
        
        [self GetPersonDetailsFromServer];
    _addEmployeeView.hidden = NO ;

}
- (IBAction)btnFuncGroup:(id)sender {
    isUser = true ;
    [_btnCheckAll setSelected:NO];
    
    
    [self groupFunction];
    
}

-(void)groupFunction{
    isUser = false ;
    
    
    userListArray = [[NSMutableArray alloc]init];
//    totalcheckmarkArray =[[NSMutableArray alloc]init];
//    groupcheckmarkArray = [[NSMutableArray alloc]init];

    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:YES];
    selectUserArray = [[NSMutableArray alloc]init];
    
    isUser = false ;
    
    [self.addEmployeeView setHidden:NO];
    self.lblName.text  = @"Members";
    self.lblRole.text = @"Group des.";
    self.lblMobile.text = @"Group Name";
    
    
   
    [KVNProgress show];
    
    [self GettingGroupsFromServer];
        
    

}

- (IBAction)btnPhoneDirectory:(id)sender

{
    
    isContactsSt = NO ;
    NSMutableArray *cont = [[NSMutableArray alloc]init];
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];

    for (NSString*str  in [dictData valueForKey:@"PD"]) {
        
        [cont addObject:str];
    }
    NSLog(@"%@",cont);
    
    
//    if (delegate.SynchContacts == YES) {
//        
//        [delegate.tabView setHidden:YES];
//        [_PhoneContactsView setHidden:NO];
//    }
    
    

//
//        
//    }else if (contactsSyched == YES){
//            
//        
//            [delegate.tabView setHidden:YES];
//            [_PhoneContactsView setHidden:NO];
//        
//        }
    
//    if ([[NSUserDefaults standardUserDefaults]boolForKey:@"synchContacts"]== true) {
//        
//        [delegate.tabView setHidden:YES];
//        [_PhoneContactsView setHidden:NO];
//    }
        if (contactsAlldata.count >0){
    
            [delegate.tabView setHidden:YES];
            [_PhoneContactsView setHidden:NO];
        
            [_contactsTableView reloadData];
            
       }
    
else{

    // AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:YES];
    [_PhoneContactsView setHidden:NO];
   
    [KVNProgress show];
    contactsAlldata = [[NSMutableArray alloc]init];
    [self fetchContactsandAuthorization];
    
    
    }
    
}


    
-(void)selectContactData {
    
    CNContactPickerViewController * picker = [[CNContactPickerViewController alloc] init];
    
    picker.delegate = self;
    picker.displayedPropertyKeys = (NSArray *)CNContactGivenNameKey;
    
    [self presentViewController:picker animated:YES completion:nil];
    
}

-(void)contactPicker:(CNContactPickerViewController *)picker didSelectContact:(CNContact *)contact {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    NSString *test = contact.givenName;
    NSLog(@"%@",test);
    
}

- (BOOL)personViewController:(ABPersonViewController *)personViewController shouldPerformDefaultActionForPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifierForValue
{
    BOOL shouldPerformDefaultAction = YES;
    
    // Perform special action if phone number was selected
    if (property == kABPersonPhoneProperty)
    {
        CFTypeRef phoneProperty = ABRecordCopyValue(person, kABPersonPhoneProperty);
        NSArray *phones = (__bridge NSArray *)ABMultiValueCopyArrayOfAllValues(phoneProperty);
        CFRelease(phoneProperty);
        
        for (NSString *phone in phones)
        {
            NSLog(@"phone = %@", phone);
        }
        
        shouldPerformDefaultAction = NO;
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    // Otherwise, allow the default action to occur.
    return shouldPerformDefaultAction;
}


# pragma mark - peoplePickerDelegate methods
- (void)peoplePickerNavigationControllerDidCancel:(ABPeoplePickerNavigationController *)peoplePicker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (BOOL)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker shouldContinueAfterSelectingPerson:(ABRecordRef)person{
    [self displayPerson:person];
    [self dismissViewControllerAnimated:YES completion:nil];
    return NO;
}
- (BOOL)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker
      shouldContinueAfterSelectingPerson:(ABRecordRef)person
                                property:(ABPropertyID)property
                              identifier:(ABMultiValueIdentifier)identifier
{
    return NO;
}
- (void)displayPerson:(ABRecordRef)person
{
    
    
   
    
    NSString* name = (__bridge_transfer NSString*)ABRecordCopyValue(person,                                                               kABPersonFirstNameProperty);
    NSString* phone = nil;
    
    
    ABAddressBookRef addressBook = ABAddressBookCreate( );
    CFArrayRef allPeople = ABAddressBookCopyArrayOfAllPeople( addressBook );
    CFIndex nPeople = ABAddressBookGetPersonCount( addressBook );
    
    for ( int i = 0; i < nPeople; i++ )
    {
        ABRecordRef ref = CFArrayGetValueAtIndex( allPeople, i );
        
    }
    
    ABMultiValueRef phoneNumbers = ABRecordCopyValue(person,
                                                     kABPersonPhoneProperty);
    if (ABMultiValueGetCount(phoneNumbers) > 0) {
        phone = (__bridge_transfer NSString*)
        ABMultiValueCopyValueAtIndex(phoneNumbers, 0);
    } else {
        phone = @"[None]";
    }
    CFRelease(phoneNumbers);
}



- (IBAction)btnBulkUpload:(id)sender {
    
    UIDocumentMenuViewController *objMenuView = [[UIDocumentMenuViewController alloc]initWithDocumentTypes:@[@"public.data"] inMode:UIDocumentPickerModeImport];
    
    //Create Custom option to display
    [objMenuView addOptionWithTitle:@"My Custom option" image:nil order:UIDocumentMenuOrderFirst handler:^{
        //Call when user select the option
        
    }];
   // [objMenuView.view setTranslatesAutoresizingMaskIntoConstraints:NO];

    //Set the delegate
    objMenuView.delegate = self;
    //present the document menu view
    
    
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
    objMenuView.modalTransitionStyle = UIModalPresentationPopover ;
    objMenuView.popoverPresentationController.sourceView = self.view ;
         [self presentViewController:objMenuView animated:YES completion:nil];
    }
    else{
        [self presentViewController:objMenuView animated:YES completion:nil];

    }
    
   
    
    
}
- (void)documentMenu:(UIDocumentMenuViewController *)documentMenu didPickDocumentPicker:(UIDocumentPickerViewController *)documentPicker {
    documentPicker.delegate = self;
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dictData];
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"dictDTA"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [self presentViewController:documentPicker animated:YES completion:nil];
}

-(void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentAtURL:(NSURL *)url
{
    if (controller.documentPickerMode == UIDocumentPickerModeImport)
    {
        
      //  documentsDirectory = [NSString stringWithFormat:@"%@",url];
        
        documentsDirectory = [url path];
         extensionFile = [documentsDirectory pathExtension];
        NSLog(@"%@",extensionFile);
        
        NSUserDefaults *defaults = [[NSUserDefaults alloc]init];
        NSData *dictionaryData = [defaults objectForKey:@"dictDTA"];
        dictData = [NSKeyedUnarchiver unarchiveObjectWithData:dictionaryData];
        
        fileData = [[NSFileManager defaultManager] contentsAtPath:documentsDirectory];
        //fileData = [NSData dataWithContentsOfURL:url];
        
        if ([extensionFile isEqualToString:@"csv"]||[extensionFile isEqualToString:@"xls"]||[extensionFile isEqualToString:@"CSV"]||[extensionFile isEqualToString:@"xlsx"]) {
            
            // Condition called when user download the file
            
            
            NSBundle *mainBundle = [NSBundle mainBundle];
            NSString *myFile = [mainBundle pathForResource: documentsDirectory ofType: @"pdf"];
            
            

         NSString *content = [NSString stringWithContentsOfURL:url encoding:NSASCIIStringEncoding error:nil];
            
           
            
            NSArray *arracontent = [[NSArray alloc]init];

            
           NSLog(@"%@",content);
            
            
            
            
            NSArray *arrayy = [content componentsSeparatedByString:@"\n"];


            NSMutableArray*arrBulk = [NSMutableArray new];
            
            
            
            
            NSCharacterSet* notDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
            for (NSString *str in arrayy) {
                
              //  NSString*strrr = [str stringByReplacingOccurrencesOfString:@"\n" withString:@""];
                
                NSString* strrr = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                
                [arrBulk addObject:strrr];
                
                
            }
            
            
             NSMutableArray*arrUpload = [NSMutableArray new];
            for (NSString *strr in arrBulk) {
                
                            if ([strr rangeOfCharacterFromSet:notDigits].location == NSNotFound)
                            {
                                if (strr.length >= 10) {
                                    [arrUpload addObject:strr];
                                }
                
                
                                // newString consists only of the digits 0 through 9
                            }
                            else{
                                
                                
                                
                            }
                
                
            }
            
            


            
            NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"intValue" ascending:YES];
            [arrayy sortedArrayUsingDescriptors:@[sortDescriptor]];

            
            
            NSArray *array = [content componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            
            
            [dictData setObject:arrUpload forKey:@"BLK"];
            

            
            
        }else{
            
         //   NSString *alertMessage = [NSString stringWithFormat:@"Successfully uploaded file %@", [url lastPathComponent]];

            
            UIAlertController *alertController = [UIAlertController
                                                           alertControllerWithTitle:nil
                                                                                                        message:@"Please select csv/xls file"
                                                                                                        preferredStyle:UIAlertControllerStyleAlert];
                                                                  [alertController addAction:[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil]];

//            [alertController addAction:[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil]];
                [self presentViewController:alertController animated:YES completion:nil];
            
            

            
        }
        
    [_collectionView reloadData];
}
    
}

- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {
    
    NSUserDefaults *defaults = [[NSUserDefaults alloc]init];
    NSData *dictionaryData = [defaults objectForKey:@"dictDTA"];
    dictData = [NSKeyedUnarchiver unarchiveObjectWithData:dictionaryData];
    [_collectionView reloadData];
    

}



- (IBAction)btnAddOn:(id)sender

{
    
    [_openParticipantsView setHidden:NO];
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:YES];
    
    
}





/////  check box

- (IBAction)btnDialOut:(id)sender {
    
    if (!self.btnDialOut.isSelected) {
        [self.btnDialOut setSelected:YES];
        [_btnSecure setSelected:NO];
        
        dialType = @"dialout";
        dialOut = @"1" ;
        dialIn = @"0";
        Secure = @"0" ;
        
       
        
    }else
    {
        [self.btnDialOut setSelected:NO];
        dialOut = @"0" ;
        dialType = @"dialin";
        
         dialIn = @"1";
        
        

        
    }
    
}

- (IBAction)btnSecure:(id)sender

{
    if (!self.btnSecure.isSelected) {
        [self.btnSecure setSelected:YES];
        
        
        [self.btnDialOut setSelected:NO];
        
        Secure = @"1" ;
        dialOut = @"0";
        
       
    }else
    {
        [self.btnSecure setSelected:NO];
        Secure = @"0" ;
    }
    
}

- (IBAction)btnManage:(id)sender

{
    if (!self.btnManage.isSelected) {
        [self.btnManage setSelected:YES];
        
        Manage = @"1" ;
    }else
    {
        [self.btnManage setSelected:NO];
        Manage = @"0" ;
    }
    
}

- (IBAction)btnRecording:(id)sender

{
    if (!self.btnRecording.isSelected) {
        [self.btnRecording setSelected:YES];
        
        Recording = @"1" ;
    }else
    {
        [self.btnRecording setSelected:NO];
        Recording = @"0";
    }
    
}

- (IBAction)btnQA:(id)sender

{
    if (!self.btnQA.isSelected) {
        [self.btnQA setSelected:YES];
        
        QA = @"1" ;
    }else
    {
        [self.btnQA setSelected:NO];
    
        QA = @"0" ;
    }

}
- (IBAction)btnPreview:(id)sender {
    [self previewData];
    
   
}

- (IBAction)btnSchedule:(id)sender {
    
  
    
    
    [self scheduleConference];
    
}

- (IBAction)btnReset:(id)sender {
    
    self.scrollView.contentOffset = CGPointZero;
    self.scrollView.contentInset = UIEdgeInsetsZero;
    
    
    dictData = [[NSMutableDictionary alloc]init];
    self.txtSelectDate.text = @"";
    self.txtStartTime.text = @"";
    self.txtEndTime.text = @"";
    self.txtSchedule.text = @"";
    
    [self.btnRecording setSelected:NO];
    Recording = 0 ;
    
    
    [self.btnManage setSelected:NO];
    Manage= 0;
    [self.btnQA setSelected:NO];
    QA = 0 ;
    
    [self.btnSecure setSelected:NO];
    Secure = 0;
    
    [self.btnDialOut setSelected:NO];
    dialType = @"dialin";
    
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"PD"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"checked"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"CSVChecked"];
    [[NSUserDefaults standardUserDefaults]synchronize];

    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"CSV"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"AO"];
    [[NSUserDefaults standardUserDefaults]synchronize];

 [self.txtNoEmployee setHidden:NO];
    
    contactsAlldata = [[NSMutableArray alloc]init];
    arrayContacts = [[NSMutableArray alloc]init];
    selectedUsers = [[NSMutableArray alloc]init];
    selectedGroups = [[NSMutableArray alloc]init];
    contactNumbersArray = [[NSMutableArray alloc]init];
    
    
    
    [self.collectionView reloadData];
    
}
- (IBAction)btnDownload:(id)sender {
}

-(void)ShowSelectedDate
{
    
    if ([DateStr isEqualToString:@"SelectDate"]) {
        
       
        NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
        self.txtSelectDate.font = [UIFont systemFontOfSize:12.0f];
        [formatter setDateFormat:@"yyyy-MM-dd"];
        NSString *str=[NSString stringWithFormat:@"%@",[formatter stringFromDate:_datePicker.date]];
        //  NSString *newString = [str stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
        
        self.txtSelectDate.text = str;
        
        [self.txtSelectDate resignFirstResponder];

    }else if ([DateStr isEqualToString:@"startTime"]){
        
        NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
        self.txtStartTime.font = [UIFont systemFontOfSize:12.0f];
        [formatter setDateFormat:@"HH:mm"];
        NSString *str=[NSString stringWithFormat:@"%@",[formatter stringFromDate:_datePicker.date]];
        //  NSString *newString = [str stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
        self.txtStartTime.text = str;
        
        [self.txtStartTime resignFirstResponder];
    }
    else if ([DateStr isEqualToString:@"EndTime"]){
        
        NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
        self.txtEndTime.font = [UIFont systemFontOfSize:12.0f];
        [formatter setDateFormat:@"HH:mm"];
        NSString *str=[NSString stringWithFormat:@"%@",[formatter stringFromDate:_datePicker.date]];
        //  NSString *newString = [str stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
        self.txtEndTime.text = str;
        
        [self.txtEndTime resignFirstResponder];
        
    }
    
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (textField == _txtSelectDate) {
        [_txtSchedule resignFirstResponder];
        
        NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en"];
        [_datePicker setLocale:locale];
        _datePicker.datePickerMode = UIDatePickerModeDate;
        
        self.txtEndTime.text = @"" ;
        self.txtStartTime.text = @"" ;
        [UIView animateWithDuration:0.5 animations:^{
            [self.datePicker setMinimumDate: [NSDate date]];
            
            DateStr = @"SelectDate" ;
            self.bottomPicker.constant = 0 ;
            [self.view layoutIfNeeded];
            
            
            
            
            
            
        }];
        
        return NO;
        
    }else if (textField == _txtStartTime) {
        [_txtSchedule resignFirstResponder];
        
        self.txtEndTime.text = @"" ;
        
        
        if ([_txtSelectDate.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Select the date first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            
            
            
        }else{
            [UIView animateWithDuration:0.5 animations:^{
                
                
                
                
                DateStr = @"startTime" ;
                self.bottomPicker.constant = 0 ;
                [self.view layoutIfNeeded];
                
                NSString *dateSelected = [NSString stringWithFormat:@"%@",self.txtSelectDate.text];
                NSDateFormatter *dateFormt = [[NSDateFormatter alloc] init];
                dateFormt.dateFormat = @"yyyy-MM-dd";
                dateFormt.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
                NSDate * dateM= [dateFormt dateFromString:dateSelected];
                NSLog(@"%@",dateM);

                
                
                
                NSDate* newDate1 = [[NSDate date] dateByAddingTimeInterval:5*60];
                NSLog(@"%@",newDate1);
                
                
                NSDateFormatter *dateFormt1 = [[NSDateFormatter alloc] init];
                dateFormt1.dateFormat = @"yyyy-MM-dd";
                dateFormt1.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
                NSString*currentDate = [dateFormt1 stringFromDate:[NSDate date]];
                
                NSLog(@"%@",currentDate);

                
                if ( [_txtSelectDate.text isEqualToString: currentDate] ) {
                    [_datePicker setDate:newDate1 animated:YES];
                    
                }else{
                
                [_datePicker setDate:dateM animated:YES];
                
                }
                
                
                [self.datePicker setMinimumDate: newDate1];
                
                
                
                
                NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"NL"];
                [_datePicker setLocale:locale];
                
                
                _datePicker.datePickerMode = UIDatePickerModeTime;
                
                
            }];
            
            
            
        }
        
        return NO;
    }
    else if (textField == _txtEndTime) {
        [_txtSchedule resignFirstResponder];
        
        
        
        if ([_txtStartTime.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Select the StartTime first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            
            
            
        }else{
            
            
            
            [UIView animateWithDuration:0.5 animations:^{
                
                NSString *dateSelected = [NSString stringWithFormat:@"%@",self.txtSelectDate.text];
                NSString *timeSelected = [NSString stringWithFormat:@"%@",_txtStartTime.text];
                NSString *dateAndTime = [NSString stringWithFormat:@"%@ %@",dateSelected,timeSelected];
                
                NSDateFormatter *dateFormt = [[NSDateFormatter alloc] init];
                dateFormt.dateFormat = @"yyyy-MM-dd HH:mm";
               
                NSDate * dateM= [dateFormt dateFromString:dateAndTime];
                NSLog(@"%@",dateM);
                NSDate* newDate = [dateM dateByAddingTimeInterval:15*60];
                NSLog(@"%@",newDate);
                [_datePicker setDate:newDate animated:YES];
                
                [self.datePicker setMinimumDate: newDate];
                
                
                DateStr = @"EndTime" ;
                self.bottomPicker.constant = 0 ;
                [self.view layoutIfNeeded];
                
                NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"NL"];
                [_datePicker setLocale:locale];
                
                _datePicker.datePickerMode = UIDatePickerModeTime;
                
                
                
            }];
            
            
        }
        
        return NO ;
        
    }
    
    
    else if (textField == _txtSchedule) {
        
        
     //   self.bottomPicker.constant = -232 ;
        if ([UIScreen mainScreen].bounds.size.width == 768 || [UIScreen mainScreen].bounds.size.width == 1024){
            
            
        }
           
       else if ([UIScreen mainScreen].bounds.size.width == 414) {
            
            
        }else{
        
        [UIView animateWithDuration:0.5 animations:^{
            self.scrollView.contentOffset = CGPointMake(0, 200);
        }];
        
        }
        
    }
    
    [self.view bringSubviewToFront:_datePicker];
    
    
    return YES ;
    

    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if (textField == _txtSchedule) {
        if ([UIScreen mainScreen].bounds.size.width == 768 || [UIScreen mainScreen].bounds.size.width == 1024){
            
            
        }
       else if ([UIScreen mainScreen].bounds.size.width == 414) {
            
            [UIView animateWithDuration:0.5 animations:^{
                self.scrollView.contentOffset = CGPointMake(0, 0);
            }];
            
            [_txtSchedule resignFirstResponder];
            
        }else{
        
        [UIView animateWithDuration:0.5 animations:^{
           // self.scrollView.contentOffset = CGPointMake(0, 250);
             self.scrollView.contentOffset = CGPointMake(0, self.scrollView.contentSize.height + 120 - self.view.frame.size.height);
        }];
        
   
        [textField resignFirstResponder];
    
        }
    }
    
        
    
    
    [textField resignFirstResponder];
    return YES;
    
}

- (IBAction)doneClicked:(id)sender {
    
    [UIView animateWithDuration:0.5 animations:^{
        
        self.bottomPicker.constant = -232;
        [self.view layoutIfNeeded];
        
    }];
    
    [self ShowSelectedDate];
    
}

-(void)postRequestToTrack_View{
    
//    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/addconference?cmpId=%@&confId=%@&hostId=%@&confdate=%@&strtTime=%@&endTime=%@&confDialType=%@&confSub=%@&confDesc=%@&recording=%@&manage=%@&secure=%@&qna=%@",@"1824",@"",];
    
    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
    
    
    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"POST"];
    
//    [urlrequest setValue:@"Token token=f7e31f33930d0351f99e09d81e708b51e906c3eb34d8af71" forHTTPHeaderField:@"Authorization"];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
                                            completionHandler:
                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
                                      
                                      if (data ==nil) {
                                          
                                      }else{
//                                          trackviewData=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
//                                          NSLog(@"%@",trackviewData);
                                          
                                      }
                                      
                                  }];
    
    
    [task resume];
    
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if (tableView== _pagingTableView) {
        
        addedData = [dictData allKeys];
        
        return addedData.count ;
        
    }if (tableView== _contactsTableView) {
        
        
        return contactsAlldata.count ;
        
    } else{
        
    return userListArray.count;
        
    }
 
    
}




-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (tableView == _employeeTableView){
        EmployeeManagementCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EmployeeManagementCell"];
        if (cell==nil) {
            NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"EmployeeManagementCell" owner:self options:nil];
            
            cell= arr[0];
            
        }
        
        
        NSString *str;
        
        if (isUser == true) {
            int co = (int) userListArray.count ;
            
            NSString* totalcount = [NSString stringWithFormat:@"%d Employees",co];
            
            _txtEmployeeCount.text = totalcount ;

            
            cell.txtRole.hidden = YES;
            cell.imgEmpyee.hidden = NO;
            
            
            
            if (userListArray.count >0) {
           str = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"checked"]objectAtIndex:indexPath.row]];
            
            }
            
            if (userListArray.count >0) {
                if(![str isEqualToString:@"NO"])
                {
                    
                    [cell.btnCheck setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                    
                    //  [cell.btnCheck setSelected:YES];
                    
                }
                
                else if ([[userListArray valueForKey:@"checked"] containsObject:[userListArray objectAtIndex:indexPath.row]])
                {
                    
                    [cell.btnCheck setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                }
                else
                {
                    
                    
                    [cell.btnCheck setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
                }
                
                
                [cell.btnCheck addTarget:self action:@selector(checkedClicked:) forControlEvents:UIControlEventTouchUpInside];
                
                cell.btnCheck.tag = indexPath.row ;
                
                
                
                cell.txtMobile.text = [[userListArray valueForKey:@"pmobile"]objectAtIndex:indexPath.row];
                
                NSString*firstName = [NSString stringWithFormat:@"%@", [[userListArray valueForKey:@"firstName"]objectAtIndex:indexPath.row]];
                
                NSString*endName = [NSString stringWithFormat:@"%@", [[userListArray valueForKey:@"lastName"]objectAtIndex:indexPath.row]];
                
                cell.textName.text = [NSString stringWithFormat:@"%@ %@",firstName,endName];
                
                //   cell.textName.text =  [[userListArray valueForKey:@"firstName"]objectAtIndex:indexPath.row];
                
                NSString*roleee = [NSString stringWithFormat:@"%@", [[userListArray valueForKey:@"role"]objectAtIndex:indexPath.row]];
                
                cell.imgEmpyee.layer.cornerRadius = cell.imgEmpyee.frame.size.width/2; //
                
                [cell.imgEmpyee.layer masksToBounds];
                
                cell.imgEmpyee.layer.borderWidth = 1.0f;
                
                cell.imgEmpyee.layer.masksToBounds = YES;
                
                cell.imgEmpyee.clipsToBounds = YES;
                
                NSString*proImg = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"proImg"]objectAtIndex:indexPath.row]];
                
                if ([proImg isEqualToString:@"no image"]) {
                    
                    [cell.imgEmpyee setImageWithString:cell.textName.text color:nil circular:YES];
                    
                }else{
                    
                    [cell.imgEmpyee sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://182.76.44.135:8080/%@",[userListArray valueForKey:@"proImg"]]]placeholderImage:[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"]];
                }

                
               // [cell.imgEmpyee setImageWithString:cell.textName.text color:nil circular:YES];
                
                
                if ([roleee isEqualToString:@"ROLE_SUPER_ADMIN"]) {
                    roleee = @"Admin" ;
                    
                }else if ([roleee isEqualToString:@"ROLE_HOST"]) {
                    roleee = @"Host" ;
                    
                }else if ([roleee isEqualToString:@"ROLE_PARTICIPANT"]) {
                    roleee = @"Participant" ;
                    
                }
                
                
                cell.txtRole.text = roleee ;
                
                
                
            }
            
            
            
        }
        else{
            
            NSString *str;
            if (userListArray.count >0) {
                int co = (int) userListArray.count ;
                NSString* totalcount = [NSString stringWithFormat:@"%d Groups",co];
                _txtEmployeeCount.text = totalcount ;

                
                cell.txtRole.hidden = NO;
                cell.imgEmpyee.hidden = YES;

                if (userListArray.count >0) {
                
                str = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"checked"]objectAtIndex:indexPath.row]];
                
                }
                
                if(![str isEqualToString:@"NO"])
                {
                    
                    [cell.btnCheck setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                    
                    
                    //  [cell.btnCheck setSelected:YES];
                    
                }
                
                else if ([[userListArray valueForKey:@"checked"] containsObject:[userListArray objectAtIndex:indexPath.row]])
                {
                    
                    [cell.btnCheck setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                }
                else
                {
                    
                    
                    [cell.btnCheck setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
                }
                
                [cell.btnCheck addTarget:self action:@selector(checkedClicked:) forControlEvents:UIControlEventTouchUpInside];
                
                cell.btnCheck.tag = indexPath.row ;
                
                cell.txtMobile.text = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"grpName"]objectAtIndex:indexPath.row]];
                
                cell.textName.text = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"totalmember"]objectAtIndex:indexPath.row]];
                
                cell.txtRole.text = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"grpDesc"]objectAtIndex:indexPath.row]];
                
                
                
            }
            
            
        }
        
        
        
        
        
        cell.backgroundColor = [UIColor clearColor];
        
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        return cell;
        
    }
    
    
    else if (tableView == _contactsTableView ){
        // contactsCell.h
        
        contactsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"contactsCell"];
        if (cell==nil) {
            NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"contactsCell" owner:self options:nil];
            
            cell= arr[0];
            
        }
        
        
        int count = (int)contactsAlldata.count;
        NSString*totalcount = [NSString stringWithFormat:@"%d contacts",count];
        _phoneContactCount.text = totalcount ;
        
        
        NSString *str = [NSString stringWithFormat:@"%@",[[contactsAlldata valueForKey:@"checked"]objectAtIndex:indexPath.row]];
        
        
        
        
        if ([[contactsAlldata valueForKey:@"checked"] count] >0) {
            if(![str isEqualToString:@"NO"])
            {
                
                [cell.btnCheckContact setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                
                
                
                //  [cell.btnCheck setSelected:YES];
                
            }
            
            else
            {
                
                if ([[contactsAlldata valueForKey:@"checked"]containsObject:[contactNumbersArray objectAtIndex:indexPath.row]])
                {
                    
                    [cell.btnCheckContact setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                }
                else
                {
                    
                    
                    [cell.btnCheckContact setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
                    
                    
                }
                
                
                
                
                
            }
            
            [cell.btnCheckContact addTarget:self action:@selector(btnCheckContact:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.btnCheckContact.tag = indexPath.row ;
            
            cell.selectionStyle = UITableViewCellSeparatorStyleNone ;
            cell.backgroundColor = [UIColor clearColor];
            
            
            
            
            cell.textLabel.textColor= [UIColor whiteColor];
            cell.detailTextLabel.textColor= [UIColor whiteColor];
            
            
            cell.txtContactName.text = [NSString stringWithFormat:@"%@", [[contactsAlldata valueForKey:@"fullName"]objectAtIndex:indexPath.row]];
            
            
            cell.textContactNo.text = [NSString stringWithFormat:@"%@", [[contactsAlldata valueForKey:@"PhoneNumbers"]objectAtIndex:indexPath.row]];
            
  
            
           
            
            UIImage *imgContct =  [[contactsAlldata valueForKey:@"userImage"]objectAtIndex:indexPath.row];
            
            if ([imgContct isEqual:[UIImage imageNamed:@"photo.png"]])
            {
             
                  [cell.imgContacts setImageWithString:cell.txtContactName.text color:nil circular:YES];
                
            }else{
            
                cell.imgContacts.image = imgContct ;
            
            }
            
                
            
          //  cell.imgContacts.image
            
            
            // [_sampleImageView setImageWithString:_nameField.text color:nil circular:_circularSwitch.isOn];
            
            //            cell.imgContacts.image =  [[contactsAlldata valueForKey:@"userImage"]objectAtIndex:indexPath.row];
            //
            
            
            
            cell.imgContacts.layer.cornerRadius = 20.0f; //cell.imgContacts.frame.size.width/2 ;
            
            [cell.imgContacts.layer masksToBounds];
            
            cell.imgContacts.layer.borderWidth = 1.0f;
            
            //  NSLog(@"%@",[contactsAlldata valueForKey:@"userImage"]);
            
            //cell.imgContacts.layer.borderColor = [UIColor concreteColor].CGColor;
            
            cell.imgContacts.layer.masksToBounds = YES;
            
            cell.imgContacts.clipsToBounds = YES;
            
          
            
            // [cell setNeedsLayout];
            //  }
            
            
            //    [cell.imgContacts sd_setImageWithURL:[NSURL URLWithString: imgstr]placeholderImage:[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"]];
            
            
        }
        return cell;
        
    }
    
    
    
    return 0 ;
    
    
}
    


-(void)btnCheckContact:(id)sender{
    
    UIButton *btnContacts = (UIButton*)sender ;
    NSLog(@"%ld",(long)btnContacts.tag);
    
    [self.btnCheckContacts setSelected:NO];
    
    
    if (contactsAlldata.count>0) {
        if(![[[contactsAlldata valueForKey:@"checked"]objectAtIndex:btnContacts.tag]  isEqualToString:@"NO"])
        {
            
            [btnContacts setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
            
            NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:[contactsAlldata objectAtIndex:btnContacts.tag]];
            for (NSDictionary *dicts in array) {
                
                [dictt addEntriesFromDictionary:dicts];
                
            }
            
            [dictt setObject:@"NO" forKey:@"checked"];
            [contactsAlldata  replaceObjectAtIndex:btnContacts.tag withObject:dictt];
            
            NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
            
            [arrCheck addObject:dictt];
            for (int h = 0; h < [search_phoneNAME count]; h++) {
                if ([[arrCheck[0] valueForKey:@"fullName"] isEqualToString:[[search_phoneNAME  objectAtIndex:h] valueForKey:@"fullName"]]) {
                    
                    [search_phoneNAME replaceObjectAtIndex:h withObject:arrCheck[0]];
                    
                    
                }
                
            }
            
            
            
            NSString*contact = [[contactsAlldata valueForKey:@"PhoneNumbers"] objectAtIndex:btnContacts.tag];
            
            contact = [contact stringByReplacingOccurrencesOfString:@" " withString:@""];
            contact = [contact stringByReplacingOccurrencesOfString:@"  " withString:@""];
            
            [arrayContacts removeObject: contact];
            
        }
        else
        {
            
            [btnContacts setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
            NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:[contactsAlldata objectAtIndex:btnContacts.tag]];
            
            for (NSDictionary *dicts in array) {
                
                
                [dictt addEntriesFromDictionary:dicts];
                
                
            }
            
            
            [dictt setObject:@"YES" forKey:@"checked"];
            [contactsAlldata  replaceObjectAtIndex:btnContacts.tag withObject:dictt];
            
            NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
            
            [arrCheck addObject:dictt];
            for (int h = 0; h < [search_phoneNAME count]; h++) {
                if ([[arrCheck[0] valueForKey:@"fullName"] isEqualToString:[[search_phoneNAME  objectAtIndex:h] valueForKey:@"fullName"]]) {
                    
                    [search_phoneNAME replaceObjectAtIndex:h withObject:arrCheck[0]];
                    
                    
                }
                
            }
            
            
            NSString*contact = [[contactsAlldata valueForKey:@"PhoneNumbers"] objectAtIndex:btnContacts.tag];
            
            contact = [contact stringByReplacingOccurrencesOfString:@" " withString:@""];
            contact = [contact stringByReplacingOccurrencesOfString:@"  " withString:@""];
            
            
            [arrayContacts addObject: contact];
            NSLog(@"%@",arrayContacts);
            
            
        }
        
        [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        
        
    }
    
    
    
    
}

-(void)checkedClicked:(id)sender{
    
    UIButton* btnTag  = (UIButton*)sender ;
    NSLog(@"%ld",(long)btnTag.tag);
    
    
    
    
    NSString* indexx = [NSString stringWithFormat:@"%ld",(long)btnTag.tag];
    
    if (isUser == true) {
       
        
        if (userListArray.count>0) {
            if(![[[userListArray valueForKey:@"checked"] objectAtIndex:btnTag.tag] isEqualToString:@"NO"])
            {
                
                [btnTag setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
                
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:btnTag.tag]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"NO" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:btnTag.tag withObject:dictt];
                
                NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
                
                [arrCheck addObject:dictt];
                for (int h = 0; h < [search_tableContents count]; h++) {
                    if ([[arrCheck[0] valueForKey:@"firstName"] isEqualToString:[[search_tableContents  objectAtIndex:h] valueForKey:@"firstName"]]) {
                        
                        [search_tableContents replaceObjectAtIndex:h withObject:arrCheck[0]];
                        
                        
                    }
                    
                }
              
                
                
                
                // [totalcheckmarkArray replaceObjectAtIndex:btnTag.tag withObject:@"NO"];
                [selectedUsers removeObject: [[userListArray valueForKey:@"personId"] objectAtIndex:btnTag.tag]];
                NSLog(@"%@",selectedUsers);
            }
            else
            {
                [btnTag setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                
                //  [totalcheckmarkArray replaceObjectAtIndex:btnTag.tag withObject:@"YES"];
                
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:btnTag.tag]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"YES" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:btnTag.tag withObject:dictt];
                
                NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
                
                [arrCheck addObject:dictt];
                for (int h = 0; h < [search_tableContents count]; h++) {
                    if ([[arrCheck[0] valueForKey:@"firstName"] isEqualToString:[[search_tableContents  objectAtIndex:h] valueForKey:@"firstName"]]) {
                        
                        [search_tableContents replaceObjectAtIndex:h withObject:arrCheck[0]];
                        
                        
                    }
                    
                }
                
                
                [selectedUsers addObject: [[userListArray valueForKey:@"personId"] objectAtIndex:btnTag.tag]];
                NSLog(@"%@",selectedUsers);
                
                
            }
            
            [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
            
            
        }
        
        
    }else{
        
        
        if (userListArray.count>0) {
            if(![[[userListArray valueForKey:@"checked"] objectAtIndex:btnTag.tag] isEqualToString:@"NO"])
            {
                
                [btnTag setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
                
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:btnTag.tag]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"NO" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:btnTag.tag withObject:dictt];
                
                NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
                
                [arrCheck addObject:dictt];
                for (int h = 0; h < [search_group count]; h++) {
                    if ([[arrCheck[0] valueForKey:@"grpName"] isEqualToString:[[search_group  objectAtIndex:h] valueForKey:@"grpName"]]) {
                        
                        [search_group replaceObjectAtIndex:h withObject:arrCheck[0]];
                        
                        
                    }
                    
                }
                
                
                
                // [groupcheckmarkArray replaceObjectAtIndex:btnTag.tag withObject:@"NO"];
                [selectedGroups removeObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:btnTag.tag]];
                NSLog(@"%@",selectedGroups);
            }
            else
            {
                [btnTag setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                
                //   [groupcheckmarkArray replaceObjectAtIndex:btnTag.tag withObject:@"YES"];
                
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:btnTag.tag]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"YES" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:btnTag.tag withObject:dictt];
                
                NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
                
                [arrCheck addObject:dictt];
                for (int h = 0; h < [search_group count]; h++) {
                    if ([[arrCheck[0] valueForKey:@"grpName"] isEqualToString:[[search_group  objectAtIndex:h] valueForKey:@"grpName"]]) {
                        
                        [search_group replaceObjectAtIndex:h withObject:arrCheck[0]];
                        
                        
                    }
                    
                }
                
                
                
                [selectedGroups addObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:btnTag.tag]];
                NSLog(@"%@",selectedGroups);
                
            }
            
            [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
            
            
        }
        
    }
    
}


- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([[dictData allKeys][indexPath.row] isEqualToString:@"AO"]) {
        
         NSLog(@"AO");
        
         [_openParticipantsView setHidden:NO];
        
    }else if ([[dictData allKeys][indexPath.row] isEqualToString:@"ED"]) {
        NSLog(@"ED");
        
    [self empDirectory];
    }
    else if ([[dictData allKeys][indexPath.row] isEqualToString:@"GR"]) {
        NSLog(@"GR");
        
         [self groupFunction];
    }
    else if ([[dictData allKeys][indexPath.row] isEqualToString:@"PD"]) {
        NSLog(@"PD");
        
        ContactsVc *cVc = [[ContactsVc alloc]init];
        cVc = [self.storyboard instantiateViewControllerWithIdentifier:@"ContactsVc"];
        [self.navigationController pushViewController:cVc animated:YES];

    }

    
    
       
}


- (IBAction)checkAllClicked:(id)sender {
    
    
//    selectedUsers = [[NSMutableArray alloc]init];
//    selectedGroups = [[NSMutableArray alloc]init];

    
    

    
    
    if (!_btnCheckAll.isSelected) {
        
        [_btnCheckAll setSelected:YES];
        if (isUser == true) {
             selectedUsers = [[NSMutableArray alloc]init];
        }else{
            selectedGroups = [[NSMutableArray alloc]init];
            
        }
        
        for (int j=0; j<[userListArray count]; j++)
        {
            
            if (isUser == true) {
                
               

                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:j]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"YES" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:j withObject:dictt];

              //  [totalcheckmarkArray replaceObjectAtIndex:j withObject:@"YES"];
                [selectedUsers addObject: [[userListArray valueForKey:@"personId"] objectAtIndex:j]];
                NSLog(@"%@",selectedUsers);
                
                
 
                search_tableContents = [[NSMutableArray alloc]initWithArray:userListArray];
                
                
            }
            else{
                

                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:j]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"YES" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:j withObject:dictt];

               // [groupcheckmarkArray replaceObjectAtIndex:j withObject:@"YES"];
                [selectedGroups addObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:j]];
                
                 NSLog(@"%@",selectedGroups);
                
                  search_group = [[NSMutableArray alloc]initWithArray:userListArray];
              //  [selectedGroups addObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:j]];
            }
            
            
        }
        
        
    }else{
        
        [_btnCheckAll setSelected:NO];
        for (int j=0; j<[userListArray count]; j++) // Number of Rows count
        {
            
            for (int j=0; j<[userListArray count]; j++)
            {
                if (isUser == true) {
                    
                    NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                    
                    NSMutableArray *array = [NSMutableArray new];
                    [array addObject:[userListArray objectAtIndex:j]];
                    for (NSDictionary *dicts in array) {
                        
                        [dictt addEntriesFromDictionary:dicts];
                        
                    }
                    
                    [dictt setObject:@"NO" forKey:@"checked"];
                    [userListArray  replaceObjectAtIndex:j withObject:dictt];

                 //   [totalcheckmarkArray replaceObjectAtIndex:j withObject:@"NO"];
                    
                    [selectedUsers removeObject: [[userListArray valueForKey:@"personId"] objectAtIndex:j]];
                    NSLog(@"%@",selectedUsers);
                    
                    search_tableContents = [[NSMutableArray alloc]initWithArray:userListArray];

                    
//                    [blockedArray removeObject: [[userListArray valueForKey:@"personId"] objectAtIndex:j]];
                    
                }else{
                    NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                    
                    NSMutableArray *array = [NSMutableArray new];
                    [array addObject:[userListArray objectAtIndex:j]];
                    for (NSDictionary *dicts in array) {
                        
                        [dictt addEntriesFromDictionary:dicts];
                        
                    }
                    
                    [dictt setObject:@"NO" forKey:@"checked"];
                    [userListArray  replaceObjectAtIndex:j withObject:dictt];

                  //  [groupcheckmarkArray replaceObjectAtIndex:j withObject:@"NO"];
                    
                    [selectedGroups removeObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:j]];
                    NSLog(@"%@",selectedGroups);
                    
                    search_group = [[NSMutableArray alloc]initWithArray:userListArray];

                    
//                    [selectedGroups removeObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:j]];
                    
                }
                
                
                
            }
            
            
            
        }
        
    }
    
    
    [self.employeeTableView reloadData];
    
    
}
- (IBAction)backClicked:(id)sender {
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:NO];
     _addEmployeeView.hidden = YES ;
}

- (IBAction)btnSaveClicked:(id)sender {
    self.addEmployeeView.hidden = YES;
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:NO];
    
    
    if (isUser==true) {
        
        joinedString = [selectedUsers componentsJoinedByString:@","];
        NSLog(@"%@",selectUserArray);
        if (selectedUsers.count>0) {
            
           [dictData setObject:selectedUsers forKey:@"ED"];
        }
        else{
            [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"ED"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [dictData setValue:nil forKey:@"ED"];
            
        }
        

    }else{
        joinedString = [selectedGroups componentsJoinedByString:@","];
        NSLog(@"%@",selectedGroups);
        
        if (selectedGroups.count>0) {
            
            [dictData setObject:selectedGroups forKey:@"GR"];
        }
        else{
            [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"GR"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [dictData setValue:nil forKey:@"GR"];

        }
        
       

        
    }
    
    
    if ([[dictData valueForKey:@"ED"] count] == 0) {
        [dictData removeObjectForKey:@"ED"];
        
    }else if ([[dictData valueForKey:@"GR"] count] == 0) {
        
        [dictData removeObjectForKey:@"GR"];
        
    }

   
    NSLog(@"%@",dictData);
    
    if (dictData.count >0) {
        [self.txtNoEmployee setHidden:YES];
    }else{
        
        [self.txtNoEmployee setHidden:NO];
        
    }
    
    
       
    [self.collectionView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    
    
    
//    [self addBtn];
    
    
}

-(void)GetPersonDetailsFromServer{
    
//    NSDictionary *headers = @{ @"token": Tokenid,
//                               @"cache-control": @"no-cache",
//                               @"postman-token": @"5c8c4abb-a239-f17b-0991-dcdb17e4af81" };
    
    NSString *apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getperson?cmpId=%@&filterType=ALL&page=20&limit=20",companyId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        
        
        
        profileData = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(getuserDetails) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    

    
    
}


-(void)KvnPerform{
    
    [KVNProgress dismiss];
    
}

-(void)getuserDetails{
    
    userListArray = [[NSMutableArray alloc]init];
    NSMutableArray* ListArray = [[NSMutableArray alloc]init];
    
    
    ListArray = profileData[@"prsnData"];
    
   
    
    int count = 0 ;
    
    NSString*personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    double idPerson = [personId doubleValue];
    
    
    
    
    for (NSDictionary *dictt in ListArray){
        
        NSMutableDictionary *dicData = [[NSMutableDictionary alloc]init];
        
        [dicData addEntriesFromDictionary:dictt];
        
        
        
        [dicData setValue:@"NO" forKey:@"checked"];
        
        
        
        count = count + 1 ;
        
        int i = count - 1 ;
        NSString*list = [NSString stringWithFormat:@"%@",[dictt valueForKey:@"empSts"]];
        NSString*roleNme = [NSString stringWithFormat:@"%@",[dictt valueForKey:@"role"]];
        
        
        
        if ([list isEqualToString:@"1"]) {
            
            if ([[dictt valueForKey:@"personId"] isEqual:[NSNumber numberWithDouble:idPerson]]) {
                
            }else{
                
                [userListArray addObject:dicData];
                
                
            }
            
            
        }
        
        
        
        
        
    }
    
    if (selectedUsers.count>0) {
        
        userListArray = [NSMutableArray arrayWithArray:search_tableContents];
        
        
    }else{

     search_tableContents = [[NSMutableArray alloc]initWithArray:userListArray];
    
   
    }
    
    
    
    
    for (int i=0; i<[userListArray count]; i++) // Number of Rows count
    {
        
        [totalcheckmarkArray addObject:@"NO"];
        
        
    }
    
    
    // [self addBtn];
    
    [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    
    
}

-(void)GettingGroupsFromServer{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/group/secure/getgroup?cmpId=%@&personId=%@",companyId,personIdStr];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        
        
        
        getGroupDetails = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(getData) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    
    
}



-(void)getData {
    
    
    
    userListArray = [[NSMutableArray alloc]init];
    userListArray = [getGroupDetails valueForKey:@"prsngrp"];
    
    
    
    
    userListArray = [[NSMutableArray alloc]init];
    NSMutableArray* ListArray = [[NSMutableArray alloc]init];
    
    
    
    ListArray = getGroupDetails[@"prsngrp"];
    
   // ListArray = getGroupDetails[@"prsngrp"];
    int count = 0 ;
    
   
    for (NSDictionary *dict in ListArray){
        NSMutableDictionary *dicData = [[NSMutableDictionary alloc]init];
        
        
        [dicData addEntriesFromDictionary:dict];
        [dicData setValue:@"NO" forKey:@"checked"];
        
        
        
        count = count + 1 ;
        
        int i = count - 1 ;
        NSString*list = [NSString stringWithFormat:@"%@",[dict valueForKey:@"grpSts"]];
        NSString*roleNme = [NSString stringWithFormat:@"%@",[dict valueForKey:@"role"]];
        
        
        if ([list isEqualToString:@"1"]) {
            
            [userListArray addObject:dicData];
            
            
        }
        
    }
        
    if (selectedGroups.count>0) {
        
        userListArray = [NSMutableArray arrayWithArray:search_group];
        
        
    }else{
        
        search_group = [[NSMutableArray alloc]initWithArray:userListArray];
        
        
    }
    
    
 //   search_tableContents = [[NSMutableArray alloc]initWithArray:userListArray];
    
    
    for (int i=0; i<[userListArray count]; i++) // Number of Rows count
    {
        [groupcheckmarkArray addObject:@"NO"];
        
        
    }
    
    
    
    [self.employeeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        
    
    
}


-(void)addBtn{

    UIScrollView *scrollVw = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, _ScrollContactView.frame.size.width, _ScrollContactView.frame.size.height)];
    
    
    NSLog(@"%@",scrollVw.subviews);
    if (scrollVw.subviews.count >0)
    {
        [scrollVw.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];

    }
    NSLog(@"%@",scrollVw.subviews);

    

    for (int i = 0; i < [dictData count]; i++)
    {
       // CGFloat xOrigin = i * imageView.frame.size.width;
        btn = [[UIButton alloc] initWithFrame:CGRectMake(i * 60, 2, 60 , 30)];
        btn.backgroundColor = [UIColor redColor];
        
        
//        if ([[dictData valueForKey:@"FG"] count] == 0) {
//           
//            [btn removeFromSuperview];
//        
//            
//        }else if ([[dictData valueForKey:@"FU"] count] == 0) {
//            [scrollVw removeObserver:btn forKeyPath:@"FU"];
//        }
//        else{
        [scrollVw addSubview:btn];
        
      
        
//        [imageView setImage:[UIImage imageNamed:[imagesArray objectAtIndex:i]]];
        
        

       
        [_ScrollContactView addSubview:scrollVw];

    }

    [scrollVw setContentSize:CGSizeMake(60* [dictData count], scrollVw.frame.size.height)];


}


- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return dictData.count;
    
    
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
        static NSString *CellIdentifier = @"customData";
    customDataCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    
    
  
    
    if (dictData.count>0) {
        NSMutableArray *arr = [[NSMutableArray alloc]init];
        
        
        NSString *strkey = [[dictData allKeys]objectAtIndex:indexPath.row] ;
        
        
        if ([strkey containsString:@"BLK"]) {
            [cell.btnCloseBlk setHidden:NO];
        }else{
            [cell.btnCloseBlk setHidden:YES];
            
        }
        
        
        arr = [[dictData allValues]objectAtIndex:indexPath.row];
        NSLog(@"%@",arr);
        
        
        NSString *str = [NSString stringWithFormat:@"%ld %@", (long)arr.count ,strkey];
        cell.lblTxt.text = str ;
        
        cell.lblTxt.backgroundColor = [UIColor colorWithRed:20/255.0f  green:20/255.0f blue:20/255.0f alpha:0.7];
        cell.lblTxt.layer.cornerRadius = 5.0f;
        [cell.lblTxt clipsToBounds];
      
        
        cell.contentView.layer.cornerRadius= 5.0f ;
        [cell.contentView clipsToBounds];
        [cell.contentView.layer masksToBounds];
        
        
         [self.txtNoEmployee setHidden:YES];
        
    }
    else{
        
        [self.txtNoEmployee setHidden:NO];
        
    }
    
    [cell.btnCloseBlk addTarget:self action:@selector(blkclose:) forControlEvents:UIControlEventTouchUpInside];

    
    
    
    return cell;
    
}

-(void)blkclose:(id)sender{
    
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Do you want to remove bulk contacts" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
    
    alert.tag = 501 ;
    
    [alert show];

    
    
    
    
}


- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    float width = collectionView.frame.size.width / 2;
    return CGSizeMake(80, 40);
    
    
    
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0.0;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0.0;
}

- (UIEdgeInsets)collectionView:
(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    //    return UIEdgeInsetsMake(50, 20, 50, 20);
    return UIEdgeInsetsMake(0,0, 0, 0);
}



- (IBAction)doneBtn:(id)sender {
    
    
    NSString *str = _txtView.text ;
    
    
    NSMutableArray *arrDigits = [[NSMutableArray alloc]init];
    
    
    NSArray*ar = [str componentsSeparatedByString:@","];
    [arrDigits addObjectsFromArray:ar];
    
    
    addOnArray = [[NSMutableArray alloc]init];
    
    if (arrDigits.count > 1) {
        NSString*strDigit;
        int i = 0 ;
                  for (NSArray*arr in arrDigits) {
                        i = i + 1 ;
                        int count = i - 1 ;
            
                      strDigit = [arrDigits objectAtIndex:count];
                      
                      
                        NSLog(@"%@",str);
            
                        if (strDigit.length!=10) {

                            
                            break ;
                            
                            
                        }else{
                              [addOnArray addObject:strDigit];
                            
                        }
                    }

        
        
    }else if (arrDigits.count == 1){
         if (str.length != 10){
            
            
         }else{
             
             [addOnArray addObjectsFromArray:arrDigits];
             
             
         }
        
    }
    else{

    }
    
    
   
    
    
    if (addOnArray.count != arrDigits.count) {
        
        if ([_txtView.text isEqualToString:@""]) {
            
            [self.openParticipantsView setHidden:YES];
            
  [self tabView];
            
           
                
                [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"AO"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                [dictData setValue:nil forKey:@"AO"];
            
            if ([[dictData valueForKey:@"AO"] count] == 0) {
                [dictData removeObjectForKey:@"AO"];
                
            }
            
            
            NSLog(@"%@",dictData);
            
            if (dictData.count >0) {
                [self.txtNoEmployee setHidden:YES];
            }else{
                
                [self.txtNoEmployee setHidden:NO];
                
            }

            
            [self.collectionView reloadData];
            
            
        }else{
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Enter mobile no. in given format" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
            
        }
    }
    else{
        
        [[NSUserDefaults standardUserDefaults]setObject:arrDigits forKey:@"AO"];
                        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [self.openParticipantsView setHidden:YES];
        
  [self tabView];
                        NSMutableArray *ADDON = [[NSUserDefaults standardUserDefaults]valueForKey:@"AO"];
                        NSLog(@"%@",ADDON);
        
                        if (ADDON.count >0) {
        
                            [dictData setValue:ADDON forKey:@"AO"];
                            NSLog(@"%@",dictData);
        
                        }else{
        
                            [[NSUserDefaults standardUserDefaults]setObject:ADDON forKey:@"AO"];
                            [[NSUserDefaults standardUserDefaults]synchronize];
        
                            [dictData setValue:nil forKey:@"AO"];
                            
                        }
        
        if ([[dictData valueForKey:@"AO"] count] == 0) {
            [dictData removeObjectForKey:@"AO"];
            
        }
        
        
        NSLog(@"%@",dictData);
        
        if (dictData.count >0) {
            [self.txtNoEmployee setHidden:YES];
        }else{
            
            [self.txtNoEmployee setHidden:NO];
            
        }
        
        [self tabView];
        
                        [self.collectionView reloadData];

    }
}



- (IBAction)backOpenParticpants:(id)sender {
    
     [self.openParticipantsView setHidden:YES];
    [self tabView];
    
}





-(void)updateDataFromServer{
    //openParticipantFile
    NSString * json ;
    
    NSString*subject = [NSString stringWithFormat:@"%@",_txtSubject.text ];
    subject = [subject stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    
    
    if (IsEditing == true) {
        confId = [NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"confId"]];
        
        
        
         json = [NSString stringWithFormat: @"cmpId=%@&confId=%@&hostId=%d&confdate=%ld&strtTime=%ld&endTime=%ld&confDialType=%@&confSub=%@&confDesc=%@&recording=%d&manage=%d&secure=%d&qna=%d",companyId,confId,personID,datee,strtTIME,ENDTIME,dialType,self.txtSchedule.text,subject,RECORDINGINT,ManageINT,SecureINT,QAINT];

    }else{
    
        json = [NSString stringWithFormat: @"cmpId=%@&confId=%d&hostId=%d&confdate=%ld&strtTime=%ld&endTime=%ld&confDialType=%@&confSub=%@&confDesc=%@&recording=%d&manage=%d&secure=%d&qna=%d",companyId,0,personID,datee,strtTIME,ENDTIME,dialType,self.txtSchedule.text,subject,RECORDINGINT,ManageINT,SecureINT,QAINT];
    
    
    }
    
    json = [json stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
    
    
    NSString *apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/addconference?%@",json];

    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
       // [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        
        
        
        scheduleData = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(getScheduleData) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        
        NSLog(@"Error: %@", error);
        
    }];


    
}

-(void)DismissProgress
{
    [KVNProgress dismiss];
}

-(void)getScheduleData{
    
    if ([[scheduleData valueForKey:@"message"] isEqualToString:@"success"] ) {
        
        
        confId = [scheduleData valueForKey:@"confId"];
        
        [self addNumbersApi];
        
        
    }else{
        
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
       

        UIAlertView*alert = [[UIAlertView alloc]initWithTitle:nil message:[scheduleData valueForKey:@"message"]  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
    }
    
    
}

-(void)addNumbersApi{
    
   //  NSString *apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/addNumbers"];
    
    
    NSMutableArray *phoneContactsArray = [[NSMutableArray alloc]init];
    phoneContactsArray = [dictData valueForKey:@"PD"];
    
    NSMutableArray *AddOn = [[NSMutableArray alloc]init];
    AddOn = [dictData valueForKey:@"AO"];
    
    
    NSMutableArray *arrayNumbers = [[NSMutableArray alloc]init];
    if (phoneContactsArray.count>0) {
        [arrayNumbers addObjectsFromArray:phoneContactsArray];
    }
    
    if (AddOn.count>0) {
        [arrayNumbers addObjectsFromArray:AddOn];
    }
    
    NSLog(@"%@",arrayNumbers);
    
    
    mobile = [arrayNumbers componentsJoinedByString:@","];
    
    
    
    mobile = [mobile stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobile = [mobile stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobile = [mobile stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobile = [mobile stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSLog(@"%@",mobile);
    
    
    
    NSMutableArray *personId = [dictData valueForKey:@"ED"];
     NSMutableArray *grpId = [dictData valueForKey:@"GR"];
  //  NSMutableArray *mobile1 =  [dictData valueForKey:@"PD"];
    
    
//    NSString *grpIdd;
//    NSString*mobileIdd;
//     NSString*strpersonId;
    
    if (personId.count >= 1) {
        
        strpersonId = [personId componentsJoinedByString:@","];
        
        
    }
    //    else if (personId.count == 1){
//        
//        strpersonId = [personId objectAtIndex:0];
//        
//    }
    else{
        strpersonId = @"";
        
    }
    
    
    if (grpId.count >= 1) {
        
        grpIdd = [grpId componentsJoinedByString:@","];
        
        
    }else{
        grpIdd = @"";
        
    }
    
    
//    if (mobile1.count >= 1) {
//        
//        mobileIdd = [mobile1 componentsJoinedByString:@","];
//       
//    }
//    else{
//     mobileIdd = @"";
//        
//    }
    
   
    if (IsEditing==true) {
        
        editFlag = @"1";
    }else{
        
         editFlag = @"0";
    }
    
//    NSString * json = [NSString stringWithFormat: @"personId=%@&grpId=%@&mobile=%@&confId=%@&editFlag=%@",strpersonId,grpIdd,mobile,confId,editFlag];
//    
//    json = [json stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    
    
    [self csvUploadingToServer];
    
    
    
    
    
}

-(void)AllData{
    
    if ( [[dataAll valueForKey:@"message"] isEqualToString:@"success"]) {
        AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [delegate.tabView removeFromSuperview];
        
        HomeVC*lVc = [[HomeVC alloc]init];
        NSString * storyboardName = @"Main";
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        lVc= [storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
        UINavigationController *navControllr = [[UINavigationController alloc]initWithRootViewController:lVc];
        navControllr.navigationBarHidden = true;
        delegate.window.rootViewController= navControllr;
        [delegate.window makeKeyAndVisible];
//        [self.navigationController popViewControllerAnimated:YES];
        
    }else{
        
//        UIAlertView*alert = [[UIAlertView alloc]initWithTitle:nil message:[dataAll valueForKey:@"message"]  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
//        [alert show];
       
  if ( [[dataAll valueForKey:@"message"] isEqualToString:@"Invalid File!Only CSV is permitted"] || [[dataAll valueForKey:@"message"] isEqualToString:@"Company Id can not empty"]) {

              UIAlertView*alert = [[UIAlertView alloc]initWithTitle:nil message:[dataAll valueForKey:@"message"]  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
              [alert show];
      
        
        
  }else{
      
       [self  cancelConferceFromServer];
  }
   
}
    
}



- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text;
{

    
    NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
    
    NSString *filtered = [[text componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
    
    return [text isEqualToString:filtered];
    
    
}


- (IBAction)opBckClicked:(id)sender {
    
    [self.openParticipantsView setHidden:YES];
    
      [self tabView];
    
    
    
    
}

- (IBAction)myMeetingsClicked:(id)sender {
    
    MyMeetingsVc *meetingVc = [[MyMeetingsVc alloc]init];
    meetingVc = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMeetingsVc"];
    meetingVc.delegate=self;
    [self.navigationController pushViewController:meetingVc animated:YES];
    

}


-(void)sendDataToA:(NSArray *)array{
    
    schededDataArray =  [[NSMutableDictionary alloc]init];
    [schededDataArray setValue:array forKey:@"scheduled"];
    
    NSLog(@"%@",schededDataArray);
    
    NSLog(@"%@",schededDataArray);
    NSLog(@"su");
    
    
    
    
}

- (IBAction)btnSubscribe:(id)sender {
    SubscriptionVC*subVc = [[SubscriptionVC alloc]init];
    
    subVc = [self.storyboard instantiateViewControllerWithIdentifier:@"SubscriptionVC"];
    
    [self.navigationController pushViewController:subVc animated:YES];
    
}
- (IBAction)bckEditClicked:(id)sender {
    MyMeetingsVc *meetingVc = [[MyMeetingsVc alloc]init];
    meetingVc = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMeetingsVc"];
    meetingVc.delegate=self;
    [self.navigationController pushViewController:meetingVc animated:YES];
}

-(void)scheduleConference{
    
  
    
    if ([_txtSelectDate.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select Date First" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
        
    }
    else if ([_txtStartTime.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select Start Time" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
        
    }
    else if ([_txtEndTime.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select End Time" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
        
    }
    else if ([self.txtSchedule.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter Title For schedule  " delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
        
    }else if (self.txtNoEmployee.hidden == NO){
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select participant" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
        
    }
    
    else{
        
        NSString *date ;
        date = self.txtSelectDate.text ;
        
        
        
        
        //startTime = [startTime stringByReplacingOccurrencesOfString:@":" withString:@""];
        
        NSDateFormatter *selectdateFormatter = [[NSDateFormatter alloc] init];
        // [selectdateFormatter setDateFormat:@"YYYY-MM-dd"];
        
        if (IsEditing == true) {
            
            [selectdateFormatter setDateFormat:@"dd-MM-YYYY"];
            
            datee =[[NSString stringWithFormat:@"%@",[[schededDataArray valueForKey:@"scheduled"]valueForKey:@"confdate"]]longLongValue];
            
            
            
        }
        else{
            [selectdateFormatter setDateFormat:@"yyyy-MM-dd"];
            NSDate *dateFromString2 = [selectdateFormatter dateFromString:date];
            NSTimeInterval selectDateInterval = [dateFromString2 timeIntervalSince1970]*1000;
            NSLog(@"%f",selectDateInterval);
            NSString * dateInerval = [NSString stringWithFormat:@"%f",selectDateInterval];
            dateInerval = [dateInerval stringByReplacingOccurrencesOfString:@".000000" withString:@""];
            
            datee = [dateInerval longLongValue];
        }
        //  selectdateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        
        
        
        
        NSString *startTime = self.txtStartTime.text ;
        NSArray *startArray = [startTime componentsSeparatedByString:@":"];
        int hh ;
        int mm ;
        if (startArray.count>0) {
            hh = [startArray[0] intValue];
            mm = [startArray[1] intValue];
        }
        
        
        
        int valueStartTime  = (hh*60*60*1000) + (mm*60*1000) ;
        NSLog(@"%d",valueStartTime) ;
        NSString *strtTime =  [NSString stringWithFormat:@"%d",valueStartTime];
        
        
        
        NSString *endTime = self.txtEndTime.text ;
        NSArray *endArray = [endTime componentsSeparatedByString:@":"];
        int hhEnd;
        int mmEnd;
        if (endArray.count>0) {
            hhEnd = [endArray[0] intValue];
            mmEnd = [endArray[1] intValue];
        }
        
        
        int valueEndTime  = (hhEnd*60*60*1000) + (mmEnd*60*1000) ;
        NSLog(@"%d",valueEndTime) ;
        NSString *endTimestr =  [NSString stringWithFormat:@"%d",valueEndTime];
        
        
        personID = [personIdStr intValue];
        
        
        
        
        strtTIME = [strtTime longLongValue];
        ENDTIME = [endTimestr longLongValue];
        
        RECORDINGINT = [Recording intValue];
        ManageINT = [Manage intValue];
        SecureINT = [Secure intValue];
        QAINT = [QA intValue];
        
        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
        if (networkStatus == NotReachable) {
            UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message: @"No Network Connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alert show];
            return;
            
            
        }else{
          [KVNProgress show];
        [self updateDataFromServer];
            
        }
        
    }
    
}

-(void)previewData{
    
    PreviewPageVc *preview = [[PreviewPageVc alloc]init];
    preview = [self.storyboard instantiateViewControllerWithIdentifier:@"PreviewPageVc"];
    
    if ([_txtSelectDate.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Incomplete Information" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
        
    }
    else if ([_txtStartTime.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Incomplete Information" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
        
    }
    else if ([_txtEndTime.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Incomplete Information" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
        
    }
    else if ([self.txtSchedule.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Incomplete Information" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
    }
    else if (!(dictData.count>0)) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Incomplete Information" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
    }
    else{
        
        AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [delegate.tabView removeFromSuperview];

        
        
        _txtPrevEnd.text = self.txtEndTime.text ;
        _txtPrevStart.text = self.txtStartTime.text ;
        _txtPrevDate.text = self.txtSelectDate.text ;
        _txtPrevHeaderDate.text = self.txtSelectDate.text ;
        _txtSubject.text = self.txtSchedule.text ;
        _txtPrevDialOut.text = dialType;
        
        
        
        
        _txtDear.text = @"Dear Participants";

        
        NSString*strName = [[NSUserDefaults standardUserDefaults]valueForKey:@"firstName"];
        _txtPrevDetails.text = [NSString stringWithFormat:@"You have a conference call invite,from %@ Bhargava we request you to kindly block your calender according to the details mentioned below",strName];

        
        [self.previewPage setHidden:NO];
        
        
//        preview.headerDate = self.txtSelectDate.text ;
//        preview.startTime = self.txtStartTime.text ;
//        preview.EndTime = self.txtEndTime.text ;
//        preview.mode = dialType ;
//        preview.DateStr = _txtSelectDate.text ;
//        preview.subject = self.txtSchedule.text ;
        
        
      //  [self.navigationController pushViewController:preview animated:YES];
        
        
    }
    
}


- (IBAction)rePreviewClicked:(id)sender {
    [self previewData];
    
}

- (IBAction)reScheduleClicked:(id)sender {
    self.scrollView.contentOffset = CGPointZero;
    self.scrollView.contentInset = UIEdgeInsetsZero;

    [self scheduleConference];
}

-(void)insets{
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:NO];
    
    
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 14, 0, 0)];
        [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
        [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 17, 0, 0)];
        [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
        [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];

        
        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 375) {
        
//        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -40, 0, 0)];
//        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
//        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -42, 0, 0)];
//        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -42, 0, 0)];
//        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -41, 0, 0)];
        
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        
        
        [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
        [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
        [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
        [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
        [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];

        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 414) {
        
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -40, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -28, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        
        
        
        [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
        [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
        [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 23, 0, 0)];
        [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 24, 0, 0)];
        [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 24, 0, 0)];

        
    }else if ([UIScreen mainScreen].bounds.size.width == 768) {
        
        [delegate.tabView.btnToday setImage: [UIImage imageNamed:@"ipad-today.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnControlPanel setImage: [UIImage imageNamed:@"ipad-control-panel.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnDashboard setImage: [UIImage imageNamed:@"ipad-dashboard.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setImage: [UIImage imageNamed:@"ipad-schedule-meeting.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnMenu setImage: [UIImage imageNamed:@"ipad-menu.png"] forState:UIControlStateNormal];
        
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:12]];
        
        
        
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 20, 45)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(10, 50, 25, 55)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 40, 20, 45)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            
        
        
    } else if ([UIScreen mainScreen].bounds.size.width == 1024){
        
        [delegate.tabView.btnToday setImage: [UIImage imageNamed:@"ipad-today.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnControlPanel setImage: [UIImage imageNamed:@"ipad-control-panel.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnDashboard setImage: [UIImage imageNamed:@"ipad-dashboard.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setImage: [UIImage imageNamed:@"ipad-schedule-meeting.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnMenu setImage: [UIImage imageNamed:@"ipad-menu.png"] forState:UIControlStateNormal];
        
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:12]];
        
      
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 20, 45)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 50, 20, 55)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(20, 63, 35, 73)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(8, 50, 22, 55)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            
        }
        
        
    


    
}

-(void)fetchContactsandAuthorization
{
    
   
    
    // Request authorization to Contacts
    CNContactStore *store = [[CNContactStore alloc] init];
    contactsAlldata = [[NSMutableArray alloc]init];
    contctInfo = [[NSMutableArray alloc]init];
    cnArray = [[NSMutableArray alloc]init];
    sendingContacts = [[NSMutableArray  alloc] init];
    
    
    
    [store requestAccessForEntityType:CNEntityTypeContacts completionHandler:^(BOOL granted, NSError * _Nullable error) {
        if (granted == YES)
        {
            //keys with fetching properties
            NSArray *keys = @[CNContactFamilyNameKey, CNContactGivenNameKey, CNContactPhoneNumbersKey, CNContactImageDataKey,CNContactDatesKey];
            NSString *containerId = store.defaultContainerIdentifier;
            NSPredicate *predicate = [CNContact predicateForContactsInContainerWithIdentifier:containerId];
            NSError *error;
            NSArray *cnContacts = [store unifiedContactsMatchingPredicate:predicate keysToFetch:keys error:&error];
            if (error)
            {
                NSLog(@"error fetching contacts %@", error);
            }
            else
            {
                NSString *phone;
                NSString *fullName;
                NSString *firstName;
                NSString *lastName;
                // UIImage *profileImage;
                NSString* phonee ;
                NSMutableArray *contactNumbersArrayy = [[NSMutableArray alloc]init];
                
                

                for (CNContact *contact in cnContacts) {
                    // copy data to my custom Contacts class.
                    firstName = contact.givenName;
                    lastName = contact.familyName;
                    if (lastName == nil) {
                        fullName=[NSString stringWithFormat:@"%@",firstName];
                    }else if (firstName == nil){
                        fullName=[NSString stringWithFormat:@"%@",lastName];
                    }
                    else{
                        fullName=[NSString stringWithFormat:@"%@ %@",firstName,lastName];
                    }
                    
                    UIImage *image = [UIImage imageWithData:contact.imageData];
                    if (image != nil) {
                        profileImage = image;
                        
                        // [contactImagesArray addObject:profileImage];
                        
                    }else{
                        
                        
                        profileImage = [UIImage imageNamed:@"photo.png"];
                        
                    
                    }
                    for (CNLabeledValue *label in contact.phoneNumbers) {
                        phonee = [label.value stringValue];
                        if ([phonee length] > 0) {
                            
                            phonee = [[phonee componentsSeparatedByCharactersInSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]] componentsJoinedByString:@""];
                            //  phonee = [phonee stringByReplacingOccurrencesOfString:@" " withString:@""];
                            NSString *contct;
                            if (phonee.length>=10) {
                               phonee = [phonee substringFromIndex: [phonee length] - 10];
                            }
                            
                            
                            [contactNumbersArrayy addObject:phonee];
                        }
                    }
                    
                    // [addImage addObject:profileImage];
                    
                    
                    personDictt = [[NSMutableDictionary alloc] initWithObjectsAndKeys: fullName,@"fullName",phonee,@"PhoneNumbers",profileImage,@"userImage",@"NO",@"checked",nil];
                    
                    NSMutableDictionary *contactDetails = [[NSMutableDictionary alloc] initWithObjectsAndKeys: fullName,@"contactname",phonee,@"contactNo",@"true",@"status",nil];
                    
                     [cnArray addObject:contactDetails];
                       [contctInfo addObject:personDictt];
                    
                    
                    [contactNumbersArray addObject:[NSString stringWithFormat:@"%@",[personDictt objectForKey:@"PhoneNumbers"]]];
                    
                    [nameList addObject:[NSString stringWithFormat:@"%@",[personDictt objectForKey:@"fullName"]]];
                    
                }
                
                for (int i=0; i<[contactsAlldata count]; i++) // Number of Rows count
                {
                    [checkedConatcts addObject:@"NO"];
                    
                    
                }
                
                
                [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"synchContacts"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                
                
                
              //  contactsSyched = YES;
                
//                NSData *data = [NSKeyedArchiver archivedDataWithRootObject:contactsAlldata];
//                [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"synchedContacts"];
//                [[NSUserDefaults standardUserDefaults]synchronize];
                
                NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:contctInfo];
                NSArray*arr = orderedSet.array;
                NSLog(@"%@",arr);
               
                NSOrderedSet *orderedSet2 = [NSOrderedSet orderedSetWithArray:cnArray];
                NSArray*arr2 = orderedSet2.array;
                NSLog(@"%@",arr2);
                
               
                NSMutableArray*keysSet = [[NSMutableArray alloc]init];
                [keysSet  addObject: [arr valueForKey:@"PhoneNumbers"]];
                NSMutableArray *check ;
                for (NSDictionary *msg in arr) {
                   
                    NSString*key =[NSString stringWithFormat:@"%@",[msg valueForKey:@"PhoneNumbers"]];
                    
                    if (contactsAlldata.count>0) {
                        check = [[NSMutableArray alloc]initWithArray:[contactsAlldata valueForKey:@"PhoneNumbers"]];
                    }

                    
                    if (![check containsObject:key]) {
                        [contactsAlldata addObject:msg];
                       
                        
                    }
                }
                
                
                
                NSMutableArray*keysSet2 = [[NSMutableArray alloc]init];
                [keysSet2  addObject: [arr2 valueForKey:@"PhoneNumbers"]];
                NSMutableArray *check2 ;
                for (NSDictionary *msg2 in arr2) {
                    
                    NSString*key2 = [msg2 valueForKey:@"PhoneNumbers"];
                    
                    if (sendingContacts.count>0) {
                        check2 = [[NSMutableArray alloc]initWithArray:[sendingContacts valueForKey:@"PhoneNumbers"]];
                    }
                    
                    
                    if (![check2 containsObject:key2]) {
                        [sendingContacts addObject:msg2];
                        
                        
                    }
                }

                
                
                
                  [contactsAlldata sortUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"fullName" ascending:YES]]];
                
                 [sendingContacts sortUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"fullName" ascending:YES]]];
                
                
                  [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];

                search_phoneNAME = [[NSMutableArray alloc]initWithArray:contactsAlldata];

                
                if (isContactsSt == YES) {
                  
                    [self  sendContactsDataToServer];
                    

                    
                }else{
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        
                        [self.contactsTableView reloadData];
                        
                        
                       
                    });
                    
                }
                
                            }
        }
    }];
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
    if (tableView== _contactsTableView) {
        NSLog(@"%@",self.checkArray);
        
        NSUInteger row = [indexPath row] ;
        
//        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
//        
//        if ([self.checkArray containsObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]]) {
//            
//            
//            [self.checkArray removeObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
//            cell.accessoryType = UITableViewCellAccessoryNone;
//            [arrayContacts removeObject:contactNumbersArray[indexPath.row]];
//            
//            
//        }else{
//            
//            
//            [self.checkArray addObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
//            [arrayContacts addObject:contactNumbersArray[row]];
//            cell.accessoryType = UITableViewCellAccessoryCheckmark;
//            
//        }
        
        
        
        
        
//        [[NSUserDefaults standardUserDefaults]setValue:_checkArray forKey:@"checked"];
//        [[NSUserDefaults standardUserDefaults]synchronize];
//        
//        
//        [[NSUserDefaults standardUserDefaults]setValue:arrayContacts forKey:@"PD"];
//        [[NSUserDefaults standardUserDefaults]synchronize];
        

    }
   
    
}


- (IBAction)phoneBckClicked:(id)sender{
    
    if ((isContactsSt = YES) ) {
        
        contactsAlldata = [[NSMutableArray alloc]init];
        arrayContacts = [[NSMutableArray alloc]init];
                 [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"PD"];
        [[NSUserDefaults standardUserDefaults]synchronize];

        
        [self.txtNoEmployee setHidden:NO];

        
        
        
          [_collectionView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        
        
    }else{
        
        
    }
    
     [_PhoneContactsView setHidden:YES];
     [self tabView];

    
}
- (IBAction)PhonedoneClicked:(id)sender{
    
    if (arrayContacts.count >0) {
        if (isContactsSt == YES) {
            
            [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"PD"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [dictData setValue:nil forKey:@"PD"];

            
        }else{
        
            
        [dictData setObject:arrayContacts forKey:@"PD"];
        }
        
    }else{
        
        [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"PD"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [dictData setValue:nil forKey:@"PD"];
        

    }
    
    if ([[dictData valueForKey:@"PD"] count] == 0) {
        [dictData removeObjectForKey:@"PD"];
        
    }
    
    
    NSLog(@"%@",dictData);
    
    if (dictData.count >0) {
        [self.txtNoEmployee setHidden:YES];
    }else{
        
        [self.txtNoEmployee setHidden:NO];
        
    }
    
     [self tabView];
    
    
    
 [_PhoneContactsView setHidden:YES];
    
    [_collectionView reloadData];
    
    
}



-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText

{
    
    if (searchBar == _phoneSearchBar) {
        
        NSMutableArray *arrSearch = [[NSMutableArray alloc]init];
        // arrSearch = [[NSMutableArray alloc]initWithArray: [userListArray valueForKey:@"firstName"]];
        
        NSString *searchTextt = self.phoneSearchBar.text ;
        
        
        
        contactsAlldata = [[NSMutableArray alloc] initWithArray:search_phoneNAME];
        
        if ([searchTextt isEqualToString:@""]) {
            [self.contactsTableView reloadData];
            
            
            
        }else{
            NSPredicate *predicate = [NSPredicate
                                      predicateWithFormat:@"SELF.fullName contains %@",
                                      searchTextt];
            
            
            contactsAlldata = [NSMutableArray arrayWithArray:[contactsAlldata filteredArrayUsingPredicate:predicate]];
            NSLog(@"filtered count %lu ",(unsigned long)contactsAlldata.count);
            
            [self.contactsTableView reloadData];
        }
        

        
    }else{
    
    if (isUser == true) {
        
        NSMutableArray *arrSearch = [[NSMutableArray alloc]init];
        // arrSearch = [[NSMutableArray alloc]initWithArray: [userListArray valueForKey:@"firstName"]];
        
        NSString *searchText = self.searchBar.text ;
        
        
        
        userListArray = [[NSMutableArray alloc] initWithArray:search_tableContents];
        
        if ([searchText isEqualToString:@""]) {
            [self.employeeTableView reloadData];
            
            
            
        }else{
            NSPredicate *predicate = [NSPredicate
                                      predicateWithFormat:@"SELF.firstName contains %@",
                                      searchText];
            
            userListArray = [NSMutableArray arrayWithArray:[userListArray filteredArrayUsingPredicate:predicate]];
            NSLog(@"filtered count %lu ",(unsigned long)userListArray.count);
            
            [self.employeeTableView reloadData];
        }
        
        
        
        
        
        
    }
    else{
        
        
        
        
        userListArray = [[NSMutableArray alloc] initWithArray:search_group];
        
        if ([searchText isEqualToString:@""]) {
            
            [self.employeeTableView reloadData];
            
            
            
        }else{
            NSPredicate *predicate = [NSPredicate
                                      predicateWithFormat:@"SELF.grpName contains %@",
                                      searchText];
            
            userListArray = [NSMutableArray arrayWithArray:[userListArray filteredArrayUsingPredicate:predicate]];
            NSLog(@"filtered count %lu ",(unsigned long)userListArray.count);
            
            [self.employeeTableView reloadData];
        }
        
    }
    }
    
}


-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar

{
    
    
    [self.searchBar resignFirstResponder];
    
    
    
}


- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    
    //hide keyboard
    
    [_searchBar resignFirstResponder];
    
}

- (IBAction)refreshContactsClicked:(id)sender {
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:YES];
    [_PhoneContactsView setHidden:NO];
    
    isContactsSt = YES ;
    [self.txtNoEmployee setHidden:NO];
//    contactsAlldata = [[NSMutableArray alloc]init];
//    arrayContacts = [[NSMutableArray alloc]init];
//    selectedUsers = [[NSMutableArray alloc]init];
//    selectedGroups = [[NSMutableArray alloc]init];
//    contactNumbersArray = [[NSMutableArray alloc]init];

    
    [KVNProgress show];
    contactsAlldata = [[NSMutableArray alloc]init];
    arrayContacts = [[NSMutableArray alloc]init];
      [dictData setValue:nil forKey:@"PD"];

    [_btnCheckAll setSelected:NO];
  //  [_collectionView performSelectorOnMainThread:@selector(reloadData) withObject:ni waitUntilDone:YES];
    
    [self fetchContactsandAuthorization];
  
    
}

-(void)sendContactsDataToServer{
    
      NSString *apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/directory/add?"];
    
    
   
    
    
    NSDictionary *parameters = @{ @"personId": personIdStr,
                                  @"phone": sendingContacts 
                                  
                                  };
    
   
    

    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
 //   [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    
    
    [manager POST:apiURLStr parameters:parameters success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        id response = responseObject ;
        
        [self.contactsTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        

        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message: [response valueForKey:@"message"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        [alert show];
        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
        
        NSLog(@"Error: %@", error);
        
    }];
    

}


- (IBAction)bckPreviewClicked:(id)sender {
    
    [self.previewPage setHidden:YES];
    [self tabView];
    

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([UIScreen mainScreen].bounds.size.width== 768 || [UIScreen mainScreen].bounds.size.width== 1024) {
        
        return 100 ;
    }else{
        if (tableView == _contactsTableView) {
            return 69;
            
        }else{
            
          return  44 ;
            
        }
        
        
    }
    
//    if (tableView == _contactsTableView) {
//        return 69;
//
//    }
//
//    return 44 ;
    
}
- (IBAction)allContactsClicked:(id)sender {
    
    
    arrayContacts = [[NSMutableArray alloc]init];
    
    for (int i=0; i<[arrayContacts count]; i++) // Number of Rows count
    {
        [checkedConatcts addObject:@"NO"];
        
        
    }
    
    
    
    
    if (!_btnCheckContacts.isSelected) {
        
        [_btnCheckContacts setSelected:YES];
        
        
        
        
        for (int j=0; j<[contactsAlldata count]; j++)
        {
            NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:[contactsAlldata objectAtIndex:j]];
            for (NSDictionary *dicts in array) {
                
                [dictt addEntriesFromDictionary:dicts];
                
            }
            
            [dictt setObject:@"YES" forKey:@"checked"];
            [contactsAlldata  replaceObjectAtIndex:j withObject:dictt];

            
          //  [checkedConatcts replaceObjectAtIndex:j withObject:@"YES"];
            
            NSString *contact = [NSString stringWithFormat:@"%@",[[contactsAlldata valueForKey:@"PhoneNumbers"] objectAtIndex:j]];
            
            [arrayContacts addObject:contact];
            
            
                NSLog(@"%@",arrayContacts);
                //  [selectedGroups addObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:j]];
            
        }
        
        
    }else{
        
        [_btnCheckContacts setSelected:NO];
        
            for (int j=0; j<[contactsAlldata count]; j++)
            {
                
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[contactsAlldata objectAtIndex:j]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"NO" forKey:@"checked"];
                [contactsAlldata  replaceObjectAtIndex:j withObject:dictt];

                    
                   // [checkedConatcts replaceObjectAtIndex:j withObject:@"NO"];
                NSString *contact = [NSString stringWithFormat:@"%@",[[contactsAlldata valueForKey:@"PhoneNumbers"] objectAtIndex:j]];
                    
                [arrayContacts removeObject: contact];
                
                
                    //                    [selectedGroups removeObject: [[userListArray valueForKey:@"grpId"] objectAtIndex:j]];
                    
                }
                
        
    }
    
    
    [self.contactsTableView reloadData];
    
    

}



-(void)csvUploadingToServer{
    
    
    NSString *apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/addNumbers?"];
    
     NSString * json = [NSString stringWithFormat: @"personId=%@&grpId=%@&mobile=%@&confId=%@&editFlag=%@",strpersonId,grpIdd,mobile,confId,editFlag];
    
    
    NSMutableDictionary *getUpdates= [[NSMutableDictionary alloc]init];
    [getUpdates setObject:strpersonId forKey:@"personId"];
    [getUpdates setObject:grpIdd forKey:@"grpId"];
    [getUpdates setObject:mobile forKey:@"mobile"];
    [getUpdates setObject:confId forKey:@"confId"];
    [getUpdates setObject:editFlag forKey:@"editFlag"];
    

        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFJSONResponseSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];

        [manager.requestSerializer setValue:@"multipart/form-data" forHTTPHeaderField:@"Content-Type"];
    // [manager.requestSerializer setValue:@"application/vnd.ms-excel" forHTTPHeaderField:@"Content-Type"];

    


    
        
        [manager POST:apiURLStr parameters:getUpdates constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            if (fileData!=nil){
                NSDictionary *jsonHeaders = @{@"Content-Disposition":@"attachment;filename=FileName.csv",
                @"Content-Type": @"application/vnd.ms-excel"};
                
                [formData appendPartWithHeaders:jsonHeaders body:fileData];
                
                
                [formData appendPartWithFileData:fileData name:@"openParticipantFile" fileName:@"someFile.csv" mimeType:@"text/csv"];
                
                
            }
            
        } success:^(NSURLSessionDataTask *operation, id responseObject) {
            NSLog(@"Success: %@", responseObject);
            
            
//            block(responseObject,nil);
            
            [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
            
            dataAll = responseObject ;
            
           
            
            [self performSelectorOnMainThread:@selector(AllData) withObject:nil waitUntilDone:YES];

            
            
        } failure:^(NSURLSessionDataTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
             [self performSelectorOnMainThread:@selector(KvnPerform) withObject:nil waitUntilDone:YES];
            
        }];
    }
    
    
    

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView.tag == 501) {
        if (buttonIndex == 1) {
            
            [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"BLK"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [dictData removeObjectForKey:@"BLK"];
            _txtView.text = @"" ;
            
            if (dictData.count >0) {
                [self.txtNoEmployee setHidden:YES];
            }else{
                
                [self.txtNoEmployee setHidden:NO];
                
            }
            
            [_collectionView reloadData];

        }
        
    }
}




@end
