//
//  VarifyAdminVC.h
//  DemogoApplication
//
//  Created by katoch on 19/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"
#import <AssetsLibrary/AssetsLibrary.h>
//#import <TesseractOCR/TesseractOCR.h>
#import "TabView.h"


//G8TesseractDelegate,
@interface VarifyAdminVC : UIViewController<UITextFieldDelegate,DropDownViewDelegate,UIAlertViewDelegate,UIGestureRecognizerDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>{
    
    DropDownView *dropDownView;
   
    
    
    id states;
    id cities ;
    id Pin;
    NSString *strStateName ;
    
    BOOL isbilling;
    UIImage *chosenImage ;
    UIImage *chosenImage1;

    id saveData ;
    
    BOOL isPanImage;
    
    id detailData;
    
     BOOL CheckBox;
    NSMutableDictionary * OfficeAddressDta ;
    NSMutableDictionary *BillingCheckedDtaa;
    
    NSMutableDictionary *checkOK;
    id PassedJSon ;
    NSString *recognizedText;
    
    NSString *panNoStr;
    UIAlertView *homeAlert ;
    NSString *comId ;
     UITapGestureRecognizer *tapScrollView;
    BOOL isPanPic ;
    NSString *tokenId;
    
    
}
@property (strong, nonatomic) IBOutlet UILabel *txtCompany;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;

@property (strong, nonatomic) TabView *tabView;

@property (weak, nonatomic) IBOutlet UIImageView *imageToRecognize;
@property (nonatomic, strong) NSOperationQueue *operationQueue;

@property (strong, nonatomic) IBOutlet UIAlertController *AlertCtrl;
@property (strong, nonatomic) UITextField *dropDownTxtfield;
@property (strong, nonatomic) IBOutlet UITextField *txtAddress;
@property (strong, nonatomic) IBOutlet UITextField *txtState;
@property (strong, nonatomic) IBOutlet UITextField *txtCity;
@property (strong, nonatomic) IBOutlet UITextField *txtPin;
@property (strong, nonatomic) IBOutlet UITextField *txtPan;
@property (strong, nonatomic) IBOutlet UITextField *txtPancardName;
- (IBAction)browseClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnBrowse;
@property (strong, nonatomic) IBOutlet UIButton *checkBtn;
- (IBAction)checkClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UITextField *txtBillingAddress;
@property (strong, nonatomic) IBOutlet UITextField *txtBillingState;
@property (strong, nonatomic) IBOutlet UITextField *txtBillingCity;
@property (strong, nonatomic) IBOutlet UITextField *txtBillingPin;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *billingHeightLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *viewHeightLayout;
@property (strong, nonatomic) IBOutlet UIView *detailsView;
@property (strong, nonatomic) IBOutlet UIView *billingView;
- (IBAction)btnImgClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnImg;
- (IBAction)saveClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *saveBtn;
@property (strong, nonatomic) IBOutlet UIView *topView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *scrollViewTopLayout;
@property (strong, nonatomic) IBOutlet UIView *headerView;

@end
