//
//  CompCellTableViewCell.m
//  DemogoApplication
//
//  Created by Rhythmus on 03/02/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "CompCellTableViewCell.h"

@implementation CompCellTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



- (IBAction)Rolebutton:(UIButton *)sender {
}
- (IBAction)SelectDepartmentButton:(id)sender {
}

- (IBAction)Addbutton:(id)sender {
}
@end
