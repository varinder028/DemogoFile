//
//  CorporateTabBarViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "CorporateTabBarViewController.h"
#import "SubscriptionViewViewController.h"
#import "CorporateHomeViewController.h"
#import "ADMINProfilePICViewController.h"
#import "CorporateCollectionViewController.h"
#import "graidientViewController.h"



@interface CorporateTabBarViewController ()

{
    CorporateHomeViewController *firstTab;
    SubscriptionViewViewController *SecondTab;
    CorporateCollectionViewController *ThirdTab;
    graidientViewController *FourTab;
    ADMINProfilePICViewController *FifthTab;
    
    NSMutableArray *collectViewArray;
    
    UINavigationController *Navigtion1;
    UINavigationController *Navigtion2;
    UINavigationController *Navigtion3;
    UINavigationController *Navigtion4;
    UINavigationController *Navigtion5;
    
    
    SubscriptionViewViewController *suc;
}

@end

@implementation CorporateTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   // [[UITabBar appearance] setTintColor:[UIColor whiteColor]];
    
   // [self SetViewsForHostOrPArticipant];
    
    //[self.tabBarController setBackgroundColor:[UIColor colorWithRed:0.01 green:0.12 blue:0.16 alpha:1.0]];

   // [[UITabBar appearance] setBarTintColor:[UIColor colorWithRed:0.01 green:0.12 blue:0.16 alpha:1.0]];
    
    //[self.tabBar setBackgroundColor:[UIColor Color]];
    
    
    
//    UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Storyboard" bundle: nil];
////    
//    UINavigationController *navController = (UINavigationController *)window.rootViewController;
//    
//    ADMINProfilePICViewController *dump = [storyboard instantiateViewControllerWithIdentifier:@"CHome"];
//    
//    dump.PersonIDAHP = _PersonIDFetch;
//    
//    [self.navigationController pushViewController:dump animated:YES];
    
    
    
//    [navController pushViewController:dump animated:YES];
//    
//    self.tabBarController .viewControllers = [NSArray arrayWithObject:navController];
    
   // [self.view addSubview:self.tabBarController.view];

    
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController;
{
//    NSLog(@"%@", _TABDependClient);
//    
//    if ([_TABDependClient isEqualToString:@"ROLE_PARTICIPANT"])
//        
//    {
//        
//        //UIStoryboard *story = [UIStoryboard storyboardWithName:@"Storyboard" bundle:nil];
//        firstTab = [[CorporateHomeViewController alloc]initWithNibName:@"CorporateHomeViewControlle" bundle:nil];
//        firstTab.title = @"Today";
//        
//        
//        SecondTab = [[SubscriptionViewViewController alloc]initWithNibName:@"SubscriptionViewViewController" bundle:nil];
//        SecondTab.title = @"Subscribe";
//        
//        ThirdTab = [[CorporateCollectionViewController alloc]initWithNibName:@"CorporateCollectionViewController" bundle:nil];
//        SecondTab.title = @"Control Panel";
//        
//        FourTab = [[graidientViewController alloc]initWithNibName:@"graidientViewController" bundle:nil];
//        SecondTab.title = @"Dashboard";
//        
//        FifthTab = [[ADMINProfilePICViewController alloc]initWithNibName:@"ADMINProfilePICViewController" bundle:nil];
//        SecondTab.title = @"Menu";
//        
//        Navigtion1 = [[UINavigationController alloc]initWithRootViewController:firstTab];
//        Navigtion2 = [[UINavigationController alloc]initWithRootViewController:SecondTab];
//        Navigtion3 = [[UINavigationController alloc]initWithRootViewController:ThirdTab];
//        Navigtion4= [[UINavigationController alloc]initWithRootViewController:FourTab];
//        Navigtion5= [[UINavigationController alloc]initWithRootViewController:FifthTab];
//        
//        collectViewArray = [[NSMutableArray alloc]init];
//        
//        collectViewArray =[NSMutableArray arrayWithObjects:Navigtion1,Navigtion2,Navigtion3,Navigtion4,Navigtion5, nil];
//        
//        
//        [collectViewArray removeObjectAtIndex:1];
//        
//        self.tabBarController.viewControllers = collectViewArray;
//        
//        [self.view addSubview:self.tabBarController.view];
//        
//        
//        //   [self.view addSubview:self.tabBarController];
//        
//        //[[[[self.tabBarController tabBar]items]objectAtIndex:2]setEnabled:NO];
//    }
    

    
    return YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
