//
//  AppDelegate.h
//  DemogoApplication
//
//  Created by varinder singh on 1/23/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TabView.h"
#import <CoreLocation/CoreLocation.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,CLLocationManagerDelegate,UIAlertViewDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate,UIAlertViewDelegate>

@property (nonatomic, strong) CLLocationManager *locationManager;
@property(strong,nonnull)NSMutableArray *locationArray;
@property(strong,nonnull)NSString *locationStr;
@property(strong,nonnull)NSString *latStr;
@property(strong,nonnull)NSString *longStr;


@property(assign)BOOL shouldRotate;
@property(assign)BOOL SynchContacts;

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) TabView *tabView;
@property (retain) NSTimer  *timerHome;
@property (strong, nonatomic) UIViewController *viewcontroller;
@property (assign, nonatomic) CGRect currentStatusBarFrame;


@end

