//
//  LogSucessPasswordViewController.m
//  DemogoApplication
//
//  Created by Rhythmus on 14/03/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "LogSucessPasswordViewController.h"
#import "ViewController.h"
#import "VerifyAccountViewController.h"
#import "CorporateTabBarViewController.h"
#import "VarifyAdminVC.h"
#import "AppDelegate.h"
#import "HomeVC.h"
#import "TabView.h"
#import "KVNProgress.h"
#import "Reachability.h"
@interface LogSucessPasswordViewController ()<NSURLSessionDelegate,NSURLSessionDataDelegate>

{
    NSDictionary *mapData;
    NSMutableDictionary *ResponseDIc;
    NSString *oldPassWD;
    NSString *strPassword2;
    
    
    NSString *Base64Password;
    NSString *Base64encodePassword ;
    
    
    NSString *messageStr;
    
    
}


@property (strong, nonatomic) IBOutlet UIImageView *logo;


@property (strong, nonatomic) IBOutlet UITextField *oldPasswordTextField;
@property (strong, nonatomic) IBOutlet UITextField *newpasswordTextField;

@property (strong, nonatomic) IBOutlet UITextField *conformTextField;


@property (strong, nonatomic) IBOutlet UIImageView *oldPassICoN;
@property (strong, nonatomic) IBOutlet UIImageView *newpassICoN;
@property (strong, nonatomic) IBOutlet UIImageView *conPassICoN;



@end

@implementation LogSucessPasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    
    _newpasswordTextField.delegate= self;
    
   // self.navigationController.navigationBar.topItem.title = @"CHANGE PASSWORD";
    
    messageStr = [[NSString alloc]init];
    
   // messageStr = @"success";
    
    ResponseDIc = [[NSMutableDictionary alloc]init];
    
    oldPassWD= [[NSString alloc]init];
    
    strPassword2 = [[NSString alloc]init];
    
    Base64encodePassword = [[NSString alloc]init];
    
    Base64Password = [[NSString alloc]init];
    
    
    _personID = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    
    
    
    //_personID = [[NSString alloc]init];
    
    
    self.submitOUTLET.layer.cornerRadius = 5.0;
    [_submitOUTLET clipsToBounds];
    
    
    
   NSAttributedString *OLDTest=[[NSAttributedString alloc]
         initWithString:@"old password"
         attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.oldPasswordTextField.attributedPlaceholder=OLDTest;
    
    
    NSAttributedString *NEWTest=[[NSAttributedString alloc]
                             initWithString:@"new password"
                             attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.newpasswordTextField.attributedPlaceholder=NEWTest;
    
    NSAttributedString *confirmTest=[[NSAttributedString alloc]
                             initWithString:@"confirm new password"
                             attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.conformTextField.attributedPlaceholder=confirmTest;
    
    
    // Do any additional setup after loading the view.
}










- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


                                                ///////////         KeYBOARD REsign USing MeTHod          /////////////


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}









-(void)FirstAPIPostMethodUSed;
{
    
    NSString *tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    NSString *urlstr  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/secure/changepassword"];// ?newPassword=%@&oldPassword=%@&personId=%@",Base64Password,Base64encodePassword,self.personID];
    
    
    NSError *error;
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    // NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
    
    NSURL * urll = [NSURL URLWithString:urlstr];
    
    NSMutableURLRequest * requestUrl = [NSMutableURLRequest requestWithURL:urll
                                                               cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                           timeoutInterval:60.0];
    
    
    
    
    
    
    
    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [requestUrl addValue:tokenid forHTTPHeaderField:@"token"];
    
    
    [requestUrl setHTTPMethod:@"PUT"];
    
    
    
    
    /////////  old Password convert in Base64Encoding   ./////////////
    
    
    
    oldPassWD= [NSString stringWithFormat:@"%@",self.oldPasswordTextField.text];
    
    
    NSLog(@"%@",oldPassWD);
    
    NSData *oldData = [oldPassWD dataUsingEncoding:NSUTF8StringEncoding];
    NSString *oldPassBase64 = [oldData base64EncodedStringWithOptions:0];
    NSLog(@"%@", oldPassBase64); // Zm9v

    
    
  //  NSData *TakeData = [oldPassWD dataUsingEncoding:NSUTF8StringEncoding];
    
    // Convert to Base64 data
    
//    NSData *BaseData = [TakeData base64EncodedDataWithOptions:0];
//    
//    NSString *oldPassBase64 = [NSString stringWithFormat:@"%@",[NSString stringWithUTF8String:[BaseData bytes]]];
//    
//    NSLog(@"%@", oldPassBase64);
    
    
    
    
    /////////  new Password convert in Base64Encoding   ./////////////
    
    
    
    NSLog(@"%@",_personID);
    
    NSString *strpass;
    strpass= self.newpasswordTextField.text;
    
    NSData *plainData = [strpass dataUsingEncoding:NSUTF8StringEncoding];
    NSString *NewPassBase64 = [plainData base64EncodedStringWithOptions:0];
    NSLog(@"%@", NewPassBase64); // Zm9v

    
    
  mapData = [[NSDictionary alloc] initWithObjectsAndKeys: NewPassBase64,@"newPassword",oldPassBase64,@"oldPassword",_personID,@"personId",nil];
    
   NSLog(@" %@",mapData);
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:mapData options:0 error:&error];
    
    [requestUrl setHTTPBody:postData];
    
    
    
    
    
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:requestUrl completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
{
    dispatch_async(dispatch_get_main_queue(),^
    {
        
        [self performSelectorOnMainThread:@selector(dismissKvn) withObject:nil waitUntilDone:YES];
        
            NSError *jsonError;
                                              
            ResponseDIc =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                              
                                              
            messageStr = [NSString stringWithFormat:@"%@",[ResponseDIc valueForKey:@"message"]];
                                              
                                              
            NSLog(@"message is %@",messageStr);
                                              
                                              
            NSLog(@"%@",ResponseDIc);
        
        
        
        

//        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"AlreadyLogin"];
//        [[NSUserDefaults standardUserDefaults]synchronize];
        
        NSString *varify  = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:@"varify"]];
        
        
        
        if ([varify isEqualToString:[NSString stringWithFormat:@"1"]]) {
            
            if ([messageStr isEqualToString:@"success"]) {
                AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
                
                [delegate.tabView removeFromSuperview];
                
                HomeVC*lVc = [[HomeVC alloc]init];
                NSString * storyboardName = @"Main";
                UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
                lVc= [storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
                UINavigationController *navControllr = [[UINavigationController alloc]initWithRootViewController:lVc];
                navControllr.navigationBarHidden = true;
                delegate.window.rootViewController= navControllr;
                [delegate.window makeKeyAndVisible];
                
                
            }
        }else{
            if ([messageStr isEqualToString:@"success"])
                
                
            {
                
                NSString *str = [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
                
                
                if([str isEqualToString:@"ROLE_SUPER_ADMIN"]){
                    
                    VarifyAdminVC *varifyVc = [[VarifyAdminVC alloc]init];
                    
                    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"isFirst"];
                    [[NSUserDefaults standardUserDefaults]synchronize];
                    
                    varifyVc = [self.storyboard instantiateViewControllerWithIdentifier:@"VarifyAdminVC"];
                    [self.navigationController pushViewController:varifyVc animated:YES];
                    
                }
                else{
                    
                    
                    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
                    
                    [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"isFirst"];
                    [[NSUserDefaults standardUserDefaults]synchronize];
                    
                    HomeVC *hVc = [[HomeVC alloc]init];
                    UIStoryboard *story =[UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    hVc =[story instantiateViewControllerWithIdentifier:@"HomeVC"];
                    
                    NSString *str = [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
                    
                    
                    if ([str isEqualToString:@"ROLE_PARTICIPANT"])
                    {
                        hVc.RoleStr = @"PARTICIPANT" ;
                    }
                    else if ([str isEqualToString:@"ROLE_HOST"])
                    {
                        hVc.RoleStr = @"HOST" ;
                    }
                    else if ([str isEqualToString:@"ROLE_SUPER_ADMIN"])
                    {
                        hVc.RoleStr = @"ADMIN" ;
                        
                    }
                    
                    UINavigationController *navVc = [[UINavigationController alloc]initWithRootViewController:hVc];
                    
                    
                    
                    [navVc setViewControllers: @[hVc] animated: YES];
                    navVc.navigationBarHidden = true;
                    delegate.window.rootViewController= navVc;
                    [delegate.window makeKeyAndVisible];
                    
                    
                    
                    
                    [_tabView todayClicked];
                    
                    
                }
                
                
                
            }
            
            else
                
            {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[ResponseDIc valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
                
                [alert show];
                
            }
            
        }
        
        
//        if ([[NSUserDefaults standardUserDefaults]boolForKey:@"AlreadyLogin"]== true) {
//            
//            if ([messageStr isEqualToString:@"success"]) {
//                AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
//                
//                [delegate.tabView removeFromSuperview];
//                
//                HomeVC*lVc = [[HomeVC alloc]init];
//                NSString * storyboardName = @"Main";
//                UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
//                lVc= [storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
//                UINavigationController *navControllr = [[UINavigationController alloc]initWithRootViewController:lVc];
//                navControllr.navigationBarHidden = true;
//                delegate.window.rootViewController= navControllr;
//                [delegate.window makeKeyAndVisible];
//                
//                
//            }
//            
//           
//            
//        }
        
        
   
            
            
            
    
    });
        
    
                                                                                            
        
                                                                                                                 
                                                  

    
}];
                                                                    
    
    
    
    [postDataTask resume];
    
    
    
    
}

-(void)dismissKvn
{
    
    [KVNProgress dismiss];
}





- (IBAction)submitButton:(id)sender {
    
    
    NSString *passwordRegex = @"^.*(?=.{6,})(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$!&]).*$";
    NSPredicate *passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", passwordRegex];
    
    
        if ([self.newpasswordTextField.text isEqualToString:@""] || [self.conformTextField.text isEqualToString:@""] || [self.oldPasswordTextField.text isEqualToString:@""])

{
        
        
    UIAlertController *WithoutText = [UIAlertController alertControllerWithTitle:@"Change Password" message:@"Your password cannot change,Please fill all Query" preferredStyle:UIAlertControllerStyleAlert];
        
    UIAlertAction* error = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                            
        {


        }];
    
        [WithoutText addAction:error];
        
        [self presentViewController:WithoutText animated:YES completion:nil];
    
    }else if (![passwordTest evaluateWithObject:_conformTextField.text] || !([_conformTextField.text length]>=8)) {
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Password should be at least 8 characters.Password Must be at least 1 Uppercase, 1 Lowercase, 1 Number and 1 Special Character" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
    
    [alert show];
}
    else if(![passwordTest evaluateWithObject:_newpasswordTextField.text] ||!([_newpasswordTextField.text length]>=8)){
        
        NSLog(@"%@",_newpasswordTextField.text);
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Password should be at least 8 characters.Password Must be at least 1 Uppercase, 1 Lowercase, 1 Number and 1 Special Character" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
      
        
        
        
    } else if (![_newpasswordTextField.text isEqualToString:_conformTextField.text]){
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Passwords are not Matching" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
    
    else
        
    {
        
        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
        if (networkStatus == NotReachable) {
            UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message: @"No Network Connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alert show];
            return;
            
            
        }else{

        
        [KVNProgress show];
        
        [self FirstAPIPostMethodUSed];
            
        }

       
    }
    
}

    - (IBAction)SendCmpID:(id)sender


{
    
    VerifyAccountViewController *veri = [self.storyboard instantiateViewControllerWithIdentifier:@"VA"];
    
    veri.CMpid = _CMPID;
    
    [self.navigationController pushViewController:veri animated:YES];
    
    }

- (IBAction)backClicked:(id)sender {
    
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
    
    return YES;
}



//- (BOOL)isPasswordValid:(NSString*)strText
//{
//    NSString* const pattern = @"^.*(?=.{6,})(?=.*[a-z])(?=.*[A-Z]).*$";
//    NSRegularExpression* regex = [[NSRegularExpression alloc] initWithPattern:pattern options:0 error:nil];
//    NSRange range = NSMakeRange(0, [strText length]);
//    return [regex numberOfMatchesInString:strText options:0 range:range] > 0;
//}

//-(BOOL)isValidPassword:(NSString *)passwordString
//{
//    NSString *stricterFilterString = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{10,}";
//    NSPredicate *passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", stricterFilterString];
//    return [passwordTest evaluateWithObject:passwordString];
//}


  @end
    
