//
//  VarifyAdminVC.m
//  DemogoApplication
//
//  Created by katoch on 19/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "VarifyAdminVC.h"
#import <Photos/Photos.h>
#import <QuartzCore/QuartzCore.h>
#import "HomeVC.h"
#import "CorporateTabBarViewController.h"
#import "AppDelegate.h"
#define ACCEPTABLE_CHARACTERS @"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
#import "KVNProgress.h"

@interface VarifyAdminVC ()

@end

@implementation VarifyAdminVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    NSString*strCompanyname = [[NSUserDefaults standardUserDefaults]valueForKey:@"cmpNm"];
    _txtCompany.text = strCompanyname ;
    
    
    _saveBtn.layer.cornerRadius = 5.0f ;
    [_saveBtn clipsToBounds];
    
    
    
    
    UITapGestureRecognizer *gesRecognizerConf = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headerVieww)]; // Declare the Gesture.
    gesRecognizerConf.delegate = self;
    [_headerView addGestureRecognizer:gesRecognizerConf];
    
    
   
    self.automaticallyAdjustsScrollViewInsets = false ;
    _scrollView.delaysContentTouches = false;

    
    tapScrollView.delegate = self;
    self.automaticallyAdjustsScrollViewInsets = false ;
    _scrollView.delaysContentTouches = false;
    
    
    
    tapScrollView = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(scrollTap)];
    [self.scrollView addGestureRecognizer:tapScrollView];

    tapScrollView.delegate = self;
    
    
    
   // [NSUserDefaults standardUserDefaults]boolForKey:@"DropHome"]== true
    
    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    comId = [[NSUserDefaults standardUserDefaults]valueForKey:@"ComId"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    _btnImg.layer.cornerRadius = self.btnImg.frame.size.height/2 ;
    self.btnImg.clipsToBounds = YES;
    

    
    _txtState.rightViewMode = UITextFieldViewModeAlways;
    _txtState.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    [self.view bringSubviewToFront:_txtState.rightView];
    UIColor *color = [UIColor lightGrayColor];
    _txtState.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Select State" attributes:@{NSForegroundColorAttributeName: color}];
    
    
    
    
    _txtCity.rightViewMode = UITextFieldViewModeAlways;
    _txtCity.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    UIColor *color1 = [UIColor lightGrayColor];
    _txtCity.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Select City" attributes:@{NSForegroundColorAttributeName: color1}];
    
    
    _txtPin.rightViewMode = UITextFieldViewModeAlways;
    _txtPin.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    UIColor *color2 = [UIColor lightGrayColor];
    _txtPin.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Select Pin" attributes:@{NSForegroundColorAttributeName: color2}];
    
    
    
    _txtBillingCity.rightViewMode = UITextFieldViewModeAlways;
    _txtBillingCity.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
   
   
    
    _txtBillingState.rightViewMode = UITextFieldViewModeAlways;
    _txtBillingState.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    [self.view bringSubviewToFront:_txtBillingState.rightView];
   
    
    
    _txtBillingPin.rightViewMode = UITextFieldViewModeAlways;
    _txtBillingPin.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    
    
    UIColor *color6 = [UIColor lightGrayColor];
    _txtBillingAddress.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Enter Address" attributes:@{NSForegroundColorAttributeName: color6}];
    
    UIColor *color7 = [UIColor lightGrayColor];
    _txtAddress.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Enter Address" attributes:@{NSForegroundColorAttributeName: color7}];
    
    UIColor *color8 = [UIColor lightGrayColor];
    _txtPan.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Pan Number" attributes:@{NSForegroundColorAttributeName: color8}];
    
    UIColor *color9 = [UIColor lightGrayColor];
    _txtPancardName.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Pan Card" attributes:@{NSForegroundColorAttributeName: color9}];

    
    UIColor *color10 = [UIColor lightGrayColor];
    _txtBillingState.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Select State" attributes:@{NSForegroundColorAttributeName: color10}];

    
    UIColor *color11 = [UIColor lightGrayColor];
    _txtBillingPin.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Select Pin" attributes:@{NSForegroundColorAttributeName: color11}];
    
    
    UIColor *color12 = [UIColor lightGrayColor];
    _txtBillingCity.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Select City" attributes:@{NSForegroundColorAttributeName: color12}];
    
    
    
    
    
    _topView.layer.cornerRadius = 5.0f ;
    [_topView setClipsToBounds:YES];
    
    [self setAlertCtrl];
    
    self.billingView.hidden = YES;
    
    
       
    
    _billingHeightLayout.constant = 0;
     _viewHeightLayout.constant = 565 ;
    [self.view layoutIfNeeded];
    
    [self GettingStatesFromServer];
   

    // Do any additional setup after loading the view.
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [dropDownView closeAnimation];
    [super touchesBegan:touches withEvent:event];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    
}

- (IBAction)browseClicked:(id)sender {
    
    isPanImage = true ;
    [self presentViewController:self.AlertCtrl animated:YES completion:nil];

   
    
    
}



- (IBAction)checkClicked:(id)sender {
    
    if (!_checkBtn.isSelected) {
        
        [_checkBtn setSelected:YES];
         _viewHeightLayout.constant = 817 ;
        _billingHeightLayout.constant = 252;
         [self.view layoutIfNeeded];
        
         self.billingView.hidden = NO;
        
    }else{
        
         [_checkBtn setSelected:NO];
        
         _billingHeightLayout.constant = 0;
         _viewHeightLayout.constant = 565 ;
        
        [self.view layoutIfNeeded];
        
         self.billingView.hidden = YES;
        
        
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
    if (textField == _txtAddress ) {
        
        return true;

       
    }else if ( textField == _txtState){
        
            isbilling = false ;
        
        if (dropDownView != nil) {
            [dropDownView.view removeFromSuperview];
            dropDownView = nil;
        }
        
        NSArray *arrState = [states valueForKey:@"state"] ;
        
        
        long maxHeight = 150 ;
        long  TableHeight = arrState.count *30 ;
        
        
        if (TableHeight >=maxHeight ) {
            
            TableHeight = 150 ;
        }
        else{
            
            TableHeight = arrState.count *30 ;
            
        }
        
        
        
        dropDownView = [[DropDownView alloc] initWithArrayData:arrState  cellHeight:30 heightTableView:TableHeight paddingTop:0 paddingLeft:0 paddingRight:0 refView:textField animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
        
        dropDownView.delegate = self;
        
        [self.detailsView addSubview:dropDownView.view];
          self.dropDownTxtfield = textField ;
       
        [dropDownView openAnimation];
        
        return false;

        
    }
    
    
    else if ( textField == _txtCity){
        isbilling = false ;
        if (dropDownView != nil) {
            [dropDownView.view removeFromSuperview];
            dropDownView = nil;
        }
        
        if ([_txtState.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select the state first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            
            [alert show];
        }

        else{
        
            NSArray *arrcitie = [cities valueForKey:@"city"] ;
            
            
            long maxHeight = 150 ;
            long  TableHeight = arrcitie.count *30 ;
            
            
            if (TableHeight >=maxHeight ) {
                
                TableHeight = 150 ;
            }
            else{
                
                TableHeight = arrcitie.count *30 ;
                
            }
            
        dropDownView = [[DropDownView alloc] initWithArrayData:arrcitie cellHeight:30 heightTableView:TableHeight paddingTop:0 paddingLeft:0 paddingRight:0 refView:textField animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
        
        dropDownView.delegate = self;
        
        [self.detailsView addSubview:dropDownView.view];
        self.dropDownTxtfield = textField ;
        [dropDownView openAnimation];
            
            
        }
        
      return false;

        
        
    }
    else if ( textField == _txtPin){
        isbilling = false ;

        if (dropDownView != nil) {
            [dropDownView.view removeFromSuperview];
            dropDownView = nil;
        }
        
        if ([_txtCity.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select the City first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            
            [alert show];
        }
        else{
        NSArray *arr = [[NSArray alloc]init];
        arr = [Pin valueForKey:@"pinCode"];
        
            
            long maxHeight = 150 ;
            long  TableHeight = arr.count *30 ;
            
            
            if (TableHeight >=maxHeight ) {
                
                TableHeight = 150 ;
            }
            else{
                
                TableHeight = arr.count *30 ;
                
            }

            
        dropDownView = [[DropDownView alloc] initWithArrayData: arr  cellHeight:30 heightTableView:150 paddingTop:0 paddingLeft:0 paddingRight:0 refView:textField animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
        
        dropDownView.delegate = self;
        
        [self.detailsView addSubview:dropDownView.view];
        self.dropDownTxtfield = textField ;
        [dropDownView openAnimation];
        
        
            
            
        }
         return false;
        
    }
    else if ( textField == _txtPan){
        _txtPan.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
        [UIView animateWithDuration:0.5 animations:^{
//            _scrollViewTopLayout.constant = -200 ;
//            [self.view layoutIfNeeded];
            
            
            self.scrollView.contentOffset = CGPointMake(0, 230);

            
        }];
       
        
        
        
    }
    
    else if ( textField == _txtPancardName){
        [UIView animateWithDuration:0.5 animations:^{

//        _scrollViewTopLayout.constant = -250 ;
//        [self.view layoutIfNeeded];
            
            self.scrollView.contentOffset = CGPointMake(0, 280);
            
          }];
        
    }
    
   else if (textField == _txtBillingAddress ) {
        
     

    }
   else if ( textField == _txtBillingState){
       
       isbilling = true ;

       
       if (dropDownView != nil) {
           [dropDownView.view removeFromSuperview];
           dropDownView = nil;
       }
       NSArray *arrStates = [states valueForKey:@"state"] ;
       
       
       long maxHeight = 150 ;
       long  TableHeight = arrStates.count *30 ;
       
       
       if (TableHeight >=maxHeight ) {
           
           TableHeight = 150 ;
       }
       else{
           
           TableHeight = arrStates.count *30 ;
           
       }
       
       
       dropDownView = [[DropDownView alloc] initWithArrayData:arrStates cellHeight:30 heightTableView:TableHeight paddingTop: 0 paddingLeft:0 paddingRight:0 refView:textField animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
       
       dropDownView.delegate = self;
       
       [self.billingView addSubview:dropDownView.view];
       self.dropDownTxtfield = textField ;
       [dropDownView openAnimation];

      return false;
       
       
    }
    
    
    
    
    else if ( textField == _txtBillingCity){
        
        isbilling = true ;
        
        if (dropDownView != nil) {
            [dropDownView.view removeFromSuperview];
            dropDownView = nil;
        }
        
        if ([_txtBillingState.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select the State first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            
            [alert show];
        }else{
            
            NSArray *arrCity = [cities valueForKey:@"city"] ;
            
            
            long maxHeight = 150 ;
            long  TableHeight = arrCity.count *30 ;
            
            
            if (TableHeight >=maxHeight ) {
                
                TableHeight = 150 ;
            }
            else{
                
                TableHeight = arrCity.count *30 ;
                
            }

        
        dropDownView = [[DropDownView alloc] initWithArrayData:arrCity cellHeight:30 heightTableView:TableHeight paddingTop:0 paddingLeft:0 paddingRight:0 refView:textField animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
        
        dropDownView.delegate = self;
        
        [self.billingView addSubview:dropDownView.view];
        self.dropDownTxtfield = textField ;
        [dropDownView openAnimation];
            
            _billingHeightLayout.constant = 320;
            [self.view layoutIfNeeded];

//
          //  self.scrollView.contentOffset = CGPointMake(0, 320);

       
            
        }

         return false;
        
    }
    else if ( textField == _txtBillingPin){
        
        isbilling = true ;

        if (dropDownView != nil) {
            [dropDownView.view removeFromSuperview];
            dropDownView = nil;
        }
        if ([_txtBillingCity.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select the City first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
        }else{
            
            NSArray *arrPin = [Pin valueForKey:@"pinCode"] ;
            
            
            long maxHeight = 150 ;
            long  TableHeight = arrPin.count *30 ;
            
            
            if (TableHeight >=maxHeight ) {
                
                TableHeight = 150 ;
            }
            else{
                
                TableHeight = arrPin.count *30 ;
                
            }
        
        dropDownView = [[DropDownView alloc] initWithArrayData:arrPin  cellHeight:30 heightTableView:TableHeight paddingTop: 0  paddingLeft:0 paddingRight:0 refView:textField  animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
        
        dropDownView.delegate = self;
        
        [self.billingView addSubview:dropDownView.view];
        self.dropDownTxtfield = textField ;
        [dropDownView openAnimation];
        
            _billingHeightLayout.constant = 370;
            [self.view layoutIfNeeded];
            
           // self.scrollView.contentOffset = CGPointMake(0, 370);

        
        
        }
        
        return false;

        
    }
    
    
    return YES;
    
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
     [UIView animateWithDuration:0.5 animations:^{
//    _scrollViewTopLayout.constant = 0 ;
//    [self.view layoutIfNeeded];
         
          self.scrollView.contentOffset = CGPointMake(0,0);
         
     }];
    
    [textField resignFirstResponder];
    return YES ;
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (textField == _txtPan) {
        NSCharacterSet *allowedCharacters = [[NSCharacterSet alphanumericCharacterSet] invertedSet];
        NSRange lowercaseCharRange = [string rangeOfCharacterFromSet:[NSCharacterSet lowercaseLetterCharacterSet]];
        
        if (lowercaseCharRange.location != NSNotFound) {
            textField.text = [textField.text stringByReplacingCharactersInRange:range
                                                                     withString:[string uppercaseString]];
            return NO;
        }
        
        
        if (textField.text.length == 10 && range.length == 0)
        {
            return NO; // return NO to not change text
        }

        return ([string rangeOfCharacterFromSet:allowedCharacters].location == NSNotFound);
    }
        
    return YES;

    
    }
    
    
    

    
    


-(void)dropDownCellSelected:(NSInteger)returnIndex{
    
    
    
    if (_dropDownTxtfield == _txtState) {
        
        isbilling = false ;
        
        self.dropDownTxtfield.text = [[states valueForKey:@"state"] objectAtIndex:returnIndex];
        
       
            
            [self CitiesListFromServer];
            
                    
        
    }else if (_dropDownTxtfield == _txtCity) {
        isbilling = false ;

        
        self.dropDownTxtfield.text = [[cities valueForKey:@"city"] objectAtIndex:returnIndex];
        
        
            
            [self PinListFromServer];
            
            
        
        
    }
    
    
    
    
    else if (_dropDownTxtfield == _txtPin) {
        
        
        self.dropDownTxtfield.text = [NSString stringWithFormat:@"%@",[[Pin valueForKey:@"pinCode"] objectAtIndex:returnIndex]];
        
        
       
        
    }
    
    else if (_dropDownTxtfield == _txtBillingState) {
        
          isbilling =true ;
        
        self.dropDownTxtfield.text = [[states valueForKey:@"state"] objectAtIndex:returnIndex];
        
       
            
            [self CitiesListFromServer];
            
            
        
        
    }
    else if (_dropDownTxtfield == _txtBillingCity) {
        
        isbilling = true ;

        self.dropDownTxtfield.text = [[cities valueForKey:@"city"] objectAtIndex:returnIndex];
        
        
            [self PinListFromServer];
            
        _billingHeightLayout.constant = 252;
        [self.view layoutIfNeeded];
        
        
    }
    
    else if (_dropDownTxtfield == _txtBillingPin) {
        
        _billingHeightLayout.constant = 252;
        [self.view layoutIfNeeded];
       
        
        self.dropDownTxtfield.text = [NSString stringWithFormat:@"%@",[[Pin valueForKey:@"pinCode"] objectAtIndex:returnIndex]];

        
            
        
        
        
    }
    
    
    
}

-(void)GettingStatesFromServer{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/states"];
    
    
    
    
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithURL:[NSURL URLWithString:apiURLStr]
            completionHandler:^(NSData *data,
                                NSURLResponse *response,
                                NSError *error) {
                
                // NSError* error;
                if (data != nil) {
                    states =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                }
                
                
                NSLog(@"%@",states);
                
                
            }] resume];
}

-(void)CitiesListFromServer{
    NSString *stringState;
    if (isbilling == true) {
        stringState = _txtBillingState.text;
        

    }else{
        
        
    stringState = _txtState.text ;
        
    }
   
 
    
    
   
    stringState = [stringState stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    stringState  = [stringState stringByReplacingOccurrencesOfString:@"&" withString:@"%26"];
    
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/cities?state=%@",stringState];
    

    
    
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithURL:[NSURL URLWithString:apiURLStr]
            completionHandler:^(NSData *data,
                                NSURLResponse *response,
                                NSError *error) {
                
                // NSError* error;
                if (data != nil) {
                    cities =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                }
                
                
                NSLog(@"%@",cities);
                
                
            }] resume];
}


-(void)PinListFromServer{
    
    
    
    NSString *stringCity ;
    
    if (isbilling == true) {
        stringCity = _txtBillingCity.text;
        
        
    }else{
        stringCity = _txtCity.text ;
        
    }
    stringCity = [stringCity stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    stringCity  = [stringCity stringByReplacingOccurrencesOfString:@"&" withString:@"%26"];

    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/pin?city=%@",[NSString stringWithFormat:@"%@",stringCity]];
    

    
    
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithURL:[NSURL URLWithString:apiURLStr]
            completionHandler:^(NSData *data,
                                NSURLResponse *response,
                                NSError *error) {
                
                // NSError* error;
                if (data != nil) {
                    Pin =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                }
                
                
                NSLog(@"%@",Pin);
                
                
            }] resume];
}



- (void)selectPhoto {
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];
    
    
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
   if (isPanImage == true){
       
       if (isPanPic == true) {
            chosenImage = info[UIImagePickerControllerEditedImage];
           
           NSData *webData = UIImagePNGRepresentation(chosenImage);
           NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
           NSString *documentsDirectory = [paths objectAtIndex:0];
           
           self.txtPancardName.text = documentsDirectory ;
           UIImageWriteToSavedPhotosAlbum(chosenImage, nil, nil, nil);
           
        //   NSString *localFilePath = [documentsDirectory stringByAppendingPathComponent:png];
           
       }else{
       
       
        chosenImage = info[UIImagePickerControllerEditedImage];
       NSURL *refURL = [info valueForKey:UIImagePickerControllerReferenceURL];
       PHFetchResult *result = [PHAsset fetchAssetsWithALAssetURLs:@[refURL] options:nil];
       NSString *filename = [[result firstObject] filename];
       self.txtPancardName.text = filename ;
       
       self.operationQueue = [[NSOperationQueue alloc] init];
           
       }
       
      // [self recognizeImageWithTesseract:chosenImage];
       
    }
   else{
       
       chosenImage1 = info[UIImagePickerControllerEditedImage];
   }
    
    

    
    [self.btnImg setBackgroundImage:chosenImage1 forState:UIControlStateNormal];
    
   
    if (isPanImage == true) {
       
    }
    else{
        
        
    }
   
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
    
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

-(void)camera{
    
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                              message:@"Device has no camera"
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles: nil];
        
        [myAlertView show];
        
        
    } else {
        
        
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        
        [self presentViewController:picker animated:YES completion:nil];
        
    }

}


-(void)setAlertCtrl;
{
    
    
        
        self.AlertCtrl = [UIAlertController alertControllerWithTitle:@"selectImage" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *camera = [UIAlertAction actionWithTitle:@"Camera" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                                 
                                 {
                                     [self camera];
                                     
                                     isPanPic = true;
                                     
                                     
                                 }];
        
        UIAlertAction *Library  = [UIAlertAction actionWithTitle:@"Image Gallery" style:UIAlertActionStyleDefault handler:^(UIAlertAction *  action)
                                   
                                   {
                                       
                                       [self selectPhoto];
                                       
                                        isPanPic = false;
                                   }];
        
        UIAlertAction *Cancel  = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *  action) {
            isPanPic = false;
            
        }];
        
        [self.AlertCtrl addAction:camera];
        [self.AlertCtrl addAction:Library];
        [self.AlertCtrl addAction:Cancel];
        
    }
    



- (IBAction)btnImgClicked:(id)sender {
    
    isPanImage = false ;
    [self presentViewController:self.AlertCtrl animated:YES completion:nil];
}



- (IBAction)saveClicked:(id)sender {
   
    NSCharacterSet* tSet = [NSCharacterSet characterSetWithCharactersInString:
                            ACCEPTABLE_CHARACTERS];//whatever amount or type of characters you want to use
    NSCharacterSet* invSet = [tSet invertedSet];

    int limit = 10;
    if ([_txtAddress.text isEqualToString:@""]) {
        UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Enter the Address field"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert1 show];
    }else if ([_txtState.text isEqualToString:@""]) {
        UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Enter the state field"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert1 show];
    }else if ([_txtCity.text isEqualToString:@""]) {
        UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Enter the city field"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert1 show];
    }else if ([_txtPin.text isEqualToString:@""]) {
        UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Enter the Zip field"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert1 show];
    }else if ([_txtPan.text isEqualToString:@""]) {
        UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Enter your Pan number"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert1 show];
    }
    
    else if ([self.txtPan text].length != 10) {
        
        UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Please enter correct Pan Number"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert1 show];
    }

    else if ([_txtPancardName.text isEqualToString:@""]) {
        UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Please select Pand Card Image"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert1 show];
    }
    else if (![self ispan:self.txtPan.text]){
        UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Please Select the valid Pan card Image/Valid Pan No."  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
               [alert1 show];
        
    }
 
    
     else if (chosenImage1 == nil) {
        
        UIAlertView *ALERT = [[UIAlertView alloc]initWithTitle:nil message:@"Please Select the Company Image" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [ALERT show];
        
    }
    
   
    
    
   
    else{
        if (_checkBtn.isSelected) {
            
            
        }else{
            
            [KVNProgress show];
        
        [self postdata];
            
            
            
        }
        
    }
    
    
    
        if (_checkBtn.isSelected) {
            
            if ([_txtBillingAddress.text isEqualToString:@""]) {
                UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Enter the Address field"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
                [alert1 show];
            }else if ([_txtBillingState.text isEqualToString:@""]) {
                UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Enter the state field"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
                [alert1 show];
            }else if ([_txtBillingCity.text isEqualToString:@""]) {
                UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Enter the city field"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
                [alert1 show];
            }else if ([_txtBillingPin.text isEqualToString:@""]) {
                UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Enter the Zip field"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
                [alert1 show];
            
            }else{
                [KVNProgress show];
                 [self postdata];
                
                
            }
            
        }
    
        
        
    }
    


-(void)postdata {
    
    
     NSString *urlString=[NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/secure/verify?"];
    
    
    NSMutableDictionary* _params = [[NSMutableDictionary alloc] init];
    [_params setObject:comId forKey:@"cmpId"];
    [_params setObject:self.txtPan.text forKey:@"cmpPanNo"];
        [_params setObject:@"false" forKey:@"empRegReq"];
//    [_params setObject:chosenImage forKey:@"cmpLogo"];
//    [_params setObject:chosenImage forKey:@"cmpPan"];
    [_params setObject:@"APP" forKey:@"src"];
   
    
//http://182.76.44.135:8080/demogomobile/person/addprofimg?personId=%@",@"3799
    
    // the boundary string : a random string, that will not repeat in post data, to separate post data fields.
    NSString *BoundaryConstant = @"----------V2ymHFg03ehbqgZCaKO6jy";
    
    // string constant for the post parameter 'file'. My server uses this name: `file`. Your's may differ
    NSString* Filelogo = @"cmpLogo";
     NSString* FileParamConstant1 = @"cmpPan";
    
    // the server url to which the image (or the media) is uploaded. Use your server url here
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:urlString]];
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:30];
    
    [request setHTTPMethod:@"POST"];

    tokenId = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    
    // set Content-Type in HTTP header
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", BoundaryConstant];
    [request setValue:contentType forHTTPHeaderField: @"Content-Type"];
    [request setValue:tokenId forHTTPHeaderField: @"token"];
   // [request setValue: forHTTPHeaderField: @"Content-Type"];

    
    // post body
    NSMutableData *body = [NSMutableData data];
    
    // add params (all params are strings)
    for (NSString *param in _params) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", param] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"%@\r\n", [_params objectForKey:param]] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    // add image data
    NSData *imageData = UIImageJPEGRepresentation(chosenImage, 1.0);
     NSData *imagelogo = UIImageJPEGRepresentation(chosenImage1, 1.0);
    if (imagelogo) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"image.jpg\"\r\n", Filelogo] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:imagelogo];
        [body appendData:[[NSString stringWithFormat:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    if (imageData) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"image.jpg\"\r\n", FileParamConstant1] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:imageData];
        [body appendData:[[NSString stringWithFormat:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    }

    
    
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // setting the body of the post to the reqeust
    [request setHTTPBody:body];
    
    // set the content-length
    NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[body length]];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    // set URL
    [request setHTTPBody:body];
    
    
    NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *task = [session dataTaskWithRequest:request
                                                completionHandler:
                                      ^(NSData *data, NSURLResponse *response, NSError *error) {
                                          
                                          [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
                                          
                                          
                                          NSLog(@"%@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
                                          
                                           saveData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                          
                                          
                                          [self performSelectorOnMainThread:@selector(fetchUserDetails) withObject:nil waitUntilDone:NO];
                                          
                                          // [self.tumblrHUD hide];
                                      }];
        
        [task resume];

}
-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}

-(void)fetchUserDetails{
    
    if ([saveData[@"responseCode"] isEqual:[NSNumber numberWithInteger:200]]) {
        
        [KVNProgress show];
        
        
        [self AllDataDetails];
    }else{
        UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Error in Uploading Data"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert1 show];
        
    }
    
    
}

-(void)AllDataDetails{
    
    {
        
        
        
        
        
        NSError *linkError;
        
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        
        NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
        
        
        NSURL *PushLinkUrl = [NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/secure/address"];
        
        
        NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                                
                                                NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
        
        [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        
        [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
        
       // NSString *tokenStringV = @"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI4MDU0NTExMDMxOlJPTEVfU1VQRVJfQURNSU46MTczMCIsImlhdCI6MTQ5MTI3OTI1OH0.KKnIluFymHkR9zEs3PdOK0B04xee8_jPaJ41ix5Z6ik";
        
//        NSString *tokenstring = [NSString stringWithString:tokenStringV];
//        
//        NSLog(@"%@",tokenstring);
        
        [SendingRequest addValue:tokenId forHTTPHeaderField:@"token"];
        
        
        [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
        
        
        
        [SendingRequest setHTTPMethod:@"POST"];
        
        
        
            
            
            if (_checkBtn.isSelected) {
                OfficeAddressDta = [[NSMutableDictionary alloc]
                                                            initWithObjectsAndKeys:self.txtAddress.text,@"add",_txtCity.text,@"city", comId  ,@"cmpId",self.txtPan.text,@"cmpPanNo",@"India",@"country",_txtState.text,@"state",@"BILLING",@"type",_txtPin.text,@"zip",@"APP",@"src",nil];
                
                
                
           BillingCheckedDtaa = [[NSMutableDictionary alloc]
                                                         initWithObjectsAndKeys:self.txtBillingState.text,@"add",_txtBillingCity.text,@"city", comId ,@"cmpId",self.txtPan.text,@"cmpPanNo",@"India",@"country",_txtBillingState.text,@"state",@"OFFICE",@"type",_txtBillingPin.text,@"zip",@"APP",@"src",nil];
            }else{
                
             OfficeAddressDta = [[NSMutableDictionary alloc]
                                                          initWithObjectsAndKeys:self.txtAddress.text,@"add",_txtCity.text,@"city",comId,@"cmpId",self.txtPan.text,@"cmpPanNo",@"India",@"country",_txtState.text,@"state",@"BILLING",@"type",_txtPin.text,@"zip",@"APP",@"src",nil];
                
                
              BillingCheckedDtaa = [[NSMutableDictionary alloc]
                                                           initWithObjectsAndKeys:self.txtAddress.text,@"add",_txtCity.text,@"city",comId,@"cmpId",self.txtPan.text,@"cmpPanNo",@"India",@"country",_txtState.text,@"state",@"OFFICE",@"type",_txtPin.text,@"zip",@"APP",@"src",nil];
                
                
                
            }
            
           
            
            
            NSMutableArray *addressData =[[NSMutableArray alloc]init];
            
            [addressData addObject:OfficeAddressDta];
            
            [addressData addObject:BillingCheckedDtaa];
            
            
            checkOK=[[NSMutableDictionary alloc]initWithObjectsAndKeys:addressData,@"address", nil];
            
            
            [checkOK  setValue:comId forKey:@"cmpId"];
            
            NSLog(@"the json data is = %@",checkOK);
            
            
            
            detailData= [NSJSONSerialization dataWithJSONObject:checkOK options:kNilOptions error:&linkError];
            
            [SendingRequest setHTTPBody:detailData];
            
            
        
        
    
        
        
        
        
        
        NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
        
        
        
        NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                              
                                              {
                                                  dispatch_async(dispatch_get_main_queue(),^{
                                                      
                                                      NSError *jsonError;
                                                      
                                                       [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
                                                      
                                                      PassedJSon =[NSJSONSerialization JSONObjectWithData:data
                                                               options:NSJSONReadingMutableContainers error:&jsonError];
                                                      
                                                      
                                                      
                                                      
                                                      //NSLog(@"%@",[PassedJSonArray valueForKey:@"cmpId"]);
                                                      
                                                      // NSLog(@"%@",[PassedJSonArray valueForKey:@"token"]);
                                                      
                                                      
                                                      NSLog(@"%@",PassedJSon);
                                                      
                                                       [self performSelectorOnMainThread:@selector(getDetails) withObject:nil waitUntilDone:NO];
                                                      
                                                  });
                                                  
                                                  
                                                  
                                              }];
        
        [postDataTask resume];
        
     
        
    }
}


-(void)getDetails{
    
    if ([PassedJSon[@"responseCode"] isEqual:[NSNumber numberWithInteger:200]]) {
       homeAlert = [[UIAlertView alloc]initWithTitle:nil message:PassedJSon[@"message"]  delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [homeAlert show];
        
        }
    else{
        UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:nil message: @"Error in Uploading Data"  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert1 show];
        
    }
    
    
}


- (BOOL) validatePanCardNumber: (NSString *) cardNumber {
    NSString *emailRegex = @"^[A-Z]{5}[0-9]{4}[A-Z]$";
    NSPredicate *cardTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [cardTest evaluateWithObject:cardNumber];
}


//-(void)recognizeImageWithTesseract:(UIImage *)image
//{
//    
//    G8RecognitionOperation *operation = [[G8RecognitionOperation alloc] initWithLanguage:@"eng"];
//       operation.tesseract.engineMode = G8OCREngineModeTesseractOnly;
//    
//       operation.tesseract.pageSegmentationMode = G8PageSegmentationModeAutoOnly;
//    
//    
//    operation.delegate = self;
//    
//   
//    operation.tesseract.image = image;
//    
//   
//    operation.recognitionCompleteBlock = ^(G8Tesseract *tesseract) {
//        // Fetch the recognized text
//        recognizedText = tesseract.recognizedText;
//        
//        
//        
//        // first, separate by new line
//        
//        NSArray* allLinedStrings =
//        [recognizedText componentsSeparatedByCharactersInSet:
//         [NSCharacterSet newlineCharacterSet]];
//        
//        // then break down even further
//        NSString* strsInOneLine;
//        if (allLinedStrings.count >=9) {
//            
//            int count = 0 ;
//            
//            for (NSDictionary *dict in allLinedStrings) {
//                count = count + 1 ;
//                int i = count -1 ;
//                
//                
//                NSString *str = allLinedStrings[i] ;
//                str = [str stringByReplacingOccurrencesOfString:@"/" withString:@""];
//                str = [str stringByReplacingOccurrencesOfString:@"/" withString:@""];
//               str = [str stringByReplacingOccurrencesOfString:@"‘" withString:@""];
//                str = [str stringByReplacingOccurrencesOfString:@" " withString:@""];
//                str = [str stringByReplacingOccurrencesOfString:@"Signature" withString:@""];
//               
//                
//                NSScanner *scanner = [NSScanner scannerWithString:str];
//                BOOL isNumeric = [scanner scanInteger:NULL] && [scanner isAtEnd];
//                
//                
//                if ( str.length == 10) {
//                    
//                    
//                strsInOneLine = str ;
//                    
//                }
//                
//                
//                
//            }
//            
//            // strsInOneLine =
//            // [allLinedStrings objectAtIndex:9];
//        }
//        
////        NSArray* allLinedStrings =
////        [recognizedText componentsSeparatedByCharactersInSet:
////         [NSCharacterSet newlineCharacterSet]];
////        
////        // then break down even further
////        NSString* strsInOneLine;
////        if (allLinedStrings.count >=9) {
////          strsInOneLine =
////            [allLinedStrings objectAtIndex:9];
////        }
////        
//       
//        
//        panNoStr = [strsInOneLine stringByReplacingOccurrencesOfString:@" " withString:@""];
//        NSLog(@"%@",panNoStr);
//        NSLog(@"%@", recognizedText);
//        
//        
//
//    };
//    
//    
//    self.imageToRecognize.image = operation.tesseract.thresholdedImage;
//    
//    
//    [self.operationQueue addOperation:operation];
//}
//

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == homeAlert) {
        if (buttonIndex == 0) {
            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [delegate.tabView removeFromSuperview];
            
            
            [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"isFirst"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            HomeVC *hVc = [[HomeVC alloc]init];
            UIStoryboard *story =[UIStoryboard storyboardWithName:@"Main" bundle:nil];
            hVc =[story instantiateViewControllerWithIdentifier:@"HomeVC"];
            hVc.RoleStr = @"HOST" ;
            UINavigationController *navVc = [[UINavigationController alloc]initWithRootViewController:hVc];
            
            
            
            [navVc setViewControllers: @[hVc] animated: YES];
            navVc.navigationBarHidden = true;
            delegate.window.rootViewController= navVc;
            [delegate.window makeKeyAndVisible];
  
            
        }
        
    }
}

-(void)scrollTap{
    [UIView animateWithDuration:0.5 animations:^{

    self.scrollView.contentOffset = CGPointMake(0,0);
        
    }];
    
    //self.scrollView.contentSize.height + 67 - self.view.frame.size.height
    [dropDownView closeAnimation];
    
    
    //[_txtSchedule resignFirstResponder];
    
}

-(void)headerVieww{
    
    [dropDownView closeAnimation];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isDescendantOfView:dropDownView.view]) {
        
        // Don't let selections of auto-complete entries fire the
        // gesture recognizer
        // gesture recognizer
        [self.scrollView setScrollEnabled: false];
        return NO;
    }
    [self.scrollView setScrollEnabled: true];
    
    return YES;
}


- (BOOL)ispan:(NSString*)strText
{
    NSString* const pattern = @"[A-Z]{5}[0-9]{4}[A-Z]{1}";
    
    NSRegularExpression* regex = [[NSRegularExpression alloc] initWithPattern:pattern options:0 error:nil];
    NSRange range = NSMakeRange(0, [strText length]);
    return [regex numberOfMatchesInString:strText options:0 range:range] > 0;
}


@end
