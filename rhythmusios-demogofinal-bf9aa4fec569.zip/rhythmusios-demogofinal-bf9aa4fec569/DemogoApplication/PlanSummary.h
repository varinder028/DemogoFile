//
//  ViewController.h
//  chart
//
//  Created by katoch on 01/06/17.
//  Copyright © 2017 katoch. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"
#import "XYPieChart.h"


@interface PlanSummary : UIViewController<XYPieChartDelegate,XYPieChartDataSource>



{
    NSMutableArray *SelctDpOrHostArray;
    NSMutableArray *selectYearArray;
    NSMutableArray *SelctMonthArray;
    DropDownView *dropDownView;
    NSMutableArray *dropDownListArray;
    NSMutableArray*monthsCount ;
    id cities;
    NSMutableArray *responseArray;
}


@property(nonatomic, strong) NSMutableArray *slices;
@property(nonatomic, strong) NSArray *sliceColors;

@property (strong, nonatomic) UITextField *dropDownTxtfield;

@property (strong, nonatomic) IBOutlet UITextField *txtselectDepartmentOrHost;
@property (strong, nonatomic) IBOutlet UITextField *txtYears;
@property (strong, nonatomic) IBOutlet UITextField *txtMonth;

@property (strong, nonatomic) IBOutlet UILabel *lablSelectValue;

@property (strong, nonatomic) IBOutlet UIView *graphvieeww;


@property (strong, nonatomic) IBOutlet XYPieChart *pieChartLeft;

@property (strong, nonatomic) IBOutlet UIView *viewBackButtons;
@property (strong, nonatomic) IBOutlet UITableView *TableViewLegendShow;
- (IBAction)planBackClicked:(id)sender;


@end

