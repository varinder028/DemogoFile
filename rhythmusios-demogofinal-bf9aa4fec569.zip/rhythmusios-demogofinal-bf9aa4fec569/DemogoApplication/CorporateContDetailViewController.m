//
//  CorporateContDetailViewController.m
//  DemogoApplication
//
//  Created by Rhythmus on 03/02/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "CorporateContDetailViewController.h"

@interface CorporateContDetailViewController ()
{
    
    NSAttributedString *str;
    NSAttributedString *str2;
    NSAttributedString *str3;
    NSAttributedString *str4;
    NSAttributedString *str5;
    NSAttributedString *str6;

}
@property (weak, nonatomic) IBOutlet UIButton *saveOUtlet;
- (IBAction)BillingCheckButton:(id)sender;
- (IBAction)regCheckButton:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *PancardTextField;
@property (weak, nonatomic) IBOutlet UITextField *PanNumber;
@property (weak, nonatomic) IBOutlet UITextField *pinCodeTextField;
@property (weak, nonatomic) IBOutlet UITextField *CityTextField;
@property (weak, nonatomic) IBOutlet UITextField *StateTextField;
@property (weak, nonatomic) IBOutlet UITextField *AddressTextFielld;
@property (weak, nonatomic) IBOutlet UILabel *urlLinkLabel;
@property (weak, nonatomic) IBOutlet UILabel *CompanyNameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *CompanyIcon;
- (IBAction)save:(id)sender;

@end

@implementation CorporateContDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.saveOUtlet.layer.cornerRadius = 10.5;
    
    self.CompanyIcon.layer.cornerRadius = 46;
   
    str=[[NSAttributedString alloc]
         initWithString:@"Address"
         attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.AddressTextFielld.attributedPlaceholder=str;
    
    
    str2=[[NSAttributedString alloc]
          initWithString:@"State"
          attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    self.StateTextField.attributedPlaceholder=str2;
    
    
    str3=[[NSAttributedString alloc]
          initWithString:@"City"
          attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    self.CityTextField.attributedPlaceholder=str3;
    
  //  self.MobileNumberTextField.keyboardType =UIKeyboardTypeNumberPad;
    
    str4=[[NSAttributedString alloc]
          initWithString:@"Pin Code"
          attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    self.pinCodeTextField.attributedPlaceholder=str4;
    

    
    str5=[[NSAttributedString alloc]
          initWithString:@"Pan number"
          attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    self.PanNumber.attributedPlaceholder=str3;
    
    //  self.MobileNumberTextField.keyboardType =UIKeyboardTypeNumberPad;
    
    str6=[[NSAttributedString alloc]
          initWithString:@"Pancard"
          attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    self.PancardTextField.attributedPlaceholder=str4;
    

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)BillingCheckButton:(id)sender {
}

- (IBAction)regCheckButton:(id)sender {
}
- (IBAction)save:(id)sender {
}
@end
