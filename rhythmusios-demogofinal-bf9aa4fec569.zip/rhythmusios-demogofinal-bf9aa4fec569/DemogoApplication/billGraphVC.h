//
//  billGraphVC.h
//  DemogoApplication
//
//  Created by katoch on 18/07/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <PNChart/PNChart.h>
#import <PNChartDelegate.h>



@interface billGraphVC : UIViewController<PNChartDelegate,UINavigationControllerDelegate,UIAlertViewDelegate,UIGestureRecognizerDelegate>{
    
    NSString *companyId;
    NSString*companyToken ;
    
    id billData;
    UIAlertView *alert;
    
}
@property (nonatomic) BOOL isPresented;
@property(assign)BOOL shouldRotate;

@property (nonatomic) PNLineChart * lineChart;
@property (nonatomic) PNBarChart * barChart;
@property (nonatomic) PNCircleChart * circleChart;
@property (nonatomic) PNPieChart *pieChart;
@property (nonatomic) PNScatterChart *scatterChart;
@property (nonatomic) PNRadarChart *radarChart;
@property (weak, nonatomic) IBOutlet UILabel *centerSwitchLabel;
@property (strong, nonatomic) IBOutlet UIButton *backBtnClicked;
- (IBAction)bckButton:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *viewDetails;
@property (strong, nonatomic) IBOutlet UILabel *txtTotal;
@property (strong, nonatomic) IBOutlet UILabel *txtAverage;
- (IBAction)btnDetailData:(id)sender;
- (IBAction)bckClicked:(id)sender;

@end
