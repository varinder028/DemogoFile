//
//  mainViewTableViewCell.h
//  DemogoApplication
//
//  Created by Rhythmus on 28/02/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mainViewTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *listCMP;


@end
