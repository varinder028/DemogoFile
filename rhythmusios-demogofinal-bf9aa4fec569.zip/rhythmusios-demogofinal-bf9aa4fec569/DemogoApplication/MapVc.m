 //
//  MapVc.m
//  excelSheetUpload
//
//  Created by Rhythmus on 20/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "MapVc.h"
@class CourseAnnotation;
@interface MapVc ()<CLLocationManagerDelegate,MKMapViewDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate>
{
    NSString *latvalue;
    NSString *longvalue;
    NSString *latvalued;
    NSString *longvalued;
}
@end

@implementation MapVc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _mapkit.delegate =  self;
    
    [self findLocation];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)locationfindButton:(id)sender
{
    
  
}

- (IBAction)btnBckClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)findLocation
{
    
  NSString*  Tokenstr = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
     NSString *  Logincmpid = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    NSString *  LoginHostId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
       NSString *   LoginpersonId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    NSError*linkError;
//  NSString *  Logincmpid = @"1770";
//   NSString *   LoginpersonId = @"3773";
//    NSString *  LoginHostId = @"3773";
     NSString * typed = @"default";
     NSString * departmentdata = @"";
    
        NSString *otdat;
        // NSError *linkError;
        
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        
        
        
    otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/dashboard/secure/meetingdetails"];
    //?cmpId=%@&depName=%@&hostId=%@&personId=%@&type=%@",Logincmpid,departmentdata,LoginHostId,LoginpersonId,typed];
        
        
        NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
        
        
        NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
        
        
        NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                                
                                                NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
        
//       NSString* Tokenstr =@"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MDExMDU2MTg3OlJPTEVfU1VQRVJfQURNSU46MTc3MCIsImlhdCI6MTQ5NDgzNDE4OH0.YrwI-7Ma2bqZE58yTRjB79rgXn0g8jzyi58aK_C3DXg";
    
    
        [SendingRequest addValue:Tokenstr forHTTPHeaderField:@"token"];
        
        
        [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
        
        
        [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
    
        [SendingRequest setHTTPMethod:@"POST"];
        
    NSMutableDictionary * GetDicDta = [NSMutableDictionary dictionaryWithObjectsAndKeys:
            
    Logincmpid,@"cmpId",departmentdata,@"depName",LoginHostId,@"hostId",LoginpersonId,@"personId",typed,@"type", nil];
        
        
        NSData * SendData= [NSJSONSerialization dataWithJSONObject:GetDicDta options:kNilOptions error:&linkError];
    
    
         [SendingRequest setHTTPBody:SendData];
        
        NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                              
                                              {
                                                  
                                                  dispatch_async(dispatch_get_main_queue(),^
                                                                 {
                                                                     
                                                                     NSError *jsonError;
                                                                     
                                                                     
                                                                       if (data) {
                                                                         
                                                                         NSError *error;
                                                                         JSON = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves | NSJSONReadingMutableContainers error:&error];
                                                                         NSLog(@"%@",JSON);
                                                                         

                                                            
                                                                            
                                                                           [self performSelectorOnMainThread:@selector(datalocation) withObject:nil waitUntilDone:YES];
                                                                           
                                                                             
                                                                       
                                                                         
                                                                         
                                                                     }
                                                                     
//
                                                                     
                                                                 });
                                                  
                                                  
                                                  
                                              }];
        
        [postDataTask resume];
        
    }
    

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == ALERTMAP) {
        
        [self.navigationController popViewControllerAnimated:YES];
        
        
    }
}

-(void)datalocation{
    
    NSDictionary *response = JSON;
    
    
   if ([[response valueForKey:@"responseCode"] isEqual:[NSNumber numberWithInteger:400]]){
       
       NSString *str = [response valueForKey:@"message"];
       
       if ([str isKindOfClass:(id)[NSString class]] || str == nil ) {
           
//           ALERTMAP = [[UIAlertView alloc]initWithTitle:nil message:@"Server Error" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
//           [ALERTMAP show];
//
//       }else
//       {
   //    [response  valueForKey:@"message"]
       
       
        ALERTMAP = [[UIAlertView alloc]initWithTitle:nil message:@"Server error" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [ALERTMAP show];
           
           
       }
       
       
    }else{
    
    for (NSDictionary *entry in response[@"mtngdetail"][@"empgeolist"]) {
        NSString *firstname = entry[@"firstName"];
//
        
        
        latitude = [entry[@"loclat"] doubleValue];
        longitude = [entry[@"loclng"] doubleValue];
        NSString *locationed =[NSString stringWithFormat:@"%@",[entry valueForKey: @"location"]];
        MKPointAnnotation *myAnnotation = [[MKPointAnnotation alloc] init];
        myAnnotation.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        myAnnotation.title = firstname;
        myAnnotation.subtitle = [NSString stringWithFormat:@"Location: %@",locationed ];
        
        MKCoordinateRegion region;
        CLLocation *locObj = [[CLLocation alloc] initWithCoordinate:CLLocationCoordinate2DMake(latitude, longitude)
                                                           altitude:0
                                                 horizontalAccuracy:0
                                                   verticalAccuracy:0
                                                          timestamp:[NSDate date]];
        region.center = locObj.coordinate;
        MKCoordinateSpan span;
        span.latitudeDelta  = 7; // values for zoom
        span.longitudeDelta = 7;
        region.span = span;
        
        
      ///  if( latitude > -89 && latitude < 89 && longitude > -179 && longitude < 179 ){
            [self.mapkit setRegion:region animated:YES];
       // }
      //  [self.mapkit setRegion:region animated:YES];
        
        [_mapkit addAnnotation:myAnnotation];
        
        [self showAnnotationCallOut];
        
    }
        
}
    
}


- (void) showAnnotationCallOut {
    [_mapkit setSelectedAnnotations:@[[[_mapkit annotations] lastObject]]];
   
}


//- (void)locationManager:(CLLocationManager*)manager didUpdateToLocation:(CLLocation*)newLocation fromLocation:(CLLocation *)oldLocation
//{
//    NSLog(@"didUpdateToLocation: %@", newLocation);
//
// CLLocation* currentLocation = newLocation;
//
//
//    latitude = currentLocation.coordinate.latitude;
//    longitude = currentLocation.coordinate.longitude;
//
//
//
//    CLLocationCoordinate2D loct = [currentLocation coordinate];
//
//    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(loct, 600, 600);
//    [self.mapkit setRegion:region animated:YES];
//
//
//
//
//}






@end
