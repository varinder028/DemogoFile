//
//  openParticiapntsViewController.h
//  schedulePAgeDesign
//
//  Created by Rhythmus on 26/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface openParticiapntsViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextView *textViews;


- (IBAction)btnDone:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnDone;
- (IBAction)BtnBack:(id)sender;

@end
