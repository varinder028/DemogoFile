//
//  HomeVC.h
//  DemogoApplication
//
//  Created by katoch on 20/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"
#import <CoreLocation/CoreLocation.h>
#import "UIImageView+WebCache.h"
#import <AFNetworking/AFNetworking.h>

@interface HomeVC : UIViewController<UITableViewDelegate,UITableViewDataSource,UIGestureRecognizerDelegate,DropDownViewDelegate,UITextFieldDelegate,UIScrollViewDelegate,UIViewControllerTransitioningDelegate>{
       DropDownView *dropDownView ;
    
    CAGradientLayer *gradient ;
    
    NSString*  CompanyUserName;
    NSMutableArray *accountNameArray;
    NSString* companyName;
    UIImageView *todayImage ;
    
    UIImageView *upcomingImage ;
    NSURL *url;
     NSMutableDictionary *GetDicDta;
    NSDictionary *userEmailID;
     NSMutableString *EMAILDATA;
    NSMutableArray *companyNameArray;
    
    NSString *compId;
    
    NSMutableDictionary* PassedJSonArray;
    NSMutableArray * signUpInfoArray;
    
    NSString *companyId ;
    NSString *companyImage;
    NSString *companyToken;
    NSString *personId ;
       NSString *companyStr;
    AFHTTPSessionManager * manager ;
    
    
    id GetConfernceData ;
    
    NSMutableDictionary *objectDict;
    
    NSMutableArray *confernceDetailArray;
    NSDate *date ;
    NSDateComponents *components;
    NSMutableArray *todayMeetingArray ;
    NSMutableArray *UpcomingMeetingArray ;
    NSString *Todayduration ;
    NSString*upcomingDuration ;
    
    NSMutableArray *enddataArray ;
    NSMutableArray *endMeetingArray ;
    
    NSArray* TodayArray;
    
    id result ;
    
    UIAlertView *alertAdded;
    
    NSDictionary *mapData;
    
    NSTimeInterval timeInMiliseconds ;
    NSString *strTime ;
    
    NSMutableArray *dropDownListArray;
    NSMutableArray *listCompanies ;
    NSMutableArray *arrList ;
    
    NSMutableArray *CompanyDetailArray;
    
    id profileData;
    NSDate *startToday ;
    NSTimer* myTimer;
    NSMutableArray *calenderDates;
    NSMutableArray*onlyDates;
    NSString *dialInNumber;
    
    NSURLSession *sessionhOME;
    NSURLSessionDataTask *taskHome ;
    
    BOOL isSessionNil ;
    UILabel *tapEditLbl ;
    
    NSString*DeleteRowStr;
    id deleteData;
    
   
//    NSDate *endToday;
//    NSDate *startToday;
//    NSDate *CurrrentDate;
    
    UIAlertView*deleteAlert;
    
}


@property (strong, nonatomic) IBOutlet UITableView *dropTableView;

@property (strong, nonatomic) IBOutlet UIView *confViewDetail;

@property (strong, nonatomic) IBOutlet UIView *calnderView;

@property (strong, nonatomic) IBOutlet UIView *HeaderView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *heightImgToday;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *heigthImgUpcoming;

@property NSInteger myCellIndex; 

@property(nonatomic ,strong)NSString *RoleStr ;


@property (nonatomic, strong) CLLocationManager *locationManager;
@property (strong, nonatomic) UITextField *dropDownTxtfield;
@property (strong, nonatomic) IBOutlet UITextField *txtUserName;
@property (strong, nonatomic) IBOutlet UIImageView *userImg;
@property (strong, nonatomic) IBOutlet UIView *todaysMeetingView;
@property (strong, nonatomic) IBOutlet UITableView *todayTableView;
@property (strong, nonatomic) IBOutlet UITableView *upcomingTableView;
@property (strong, nonatomic) IBOutlet UIButton *btnTodayMeeting;
- (IBAction)todayMeetingClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnUpcomingMeeting;
- (IBAction)upcomingMeetingClicked:(id)sender;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *heightUpcomingLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *todayHeightLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *upcomingHeightLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *heightTodayLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *bottomLayoutToday;
@property (strong, nonatomic) IBOutlet UILabel *txtTodayDate;
@property (strong, nonatomic) IBOutlet UILabel *txtMonth;
@property (strong, nonatomic) IBOutlet UILabel *txtDay;
@property (strong, nonatomic) IBOutlet UIImageView *todayImg;
@property (strong, nonatomic) IBOutlet UIImageView *upcomingImg;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *imgHeigthLayout;
- (IBAction)closeBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *addAccountView;
@property (strong, nonatomic) IBOutlet UITextField *txtPassword;
@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtCompanyName;
- (IBAction)forgetPassword:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *lblPassword;
@property (strong, nonatomic) IBOutlet UILabel *lblUserName;
@property (strong, nonatomic) IBOutlet UILabel *lblCompany;
@property (strong, nonatomic) IBOutlet UIButton *btnAdd;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtCompanyHeight;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *lblCompanyLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtCompanyTop;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *lblTop;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *addAccountSubViewHeight;

- (IBAction)addClicked:(id)sender;
- (IBAction)notificationClicked:(id)sender;
- (IBAction)calenderClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *txtSubject;
@property (strong, nonatomic) IBOutlet UILabel *txtTime;
@property (strong, nonatomic) IBOutlet UILabel *txtDate;
@property (strong, nonatomic) IBOutlet UIView *conferenceDetailView;
@property (strong, nonatomic) IBOutlet UIView *gradientConfView;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *confHeight; //260 //180

//208 //130
- (IBAction)joinNowClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *lblPin;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *subConfHeight;
@property (strong, nonatomic) IBOutlet UIButton *btnJoinNow;
- (IBAction)joinNow:(id)sender;

@end
