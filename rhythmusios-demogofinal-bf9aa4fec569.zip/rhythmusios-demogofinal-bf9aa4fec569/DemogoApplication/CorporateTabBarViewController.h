//
//  CorporateTabBarViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CorporateTabBarViewController : UITabBarController

@property (weak, nonatomic) IBOutlet NSString *PersonIDFetch;


@end
