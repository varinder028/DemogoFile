//
//  TabView.m
//  DemogoApplication
//
//  Created by katoch on 24/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "TabView.h"
#import "HomeVC.h"
#import "MenuVc.h"
#import "ControlPanelVc.h"
#import "DashBoardVc.h"
#import "EmployeeManagementVc.h"
#import "AppDelegate.h"
#import "schduleVc.h"

@implementation TabView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


- (IBAction)todayClicked:(id)sender {
    
  //  [self insets];
    
    
    self.btnToday.backgroundColor = [UIColor colorWithRed:0/255.0f green:32/255.0f blue:41/255.0f alpha:1];
    
     self.btnSchedule.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
     self.btnDashboard.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
     self.btnControlPanel.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];

     self.btnMenu.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    
    
    NSMutableArray *contacts = [[NSMutableArray alloc]init];
    
    
    [[NSUserDefaults standardUserDefaults]setObject:contacts forKey:@"PD"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"checked"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"AO"];
    [[NSUserDefaults standardUserDefaults]synchronize];


    
    
    [self.btnToday setBackgroundColor: [UIColor colorWithRed:0/255.0f green:32/255.0f blue:40/255.0f alpha:1]];
    
    [self.btnSchedule setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
    
     [self.btnControlPanel setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
    
      [self.btnDashboard setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
    
      [self.btnMenu setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];

    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    HomeVC *home = [[HomeVC alloc]init];
    
   home = (HomeVC*)[mainStoryboard instantiateViewControllerWithIdentifier:@"HomeVC"];
    UINavigationController *navVc=(UINavigationController*) self.window.rootViewController;
    
    NSArray* tempVCA = [navVc viewControllers];
    
    for(UIViewController *tempVC in tempVCA)
    {
        if([tempVC isKindOfClass:[HomeVC class]])
        {
            [tempVC removeFromParentViewController];
        }
    }
    
    [navVc pushViewController: home animated:NO];
}

- (IBAction)scheduleMeetingClicked:(id)sender {
     [NSObject cancelPreviousPerformRequestsWithTarget:self];
    
    self.btnToday.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    
    self.btnSchedule.backgroundColor = [UIColor colorWithRed:0/255.0f green:32/255.0f blue:41/255.0f alpha:1];
    self.btnDashboard.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnControlPanel.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    
    
    self.btnMenu.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    
    
    
    
    
    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    schduleVc *targetViewController = (schduleVc*)[mainStoryboard instantiateViewControllerWithIdentifier:@"schduleVc"];
    UINavigationController *navVc=(UINavigationController *) self.window.rootViewController;
    
    NSArray* tempVCA = [navVc viewControllers];
    
    for(UIViewController *tempVC in tempVCA)
    {
        if([tempVC isKindOfClass:[schduleVc class]])
        {
            [tempVC removeFromParentViewController];
        }
    }
    [navVc pushViewController: targetViewController animated:NO];

    

    
}

- (IBAction)controlPanel:(id)sender {
    
    self.btnToday.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnSchedule.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnDashboard.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnControlPanel.backgroundColor = [UIColor colorWithRed:0/255.0f green:32/255.0f blue:40/255.0f alpha:1];
    self.btnMenu.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    
    NSMutableArray *contacts = [[NSMutableArray alloc]init];

    [[NSUserDefaults standardUserDefaults]setObject:contacts forKey:@"PD"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"checked"];
    [[NSUserDefaults standardUserDefaults]synchronize];

    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"AO"];
    [[NSUserDefaults standardUserDefaults]synchronize];


     [self.btnControlPanel setBackgroundColor: [UIColor colorWithRed:0/255.0f green:32/255.0f blue:41/255.0f alpha:1]];
    
    [self.btnToday setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
    
    [self.btnSchedule setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
    
  
    
    [self.btnDashboard setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
    
    [self.btnMenu setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    ControlPanelVc *targetViewController = [[ControlPanelVc alloc]init];
    
    targetViewController = (ControlPanelVc*)[mainStoryboard instantiateViewControllerWithIdentifier:@"ControlPanelVc"];
    UINavigationController *navVc=(UINavigationController *) self.window.rootViewController;
    
    
    NSArray* tempVCA = [navVc viewControllers];
    
    for(UIViewController *tempVC in tempVCA)
    {
        if([tempVC isKindOfClass:[ControlPanelVc class]])
        {
            [tempVC removeFromParentViewController];
        }
    }
    [navVc pushViewController: targetViewController animated:NO];
    
    

}
- (IBAction)dashBoardClciked:(id)sender {
    
    self.btnToday.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnSchedule.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnDashboard.backgroundColor = [UIColor colorWithRed:0/255.0f green:32/255.0f blue:41/255.0f alpha:1];
    self.btnControlPanel.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnMenu.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    
     [NSObject cancelPreviousPerformRequestsWithTarget:self];
    
    NSMutableArray *contacts = [[NSMutableArray alloc]init];
    [[NSUserDefaults standardUserDefaults]setObject:contacts forKey:@"PD"];
    [[NSUserDefaults standardUserDefaults]synchronize];

    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"checked"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"AO"];
    [[NSUserDefaults standardUserDefaults]synchronize];


        [self.btnDashboard setBackgroundColor: [UIColor colorWithRed:0/255.0f green:32/255.0f blue:40/255.0f alpha:1]];
    [self.btnToday setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
    
    [self.btnSchedule setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
    
    [self.btnControlPanel setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
   
    
    [self.btnMenu setBackgroundColor: [UIColor colorWithRed:0/255.0f green:92/255.0f blue:109/255.0f alpha:1]];
    
    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    DashBoardVc *targetViewController = (DashBoardVc*)[mainStoryboard instantiateViewControllerWithIdentifier:@"DashBoardVc"];
    UINavigationController *navVc=(UINavigationController *) self.window.rootViewController;
    
    NSArray* tempVCA = [navVc viewControllers];
    
    for(UIViewController *tempVC in tempVCA)
    {
        if([tempVC isKindOfClass:[DashBoardVc class]])
        {
            [tempVC removeFromParentViewController];
        }
    }
    [navVc pushViewController: targetViewController animated:NO];

    
}
- (IBAction)menuClicked:(id)sender {
    
    self.btnToday.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnSchedule.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnDashboard.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnControlPanel.backgroundColor = [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1];
    self.btnMenu.backgroundColor = [UIColor colorWithRed:0/255.0f green:32/255.0f blue:41/255.0f alpha:1];
    
     [NSObject cancelPreviousPerformRequestsWithTarget:self];
     NSMutableArray *contacts = [[NSMutableArray alloc]init];
    [[NSUserDefaults standardUserDefaults]setObject:contacts forKey:@"PD"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"checked"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"AO"];
    [[NSUserDefaults standardUserDefaults]synchronize];


    
    
    

    
    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    MenuVc *targetViewController = (MenuVc*)[mainStoryboard instantiateViewControllerWithIdentifier:@"MenuVc"];
    UINavigationController *navVc=(UINavigationController *) self.window.rootViewController;
    
    NSArray* tempVCA = [navVc viewControllers];
    
    for(UIViewController *tempVC in tempVCA)
    {
        if([tempVC isKindOfClass:[MenuVc class]])
        {
            [tempVC removeFromParentViewController];
        }
    }
    
    [navVc pushViewController: targetViewController animated:NO];

}


-(void)todayClicked{
    
    [self todayClicked:nil];
    
}

-(void)dashboardClicked{
    
    [self dashBoardClciked:nil];
    
}

-(void)menuClicked{
    
    [self menuClicked:nil];
    
}

-(void)controlPanel{
    
    
    [self controlPanel:nil];
    
}
-(void)scheduleMeetingClicked{
    
    
    [self scheduleMeetingClicked:nil];
    
}

-(void)insets{
    
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        
        [_btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -36, 0, 0)];
        [_btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -36, 0, 0)];
        [_btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [_btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [_btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 375) {
        
        [_btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
        [_btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -0, 0, 0)];
        [_btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -28, 0, 0)];
        [_btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -28, 0, 0)];
        [_btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 414) {
        
        [_btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -36, 0, 0)];
        [_btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -36, 0, 0)];
        [_btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -36, 0, 0)];
        [_btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -36, 0, 0)];
        [_btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -36, 0, 0)];
        
    }
}
@end
