//
//  ForgotPAsViewController.m
//  DemogoApplication
//
//  Created by Rhythmus on 07/03/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ForgotPAsViewController.h"
#import "ADMINProfilePICViewController.h"
#import "AppDelegate.h"
#import "KVNProgress.h"
#import "ViewController.h"
#import "LogSucessPasswordViewController.h"

@interface ForgotPAsViewController ()<NSURLSessionDelegate,NSURLSessionDataDelegate,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>

{
    
    
    
    NSString *urlstring;
    NSURL *url;
    NSMutableDictionary *GetDicDta;
    NSMutableArray *CompanydetailsArray;
    NSDictionary *items;
    
    
    NSString *mesage;
    NSString *cmp;
    UITextField *textD;
    NSDictionary *compId;
    UITableViewCell *cell;
    

    
}
- (IBAction)backButton:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *BAckOutlet;

@property (strong, nonatomic) IBOutlet UIView *firstView;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *COMPANYautolayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *PASSWORDautolayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *COMIMAGEautolayout;


@property (strong, nonatomic) IBOutlet UILabel *SelectComoanyLabel;


@property (strong, nonatomic) IBOutlet UITextField *forgotPasswordoutlet;

@property (strong, nonatomic) IBOutlet UIButton *compListOutlet;

@property (strong, nonatomic) IBOutlet UIButton *forgotoutlet;

- (IBAction)cmpListButton:(id)sender;

- (IBAction)forgotButton:(id)sender;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *FirstViewAutoLayout;

@end

@implementation ForgotPAsViewController








- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.forgotoutlet.layer .cornerRadius = 5.5f;
   NSAttributedString* str=[[NSAttributedString alloc]
         
                            initWithString:@"Select Company"
         
         attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.txtComanyName.attributedPlaceholder=str;

    
    
    
    [_forgotPasswordoutlet addTarget:self
                           action:@selector(textFieldDidChange:)
                 forControlEvents:UIControlEventEditingChanged];
    
    _imgHeightLayout.constant = 0 ;
    _heightForgetLayout.constant = 0 ;
    [self.view layoutIfNeeded];
    
    
    
    
    //self.navigationController.navigationBar.topItem.title = @"FORGOT PASSWORD";
    
    
    
    
    
    items = [[NSDictionary alloc]init];
    
//    self.compListOutlet.layer.cornerRadius = 10;
//    
//    cmp=[[NSString alloc]init];
//        self.tableview.hidden=YES;
//            self.tableview.delegate =self;
//                self.tableview.dataSource = self;
//                    CompanydetailsArray = [[NSMutableArray alloc]init];
//    
//    self.SelectComoanyLabel.hidden = YES;
//    self.blurview.layer.cornerRadius=10.5;
//    self.tableview.layer.cornerRadius = 10.5;
//    self.compListOutlet.hidden=YES;
//        self.companyImage.hidden = YES;
//            self.viewList.hidden =NO;
//                self .PASSWORDautolayout.constant =17;
//                    mesage = [[NSString alloc]init];
//                        mesage = @"success";
//    
//    
//    self.firstView.layer.cornerRadius = 10.5;
//        self.viewList.layer.cornerRadius = 10.5;
//            self.forgotoutlet.layer.cornerRadius = 10.5;
//                textD = [[UITextField alloc]init];
//    self.blurview.hidden = YES;
//    self.FirstViewAutoLayout.constant=262;
//    
    
    
    
    NSAttributedString *str1;
    
        str1=[[NSAttributedString alloc]initWithString:@"Enter email ID/Number"attributes:@{NSForegroundColorAttributeName :
                                                                                               
            [UIColor grayColor] }];
    
                    self.forgotPasswordoutlet.attributedPlaceholder=str1;
    

    
    
    
    
    // Do any additional setup after loading the view.
}


-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView removeFromSuperview];
    
}

-(void)SaveDataSecondApi
{
    
    urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/getemaildetails?email=%@",self.forgotPasswordoutlet.text];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    url = [NSURL URLWithString:urlstring];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    
    
    
    GetDicDta = [[NSMutableDictionary alloc]initWithObjectsAndKeys:
                 self.forgotPasswordoutlet.text,@"username",
                 
                 nil];
    
    
   
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              
                                              dispatch_async(dispatch_get_main_queue(),^
                                                             {
                                                                 
                                                                 
                                                                 NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                                                 NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                                                 NSError* error;
                itemsDR = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                                                 
                CompanydetailsArray = [itemsDR objectForKey:@"cmpList"];
                                                                 
                                                                 
                   strMessage   = itemsDR [@"message"];
                                                                 
                                                                 
                [self performSelectorOnMainThread:@selector(ShowCompanyField) withObject:nil waitUntilDone:YES];
                                                                 
                                                                 
                                                                 
                                                                 
                        });
                                              
                                          }];
   
    
    [postDataTask resume];
    
    
    
    
    
    
    
}


-(void)ShowCompanyField{
    
    
 
    
        if ([strMessage isEqualToString:@"success"]){
            
                _imgHeightLayout.constant = 26 ;
                _heightForgetLayout.constant = 30 ;
                [self.view layoutIfNeeded];
            
            CGRect frme = self.view.frame ;
            frme.origin.y = 0;
            self.view.frame = frme ;

            
            [self.forgotPasswordoutlet resignFirstResponder];
            

        }else{
            _imgHeightLayout.constant = 0 ;
            _heightForgetLayout.constant = 0 ;
            [self.view layoutIfNeeded];
            
            self.txtComanyName.text = @"" ;
            
            
        }
    
        

    
}



- (BOOL)textFieldShouldReturn:(UITextField *)textField


{
   
    if ([UIScreen mainScreen].bounds.size.height == 480) {
        CGRect frme = self.view.frame ;
        frme.origin.y = 0;
        self.view.frame = frme ;
        
        
        
    }
    
    [self.forgotPasswordoutlet resignFirstResponder];
    
    
    
    return YES;
    
    
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)usernameApiSnd;
{
    
    NSString  *ur  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/resetpassword?username=%@&cmpId=%@",self.forgotPasswordoutlet.text,compId];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL * uRL = [NSURL URLWithString:ur];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:uRL cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    //    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    //
    //
    //    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    
    
    [SendingRequest setHTTPMethod:@"POST"];
    
    
    
    
    NSDictionary * GetDic = [[NSMutableDictionary alloc]initWithObjectsAndKeys:
                             self.forgotPasswordoutlet.text,@"username",
                             compId,@"cmpId",
                             nil];
    
    
    // SendData= [NSJSONSerialization dataWithJSONObject:GetDicDta options:kNilOptions error:&linkError];
    
    
    NSError *error;
    NSData *postData = [NSJSONSerialization dataWithJSONObject:GetDic options:0 error:&error];
    
    [SendingRequest setHTTPBody:postData];
    
    
    
    // [SendingRequest setHTTPBody:SendData];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              
                                              dispatch_async(dispatch_get_main_queue(),^
                                                             {
                                                                
                                                                 [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
                                                                 
                                                                 //getResponse =[NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                                                                 NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                                                 NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                                                 NSError* error;
                                                                 items = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                                                 
                                                                 NSLog(@"%@",items);
                                                                 
                               
                                                                 [self performSelectorOnMainThread:@selector(alertSuccess) withObject:nil waitUntilDone:YES];
                                                                 
                                                                 
                                                                 
                                                             });
                                              
                                          }];
    
    [postDataTask resume];
    
    
    
    
    
    
    
}

-(void)alertSuccess{
    
    if ([[items valueForKey:@"message"] isEqualToString:@"success"]) {
        alert = [[UIAlertView alloc]initWithTitle:nil message:@"Password has been sent to mobile number and email id" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];

        
    }else
    {
    
 alert = [[UIAlertView alloc]initWithTitle:nil message:items[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
    
    [alert show];
    
    }
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    
    if (alertView ==  alert) {
        
        
        if (buttonIndex == 0) {
            
//            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
//            [delegate.tabView removeFromSuperview];
//            NSLog(@"success");
//            
//            
//            LogSucessPasswordViewController *logVc = [[LogSucessPasswordViewController alloc]init];
//            logVc = [self.storyboard instantiateViewControllerWithIdentifier:@"LSP"];
//            [self.navigationController pushViewController:logVc animated:YES];
            [self.navigationController popToRootViewControllerAnimated:YES];
            
        }
        
        
    }
}

- (IBAction)cmpListButton:(id)sender {
    if (self.tableview.hidden==YES)
    {
        
        
        self.tableview.hidden=NO;
        self.blurview.hidden = NO;
        self.SelectComoanyLabel.hidden = NO;
        
        
    }else
    {
        
        
        self.tableview.hidden=YES;
        
        self.blurview.hidden = YES;
        
         self.SelectComoanyLabel.hidden = YES;
    }

}

- (IBAction)forgotButton:(id)sender {
    
   // [self usernameApiSnd];
    
    
    
    
        if ([self.forgotPasswordoutlet.text isEqualToString:@""]) {
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:
                                              @"Forgot Password" message:
                                              @"please fill correct Email ID "preferredStyle:
                                              UIAlertControllerStyleAlert];
        UIAlertAction* ok = [UIAlertAction
                             actionWithTitle:@"Try Again"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                             }];
        [alertController addAction:ok];
        [self presentViewController:alertController animated:YES completion:nil];

        
        
        
        
        }else if ([self.txtComanyName.text isEqualToString:@""]){
            
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Enter Your Correct Name" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            
            [alert show];
            
        }
    
        else
    {
        
        [KVNProgress show];
        
        [self usernameApiSnd];
    }
        
    
    
}

-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}
- (IBAction)backButton:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    
    
    if (textField == _forgotPasswordoutlet) {
        if ([UIScreen mainScreen].bounds.size.height == 480) {
            CGRect frme = self.view.frame ;
            frme.origin.y = -100;
            self.view.frame = frme ;
            
            
            
        }

        
    }
    
    
    
    else if (textField == _txtComanyName) {
        
        if ([UIScreen mainScreen].bounds.size.height == 480) {
            CGRect frme = self.view.frame ;
            frme.origin.y = 0;
            self.view.frame = frme ;
            
            
            
        }

        
        [self.forgotPasswordoutlet resignFirstResponder];
       
        
        [self performSelectorOnMainThread:@selector(companyDatatable) withObject:nil waitUntilDone:YES];
        
        return false ;
        
    }
    
    return YES ;
    
}


-(void)textFieldDidChange:(UITextField*)textfield{
    
     [self SaveDataSecondApi];
    
    
}

-(void)companyDatatable{
    
    
    dropDownView = [[DropDownView alloc] initWithArrayData:[CompanydetailsArray valueForKey:@"cmpNm"]  cellHeight:40 heightTableView:120 paddingTop:self.firstView.frame.origin.y  paddingLeft:_firstView.frame.origin.x paddingRight:0 refView:_txtComanyName animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    
    
    
    NSLog(@" SSS  SSSS  S S S S S  USUU U     UUUU  U U U  U");
    
    
    
}



-(void)dropDownCellSelected:(NSInteger)returnIndex{
    
    
    
    
    self.txtComanyName.text = [[CompanydetailsArray valueForKey:@"cmpNm"] objectAtIndex:returnIndex];
    
    compId = [[CompanydetailsArray valueForKey:@"cmpId"] objectAtIndex:returnIndex];
              
    
    [[NSUserDefaults standardUserDefaults]setValue:compId forKey:@"ComId"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    
    [dropDownView closeAnimation];
    
    
}


//    if (userEmailID.count >0) {
//        
//        
//        if ([EMAILDATA  isEqualToString:@"success"]) {
//            
//            [self SaveDataSecondApi];
//            
//        }else{
//            
//            _txtComanyName.text = @"" ;
//            
//            
//            

        
        
        
  //  }
    
//}


- (IBAction)backClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}
@end
