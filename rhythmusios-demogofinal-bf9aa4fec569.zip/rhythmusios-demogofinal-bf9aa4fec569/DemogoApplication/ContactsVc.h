//
//  ContactsVc.h
//  DemogoApplication
//
//  Created by katoch on 11/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactsVc : UIViewController<UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate>{
    
    NSMutableArray *arrayTableData;
    NSMutableArray *contactNumbersArray;
    
    NSString *phone;
    NSMutableDictionary *dict;
    NSMutableArray *nameList ;
    NSMutableArray *arrayContacts;
      
}
@property(nonatomic,strong)NSMutableArray *checkArray ;
@property (nonatomic, retain) NSIndexPath* checkedIndexPath;

@property (strong, nonatomic) IBOutlet UITableView *contactsTableView;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
- (IBAction)bckClicked:(id)sender;
- (IBAction)doneClicked:(id)sender;

@end
