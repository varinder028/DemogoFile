//
//  NotifcationTableViewCell.h
//  excelSheetUpload
//
//  Created by Rhythmus on 16/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotifcationTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *inviteLabel;
@property (strong, nonatomic) IBOutlet UILabel *Labeltimedatails;


   // Preview Notify label
@property (strong, nonatomic) IBOutlet UILabel *PreviewInvite;

@property (strong, nonatomic) IBOutlet UILabel *PreviewTime;

////  Today Notify Label

@property (strong, nonatomic) IBOutlet UILabel *Todayinvite;

@property (strong, nonatomic) IBOutlet UILabel *TodayTime;

////  VerifyAccount List

@property (strong, nonatomic) IBOutlet UILabel *Verifyinvite;

@property (strong, nonatomic) IBOutlet UILabel *VerifyTime;


@end
