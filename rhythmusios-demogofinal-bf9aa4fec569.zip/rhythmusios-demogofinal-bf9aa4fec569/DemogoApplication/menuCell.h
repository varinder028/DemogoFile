//
//  menuCell.h
//  DemogoApplication
//
//  Created by katoch on 22/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface menuCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imgmenu;
@property (strong, nonatomic) IBOutlet UILabel *txtlbl;
@property (strong, nonatomic) IBOutlet UIImageView *arrowImg;

@end
