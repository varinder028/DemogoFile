//
//  MyPlanViewController.h
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyPlanViewController : UIViewController{
    
    NSString*CompanyId;
    NSString*personId;
    NSString*Tokenid;
    id myPlans ;

}
- (IBAction)BAckButton:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *LabelPlanNameHeader;

@property (strong, nonatomic) IBOutlet UILabel *LabelMRV;

@property (strong, nonatomic) IBOutlet UILabel *LAbelFcvRate;

@property (strong, nonatomic) IBOutlet UILabel *LabelPortRate;

@property (strong, nonatomic) IBOutlet UILabel *LAbelINDRate;

@property (strong, nonatomic) IBOutlet UILabel *AsPerCountrySpecificChargeLAbel;

@property (strong, nonatomic) IBOutlet UIView *ViewDetailsData;

@end
