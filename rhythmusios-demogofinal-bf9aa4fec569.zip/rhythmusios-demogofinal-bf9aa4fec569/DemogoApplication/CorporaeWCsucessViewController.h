//
//  CorporaeWCsucessViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CorporaeWCsucessViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *usernamefillTextfield;
@property (strong, nonatomic) IBOutlet UILabel *userEmailFillTextField;
- (IBAction)loginButton:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *loginoutlet;
@property (strong, nonatomic) NSString *NameString;

@property (strong, nonatomic) NSString *EmailIDString;
@end
