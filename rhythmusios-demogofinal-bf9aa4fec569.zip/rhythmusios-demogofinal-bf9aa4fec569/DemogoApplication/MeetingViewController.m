//
//  graphicsViewController.m
//  excelSheetUpload
//
//  Created by Rhythmus on 23/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "MeetingViewController.h"
#import "PNChartDelegate.h"
#import "PNChart.h"
#import <AFNetworking/AFNetworking.h>
#import "KVNProgress.h"


@interface MeetingViewController ()<UITextFieldDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate>
{
    NSMutableArray * companyArray;
    NSString *Tokenstr;
    NSMutableArray *DepartArray;
    NSMutableArray *HostNameArray;

    NSMutableArray *hostIDArray;
    NSString *Dpt ;
    NSMutableDictionary *dstr;
    
    NSString*TYPE;
    NSString*HOstId;
    NSString *strENdTime ;
    
    NSString*DepNames;
    NSString *HostDurationTime;
    
    NSString *statusSmS;
}
@end

@implementation MeetingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if ([UIScreen mainScreen].bounds.size.height== 480 ) {
        
        self.heightGraph.constant = 200 ;
        self.widthGraph.constant = 200 ;
        
    }else{
        self.heightGraph.constant = 300 ;
        self.widthGraph.constant = 300 ;

        
        
    }
    
    [self.view layoutIfNeeded];
    
    
    UITapGestureRecognizer *gesRecognizer4 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchScreen)]; // Declare the Gesture.
    gesRecognizer4.delegate = self;
    [self.view addGestureRecognizer:gesRecognizer4];
    
    
   
    statusSmS = @"No Conference Available";
    
    TYPE=@"default";
   [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"IncWidth"];

    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"Plan"];
    
    UIImageView *imgforLeft=[[UIImageView alloc] initWithFrame:CGRectMake(10, 0, 25, 25)]; // Set
    [imgforLeft setImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    [imgforLeft setContentMode:UIViewContentModeCenter];// Set content mode centre or fit
    _txtSelectOption.rightView=imgforLeft;
    _txtSelectOption.rightViewMode=UITextFieldViewModeAlways;

    
    UIImageView *imgfo=[[UIImageView alloc] initWithFrame:CGRectMake(10, 0, 25, 25)]; // Set
    [imgfo setImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    [imgfo setContentMode:UIViewContentModeCenter];// Set content mode centre or fit
    _txtSelectDepartment.rightView=imgfo;
    _txtSelectDepartment.rightViewMode=UITextFieldViewModeAlways;
    

//    _txtSelectOption.rightViewMode = UITextFieldViewModeAlways;
//      _txtSelectOption.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    
//    _txtSelectDepartment.rightViewMode = UITextFieldViewModeAlways;
//    _txtSelectDepartment.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
//    
    
    
    [self.view bringSubviewToFront:_txtSelectOption.rightView];
    [self.view bringSubviewToFront:_txtSelectDepartment.rightView];

    
    
    
    Tokenstr = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    PersonID = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];

    
    DepNames = @"";
    
     DepartArray = [[NSMutableArray alloc]init];
    HostNameArray = [[NSMutableArray alloc]init];
    hostIDArray = [[NSMutableArray alloc]init];

    
    dropDownListArray = [NSMutableArray new];
    self.txtSelectDepartment.hidden=YES;
    
   // Tokenstr = @"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MDExMDU2MTg3OlJPTEVfU1VQRVJfQURNSU46MTc3MCIsImlhdCI6MTQ5NDgzNDE4OH0.YrwI-7Ma2bqZE58yTRjB79rgXn0g8jzyi58aK_C3DXg";
    
    companyArray  = [[NSMutableArray alloc]init];
    companyArray = [NSMutableArray arrayWithObjects:@"self",@"company",@"department",@"host", nil];
    
   
    self.txtSelectOption.layer.cornerRadius=5.5f;
    self.txtSelectDepartment.layer.cornerRadius=5.5f;
    
 
    
    [self MeetingGraphSelfApi];
    
    
    
    // Do any additional setup after loading the view.
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (textField == self.txtSelectOption)
    {
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        self.dropDownTxtfield = textField ;

        [self companyDatatable];
        
    }
    
    else if(textField == self.txtSelectDepartment)
        
    {
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        if ([self.txtSelectOption.text isEqualToString:@"department"])
            
        {
        self.dropDownTxtfield = textField ;

        
       [self DepartDropDOWN];
            
        }else
            
        {
            self.dropDownTxtfield = textField ;
            [self HostDropDOWN];
        }
    }
   
    
    
//
    return NO ;
    
}

-(void)touchScreen{
    
    [dropDownView closeAnimation];
 
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)HostDropDOWN
{
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:HostNameArray cellHeight:40 heightTableView:120 paddingTop:self.view.frame.origin.y  paddingLeft:self.view.frame.origin.x paddingRight:0 refView:_txtSelectDepartment animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    

}

-(void)DepartDropDOWN
{
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:DepartArray cellHeight:40 heightTableView:120 paddingTop:self.view.frame.origin.y  paddingLeft:self.view.frame.origin.x paddingRight:0 refView:_txtSelectDepartment animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    
    
}

-(void)companyDatatable{
    
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:companyArray cellHeight:40 heightTableView:120 paddingTop:self.view.frame.origin.y  paddingLeft:self.view.frame.origin.x paddingRight:0 refView:_txtSelectOption animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    
   
    
    
    
}



-(void)dropDownCellSelected:(NSInteger)returnIndex{
    
    
    
    if (_dropDownTxtfield == self.txtSelectOption)
    
    {
        [self.pieChart removeFromSuperview];
        
        
        NSLog(@"error");
        self.txtSelectOption.text = [companyArray objectAtIndex:returnIndex];
        
        if (returnIndex==0) {
            
            
            self.txtSelectDepartment.hidden=YES;
            
            DepNames = @"";
            PersonID = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
          
            
            
            TYPE=@"default";
            
           // self.graphView.hidden = YES;

            [self MeetingGraphSelfApi];
            
        }else if (returnIndex==1) {
            
            self.txtSelectDepartment.hidden=YES;
            
            TYPE=@"company";
            
            DepNames = @"";
            PersonID = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];

            

            [self MeetingGraphSelfApi];
            
            
        }else if(returnIndex==2) {
            
            [self.txtSelectDepartment setHidden:NO];
            
            [self DepartmentGraphSelfApi];
            
        
            
            
        }else if(returnIndex==3) {
            
            self.txtSelectDepartment.hidden=NO;

            TYPE=@"host";

             DepNames = @"";
            
            [self HostGraphSelfApi];
            
        }else
        {
            NSLog(@"error");
        }
        
       [dropDownView closeAnimation];

        
    }else
    {
        if ([self.txtSelectOption.text isEqualToString:@"department"])
        
        {
            
            NSLog(@"error");
           NSString*str  =[NSString stringWithFormat:@"%@",[DepartArray objectAtIndex:returnIndex ]];
            
            
            if (str == nil || [str isKindOfClass:(id)[NSNull null]]) {
                self.txtSelectDepartment.text = @"" ;
                
            }else{
                self.txtSelectDepartment.text =str;
                
            }
           
            DepNames = self.dropDownTxtfield.text;
            TYPE = @"department";
            
            PersonID = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];

            
            
            [self selectDepartmentGraph];
            
            if (returnIndex == 0)
            
                {
                
                    [dropDownView openAnimation];
                
                }
            

            
            
        } else if ([self.txtSelectOption.text isEqualToString:@"host"])
        {
            
        

        NSLog(@"error");
        
        
            
            // [HostNameArray addObjectsFromArray:[[RejectData valueForKey:@"hostlist"]valueForKey:@"hostName"]];
            
            self.txtSelectDepartment.text =[NSString stringWithFormat:@"%@",[HostNameArray objectAtIndex:returnIndex]] ;
            
            HOstId = [NSString stringWithFormat:@"%@",[hostIDArray objectAtIndex:returnIndex]];
            
            //[hostIDArray addObjectsFromArray:[[RejectData valueForKey:@"hostlist"]valueForKey:@"hostId"]];
            
            NSLog(@" the host id is = %@",HOstId);
            
            DepNames = self.dropDownTxtfield.text;
            
        
            
            
            
            TYPE = @"host";

            
            [dropDownView openAnimation];
             [self selectDepartmentGraph];
        }

        

        [dropDownView closeAnimation];
//
        
    }
        
    
    
    
    
   }

-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}

-(void)selectDepartmentGraph
{
    //    http://182.76.44.135:8080/demogomobile/dashboard/secure/meetingdetails
    
    
//    NSString*CmpIDd = @"1770";
//    
//   // NSString*HOstId=@"3773" ;
//    NSString*PersonID =@"3773";
    
    
   
    
    //6678
    NSMutableDictionary *dataSend = [[NSMutableDictionary alloc]init];
    
    
    if ([self.txtSelectOption.text isEqualToString:@"department"]) {
        
       dataSend = [[NSMutableDictionary alloc]initWithObjectsAndKeys:companyId,@"cmpId",DepNames,@"depName",PersonID,@"hostId",PersonID,@"personId",TYPE,@"type",nil];

    }else{
         dataSend = [[NSMutableDictionary alloc]initWithObjectsAndKeys:companyId,@"cmpId",DepNames,@"depName",HOstId,@"hostId",PersonID,@"personId",TYPE,@"type",nil];
        
    }
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/dashboard/secure/meetingdetails"];
    
    AFHTTPSessionManager * managerr = [AFHTTPSessionManager manager];
    managerr.requestSerializer = [AFJSONRequestSerializer serializer];
    [managerr.requestSerializer setValue:Tokenstr forHTTPHeaderField:@"token"];
        NSLog(@" %@",dataSend);

    
    [managerr POST:apiURLStr parameters:dataSend success:^(NSURLSessionTask *task, id responseObject) {
         [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"PLIST: %@", responseObject);
        cities = responseObject ;
        [self performSelectorOnMainThread:@selector(GetGraphData) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
}



-(void)GetGraphData{
    
    NSString * msgSucess = [cities valueForKey:@"message"];
    
    
    
    if ([msgSucess isEqualToString:@"success"])
        
    {
        self.graphView.hidden=NO;
        
        HostDurationTime = [[cities valueForKey:@"mtngdetail"]valueForKey:@"duration"];
        double duplicayTime = 10000;
        
        double secondget = [HostDurationTime doubleValue];
        
        
        double dtat= secondget/duplicayTime;
        
        NSString *strdet=[NSString stringWithFormat:@"%.02f",dtat];
        
        //
        
        [_progressBar.layer setCornerRadius:4];
        _progressBar.layer.masksToBounds = TRUE;
        _progressBar.clipsToBounds = TRUE;
        
        double endtime =[ strdet doubleValue];
        
        self.progressBar.progress=endtime;
        
        ActivePerson = [[cities valueForKey:@"mtngdetail"]valueForKey:@"active"];
        
        InactivePerson = [[cities valueForKey:@"mtngdetail"]valueForKey:@"inactive"];
        
        NotJoinPerson = [[cities valueForKey:@"mtngdetail"]valueForKey:@"notjoin"];
        
        InviteLabel = [[cities valueForKey:@"mtngdetail"]valueForKey:@"totalinvitee"];
        
        NSString*stringmsg = [[cities valueForKey:@"mtngdetail"]valueForKey:@"status"];
        
        NSString *invitesms = [NSString stringWithFormat:@"Invite %@",InviteLabel];
        
        NSString *statusmsg = [NSString stringWithFormat:@"%@ Conference" ,stringmsg];
        
        self.LabelInviteSMs.text = invitesms;
        
        self.labelConferenceStatus.text =statusmsg;
        
        [self pieChartView];
        
        
        
    }
    else
    {
        
        self.graphView.hidden = YES;
        
        
        UIAlertView *alertview = [[UIAlertView alloc]initWithTitle:nil message:msgSucess delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        [alertview show];
        
        
    }

}



-(void)MeetingGraphSelfApi
{
//    http://182.76.44.135:8080/demogomobile/dashboard/secure/meetingdetails
    
    
//    NSString*CmpIDd = @"1770";
   
    
  //  NSString*PersonID =@"3773";
    
    //6678
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/dashboard/secure/meetingdetails"];
    
    AFHTTPSessionManager * managerr = [AFHTTPSessionManager manager];
    managerr.requestSerializer = [AFJSONRequestSerializer serializer];
    [managerr.requestSerializer setValue:Tokenstr forHTTPHeaderField:@"token"];
    NSMutableDictionary *dataSend = [[NSMutableDictionary alloc]initWithObjectsAndKeys:companyId,@"cmpId",PersonID,@"hostId",PersonID,@"personId",TYPE,@"type",DepNames,@"depName",nil];
    
    
    [managerr POST:apiURLStr parameters:dataSend success:^(NSURLSessionTask *task, id responseObject) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"PLIST: %@", responseObject);
        dicData = responseObject ;
        [self performSelectorOnMainThread:@selector(getData) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    
}

-(void)MeetingGraphData{
    
    
}

-(void)getData{
    
    NSString * msgSucess = [dicData valueForKey:@"message"];
    if ([msgSucess isEqualToString:@"success"])
        
    {
        
        _graphView.hidden= NO;
        
        StartTimeString = [[dicData valueForKey:@"mtngdetail"]valueForKey:@"strttime"];
        
        DurationString = [[dicData valueForKey:@"mtngdetail"]valueForKey:@"duration"];
        
        
        
        double duplicayTime = 1000;
        
        double secondget = [DurationString doubleValue];
        
        
        double dtat= secondget/duplicayTime;
        
        NSString *strdet=[NSString stringWithFormat:@"%.02f",dtat];
        
        [_progressBar.layer setCornerRadius:4];
        
        _progressBar.layer.masksToBounds = TRUE;
        
        _progressBar.clipsToBounds = TRUE;
        
        _progressBar.progressViewStyle = UIProgressViewStyleDefault;
        
        double endtime =[ strdet doubleValue];
        
        self.progressBar.progress=endtime;
        
        
        ActivePerson = [[dicData valueForKey:@"mtngdetail"]valueForKey:@"active"];
        
        InactivePerson = [[dicData valueForKey:@"mtngdetail"]valueForKey:@"inactive"];
        
        NotJoinPerson = [[dicData valueForKey:@"mtngdetail"]valueForKey:@"notjoin"];
        
        InviteLabel = [[dicData valueForKey:@"mtngdetail"]valueForKey:@"totalinvitee"];
        
        NSString *stutssms = [[dicData valueForKey:@"mtngdetail"]valueForKey:@"status"];
        
        NSString *invitesms = [NSString stringWithFormat:@"Invite %@",InviteLabel];
        
        NSString *statusS = [NSString stringWithFormat:@"%@ Conference" ,stutssms];
        
        self.LabelInviteSMs.text = invitesms;
        
        self.labelConferenceStatus.text =statusS;
        
        [self pieChartView];
        
        
        
    }else
    {
        
        
        self.graphView.hidden = YES;
        
        
        alertviewMeetings = [[UIAlertView alloc]initWithTitle:nil message: [dicData valueForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        [alertviewMeetings show];
        
        
    }

}

-(void)DepartmentGraphSelfApi
{
  //  NSString*CmpIDd = @"1770";
    NSError *linkError;
    
    //6678
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/secure/department?cmpId=%@",companyId];
    
    AFHTTPSessionManager * managerr = [AFHTTPSessionManager manager];
    managerr.requestSerializer = [AFJSONRequestSerializer serializer];
    [managerr.requestSerializer setValue:Tokenstr forHTTPHeaderField:@"token"];
    
    [managerr GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"PLIST: %@", responseObject);
        RejectData = [[NSMutableArray alloc]init];
        
        
        RejectData = responseObject ;
        [self performSelectorOnMainThread:@selector(DepartmentDropDown) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
                                                     
}



-(void)DepartmentDropDown
{
    self.txtSelectDepartment.hidden=NO;
    self.graphView.hidden = YES;
    
    DepartArray = [[NSMutableArray alloc]init];
    
    if (RejectData.count>0) {
        [DepartArray addObjectsFromArray:[RejectData valueForKey:@"department"]];
        
        [DepartArray insertObject:@"Select Department" atIndex:0];
        
        self.labelConferenceStatus.text= @"";
        
        self.txtSelectDepartment.text = [NSString stringWithFormat:@"%@",DepartArray[0]];
        
        NSLog(@"%@",DepartArray);

    }
    else{
        
        [dropDownView closeAnimation];
        
    }
    
    

   
   // [self DepartDropDOWN];
}

-(void)HostGraphSelfApi
{
//    NSString*CmpIDd = @"1770";
    NSError *linkError;
    
    //6678
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/secure/host?cmpId=%@",companyId];
    
    
    AFHTTPSessionManager * managerr = [AFHTTPSessionManager manager];
    managerr.requestSerializer = [AFJSONRequestSerializer serializer];
    [managerr.requestSerializer setValue:Tokenstr forHTTPHeaderField:@"token"];
    
    [managerr GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"PLIST: %@", responseObject);
        
        RejectData = [[NSMutableArray alloc]init];
        
        RejectData = responseObject ;
        [self performSelectorOnMainThread:@selector(HostDropDown) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    

}



-(void)HostDropDown
{
    
    self.txtSelectDepartment.hidden=NO;
    self.graphView.hidden = YES;
    
    HostNameArray = [[NSMutableArray alloc]init];
    
    if (RejectData.count>0) {
        self.txtSelectDepartment.text = [NSString stringWithFormat:@"Select Host"];
        
        [HostNameArray addObjectsFromArray:[[RejectData valueForKey:@"hostlist"]valueForKey:@"hostName"]];
        [hostIDArray addObjectsFromArray:[[RejectData valueForKey:@"hostlist"]valueForKey:@"hostId"]];
        NSLog(@"%@",HostNameArray);
        

    }
    
   // [HostNameArray insertObject:@"Select Department" atIndex:0];
    
    
    
    
    // [self DepartDropDOWN];
}




-(void)pieChartView
{
  //  NSDate* confDtTm;
    
    NSString * notjoined = [NSString stringWithFormat:@"%@",[[dicData valueForKey:@"mtngdetail"]valueForKey:@"status"]];
    if ([notjoined isEqualToString:@"Running"]) {
        
        if ([NotJoinPerson isEqual:[NSNumber numberWithInteger:0]])
        {
            self.Boxnotjoind.hidden=YES;
            self.LabelnotJoined.hidden=YES;
            
        }
        else
        {
            
        self.Boxnotjoind.hidden=NO;
        self.LabelnotJoined.hidden=NO;
        
        }
        
    }
    else
    {
        
        self.Boxnotjoind.hidden=YES;
        self.LabelnotJoined.hidden=YES;
        
    }
    
    
    
    
    if ([self.txtSelectOption.text isEqualToString:@"department"] || [self.txtSelectOption.text isEqualToString:@"host"])
    {
        long secondget = [HostDurationTime doubleValue];
        
        int endtime = (int)secondget;
        int seconds = endtime % 60;
        int minutes = (endtime / 60) % 60;
        int hours = endtime / 3600;
        
        
        NSString * dateTIme= [NSString stringWithFormat:@"%02d:%02d:%02d",hours, minutes, seconds];
        
        self.Labelendtime.text = dateTIme;

    }
    
    else
    
        {
            
            long secondget = [DurationString doubleValue];
            int endtime = (int)secondget;
            int seconds = endtime % 60;
            int minutes = (endtime / 60) % 60;
            int hours = endtime / 3600;
    
    
            NSString * dateTIme= [NSString stringWithFormat:@"%02d:%02d:%02d",hours, minutes, seconds];
    
            self.Labelendtime.text = dateTIme;
  
        
        }
    
    double activeUser = [ActivePerson doubleValue];
    
    double InactiveUser = [InactivePerson doubleValue];
    
    double NotJoinUser = [NotJoinPerson doubleValue];
    
    if (NotJoinUser==0 )
    {
        if (InactiveUser==0)
        
        {
            NSMutableArray *items =[[NSMutableArray alloc]initWithObjects:[PNPieChartDataItem dataItemWithValue:activeUser color:[UIColor colorWithRed:0.11 green:0.75 blue:0.51 alpha:1.0]], nil];
            self.pieChart = [[PNPieChart alloc] initWithFrame:CGRectMake(10, 5, self.graphView.frame.size.width - 20, self.graphView.frame.size.height - 10) items:items];
            self.pieChart.descriptionTextColor = [UIColor whiteColor];
            // self.pieChart.descriptionTextFont = [UIFont fontWithName:@"Avenir-Medium" size:11.0];
            self.pieChart.descriptionTextShadowColor = [UIColor blueColor];
            self.pieChart.showAbsoluteValues = YES;
            self.pieChart.showOnlyValues = NO;
            [self.pieChart strokeChart];
            
            
            self.pieChart.legendStyle = PNLegendItemStyleStacked;
            self.pieChart.legendFont = [UIFont boldSystemFontOfSize:12.0f];
            [self.graphView addSubview:self.pieChart];

            
        }
        else
        {
        
        NSMutableArray *items =[[NSMutableArray alloc]initWithObjects:[PNPieChartDataItem dataItemWithValue:activeUser color:[UIColor colorWithRed:0.11 green:0.75 blue:0.51 alpha:1.0]],[PNPieChartDataItem dataItemWithValue:InactiveUser color:[UIColor colorWithRed:0.88 green:0.25 blue:0.25 alpha:1.0]], nil];
        self.pieChart = [[PNPieChart alloc] initWithFrame:CGRectMake(10, 5, self.graphView.frame.size.width - 20, self.graphView.frame.size.height - 10) items:items];
        self.pieChart.descriptionTextColor = [UIColor whiteColor];
        // self.pieChart.descriptionTextFont = [UIFont fontWithName:@"Avenir-Medium" size:11.0];
        self.pieChart.descriptionTextShadowColor = [UIColor blueColor];
        self.pieChart.showAbsoluteValues = YES;
        self.pieChart.showOnlyValues = NO;
        [self.pieChart strokeChart];
        
        
        self.pieChart.legendStyle = PNLegendItemStyleStacked;
        self.pieChart.legendFont = [UIFont boldSystemFontOfSize:12.0f];
        [self.graphView addSubview:self.pieChart];
            
            [_pieChart reloadInputViews];
            
            
        }
        
    }else if (InactiveUser==0 )
    {
    
        if (NotJoinUser ==0)
        
        {
            NSMutableArray *items =[[NSMutableArray alloc]initWithObjects:[PNPieChartDataItem dataItemWithValue:activeUser color:[UIColor colorWithRed:0.11 green:0.75 blue:0.51 alpha:1.0]] , nil];
            
            self.pieChart = [[PNPieChart alloc] initWithFrame:CGRectMake(10, 5, self.graphView.frame.size.width - 20, self.graphView.frame.size.height - 10) items:items];
            self.pieChart.descriptionTextColor = [UIColor whiteColor];
            // self.pieChart.descriptionTextFont = [UIFont fontWithName:@"Avenir-Medium" size:11.0];
            self.pieChart.descriptionTextShadowColor = [UIColor blueColor];
            self.pieChart.showAbsoluteValues = YES;
            self.pieChart.showOnlyValues = NO;
            [self.pieChart strokeChart];
            
            
            self.pieChart.legendStyle = PNLegendItemStyleStacked;
            self.pieChart.legendFont = [UIFont boldSystemFontOfSize:12.0f];
            [self.graphView addSubview:self.pieChart];
            

    
        }else{
         NSMutableArray *items =[[NSMutableArray alloc]initWithObjects:[PNPieChartDataItem dataItemWithValue:activeUser color:[UIColor colorWithRed:0.11 green:0.75 blue:0.51 alpha:1.0]],[PNPieChartDataItem dataItemWithValue:NotJoinUser color:[UIColor colorWithRed:1.00 green:0.89 blue:0.15 alpha:1.0]] , nil];
        
        self.pieChart = [[PNPieChart alloc] initWithFrame:CGRectMake(10, 5, self.graphView.frame.size.width - 20, self.graphView.frame.size.height - 10) items:items];
        self.pieChart.descriptionTextColor = [UIColor whiteColor];
        // self.pieChart.descriptionTextFont = [UIFont fontWithName:@"Avenir-Medium" size:11.0];
        self.pieChart.descriptionTextShadowColor = [UIColor blueColor];
        self.pieChart.showAbsoluteValues = YES;
        self.pieChart.showOnlyValues = NO;
        [self.pieChart strokeChart];
        
        
        self.pieChart.legendStyle = PNLegendItemStyleStacked;
        self.pieChart.legendFont = [UIFont boldSystemFontOfSize:12.0f];
        [self.graphView addSubview:self.pieChart];

        
        }
    }
    else
    {
        
    
    NSMutableArray *items =[[NSMutableArray alloc]initWithObjects:[PNPieChartDataItem dataItemWithValue:activeUser color:[UIColor colorWithRed:0.11 green:0.75 blue:0.51 alpha:1.0]],[PNPieChartDataItem dataItemWithValue:InactiveUser color:[UIColor colorWithRed:0.88 green:0.25 blue:0.25 alpha:1.0]],[PNPieChartDataItem dataItemWithValue:NotJoinUser color:[UIColor colorWithRed:1.00 green:0.89 blue:0.15 alpha:1.0]] , nil];
    
    //@[[PNPieChartDataItem dataItemWithValue:remvePerson color:PNLightGreen],
    
    
    //self.pieChart = [[PNPieChart alloc] initWithFrame:CGRectMake((CGFloat) (SCREEN_WIDTH / 3.7 - 100), 5, 300.0, 300.0) items:items];
    self.pieChart = [[PNPieChart alloc] initWithFrame:CGRectMake(10, 5, self.graphView.frame.size.width - 20, self.graphView.frame.size.height - 10) items:items];
    self.pieChart.descriptionTextColor = [UIColor whiteColor];
    // self.pieChart.descriptionTextFont = [UIFont fontWithName:@"Avenir-Medium" size:11.0];
    self.pieChart.descriptionTextShadowColor = [UIColor blueColor];
    self.pieChart.showAbsoluteValues = YES;
    self.pieChart.showOnlyValues = NO;
    [self.pieChart strokeChart];
    
    
    self.pieChart.legendStyle = PNLegendItemStyleStacked;
    self.pieChart.legendFont = [UIFont boldSystemFontOfSize:12.0f];
    
    //    UIView *legend = [self.pieChart getLegendWithMaxWidth:200];
    //    [legend setFrame:CGRectMake(130, 350, legend.frame.size.width, legend.frame.size.height)];
    //    [self.graphView addSubview:legend];
    
    [self.graphView addSubview:self.pieChart];
    
    }
}

- (IBAction)bckClickedMeetings:(id)sender {
    
   
    
}

- (IBAction)bckClicked:(id)sender {
     [self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isDescendantOfView:dropDownView.view]) {
        
        
        
        return NO;
    }
    
    
    
    return YES;
}


//- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
//    
//    
//    if (alertView == alertviewMeetings) {
//        
//        [self.navigationController popViewControllerAnimated:YES];
//        
//        
//    }
//    
//}
@end
