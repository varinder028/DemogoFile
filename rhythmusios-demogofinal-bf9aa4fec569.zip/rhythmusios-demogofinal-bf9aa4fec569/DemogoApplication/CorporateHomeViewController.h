//
//  CorporateHomeViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CorporateHomeViewController : UIViewController






////////     Today Meeting Tableview Or Date ............

@property (strong, nonatomic) IBOutlet UITableView *TableViewEditing;

@property (strong, nonatomic) IBOutlet UILabel *DateLabel;
@property (strong, nonatomic) IBOutlet UILabel *MonthNameLabel;
@property (strong, nonatomic) IBOutlet UILabel *DayLabel;
@property (strong, nonatomic) IBOutlet UIImageView *adminImage;

@property (strong, nonatomic) IBOutlet UIView *AdminTAbleOrView;


///////........      ADMIN ADDAccount TableROw Select
@property (strong, nonatomic) IBOutlet UIView *ADDACOuntVIew;

- (IBAction)ADACCountCancelButton:(UIButton *)sender;

@property (strong, nonatomic) IBOutlet UIButton *ADACCOUNTCancelOutletBtn;

                    // ADDMin Account TextField


@property (strong, nonatomic) IBOutlet UITextField *EmailMobileNoTextField;


@property (strong, nonatomic) IBOutlet UITextField *ADMinADACCOUNtPasswordTextField;



                    /// ADMIN ACCOUNT BUTTON OR BUTTON OUTLET
@property (strong, nonatomic) IBOutlet UIButton *ADDACCOuntSignInButton;

@property (strong, nonatomic) IBOutlet UILabel *topLabelAddaccount;


- (IBAction)SiginInButton:(id)sender;


- (IBAction)ADDACcountFOrgetPassButton:(UIButton *)sender;


                    //    
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *SELECTComAutolayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *PassAUtolayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *VIewAutoLayout;


////////.............     ADMIN TAbleView ........

@property (strong, nonatomic) IBOutlet UITableView *AdminTAbleView;

- (IBAction)TodayDropDownButton:(UIButton *)sender;

- (IBAction)NotificationButton:(UIButton *)sender;

- (IBAction)AdminBUtton:(UIButton *)sender;


- (IBAction)ICONButton:(UIButton *)sender;

@property (strong, nonatomic) IBOutlet UIButton *IConButtonOutlet;

- (IBAction)ADDACOOUNTButton:(id)sender;
@property (strong, nonatomic) IBOutlet UIImageView *ADDACOUNTimg;


/////       Autolayout  .......

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *FIrstTableViewAutoLayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *UpCmAutoLayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *UPCmTableviewAutolayout;

- (IBAction)UpcomingButton:(UIButton *)sender;

@property (strong, nonatomic) IBOutlet UIVisualEffectView *BlurView;



////            Upcomming Button  .......


@property (strong, nonatomic) IBOutlet UITableView *upcomingmeetingTableview;



@end
