//
//  customDataCell.m
//  DemogoApplication
//
//  Created by katoch on 09/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "customDataCell.h"

@implementation customDataCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (IBAction)closeBlk:(id)sender {
}
@end
