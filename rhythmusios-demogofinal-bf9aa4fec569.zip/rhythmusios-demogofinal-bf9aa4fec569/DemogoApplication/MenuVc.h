//
//  MenuVc.h
//  DemogoApplication
//
//  Created by katoch on 22/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"
#import "TabView.h"
#import <CoreLocation/CoreLocation.h>


@interface MenuVc : UIViewController<UITableViewDelegate,UITableViewDataSource,DropDownViewDelegate,UITextFieldDelegate,CLLocationManagerDelegate,NSURLSessionDelegate,UIAlertViewDelegate,UIGestureRecognizerDelegate>{
    
    NSString*strRole;
    NSString* companyName;
    NSString*  CompanyUserName;
    NSMutableString *versionNo;
    NSMutableString *OperatingNa;
    NSString *latitude;
    NSString *longitude;
    NSString *newDateString;
    
    NSMutableArray *tableArray ;
    NSMutableArray* listArray ;
    NSMutableArray *arrayIcons;
    
    id profileData ;
    DropDownView *dropDownView ;
    NSString *compId ;
    
    NSDictionary *userEmailID;
    NSMutableString *EMAILDATA;
    NSMutableArray *companyNameArray;
     NSURL *url;
    
     NSMutableDictionary *GetDicDta;
    
    id PassedJSonArray ;
    
      NSString* Base64encodePassword;
    
    id myProfileData;
    NSDictionary *mapData;
    NSTimeInterval timeInMiliseconds ;
    
    NSMutableArray *signUpInfoArray ;
    
    
    NSString *companyId ;
    NSString *companyImage;
    NSString *companyToken;
    NSString *personId ;
    
    
    NSString *companyStr;
    NSMutableDictionary *  result;
    UIAlertView *alertAdded;
    
    NSString *strTime ;
    NSMutableArray*dropDownListArray ;
    UIAlertView*signOutAlert;
    
    
}
@property (strong, nonatomic) IBOutlet UIButton *btnLogin;
@property (strong, nonatomic) IBOutlet UIButton *btnForgetPass;

@property (nonatomic, strong) CLLocationManager *locationManager;

@property (strong, nonatomic) TabView *tabView;
@property (strong, nonatomic) IBOutlet UITextField *dropDownTxtfield;

@property (strong, nonatomic) IBOutlet UITableView *menuTableView;

@property (strong, nonatomic) IBOutlet UIImageView *myProfileImg;
@property (strong, nonatomic) IBOutlet UILabel *txtName;
@property (strong, nonatomic) IBOutlet UILabel *txtUserEmail;
@property (strong, nonatomic) IBOutlet UIImageView *txtMobileImg;
@property (strong, nonatomic) IBOutlet UILabel *txtMobileTxt;
@property (strong, nonatomic) IBOutlet UILabel *txtAdmin;
@property (strong, nonatomic) IBOutlet UIImageView *imgCity;
@property (strong, nonatomic) IBOutlet UILabel *txtCity;

@property (strong, nonatomic) IBOutlet UIView *gradientView;
@property (strong, nonatomic) IBOutlet UITextField *txtaddEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtAddCompany;
@property (strong, nonatomic) IBOutlet UITextField *txtAddPassword;
- (IBAction)txtForgetPassword:(id)sender;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtCompHeightLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtCompLblLayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtlblTopLayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtTopLayout;
- (IBAction)backClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *addAccountView;
@property (strong, nonatomic) IBOutlet UIView *addAccountSubview;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *subViewHeightLayout;
- (IBAction)loginClicked:(id)sender;


@end
