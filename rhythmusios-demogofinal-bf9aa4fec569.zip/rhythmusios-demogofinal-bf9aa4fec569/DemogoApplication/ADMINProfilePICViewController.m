//
//  ADMINProfilePICViewController.m
//  DemogoApplication
//
//  Created by Rhythmus on 31/03/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ADMINProfilePICViewController.h"
#import "EmplyeeMAnagementViewController.h"
#import "SubscriptionViewViewController.h"
#import "BillingViewController.h"
#import "ADDNewAccountViewController.h"
#import "CompCellTableViewCell.h"
#import "cellActionViewController.h"
#import "Reachability.h"
#import "ForgotPAsViewController.h"

#import <CoreLocation/CoreLocation.h>

@interface ADMINProfilePICViewController ()<CLLocationManagerDelegate,UITableViewDelegate,UITableViewDataSource,NSURLSessionDelegate,NSURLSessionDataDelegate,UITextFieldDelegate>
{
    NSArray *arrayData;
    
    NSArray *arrayIcons;
    
    NSMutableDictionary *userEmailID;
    
    NSString *rolename;
    
    NSMutableArray * CmpListArray;
    
    NSString *compId;
    
    NSString *EMAILDATA;
    
    NSString *Base64encodePassword;
    
    CompCellTableViewCell *cell;
    
    
    
    
    
    
    
    NSString *longitude;
    NSDictionary *mapData;
    NSMutableString * versionNo;
    NSMutableString *OperatingNa;
    NSString *newDateString;
    NSString *latitude ;
}


//////........   ADD ACCOunt Button Attributes or object Functionality

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *PAsswordAutolayout;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *SlectCmpAutolayout;

@property (strong, nonatomic) IBOutlet UINavigationBar *navigationBar;

@property (strong, nonatomic) IBOutlet UIView *ADDACCOUNTVIew;

@property (strong, nonatomic) IBOutlet UIVisualEffectView *ADDACCOUNTBlur;

- (IBAction)CancelButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIImageView *LOgoImag;

@property (strong, nonatomic) IBOutlet UITextField *EmailMobileNameTextfiled;

- (IBAction)SelctCompanyButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *SelctCmpOutlet;

@property (strong, nonatomic) IBOutlet UITextField *PAsswordTExtField;

- (IBAction)SigninButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *SignInButtonOUtlet;

- (IBAction)ForgotButton:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *SELECTCMPTAbleView;




@end

@implementation ADMINProfilePICViewController


-(void)viewWillAppear:(BOOL)animated


{
    
    Base64encodePassword = [[NSString alloc]init];
    
    self.tabBarController.tabBar.hidden = NO;
    
    versionNo= [[NSMutableString alloc]initWithFormat:@"%@",[UIDevice currentDevice].systemVersion];
    
    OperatingNa= [[NSMutableString alloc]initWithFormat:@"%@",[UIDevice currentDevice].systemName];
    
    NSLog(@"%@",versionNo);
    
    NSLog(@"%@",OperatingNa);
    
    
    
    CLLocationCoordinate2D coordinate = [self getLocation];
    
    latitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
    
    longitude = [NSString stringWithFormat:@"%f", coordinate.longitude];
    
    NSLog(@"*dLatitude : %@", latitude);
    
    NSLog(@"*dLongitude : %@",longitude);
    
    
    
    
    
    
    
    /////////>>>>>>>>      Current Location Time UserLogin       >>>>>>>>>////////
    
    
    NSDate * now = [NSDate date];
    
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    
    [outputFormatter setDateFormat:@"hh:mm:ss"];
    
    NSString * newDat = [outputFormatter stringFromDate:now];
    
    newDateString  = [NSString stringWithFormat:@"%ld", (long)[newDat longLongValue]];
    
    NSLog(@"newDateString %@", newDateString);
    
    
    
    
    
    
    
    
    //////////   UsertextField    placeholder edit textfield     /////////
    
    self.EmailMobileNameTextfiled.delegate=self;
    
   NSAttributedString * str=[[NSAttributedString alloc]
         
         initWithString:@"Email/MobileNumber.."
         
         attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.EmailMobileNameTextfiled.attributedPlaceholder=str;

    
    
    
    
}
-(CLLocationCoordinate2D) getLocation


{
    
    
    CLLocationManager *locationManager = [[CLLocationManager alloc] init] ;
    
    locationManager.delegate = self;
    
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    
    locationManager.distanceFilter = kCLDistanceFilterNone;
    
    [locationManager startUpdatingLocation];
    
    CLLocation *location = [locationManager location];
    
    CLLocationCoordinate2D coordinate = [location coordinate];
    
    return coordinate;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable) {
        UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message: @"No Network Connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        [alert show];
        return;
        
        
    }
    
    else
    {

  [self PersonIdSetInServer];
    
    // Add Account Button Functionality
    
    self.ADDACCOUNTBlur.hidden=YES;
    
    self.ADDACCOUNTVIew.hidden = YES;
    
    self.SelctCmpOutlet.hidden =YES;
    
    self.PAsswordAutolayout.constant = 12;
    
    self.SelctCmpOutlet.layer.cornerRadius= 10.5;
    
    self.SELECTCMPTAbleView.layer.cornerRadius = 10.5;
    
    self.SELECTCMPTAbleView.hidden = YES;
    
    CmpListArray = [[NSMutableArray alloc]init];
    
    
    
   
    arrayData = [[NSArray alloc]init];
    
    arrayIcons = [[NSArray alloc]init];
    
    userEmailID = [[NSMutableDictionary alloc]init];
    
    self.tableview.dataSource =self;
    
    self.tableview.delegate = self;
    
    arrayData = [NSArray arrayWithObjects:@"Account Details",@"Employee Management",@"Subscription",@"Biling",@"Add New Account",@"Sign Out", nil];
    
    arrayIcons = [NSArray arrayWithObjects:@"add.png",@"add.png",@"add.png",@"add.png",@"add.png",@"add.png", nil];
   
     [self.tableview reloadData];

    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView

{
    if (tableView == self.tableview) {
        return 1;
    }
    return 1;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    if (tableView == self.tableview)
    {
        
        return [arrayData count];

    }
    return [CmpListArray count];
}

- (CompCellTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;

{
    NSString *CellID = @"cell";
    
    cell = [tableView dequeueReusableCellWithIdentifier:CellID];
   
    if (cell==nil)
        
        {
            cell = [[CompCellTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellID];
            
            cell.selectedBackgroundView.backgroundColor = [UIColor colorWithRed:0.01 green:0.12 blue:0.16 alpha:1.0];
        }
    
    if (tableView == self.tableview) {
        
    
    
            cell.LAbelName.text =[NSString stringWithFormat:@"%@", [arrayData objectAtIndex: indexPath.row]];
    
           // cell.imageView.image =[arrayIcons objectAtIndex:indexPath.row];
    
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    else if (tableView ==self.SELECTCMPTAbleView)
        
    {
        
        NSDictionary *dictionary = [CmpListArray objectAtIndex:indexPath.row];
        
        cell.CmpLISTREQ.text = [dictionary objectForKey:@"cmpNm"] ;
        
        return cell;

        
       // cell.CmpLISTREQ.text =[NSString stringWithFormat:@"%@" ,[CmpListArray objectAtIndex: indexPath.row]];
        
    }
        
   
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

{
    
    if (tableView==self.tableview)
    {
        
    
    
        if (indexPath.row == 0)
        
        {
            
            cellActionViewController *ce = [self.storyboard  instantiateViewControllerWithIdentifier:@"action"];
        
            ce.CountryName = [userEmailID valueForKey:@"cmpNm"];
            
            ce.roleNAmedata = rolename;
            
            ce.Accountname = @"Primary";//[userEmailID valueForKey:@"depName"];
            
            ce.MobileNUmberString = [userEmailID valueForKey:@"pmobile"];
            
            ce .modalTransitionStyle = UIModalTransitionStyleCoverVertical;
            
            [self.navigationController pushViewController:ce animated:YES];
        }
    
    else if (indexPath.row == 1)
        
        {
            
            
            EmplyeeMAnagementViewController * empManage = [self.storyboard  instantiateViewControllerWithIdentifier:@"EM"];
            
            empManage.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
            
             [self.navigationController pushViewController:empManage animated:YES];
            
           // [self.navigationController pushViewController:empManage animated:YES];
            
            
        }
    else if (indexPath.row == 2)
        
    {
        

        SubscriptionViewViewController * Subs = [self.storyboard  instantiateViewControllerWithIdentifier:@"S"];
        
        
        Subs .modalTransitionStyle = UIModalTransitionStyleCoverVertical;
        
        [self.navigationController pushViewController:Subs animated:YES];
    }
    
    
    else if (indexPath.row == 3)
        
    {
        
        BillingViewController * Bill = [self.storyboard  instantiateViewControllerWithIdentifier:@"B"];
        
        Bill.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
        
         [self.navigationController pushViewController:Bill animated:YES];

        
    }

    else if (indexPath.row == 4)
        
    {
        self.ADDACCOUNTBlur.hidden=NO;
        
        self.ADDACCOUNTVIew.hidden=NO;
        self.EmailMobileNameTextfiled.text =@"";
        self.PAsswordTExtField.text = @"";
        
        self.SelctCmpOutlet.hidden = YES;
        
        self.SelctCmpOutlet.titleLabel.text = @"";
        
        self.PAsswordAutolayout.constant = 12;
        
    }
    else if (indexPath.row == 5)
        
    {
        
        
        NSLog(@"success");
        [self dismissViewControllerAnimated:YES completion:nil];
        
//        EmplyeeMAnagementViewController * empManage = [self.storyboard instantiateViewControllerWithIdentifier:@"EM"];
//        
//        [self.navigationController pushViewController:empManage animated:YES];
        
        
    }
    
}

    else if (tableView == self.SELECTCMPTAbleView)
    
    {
        
        [self.PAsswordTExtField resignFirstResponder];
        
        [self.EmailMobileNameTextfiled resignFirstResponder];
        
        
        
        
        NSDictionary *dictionary = [CmpListArray objectAtIndex:indexPath.row];
        
        NSString *companyName = [dictionary objectForKey:@"cmpNm"];
        
        compId = [dictionary objectForKey:@"cmpId"];
        
        NSLog(@"%@ = %@",companyName,compId);
        
        
        
        
        
        cell=[self.SELECTCMPTAbleView cellForRowAtIndexPath:indexPath];
        
        [self.SelctCmpOutlet setTitle:cell.CmpLISTREQ.text forState:UIControlStateNormal];
        
        self.SELECTCMPTAbleView.hidden =YES;
        
        
    }
    
    

    


}


-(void)PersonIdSetInServer;

{
    
    NSString * urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/getprofile?personId=%@",@"3714"];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *url = [NSURL URLWithString:urlstring];
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
    {
                                              
        NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
        NSLog(@" the databse theXml is  =====  %@",theXML);
                                              
        NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
        userEmailID = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
        
        NSLog(@"The State Response is  ===  %@" , userEmailID);
        
        NSLog(@"The State Response is  ===  %@" , [userEmailID valueForKey:@"responseCode"]);
                                              
        NSString* str =[userEmailID valueForKey:@"role"];
                                              
        if ([str isEqualToString:@"ROLE_SUPER_ADMIN"])
            
            {
                self.NameLabel.text =[userEmailID valueForKey:@"firstName"];
                
                self.CountryNameLabel.text = [userEmailID valueForKey:@"location"];
                
                self.EmailNameLAbel.text = [userEmailID valueForKey:@"pemail"];
            
                self.MobileNumberLAbel.text = [userEmailID valueForKey:@"pmobile"];
                
                NSString *replace = [userEmailID valueForKey:@"role"];
                
                
               // NSString *theXML = [[NSString alloc] initWithData:self.reciveData encoding:NSUTF8StringEncoding];
                NSString  *responseData = [replace stringByReplacingOccurrencesOfString:@"ROLE_SUPER_" withString:@""];

                
              //  NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"ROLE_SUPER_"];
                
              //  rolename =  [replace stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
                
              //  rolename = [[rolename componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString:@""];
                
                NSLog(@"%@",responseData);
                
              //  NSLog(@"%@",rolename);
                

                
                self.AdminOrHostNameLAbel.text = responseData;
                
                
                                                  
                                                  
            }
        
        if ([str isEqualToString:@"ROLE_HOST"])
            
        {
            self.NameLabel.text =[userEmailID valueForKey:@"firstName"];
            
            self.CountryNameLabel.text = [userEmailID valueForKey:@"location"];
            
            self.EmailNameLAbel.text = [userEmailID valueForKey:@"pemail"];
            
            self.MobileNumberLAbel.text = [userEmailID valueForKey:@"pmobile"];
            
            NSString *replace = [userEmailID valueForKey:@"role"];
            
            NSString  *responseData = [replace stringByReplacingOccurrencesOfString:@"ROLE_" withString:@""];
            
            NSLog(@"%@",responseData);
            
            
            
            self.AdminOrHostNameLAbel.text = responseData;
            
            
            
            
        }
        

        
            else if(str ==nil)
                
                {
                    
                    NSLog(@"error");
                    
                }
                                              
                                              
    }];
    
    [self.TableCompanyList reloadData];
    
    [postDataTask resume];
    
 }




- (IBAction)CancelButton:(id)sender
{
    self.ADDACCOUNTVIew.hidden =YES;
    
    self.ADDACCOUNTBlur.hidden =YES;
    
}

- (IBAction)SigninButton:(id)sender

{
    [self FirstAPIPostMethodUSed];
    
}
- (IBAction)ForgotButton:(id)sender

{
    
    ForgotPAsViewController *pass  = [self.storyboard  instantiateViewControllerWithIdentifier:@"f"];
    
    pass .modalTransitionStyle = UIModalTransitionStylePartialCurl;
    
    [self.navigationController pushViewController:pass animated:YES];
    
    
    
    //[self.navigationController pushViewController:pass animated:YES];
       
}






- (IBAction)SelctCompanyButton:(id)sender
{
    
    if (self.SELECTCMPTAbleView.hidden == YES)
   
        {
        
            self.SELECTCMPTAbleView.hidden = NO;
            
        }
    
        else
        
            {
                
                self.SELECTCMPTAbleView.hidden = YES;
                
            }
    
}
























            //////  ....    ..  .   .   .     ADD  ACCOUNT BUTTON TABLE VIEW CELL WORKING

-(void)ADDAccountTableViewAPi;

{
    
    NSString *urlstr  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/getemaildetails?email=%@",self.EmailMobileNameTextfiled.text];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *urlAunt = [NSURL URLWithString:urlstr];
    
    
    
    
    
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:urlAunt cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    
    
    
    
    
    //   NSMutableDictionary * GetDic = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.EmailMobileNoTextField.text,@"email",nil];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
                                              NSLog(@" the databse theXml is  =====  %@",theXML);
                                              
                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
                                             NSMutableDictionary* USEREmailID = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                              
                                              
                                              
                                              NSLog(@" the email deatils is  =   %@",EMAILDATA);
                                              
                                              NSLog(@"the email response is = %@",USEREmailID);
                                              
                                              EMAILDATA = [USEREmailID valueForKey:@"message"];
                                              
                                              
                                              if ([EMAILDATA isEqualToString:@"Email ID Do not exist"])
                                              {
                                                  UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"ACCOUNT DETAILS" message:
                                                                                        
                                                                                        @"Your Email ID is Invalid" preferredStyle:UIAlertControllerStyleAlert];
                                                  
                                                  UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                              
                                                                              {
                                                                                  
                                                                                  
                                                                              }];
                                                  
                                                  [TextFieldError3 addAction:errorPass];
                                                  
                                                  [self presentViewController:TextFieldError3 animated:YES completion:nil];
                                                  
                                                  
                                                  
                                                  
                                              }
                                              
                                              
                                              
                                              else if ([EMAILDATA isEqualToString:@"success"])
                                                  
                                                  
                                              {
                                                  
                                                  
                                                  CmpListArray = [USEREmailID objectForKey:@"cmpList"];
                                                  
                                                  NSLog(@"%@",CmpListArray);
                                                  
                                                  NSLog(@" SSS  SSSS  S S S S S  USUU U     UUUU  U U U  U");
                                              }
                                              
                                              
                                              
                                              
                                              
                                              
                                              
                                              
                                          }];
    
    
    
    
    
    [self.SELECTCMPTAbleView reloadData];
    
    [postDataTask resume];
    
    
    
    
    
    
    
}










/////////           Table Cell Select Row Method             ////////////



    

    



////////////                UITableViewCell           //////////////



- (BOOL)textFieldShouldReturn:(UITextField *)textField


{
    
    [self.EmailMobileNameTextfiled resignFirstResponder];
    
    [self.PAsswordTExtField resignFirstResponder];
    
    [self ADDAccountTableViewAPi];
    
    
    
    
    
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Select Company Name\n Your UserId Is"
                                          
                                                                             message:self.EmailMobileNameTextfiled.text preferredStyle:UIAlertControllerStyleAlert];
    
    
    
    
    ////////    ......................Create Button On alert Notification ......................
    
    UIAlertAction* SelectCompany = [UIAlertAction actionWithTitle:@"CompanyName" style:UIAlertActionStyleDefault
                                    
                                                          handler:^(UIAlertAction * action)
                                    
                                    {
                                        
                                        //[self SaveDataSecondApi];
                                        
                                        if ([EMAILDATA isEqualToString:@"Email ID Do not exist"])
                                            
                                            
                                        {
                                            NSLog(@"email is not successfully");
                                            
                                            
                                            UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"USERNAME" message:
                                                                                  
                                                                                  @"USERNAME IS NOT CORRECT,PLEASE FILL CORRECT DETAILS" preferredStyle:UIAlertControllerStyleAlert];
                                            
                                            UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                        
                                                                        {
                                                                            
                                                                            
                                                                        }];
                                            
                                            [TextFieldError3 addAction:errorPass];
                                            
                                            [self presentViewController:TextFieldError3 animated:YES completion:nil];
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                        }
                                        
                                        
                                        
                                        
                                        else
                                            
                                            
                                        {
                                            
                                            
                                            NSLog(@" Alert Activate You Work it ");
                                            
                                            [self.SELECTCMPTAbleView reloadData];
                                            
                                            self.SelctCmpOutlet.hidden=NO;
                                            
                                            
                                            self.PAsswordAutolayout.constant=57;
                                            
                                            self.SlectCmpAutolayout.constant = 12;
                                            
                                            
                                            
                                            //self.NameCmpBT.hidden=NO;
                                        }
                                        
                                        /*else {
                                            
                                            
                                            UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"ACCOUNT DETAILS" message:
                                                                                  
                                                                                  @"Your Email ID is Invalid" preferredStyle:UIAlertControllerStyleAlert];
                                            
                                            UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                                        
                                                                        {
                                                                            
                                                                            
                                                                        }];
                                            
                                            [TextFieldError3 addAction:errorPass];
                                            
                                            [self presentViewController:TextFieldError3 animated:YES completion:nil];
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            NSLog(@"ERROR EMAIL ID LINK");
                                        }
                                        */
                                        
                                        
                                    }];
    
    
    
    
    [alertController addAction:SelectCompany];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
    
    
    
    
    return YES;
    
    
}

-(void)FirstAPIPostMethodUSed;
{
    NSString *urlstr  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/checklogin?add=%@&cmpId=%@&latitude=%@&logintym=%@&longitude=%@&os=%@&username=%@&password=%@&personId=%@&version=%@",@"true",compId,latitude,newDateString ,longitude,OperatingNa,self.EmailMobileNameTextfiled.text,Base64encodePassword,@"3714",versionNo];
    
    
    NSError *error;
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    // NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
    
    NSURL * urll = [NSURL URLWithString:urlstr];
    
    NSMutableURLRequest * requestUrl = [NSMutableURLRequest requestWithURL:urll
                                                               cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                           timeoutInterval:60.0];
    
    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [requestUrl setHTTPMethod:@"POST"];
    
    
    /////////   Password convert in Base64Encoding   ./////////////
    
    
    NSString* strPassword= self.PAsswordTExtField.text;
    
    NSLog(@"%@",strPassword);
    
    NSData *dataTake2 = [strPassword dataUsingEncoding:NSUTF8StringEncoding];
    
    // Convert to Base64 data
    
    NSData *base64Data = [dataTake2 base64EncodedDataWithOptions:0];
    
    Base64encodePassword = [NSString stringWithFormat:@"%@",[NSString stringWithUTF8String:[base64Data bytes]]];
    
    NSLog(@"%@", Base64encodePassword);
    
    mapData = [[NSDictionary alloc] initWithObjectsAndKeys:@"true",@"add",compId,@"cmpId",latitude,@"latitude",newDateString ,@"logintym",longitude,@"longitude",OperatingNa,@"os",self.EmailMobileNameTextfiled.text,@"username",Base64encodePassword,@"password",@"3714",@"personId",versionNo,@"version",nil];
    
    
    
    // newDateString,@"logintym",
    
    NSLog(@" %@",mapData);
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:mapData options:0 error:&error];
    
    [requestUrl setHTTPBody:postData];
    
    
    
    NSURLSessionDataTask *postDtaat = [session dataTaskWithRequest:requestUrl completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              
                                              
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                  
                                                  
                                                  NSError *jsonError;
                                                  
                                                  NSLog(@"theeeeeeeeeeeeee total response is  =        %@",response);
                                                  NSLog(@"%@",data);
                                                  
                                                  
                                                  
                                                NSMutableDictionary *  result =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                  
                                                  NSLog(@"%@",result);
                                                  
                                                NSString *  fetchOTP2 = [NSString stringWithFormat:@"%@",[result valueForKey:@"message"]];
                                                  
                                                 
                                                  NSLog(@"%@",fetchOTP2);
        
    
                                              });


                                          }];

    [postDtaat resume];


}





@end
