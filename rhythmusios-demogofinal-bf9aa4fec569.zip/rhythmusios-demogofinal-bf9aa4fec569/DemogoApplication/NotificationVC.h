//
//  ViewController.h
//  excelSheetUpload
//
//  Created by Rhythmus on 05/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationVc : UIViewController<UIScrollViewDelegate>{
    
    int pageNo;
    NSArray* PassedJSon;
    id allData ;
    id AcceptData ;
    id RejectData ;
    NSString *confIdString;

    NSString *NotifyIDGet;
    NSMutableArray*dateArr;
    NSMutableArray*mesgArr;
    
    NSMutableArray*NotifyStausArray;
    NSMutableArray*NotifyTime ;

    NSMutableArray*todayArray ;
    NSMutableArray*previousArray;
    NSDate *startToday ;
    NSDate *endToday;
    NSMutableArray *allDatesArray;
    NSMutableArray*messagePreviousArray;
     NSMutableArray*messageTdayArray;
    
     NSDictionary *cities;
    //// verify aacount string object
    
    NSString *NotifyString;
    NSString *CurrentFirstNM;
    NSString *CurrentLastName;
    NSString *CurrentDepart;
    NSString *CurrentLocat;
    NSString *CurrentMobileNum;
    NSString *CurrentEmailID;
    
    //// verify aacount string object
    
    
    NSString *RequestedFirstNM;
    NSString *RequestedLastName;
    NSString *RequestedDepart;
    NSString *RequestedLocat;
    NSString *RequestedMobileNum;
    NSString *RequestedEmailID;
    int i;
    NSString *mesg;
    NSMutableDictionary *dictData;
    NSMutableArray *allDataArray;
    NSMutableArray *todayFinalArray;
    NSMutableArray *PreviousFinalArray;
    NSMutableArray*variFyArray;
    
    NSString *strdata;
    NSString *strda;
    NSMutableArray *verifyArrayData;
    
    NSString *ntfyID;
    NSString *finalDate;
    NSString *finalTime;
    
    NSString * TodayNotifyID;
    NSString * TodayStatus;
    UIRefreshControl *refresh;
    
    NSString*Tokenid;
    NSString*CompanyId;
    NSString*personId;
    
    NSString*pmobile ;
    
    
    
    }
@property (strong, nonatomic) IBOutlet UILabel *txtToday;
@property (strong, nonatomic) IBOutlet UILabel *txtVerifyAccount;
@property (strong, nonatomic) IBOutlet UILabel *txtPrevious;

@property (strong, nonatomic) IBOutlet UIScrollView *scrollview;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *leadingConstant;
@property (strong, nonatomic) IBOutlet UIButton *BtnToday;
@property (strong, nonatomic) IBOutlet UIButton *BtnPreviews;
@property (strong, nonatomic) IBOutlet UIButton *BtnVerifyAccount;

- (IBAction)btnToday:(id)sender;
- (IBAction)btnPreviews:(id)sender;

- (IBAction)btnVerifyAccount:(id)sender;

@property (strong, nonatomic) IBOutlet UIView *firstVIew;
@property (strong, nonatomic) IBOutlet UIView *SecondView;
@property (strong, nonatomic) IBOutlet UIView *thirdView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *viewLeadingLayout;



@property (strong, nonatomic) IBOutlet UITableView *PreviewTableView;
@property (strong, nonatomic) IBOutlet UITableView *TodayTableView;
@property (strong, nonatomic) IBOutlet UITableView *TableViewVerifyAccount;







////////////   Verify Account View Data


@property (strong, nonatomic) IBOutlet UIView *ViewVerifyAccount;

@property (strong, nonatomic) IBOutlet UILabel *LabelcurrentDetail;
@property (strong, nonatomic) IBOutlet UILabel *LabelRequestedDetails;


@property (strong, nonatomic) IBOutlet UILabel *LabelCurrentName;
@property (strong, nonatomic) IBOutlet UILabel *LabelCurrentLastName;

@property (strong, nonatomic) IBOutlet UILabel *LabelCurrentLocation;

@property (strong, nonatomic) IBOutlet UILabel *LabelCurrentDepartment;

@property (strong, nonatomic) IBOutlet UILabel *LabelCurrentEmailId;
@property (strong, nonatomic) IBOutlet UILabel *LabelCurrentMobileNumber;


 ///  Rquested Data in Verify Account
@property (strong, nonatomic) IBOutlet UILabel *LabelRequestedName;
@property (strong, nonatomic) IBOutlet UILabel *LabelRequestedLastName;

@property (strong, nonatomic) IBOutlet UILabel *LabelRequestedLocation;

@property (strong, nonatomic) IBOutlet UILabel *LabelRequestedDepartment;

@property (strong, nonatomic) IBOutlet UILabel *LabelRequestedEmailId;
@property (strong, nonatomic) IBOutlet UILabel *LabelRequestedMobileNumber;

- (IBAction)btnBack:(id)sender;
- (IBAction)btnApprove:(id)sender;
- (IBAction)btnReject:(id)sender;




@property (strong, nonatomic) IBOutlet UIButton *BtnApprove;
@property (strong, nonatomic) IBOutlet UIButton *BtnReject;



///////////////     today meeting click views
@property (strong, nonatomic) IBOutlet UIView *ConferenceDetailsView;

@property (strong, nonatomic) IBOutlet UIView *ViewTodayConference;

@property (strong, nonatomic) IBOutlet UILabel *labelSubject;

@property (strong, nonatomic) IBOutlet UILabel *labelConferenceTime;

@property (strong, nonatomic) IBOutlet UILabel *labelCOnferenceDate;
@property (strong, nonatomic) IBOutlet UILabel *labelMode;
@property (strong, nonatomic) IBOutlet UILabel *Subject;

@property (strong, nonatomic) IBOutlet UILabel *time;
@property (strong, nonatomic) IBOutlet UILabel *date;

@property (strong, nonatomic) IBOutlet UILabel *mode;





@property (strong, nonatomic) IBOutlet UIView *ViewConfDetLabel;

@property (strong, nonatomic) IBOutlet UIView *ViewConfDetailsNew;


//////// alert  show view  button  outlet



@property (strong, nonatomic) IBOutlet UIButton *BtnJoin;
@property (strong, nonatomic) IBOutlet UIButton *BtnDecline;
@property (strong, nonatomic) IBOutlet UIButton *BtnMayBe;
//////// Action
- (IBAction)btnJoin:(id)sender;
- (IBAction)btnDecline:(id)sender;
- (IBAction)btnMayBe:(id)sender;

- (IBAction)BtnCrossConference:(id)sender;


@end

