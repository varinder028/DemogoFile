//
//  FirstLoginPAGEViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/23/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstLoginPAGEViewController : UIViewController

@end
