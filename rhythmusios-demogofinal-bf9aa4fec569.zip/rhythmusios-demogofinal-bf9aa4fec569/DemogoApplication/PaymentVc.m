//
//  PaymentVc.m
//  DemogoApplication
//
//  Created by Rhythmus on 15/06/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "PaymentVc.h"
#import "SubscriptionVC.h"
#import <AFNetworking/AFNetworking.h>
#import "KVNProgress.h"

@interface PaymentVc ()

@end

@implementation PaymentVc

- (void)viewDidLoad {
    [super viewDidLoad];
    
     CompanyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];

    
    NSLog(@"%@",_transStatus);
    
    
    if ([_transStatus isEqualToString:@"Transaction Successful"]) {
        _transImage.image = [UIImage imageNamed:@"check-mark.png"];
        _txtResult.text = @"Transaction Successful !" ;
        
        
    }else if ([_transStatus isEqualToString:@"Transaction Cancelled"]) {
        _transImage.image = [UIImage imageNamed:@"cancel 2.png"];
        _txtResult.text = @"Transaction Cancelled !" ;
        
        
    }else{
        
        _txtResult.text = @"Transaction Failed !";
        _transImage.image = [UIImage imageNamed:@"cancel 2.png"];

        
        
    }
    
    _btnContinue.layer.cornerRadius = 15.0f ;
    [_btnContinue clipsToBounds];
    
    
    
    
    
    // Do any additional setup after loading the view.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)continueClicked:(id)sender {
    if ([_txtResult.text isEqualToString:@"Transaction Failed !"]) {
         [[[[UIApplication sharedApplication] keyWindow] rootViewController] dismissViewControllerAnimated:true completion:nil];
    }
    else if ([_txtResult.text isEqualToString:@"Transaction Cancelled !"]) {
         [[[[UIApplication sharedApplication] keyWindow] rootViewController] dismissViewControllerAnimated:true completion:nil];
    }else{
        [self readPayementDataFromServer];
 
    }
        
        
    
    
   
}
-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}

-(void)readPayementDataFromServer{
NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/payment/ccavenueread?"];

    NSDictionary *parameters = @{ @"cmpId": CompanyId,
                                  @"htmlText": _htmlText
                                  };
    

    
    
AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
manager.requestSerializer = [AFJSONRequestSerializer serializer];
//[manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];

[manager POST:apiURLStr parameters:parameters success:^(NSURLSessionTask *task, id responseObject) {
    NSLog(@"PLIST: %@", responseObject);
    [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
    
    getPaymentData = responseObject ;
    
     [[[[UIApplication sharedApplication] keyWindow] rootViewController] dismissViewControllerAnimated:true completion:nil];
  
    
}
      failure:^(NSURLSessionTask *operation, NSError *error) {
         [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
         NSLog(@"Error: %@", error);
          [[[[UIApplication sharedApplication] keyWindow] rootViewController] dismissViewControllerAnimated:true completion:nil];
          

         
     }];
    
}
@end
