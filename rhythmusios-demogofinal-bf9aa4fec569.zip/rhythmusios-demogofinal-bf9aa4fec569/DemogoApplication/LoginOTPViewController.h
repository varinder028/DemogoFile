//
//  LoginOTPViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TabView.h"

@interface LoginOTPViewController : UIViewController
{
    NSMutableString *OtNumber;
    
    NSString * varifyStr ;
   
    UIAlertView*alertOtp;

   id PassedJSon;
}

@property (strong, nonatomic) IBOutlet UIView *otpView;

@property (strong, nonatomic) UIView*OtpView;

@property (strong, nonatomic) NSString *varify;
@property (strong, nonatomic) NSString *passStatus;

@property (strong, nonatomic) TabView *tabView;
@property (strong, nonatomic) IBOutlet UIButton *resendOtpOUTLET;


@property (weak, nonatomic) IBOutlet NSString *StringOTP;
@property (weak, nonatomic) IBOutlet NSString *PersonIDStr;



@property (weak, nonatomic) IBOutlet NSString *PassMobileNUm;

@property (weak, nonatomic) IBOutlet NSString *PartiCipantClient;

@property (weak, nonatomic) IBOutlet NSString *NAMEofClient;

//@property (weak, nonatomic) IBOutlet NSString *PersonIDFetch;
- (IBAction)backClicked:(id)sender;


@end
