//
//  AccountCell.h
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccountCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *txtName;

@property (strong, nonatomic) IBOutlet UIButton *btnUpdate;
@property (strong, nonatomic) IBOutlet UILabel *txtType;
@property (strong, nonatomic) IBOutlet UIButton *btnDelete;
@property (strong, nonatomic) IBOutlet UILabel *txtRole;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *widthDelete;
@end
