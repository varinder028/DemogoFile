//
//  PreviewPageVc.h
//  DemogoApplication
//
//  Created by Rhythmus on 01/06/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreviewPageVc : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *txtDate;
@property (strong, nonatomic) IBOutlet UILabel *txtStartTime;
@property (strong, nonatomic) IBOutlet UILabel *txtEndTime;
@property (strong, nonatomic) IBOutlet UILabel *txtConfCode;
@property (strong, nonatomic) IBOutlet UILabel *txtMode;
@property (strong, nonatomic) IBOutlet UILabel *txtSubject;
@property (strong, nonatomic) IBOutlet UILabel *txtHeaderDate;


@property (strong, nonatomic) IBOutlet UILabel *txtDear;
@property(strong,nonatomic)NSString *headerDate ;
@property(strong,nonatomic)NSString *DateStr ;
@property(strong,nonatomic)NSString *startTime ;
@property(strong,nonatomic)NSString *EndTime ;
@property(strong,nonatomic)NSString *ConfId;
@property(strong,nonatomic)NSString *mode;
@property(strong,nonatomic)NSString *subject;

- (IBAction)backClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UITextView *txtDetails;
@property (strong, nonatomic) IBOutlet UILabel *txtDateeee;

@end
