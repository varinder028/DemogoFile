//
//  MyBillViewController.h
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyBillViewController : UIViewController{
    
    NSString*CompanyId;
    NSString*personId;
    NSString*Tokenid;
    id myBills ;
    id dueData;
}

@property (strong, nonatomic) IBOutlet UILabel *LbLCurrentValue;

@property (strong, nonatomic) IBOutlet UILabel *LblPaymentRecieved;

@property (strong, nonatomic) IBOutlet UILabel *LbLPreviousBalance;

@property (strong, nonatomic) IBOutlet UILabel *LbLTotalAmountByDueDate;
- (IBAction)PayButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *PayBtnOutlet;
- (IBAction)DownloadButon:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *viewData;



@property (strong, nonatomic) IBOutlet UITextField *txtPlanName;
@property (strong, nonatomic) IBOutlet UITextField *txtPlanId;

@property (strong, nonatomic) IBOutlet UITextField *txtPlanType;
@property (strong, nonatomic) IBOutlet UITextField *txtCompanyName;
@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtOrderDate;
- (IBAction)PayClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnPay;
@property (strong, nonatomic) IBOutlet UITextField *txtAmount;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;

- (IBAction)backPay:(id)sender;


@property (strong, nonatomic) IBOutlet UIView *viewPay;


@end
