//
//  LiveParticipantViewController.m
//  nbng
//
//  Created by Rhythmus on 28/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "LiveParticipantViewController.h"
#import "LiveParticipantCell.h"
#import "KVNProgress.h"


@interface LiveParticipantViewController ()

@end

@implementation LiveParticipantViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    _ViewLiveInvite.layer.cornerRadius = 5.0f ;
    
    [_ViewLiveInvite clipsToBounds];
    
    
    
    
    _ViewLiveNotJoined.layer.cornerRadius = 5.0f ;
    
    [_ViewLiveNotJoined clipsToBounds];
    
    
    _ViewLiveDialOut.layer.cornerRadius = 5.0f ;
    [_ViewLiveDialOut clipsToBounds];
    
    _ViewLiveJoined.layer.cornerRadius = 5.0f ;
    [_ViewLiveJoined clipsToBounds];
    
    
    _btnRemindAll.layer.cornerRadius = 5.0f ;
    [_btnRemindAll clipsToBounds];
    
    
   
    
    
    
    confDialType = [[NSUserDefaults standardUserDefaults]valueForKey:@"confDialType"];
    NSLog(@"%@",confDialType);
    
    
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    ConfId = [[NSUserDefaults standardUserDefaults]valueForKey:@"ConfId"];
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    NSLog(@"%@",Tokenid);
    self.ViewLiveInvite.layer.cornerRadius = 5.5f;
    
    self.ViewLiveInvite.layer.masksToBounds = YES;
    
    
    self.ViewLiveNotJoined.layer.cornerRadius = 5.5;
    self.ViewLiveNotJoined.layer.masksToBounds = YES;
    
    self.ViewLiveJoined.layer.cornerRadius = 5.5;
    self.ViewLiveJoined.layer.masksToBounds = YES;
    
    self.ViewLiveDialOut.layer.cornerRadius = 5.5;
    self.ViewLiveDialOut.layer.masksToBounds = YES;
    

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    isSessionNil = NO;
    aTimer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(aTime) userInfo:nil repeats:YES];
    bTimer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(bTime) userInfo:nil repeats:YES];
    
    [self GetActiveInactiveApi];

    
}



-(void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:animated];
    
    [actInactTask  cancel];
    managerAf = nil;
    activeInactiveSession= nil;
    isSessionNil = YES;
    [aTimer invalidate];
    [bTimer invalidate];
    managerAfConf = nil ;
    
    
}

-(void)bTime{
    
    managerAfConf = nil;
        
    [self GetControlConferenceDetailsconference];
        
    
    
    
}


-(void)aTime{
    
    if (isSessionNil) {
        return ;
    }else{
        
        [self GetActiveInactiveApi];
        
    }
    
    
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    
    return [[activeInactive valueForKey:@"resList"] count];
}

-(LiveParticipantCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *cellID = @"cell";
    
    LiveParticipantCell *cell = [tableView dequeueReusableCellWithIdentifier:@"LiveParticipantCell"];
    
    if (cell == nil)
        
    {
        
        NSArray *cellarray = [[NSBundle mainBundle]loadNibNamed:@"LiveParticipantCell" owner:self options:nil];
        
        cell = cellarray[0];
        
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone ;
    
    
    NSString*strName = [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"firstName"]objectAtIndex:indexPath.row]];
    
    NSString*strActive = [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"active"]objectAtIndex:indexPath.row]];

   
    
    
    if ([strName isKindOfClass:(id)[NSNull null]] || strName == nil || [strName isEqualToString:@"<null>"]){
        cell.txtLiveName.text = @"N/A" ;
    }else{
        
        cell.txtLiveName.text = strName ;
        
    }
    
    
   NSString*strMobile = [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"pmobile"]objectAtIndex:indexPath.row]];
    
    if ([strMobile isKindOfClass:(id)[NSNull null]] || strMobile == nil ||  [strMobile isEqualToString:@"<null>"]) {
         cell.txtLiveMobile.text = @"N/A" ;
    }else{
        
         cell.txtLiveMobile.text = [NSString stringWithFormat:@"%@",strMobile];
        
    }

    
    [cell.btnSelfMute addTarget:self action:@selector(singleMute:) forControlEvents:UIControlEventTouchUpInside];
    cell.btnSelfMute.tag = indexPath.row ;
    
    
    
    [cell.btnRefresh addTarget:self action:@selector(singleRetry:) forControlEvents:UIControlEventTouchUpInside];
    cell.btnRefresh.tag = indexPath.row ;
    
    [cell.btnSelfEndCall addTarget:self action:@selector(singleEndCall:) forControlEvents:UIControlEventTouchUpInside];
    cell.btnSelfEndCall.tag = indexPath.row ;
    
    
    
    if ([strActive isEqualToString:@"2"]) {
        cell.txtLiveResponse.text = @"Not Joined" ;
        
        [cell.btnSelfMute setHidden:YES];
        [cell.btnSelfEndCall setHidden:YES];
        [cell.btnRefresh setHidden:NO];
       
        
        
       // [singleRefreshTag setSelected:NO] ;
      //  [cell.btnRefresh setImage:[UIImage imageNamed:@"reload.png"]  forState:UIControlStateNormal];
        
    }else if ([strActive isEqualToString:@"0"]) {
        cell.txtLiveResponse.text = @"Inactive" ;
        
        [cell.btnSelfMute setHidden:YES];
        [cell.btnSelfEndCall setHidden:YES];
        [cell.btnRefresh setHidden:NO];
        
      //  [singleRefreshTag setSelected:NO];
      
        
       // UIImage *img = [UIImage imageNamed:@"reload.png"];
        
        
        
      //  [cell.btnRefresh setImage: [UIImage imageNamed:@"reload.png"]  forState:UIControlStateNormal];
        
        
    }
    else{
        
        cell.txtLiveResponse.text = @"Active" ;
        [cell.btnSelfMute setHidden:NO];
        [cell.btnSelfEndCall setHidden:NO];
        [cell.btnRefresh setHidden:YES];
      //  [singleRefreshTag setSelected:YES];
        
    
   // [cell.btnRefresh setImage:[UIImage imageNamed:@"circular-arrow.png"]  forState:UIControlStateNormal];
        
        
    }
    
    NSString*mute = [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"mute"]objectAtIndex:indexPath.row]];
    if ([mute isEqualToString:@"2"]) {
        
        
        [cell.btnSelfMute setSelected:NO];
        
        
    }else if ([mute isEqualToString:@"0"]) {
        
        [cell.btnSelfMute setSelected:NO];
        
    }
    else{
        
        [cell.btnSelfMute setSelected:YES];
        
        
        
    }

    
   // NSMutableArray*arrActive = [[activeInactive valueForKey:@"resList"]valueForKey:@"active"];
    //  cell.txtLiveResponse.text = [[[activeInactive valueForKey:@"resList"]valueForKey:@""]objectAtIndex:indexPath.row];;
    
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row) {
        NSLog(@"sucess");
    }
}

-(void)singleMute:(id)sender{
    
    
    [actInactTask  cancel];
    managerAf = nil;
    activeInactiveSession= nil;
    isSessionNil = YES;
    
    singleMuteTag = (UIButton*)sender;
    NSLog(@"%ld",(long)singleMuteTag.tag);
    
      
    
    NSString*open = [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"open"]objectAtIndex:singleMuteTag.tag]];

    MobileStr =  [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"pmobile"]objectAtIndex:singleMuteTag.tag]];
    MobileStr =  [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"pmobile"]objectAtIndex:singleMuteTag.tag]];
    NSLog(@"%@",MobileStr);
  singleConfID = [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"confId"]objectAtIndex:singleMuteTag.tag]];
    
    
    
    
    if (!singleMuteTag.isSelected) {
       
        
          [self singleParticipantMute];
        
    }else{
        
     //   [singleMuteTag setSelected:NO];
        
        [self singleParticipantUnMute];
        
        
        
    }
    
    
    
    
    
    
    
}



-(void)singleEndCall:(id)sender{
    
    
    
    
    [actInactTask  cancel];
    managerAf = nil;
    activeInactiveSession= nil;
    isSessionNil = YES;

    
    
    
    
    singleEndCallTag = (UIButton*)sender;
    NSLog(@"%@",singleEndCallTag);
    
    
    
//    [singleMuteTag setEnabled:YES];
    singleEndAlert= [[UIAlertView alloc]initWithTitle:nil message:@"Sure! You want to end call" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
    
    [singleEndAlert show];

    
  

    
    
   
    
    //[self singleParticipantEndCall];

    
    

    
    
    
}

-(void)singleRetry:(id)sender{
    [actInactTask  cancel];
    managerAf = nil;
    activeInactiveSession= nil;
    isSessionNil = YES;

    
    singleRefreshTag = (UIButton*)sender;
    NSLog(@"%@",singleRefreshTag);
    
    
    MobileStr =  [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"pmobile"]objectAtIndex:singleRefreshTag.tag]];
    NSLog(@"%@",MobileStr);
    singleConfID = [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"confId"]objectAtIndex:singleRefreshTag.tag]];
   // [singleRefreshTag setSelected:YES];
    
  
    singleRefreshTag.enabled = NO;
 timerBtnRtry = [NSTimer scheduledTimerWithTimeInterval:150 target:self selector:@selector(SetTimerConform) userInfo:nil repeats:YES];
  //  [self performSelector:@selector(enableButton:) withObject:singleRefreshTag afterDelay:150.0];
    
    [singleRefreshTag setImage: [UIImage imageNamed: @"circular-arrow"] forState:UIControlStateNormal];
    
   
    if ([confDialType isEqualToString:@"dialin"]) {
        
        [self RetrySingleParticipantDianlin];
        
        
    }else{
        
        [self RetrySingleParticipantDianlOut];
        
        
    }

    
    
}

-(void)SetTimerConform{
    
    singleRefreshTag.enabled = YES;
    [singleRefreshTag setImage:[UIImage imageNamed: @"reload.png"] forState:UIControlStateNormal];

    [timerBtnRtry invalidate];
    
    
}
//- (void)enableButton:(UIButton *)button
//{
//    singleRefreshTag.enabled = YES;
//      [singleRefreshTag setImage:[UIImage imageNamed: @"reload.png"] forState:UIControlStateNormal];
//    
//}


//-(void)setTimer
//{
//    counterr = 150;
//    
//    timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(SetTimerConform) userInfo:nil repeats:YES];
//    
//    
//    
//    
//}
//
//
//
//
//
//
//-(void)SetTimerConform
//{
//    
//    
//    
//    if (counterr==0) {
//        
//        
//        
//        [timer invalidate];
//        
//        _resendOutlet.enabled = YES;
//        
//        
//        // self.resendOutlet.hidden=NO;
//        
//        
//        self.resendOutlet.layer.cornerRadius = 10.5;
//        
//        
//        
//        [_resendOutlet setBackgroundColor:[UIColor colorWithRed:255/255.0f green:18/255.0f blue:255/255.0f alpha:1]];
//        
//        
//    }


- (IBAction)btnBack:(UIButton *)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
  
    
    
}

- (IBAction)endAllConfClicked:(id)sender {

    endConfalert= [[UIAlertView alloc]initWithTitle:nil message:@"Do you want to end the conference" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
    
    [endConfalert show];

}

- (IBAction)muteClicked:(id)sender {
    
    [actInactTask  cancel];
    managerAf = nil;
    activeInactiveSession= nil;
    isSessionNil = YES;

    
if (!_btnAllMute.isSelected) {
    
        [self ConfAllMute];
        
        
    }else{
        
        [self ConfAllUnMute];
        
        
    }

}




-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}


/////////////////////////////////// Active -Inactive Api ////////////////////////////////

-(void)GetActiveInactiveApi{
    
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/getActiveInactive?confId=%@",ConfId];
    
    managerAf = [AFHTTPSessionManager manager];
    managerAf.requestSerializer = [AFJSONRequestSerializer serializer];
    [managerAf.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [managerAf GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        
        activeInactive = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(ACtiveInactiveData) withObject:nil waitUntilDone:YES];
        [self.tableview performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    

}

-(void)kvnshow{
    
    [KVNProgress show];
    
}

-(void)ACtiveInactiveData{
    
    NSLog(@"%@",activeInactive);
    
      self.txtInviteLive.text = [NSString stringWithFormat:@"%@",[activeInactive valueForKey:@"totalinvitee"]];
    
    confTyep = [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"confData"]valueForKey:@"confDialType"]objectAtIndex:0]];
    
    NSLog(@"%@",confTyep);
    
    
    
    NSPredicate*predicate = [NSPredicate predicateWithFormat:@"active ==%d",1];
    NSPredicate*predicate2 = [NSPredicate predicateWithFormat:@"active ==%d",2];
    NSPredicate*predicate3 = [NSPredicate predicateWithFormat:@"active ==%d",0];
    
    NSArray*ActiveArray = [[activeInactive valueForKey:@"resList"]filteredArrayUsingPredicate:predicate];
    
    NSArray*NotActiveArray = [[activeInactive valueForKey:@"resList"] filteredArrayUsingPredicate:predicate2];
     NSArray*NotActivezero = [[activeInactive valueForKey:@"resList"] filteredArrayUsingPredicate:predicate3];
    
    int joined = (int)ActiveArray.count ;
    int Notjoined = (int)NotActiveArray.count  + (int)NotActivezero.count;
    
    
    
    
    self.txtJoinedLive.text = [NSString stringWithFormat:@"%d",joined];
    self.txtNotJoinedLive.text = [NSString stringWithFormat:@"%d",Notjoined];
    self.txtInviteLive.text = [NSString stringWithFormat:@"%@",[activeInactive valueForKey:@"totalinvitee"]];
    
    
}




////////////////////////////////////////////selF Drop ///////////////////////////////////////

-(void)ConfSelfDRopApi{
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confselfdrop?confId=%@&personId=%@",ConfId,personId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        selfDrop = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(SelfDropResult) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"POST"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    
//    
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      
//                                    selfDrop   =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
//                                      NSLog(@"%@",selfDrop);
//                                      
//                                      
//                            [self performSelectorOnMainThread:@selector(SelfDropResult) withObject:nil waitUntilDone:YES];
//                                     
//
//                                      
//                                  }];
//    [task resume];
    
}

-(void)SelfDropResult{
    if ([[selfDrop valueForKey:@"message"]isEqualToString:@"success"]) {
        
      //  [_btnRecord setSelected:YES];
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[selfDrop valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
}



//////////////////////////////////// single participantMute-Unmute /////////////////////////////

-(void)singleParticipantMute{
    
//    NSDictionary *headers = @{ @"token": Tokenid,
//                               @"cache-control": @"no-cache",
//                               @"postman-token": @"544ba013-03da-0921-2bc2-0bdb8f6fb7a6" };
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confparticipantmute?confId=%@&status=mute&mobile=%@",singleConfID,MobileStr];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        singleParticipantMute = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(singleParticipantMuteResult) withObject:nil waitUntilDone:YES];
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
   
}
-(void)singleParticipantMuteResult{
    if ([[singleParticipantMute valueForKey:@"message"]isEqualToString:@"success"]) {
        
        
       //  [singleMuteTag setSelected:YES];
        
        [self.tableview reloadData];
        
    
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[singleParticipantMute valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
}

-(void)singleParticipantUnMute{
    
    

    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confparticipantmute?confId=%@&status=un-mute&mobile=%@",singleConfID,MobileStr];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        singleParticipantUnMute = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(singleParticipantUnMuteResult) withObject:nil waitUntilDone:YES];
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];


    
}

-(void)singleParticipantUnMuteResult{
    if ([[singleParticipantUnMute valueForKey:@"message"]isEqualToString:@"success"]) {
        
         [singleMuteTag setSelected:NO];
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[singleParticipantUnMute valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
}


////////////////////////////////// END SINGAL PARTICIPANT CALL ///////////////////////////

-(void)singleParticipantEndCall{

    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confparticipantdrop?confId=%@&mobile=%@",singleConfID,MobileStr];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        singleParticipantEndCall = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(singleParticipantEndCallResult) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

  

}

-(void)singleParticipantEndCallResult{
    if ([[singleParticipantEndCall valueForKey:@"message"]isEqualToString:@"success"]) {
        
       // [singleEndCallTag setSelected:YES];
        
        [self.tableview reloadData];
        
        
        
    }else{
         [singleEndCallTag setSelected:NO];
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[singleParticipantEndCall valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
}

//////////////////// //Retry Single Participant if call is dialIn/////////////////////////////////

-(void)RetrySingleParticipantDianlin{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confdialinreminder?confId=%@&mobile=%@",singleConfID,MobileStr];
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        RetrySingleDianlinResult = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(RetrySingleParticipantDianlinResult) withObject:nil waitUntilDone:YES];
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];



    
}
-(void)RetrySingleParticipantDianlinResult{
    if ([[RetrySingleDianlinResult valueForKey:@"message"]isEqualToString:@"success"]) {
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Successs" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        
        
        [alert show];
        
        
        
        //  [_btn setSelected:YES];
        NSLog(@"Success");
        
        
//        
//        [singleEndCallTag setSelected:NO];
       // [singleRefreshTag setSelected:YES];
       
        [self.tableview reloadData];
        
        
       // [singleMuteTag setEnabled:NO];
        
        
        
        
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[RetrySingleDianlinResult valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
}


/////////////////////Retry Single Participant if call is dialOut////////////////////////

-(void)RetrySingleParticipantDianlOut{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confparticipantdialout?confId=%@&mobile=%@",singleConfID,MobileStr];
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        RetrySingleDialOut = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(RetrySingleDialOutResult) withObject:nil waitUntilDone:YES];
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    


    
    
}
-(void)RetrySingleDialOutResult{
    if ([[RetrySingleDialOut valueForKey:@"message"]isEqualToString:@"success"]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Successs" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];

        
//     [singleRefreshTag setSelected:YES];
        
        
        //  [_btn setSelected:YES];
        NSLog(@"Success");
        
        
//         [singleEndCallTag setSelected:NO];
      //  [singleMuteTag setEnabled:NO];

        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[RetrySingleDialOut valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
}



/////////////////////////////////End conference///////////////////////////////////////

-(void)ConfDRopApi{
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confdrop?confId=%@",ConfId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        ConfDRopApi = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(ConfDropResult) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
}

-(void)ConfDropResult{
    if ([[ConfDRopApi valueForKey:@"message"]isEqualToString:@"success"]) {
        
          [_btnAllConfEnd setSelected:YES];
        
        NSLog(@"Success");
        
        
        
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[ConfDRopApi valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
}

//////////////////////////////////AllMuteConfernce///////////////////////////////////

-(void)ConfAllMute{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confallmute?confId=%@&status=mute",ConfId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        confAllMute = responseObject ;
        [self performSelectorOnMainThread:@selector(ConfAllMuteResult) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    

}

-(void)ConfAllMuteResult{
    if ([[confAllMute valueForKey:@"message"]isEqualToString:@"success"]) {
        
      // [_btnAllMute setSelected:YES];
        
        [self ConfSelfUnMute];
        
        
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[confAllMute valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
   
}

//UnMute
-(void)ConfAllUnMute{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confallmute?confId=%@&status=un-mute",ConfId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        confAllUnMute = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(ConfAllUnMuteResult) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    

}


-(void)ConfAllUnMuteResult{
    if ([[confAllUnMute valueForKey:@"message"]isEqualToString:@"success"]) {
        
   [_btnAllMute setSelected:NO];
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[confAllUnMute valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
}


////////////////////////////////// remindAll if dialIn ///////////////////////////

///hide dialOut Button

-(void)RemindAllApi{
    
    [self.btnRemindAll setHidden:YES];
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confdialin?confId=%@",ConfId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        remindAll = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(remindAllResult) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      
//                                      
//                                      
//                                      [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
//                                      
//                                      if (data != nil) {
//                                          remindAll =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//                                          NSLog(@"%@",remindAll);
//                                          [self performSelectorOnMainThread:@selector(remindAllResult) withObject:nil waitUntilDone:YES];
//                                          
//                                      }
//                                      
//                                      
//                                      
//                                  }];
//    
//    [task resume];
    
    
}

-(void)remindAllResult{
    if ([[remindAll valueForKey:@"message"]isEqualToString:@"success"]) {
        
        //  [_btn setSelected:YES];
       
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[remindAll valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[remindAll valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
}


//// if dialOut call cONFdialOutAPI

-(void)confDialOutApi{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confdialout?confId=%@",ConfId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        dialOut = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(dialOutResult) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      
//                                      
//                                      [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
//                                      
//                                      if (data != nil) {
//                                           dialOut =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//                                      }
//                                   [self performSelectorOnMainThread:@selector(dialOutResult) withObject:nil waitUntilDone:YES];
//                                      
//                                      
//                                  }];
//    
//    [task resume];
    
    
}

-(void)dialOutResult{
    if ([[dialOut valueForKey:@"message"]isEqualToString:@"success"]) {
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Success" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[remindAll valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
}




- (IBAction)dialOutClicked:(id)sender {
    [actInactTask  cancel];
    managerAf = nil;
    
    activeInactiveSession= nil;
    isSessionNil = YES;
    [self  confDialOutApi];
    [self.btnRemindAll setHidden:NO];
}

- (IBAction)remindAllClicked:(id)sender {
    
    [actInactTask  cancel];
    managerAf = nil;
    activeInactiveSession= nil;
    isSessionNil = YES;
    
    [self RemindAllApi];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == endConfalert) {
        if (buttonIndex == 1) {
            
            [actInactTask  cancel];
            managerAf = nil;
            activeInactiveSession= nil;
            isSessionNil = YES;
            
            
            [self  ConfDRopApi];
            
            
        }
    }else if (alertView == singleEndAlert) {
        
        if (buttonIndex == 1) {
            
            UIImage*IMG = [UIImage imageNamed:@"circular-arrow.png"];
            
          //  [singleRefreshTag setSelected:NO];
                  [singleRefreshTag setImage:[UIImage imageNamed: @"reload.png"] forState:UIControlStateNormal];
            singleRefreshTag.enabled = YES ;
            
            [timerBtnRtry invalidate];
            
            MobileStr =  [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"pmobile"]objectAtIndex:singleEndCallTag.tag]];
            NSLog(@"%@",MobileStr);
            singleConfID = [NSString stringWithFormat:@"%@",[[[activeInactive valueForKey:@"resList"]valueForKey:@"confId"]objectAtIndex:singleEndCallTag.tag]];
            
            
            if (!singleEndCallTag.isSelected) {
                
                
                [self singleParticipantEndCall];
                
            }else{
                
                [singleEndCallTag setSelected:NO];
                
                
            }

            
        }
    }
    
}

-(void)ConfSelfUnMute{
    
    //    NSDictionary *headers = @{ @"token": Tokenid,
    //                               @"cache-control": @"no-cache",
    //                               @"postman-token": @"d35daf96-e707-9136-1eac-340a8d628055" };
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/confselfmute?confId=%@&personId=%@&status=un-mute",ConfId,personId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        confSelfunMute = responseObject ;
        [self performSelectorOnMainThread:@selector(selfUnMuteResult) withObject:nil waitUntilDone:YES];
        
        
        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    
    
    
    
}
-(void)selfUnMuteResult{
    
    if ([[confSelfunMute valueForKey:@"message"]isEqualToString:@"success"]) {
        
        [_btnAllMute setSelected:NO];
        
        
    }else{
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[confSelfunMute valueForKey:@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    isSessionNil = NO ;
    [self GetActiveInactiveApi];
    
    
    
}


-(void)GetControlConferenceDetailsconference{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/getControlConferenceDetails?confId=%@&personId=%@",ConfId,personId];
    
    
    managerAfConf = [AFHTTPSessionManager manager];
    managerAfConf.requestSerializer = [AFJSONRequestSerializer serializer];
    [managerAfConf.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [managerAfConf GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        controlConferernce = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(controlConferceData) withObject:nil waitUntilDone:YES];
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
}


-(void)controlConferceData{
    
    status = [[controlConferernce valueForKey:@"controlres"]valueForKey:@"confStatus"];
    NSLog(@"%@",status);
    
    NSString *confDialType =   [[[controlConferernce valueForKey:@"confData"] objectAtIndex:0] valueForKey:@"confDialType"];
    NSLog(@"%@",confDialType);
    
    dialMe = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"selfactive"]];
    
    [[NSUserDefaults standardUserDefaults]setValue:confDialType forKey:@"confDialType"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    allParticipantsMute = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"allparticipantmute"]];
    NSLog(@"%@",allParticipantsMute);
    
    end = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"end"]];
    NSLog(@"%@",end);
    
    liverecording = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"liverecording"]];
    NSLog(@"%@",liverecording);
    
    
    
    selfmute = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"allparticipantmute"]];
    NSLog(@"%@",selfmute);
    
    
    if ([selfmute isEqualToString:@"0"]) {
        
        [_btnAllMute setSelected:NO];
        
    }else if ([selfmute isEqualToString:@"1"]) {
        
        [_btnAllMute setSelected:YES];
        
    }
    
    
    
//    if ([role isEqualToString:@"ROLE_SUPER_ADMIN"]){
//        if ([status isEqualToString:@"Running"]) {
//            
//            [_btnParticipants setEnabled:YES];
//            self.btnAddOn.enabled = YES ;
//            self.btnDialMe.enabled = YES ;
//            self.btnRecord.enabled = YES ;
//            if (_btnParticipantMute.isSelected) {
//                
//                self.btnSelfMute.enabled = YES ;
//            }else{
//                
//                self.btnSelfMute.enabled = NO ;
//            }
//            
//            
//            self.btnEndConfernce.enabled = YES ;
//            self.btnParticipants.enabled = YES ;
//            self.btnParticipantMute.enabled = YES ;
//            
//            
//            
//            [self synchonizing];
//            
//            
//        }
//        else{
//            
//            [_btnParticipants setEnabled:NO];
//            self.btnAddOn.enabled = NO ;
//            self.btnDialMe.enabled = NO ;
//            self.btnRecord.enabled = NO ;
//            self.btnSelfMute.enabled = NO ;
//            self.btnEndConfernce.enabled = NO ;
//            self.btnParticipants.enabled = NO ;
//            self.btnParticipantMute.enabled = NO ;
//        }
//    }else if ([role isEqualToString:@"ROLE_SUPER_HOST"]){
//        if ([status isEqualToString:@"Running"]) {
//            
//            [_btnParticipants setEnabled:YES];
//            self.btnAddOn.enabled = YES ;
//            self.btnDialMe.enabled = YES ;
//            self.btnRecord.enabled = YES ;
//            if (_btnParticipantMute.isSelected) {
//                
//                self.btnSelfMute.enabled = YES ;
//            }else{
//                
//                self.btnSelfMute.enabled = NO ;
//            }
//            // self.btnSelfMute.enabled = YES ;
//            self.btnEndConfernce.enabled = YES ;
//            self.btnParticipants.enabled = YES ;
//            self.btnParticipantMute.enabled = YES ;
//            
//            [self synchonizing];
//            
//            
//        }
//        else{
//            
//            [_btnParticipants setEnabled:NO];
//            self.btnAddOn.enabled = NO ;
//            self.btnDialMe.enabled = NO ;
//            self.btnRecord.enabled = NO ;
//            self.btnSelfMute.enabled = NO ;
//            self.btnEndConfernce.enabled = NO ;
//            self.btnParticipants.enabled = NO ;
//            self.btnParticipantMute.enabled = NO ;
//            
//            
//            
//        }
//    }
//    
//    else{
//        if ([status isEqualToString:@"Running"]) {
//            
//            [_btnParticipants setEnabled:YES];
//            self.btnAddOn.enabled = NO ;
//            self.btnDialMe.enabled = NO ;
//            self.btnRecord.enabled = NO ;
//            if (_btnParticipantMute.isSelected) {
//                
//                self.btnSelfMute.enabled = YES ;
//            }else{
//                
//                self.btnSelfMute.enabled = NO ;
//            }
//            //  self.btnSelfMute.enabled = YES ;
//            self.btnEndConfernce.enabled = YES ;
//            self.btnParticipants.enabled = NO ;
//            self.btnParticipantMute.enabled = NO ;
//            
//            NSString *dialMe = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"selfactive"]];
//            NSLog(@"%@",confDialType);
//            
//            if ([dialMe isEqualToString:@"0"]) {
//                
//                
//                [_btnDialMe setEnabled: YES];
//                
//            }
//            else{
//                
//                [_btnDialMe setEnabled: NO];
//            }
//            
//            
//            [self synchonizing];
//            
//            
//        }
//        else{
//            
//            [_btnParticipants setEnabled:NO];
//            self.btnAddOn.enabled = NO ;
//            self.btnDialMe.enabled = NO ;
//            self.btnRecord.enabled = NO ;
//            self.btnSelfMute.enabled = NO ;
//            self.btnEndConfernce.enabled = NO ;
//            self.btnParticipants.enabled = NO ;
//            self.btnParticipantMute.enabled = NO ;
//            
//            NSString *dialMe = [NSString stringWithFormat:@"%@",[[controlConferernce valueForKey:@"controlres"]valueForKey:@"selfactive"]];
//            NSLog(@"%@",confDialType);
//            
//            
//            
//            
//            
//        }
//        
//    }
    
    
    
    
    
}


//-(void)synchonizing{
//    
//    
//    if ([dialMe isEqualToString:@"0"]) {
//        
//        
//        [_btnDialMe setEnabled: YES];
//        
//    }
//    else{
//        
//        [_btnDialMe setEnabled: NO];
//    }
//    
//    
//    
//    if ([selfmute isEqualToString:@"0"]) {
//        
//        self.btnSelfMute.enabled = YES ;
//        
//        [self.btnSelfMute setSelected:NO] ;
//        
//        
//    }
//    else if ([selfmute isEqualToString:@"2"]) {
//        
//        self.btnSelfMute.enabled = NO ;
//        
//    }
//    else{
//        
//        //        [_btnSelfMute setEnabled: NO];
//        [self.btnSelfMute setSelected:YES];
//        self.btnSelfMute.enabled = YES ;
//        
//    }
//    
//    
//    if ([liverecording isEqualToString:@"0"]) {
//        
//        self.btnRecord.enabled = YES ;
//        [self.btnRecord setSelected:NO] ;
//        
//        
//        
//    }else if ([selfmute isEqualToString:@"2"]) {
//        
//        self.btnSelfMute.enabled = NO ;
//        self.btnRecord.enabled = NO ;
//        
//        
//    }else{
//        
//        self.btnRecord.enabled = YES ;
//        
//        [self.btnRecord setSelected:YES] ;
//        
//    }
//    
//    
//    if ([end isEqualToString:@"0"]) {
//        
//        [self.btnEndConfernce setSelected:NO] ;
//        
//        
//        
//    }else{
//        
//        [self.btnEndConfernce setSelected:YES];
//    }
//    
//    
//    if ([status isEqualToString:@"End"]) {
//        
//        self.btnAddOn.enabled = NO ;
//        self.btnDialMe.enabled = NO ;
//        self.btnRecord.enabled = NO ;
//        self.btnSelfMute.enabled = NO ;
//        self.btnEndConfernce.enabled = NO ;
//        self.btnParticipants.enabled = NO ;
//        self.btnParticipantMute.enabled = NO ;
//        self.btnAcknowledgement.enabled = NO;
//        
//        
//        
//    }
//    if (_btnParticipantMute.isSelected) {
//        
//        [self.btnSelfMute setEnabled:NO];
//    }else{
//        [self.btnSelfMute setEnabled:YES];
//    }
//    
//    
//    //    if ([allParticipantsMute isEqualToString:@"1"]) {
//    //
//    //        self.btnSelfMute.enabled = NO ;
//    //        [self.btnParticipantMute setSelected:YES] ;
//    //        
//    //        
//    //        
//    //        
//    //    }else{
//    //        
//    //         [self.btnParticipantMute setSelected:NO] ;
//    //        
//    //        [_btnSelfMute setEnabled: YES];
//    //        
//    //    }
//    
//}

@end
