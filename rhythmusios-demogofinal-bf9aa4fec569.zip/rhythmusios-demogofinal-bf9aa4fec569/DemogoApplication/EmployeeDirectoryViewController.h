//
//  EmployeeDirectoryViewController.h
//  schedulePAgeDesign
//
//  Created by Rhythmus on 26/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmployeeDirectoryViewController : UIViewController
@property (strong, nonatomic) IBOutlet UISearchBar *searchbar;

- (IBAction)BtnBack:(id)sender;

- (IBAction)btnCheckBox:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btncheckbox;

@end
