//
//  VerifyAccountViewController.m
//  DemogoApplication
//
//  Created by Rhythmus on 21/03/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "VerifyAccountViewController.h"

BOOL checkpan=false;
BOOL checkpro=false;


@interface VerifyAccountViewController ()<NSURLSessionDelegate,NSURLSessionDataDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>
{
    UITableViewCell *cell;
    NSString *BtnTitle ;
    NSString *citynamePush;
    NSString *cityName;
    NSString *imgfile;
    
    NSMutableArray *CityArray;
    NSMutableArray *PinARRAY;
    NSData* SendData;
     NSData* sendok;
    
    
    NSString *urlstring;
    NSURL *url;
    NSMutableDictionary *GetDicDta;
    NSMutableDictionary *CityResponseData;
    
    NSMutableDictionary *checkOK;
    NSMutableDictionary *checkNO;
    NSDictionary *userEmailID;
    NSMutableArray *collectState;
    NSMutableArray *BillingData;
    NSMutableArray *BillingUncheck ;
    
    
    UIImagePickerController *PancCardpicker;
    UIImagePickerController *panCardpicker2;
    
    
    UIImagePickerController *profilePICKER;
    UIImagePickerController *profilePicker2;
    
    
    
    UIImageView *panimag;
    UIImage *profileImage;
    
    
     BOOL Check;
     BOOL CheckBox;
    BOOL imageBool;
    BOOL panBool;
    NSData *imageData;
    NSData *pancard;
    NSString *cityPUSH;
    NSString *state;
    NSString *ZipData;
    
    
}
@property (strong, nonatomic) IBOutlet UITextField *addressTextField;

@property (strong, nonatomic) IBOutlet UIAlertController *AlertCtrl;

@property (strong, nonatomic) IBOutlet UIView *imageViewBackCompany;

@property (strong, nonatomic) IBOutlet UITextField *PannumberTextField;

@property (strong, nonatomic) IBOutlet UIScrollView *scrollViewVertically;

@end

@implementation VerifyAccountViewController

-(void)viewDidAppear:(BOOL)animated
{
    _scrollViewVertically.showsVerticalScrollIndicator=YES;
   
    _scrollViewVertically.scrollEnabled=YES;
    
    _scrollViewVertically.userInteractionEnabled=YES;
    
    _scrollViewVertically.contentSize = CGSizeMake(0,self.scrollViewVertically.frame.size.height +300);
    
    
    
   // [self.scrollViewVertically setContentOffset: CGPointMake(0, self.scrollViewVertically.contentOffset.y)];
   // self.scrollViewVertically.directionalLockEnabled = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.scrollViewVertically.contentSize = CGSizeMake(0, 620);
    
    imageBool=NO;
    
    Check = YES;
    
    panBool=NO;
    
    panimag= [[UIImageView alloc]init];
    
    profileImage = [[UIImage alloc]init];
    
    self.tableview.delegate = self;
    
    self.tableview.dataSource  = self;
    
    self.pinTableView.delegate = self;
    
    self.pinTableView.dataSource  = self;
    
    
    checkNO = [[NSMutableDictionary alloc]init];
    
    checkOK = [[NSMutableDictionary alloc]init];
    
    cityPUSH = [[NSString alloc]init];
    
    state= [[NSString alloc]init];
    
    ZipData = [[NSString alloc]init];
    
    
    BillingData = [[NSMutableArray alloc]init];
    
    BillingUncheck  = [[NSMutableArray alloc]init];
    
    cityName = [[NSString alloc]init];
    
    citynamePush = [[NSString alloc]init];
    
    PinARRAY= [[NSMutableArray alloc]init];
    
    BtnTitle  = [[NSString alloc]init];
    
    
    _CompanyImageOutlet.layer.cornerRadius = 10.5;
    
    _CompanyImage.layer.cornerRadius = 45;
    
    _CompanyImage.clipsToBounds=YES;
    
    self.CityTableview.hidden=YES;
    
    self.tableview.hidden=YES;
    
    self.pinTableView.hidden = YES;
    
    
    
    
    self.BADDImg.hidden =YES;
    
    self.BSatImg.hidden =YES;
    
    self.BCITimg.hidden =YES;
    
    self.BPINimg.hidden =YES;
    
    
    //////              textfield of billing address        ////////
    
    self.Billingaddress.hidden =YES;
    
    self.BillingState.hidden =YES;
    
    self.BillingCity.hidden =YES;
    
    self.BillingPinCode.hidden =YES;
    
    self.saveButonAutolayout.constant = 8;

    
    
    
    
    
   // _CompanyImage.layer.cornerRadius =30;
    
    
    
    collectState = [[NSMutableArray alloc]init];
    
    CityArray = [[NSMutableArray alloc]init];
    
                                        //      Api hit Method Create
    
    [self SaveDataSecondApi];
    
    [self setAlertCtrl];
    
    
    
    
    
    
    
    
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}












- (BOOL)textFieldShouldReturn:(UITextField *)textField


{
    
   
    
    //[self. resignFirstResponder];
    
       [self.tableview reloadData];

    
    return YES;
    
    
}

-(void)SaveDataSecondApi;

{
    
    urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/states"];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    url = [NSURL URLWithString:urlstring];
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
                                              NSLog(@" the databse theXml is  =====  %@",theXML);
                                              
                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
                                              userEmailID = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                              
                                              NSLog(@"The State Response is  ===  %@" , userEmailID);
                                              
                                              
                                              
                                              for (NSMutableDictionary *dic in userEmailID) {
                                                  NSMutableString *str = [NSMutableString stringWithFormat:@"%@",[dic valueForKey:@"state"]];
                                                  NSLog(@"the value is = %@",str);
                                                  
                                                  [collectState addObject:str];
                                                  
                                                  
                                              }
                                              
                                              
                                              
                                          }];
    
    
    
    
    
    [self.TableCompanyList reloadData];
    
    [postDataTask resume];
    
    
    
    
    
    
    
}


/////////           Table Cell Select Row Method             ////////////


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
   
    if (tableView == self.tableview)
    
        
    {
      
        
        cell=[self.tableview cellForRowAtIndexPath:indexPath];
   
        [self.StateverifyOUtlet setTitle:cell.textLabel.text forState:UIControlStateNormal];
    
        state = self.StateverifyOUtlet.titleLabel.text;
        
        
        
        
        
        
        NSString *replace = [NSString stringWithFormat:@"%@",cell.textLabel.text];
        
        NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"&"];
        
        BtnTitle =  [replace stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];

        BtnTitle = [[BtnTitle componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString:@"%26"];
        
        NSLog(@"%@",BtnTitle);

        self.tableview.hidden=YES;
        
        
        [self CityDetailsResponseData];
        
    
        
    }
    
    else if (tableView == self.CityTableview)
        
    {
        cell=[self.CityTableview cellForRowAtIndexPath:indexPath];
        
        [self.cityOUtlet  setTitle:cell.textLabel.text forState:UIControlStateNormal];
        
        NSString *cityspace = [NSString stringWithFormat:@"%@",cell.textLabel.text];
        
        citynamePush =  [cityspace stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        
        NSLog(@"%@",citynamePush);
        
        cityPUSH = self.cityOUtlet.titleLabel.text;
        
        
        [self PINNUMfetch];

        self.CityTableview.hidden =YES;
        
        
       // self.   .hidden=YES;
    }
    
    
    else if (tableView == self.pinTableView)
        
    {
        cell=[self.pinTableView cellForRowAtIndexPath:indexPath];
        
        [self.pin  setTitle:cell.textLabel.text forState:UIControlStateNormal];
        
        ZipData = self.pin.titleLabel.text;
        self.pinTableView.hidden =YES;
        
        
           }

    
    
    
    
}



                ////////////                Row OF TABLE VIEW           //////////////


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
                                        ////////                first state table view number of count row           /////////
    
    if (tableView==self.tableview)
    {
        return [collectState count];
    }
    
    
    
                                        ////////                Second City table view number of count row           /////////

    
    else if (tableView==self.CityTableview)
    {
        return [CityArray count];
    }
    
    
                                        ////////                Third  PinCard NUMber SHow Table ROw            /////////
    
    
    return [PinARRAY count];
}






                ////////////                UITableViewCell           //////////////


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString * cellID = @"cell";
    
     cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    if (cell ==nil)
        
    {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        
    }
    
    
    
                                                    /////////               State    First table view                   /////////
    
    
    if (tableView == self.tableview)
        
    {
        cell.textLabel.text = [collectState objectAtIndex:indexPath.row];

    }
    
    
                                                    ///////////             CIty   second tableview                 // // / //
    
    else if (tableView == self.CityTableview)
    
    {
        cell.textLabel.text =[CityArray objectAtIndex:indexPath.row];
    }
    
    
                                                    ///////////             PINCODE   tableview cell                // // / //
    
    else if (tableView == self.pinTableView)
        
    {
        cell.textLabel.text =[PinARRAY objectAtIndex:indexPath.row];
    }

    return cell;
    
    
    
}      
 


- (IBAction)stateVerifyButton:(id)sender {
    
    ///[self SaveDataSecondApi];
    [self.tableview reloadData];
    
    if (self.tableview.hidden==YES)
    {
        
        
        self.tableview.hidden=NO;
    }else
    {
        
        
        self.tableview.hidden=YES;
        
       
        
    }

    
    
    
}

-(void)CityDetailsResponseData;

{
    NSError *linkError;
    

    
    NSString * urlstri=[NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/cities?state=%@",BtnTitle];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *urlLink= [NSURL URLWithString:urlstri];
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:urlLink cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    NSMutableDictionary *getdic =  [NSMutableDictionary dictionaryWithObjectsAndKeys:BtnTitle,@"state", nil];
    
    NSData *statesendData = [NSJSONSerialization dataWithJSONObject:getdic options:kNilOptions error:&linkError];
    
    [SendingRequest setHTTPBody:statesendData];

    [SendingRequest setHTTPMethod:@"GET"];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              dispatch_async(dispatch_get_main_queue(),^{
                                              
                                                  NSError *error;
                                            
                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                                  
                                                  
                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
                                              NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                              
                                              NSLog(@"The State Response is  ===  %@" ,dict);
                                                  
        for (NSMutableDictionary *cityNm in dict)
                    
        {
                    NSMutableString *CN = [NSMutableString stringWithFormat:@"%@",[cityNm valueForKey:@"city"]];
            
                    NSLog(@"the value is = %@",CN);
            
            

                                    [CityArray addObject:CN];
            
                                            if([cityNm valueForKey:@"city"])
                
                                                {
                
                                                    [self SaveDataSecondApi];
                                                
                                                }

            
            
                                                  }
                                                  
                                                  
                                                  

                                                  
                                                  
                                                  

                                              
                                              });
                                              
                                              
                                              
                                          }];
    
    
    
    
    
    
    
    [postDataTask resume];
    
    
    
    
    
    
    
}






- (IBAction)cityButton:(id)sender {
    
    
    
    [self.CityTableview reloadData];
    
    if (self.CityTableview.hidden==YES)
    {
        
        
        self.CityTableview.hidden=NO;
    }else
    {
        
        
        self.CityTableview.hidden=YES;
        
        
    }

    
}











////////////////..............     PIN NUmber fetch api  .  . .. . . .


-(void)PINNUMfetch;
{
    NSError *error ;
    
    NSString *cityString = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/pin?city=%@",citynamePush];
    NSURLSessionConfiguration *Config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *SESSIONdata = [NSURLSession sessionWithConfiguration:Config delegate:self delegateQueue:nil];
    
    
    NSURL *Link= [NSURL URLWithString:cityString];
    
    
    
    NSMutableURLRequest * SENDreq = [NSMutableURLRequest requestWithURL:Link cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SENDreq addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SENDreq addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    NSMutableDictionary *getdic =  [NSMutableDictionary dictionaryWithObjectsAndKeys:BtnTitle,@"state", nil];
    
    NSData *statesendData = [NSJSONSerialization dataWithJSONObject:getdic options:kNilOptions error:&error];
    
    [SENDreq setHTTPBody:statesendData];
    
    [SENDreq setHTTPMethod:@"GET"];
    
    NSLog(@"%@",[SENDreq allHTTPHeaderFields]);
    
    NSURLSessionDataTask *postDataTask = [SESSIONdata dataTaskWithRequest:SENDreq completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                  
                                                  NSError *error;
                                                  
                                                  NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                                  
                                                  
                                                  NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                                  
                                                  
                                                  NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                                  
                                                  NSLog(@"The State Response is  ===  %@" ,dict);
                                                  
                                                  for (NSMutableDictionary *cityNm in dict)
                                                      
                                                  {
                                                      NSMutableString *CN = [NSMutableString stringWithFormat:@"%@",[cityNm valueForKey:@"pinCode"]];
                                                      
                                                      NSLog(@"the value is = %@",CN);
                                                      
                                                      
                                                      
                                                      [PinARRAY addObject:CN];
                                                      
                                                      
                                                  }
                                                  
                                                  
                                                  
                                                  
                                                  
                                                  
                                              });
                                              
                                              
                                              
                                          }];
    
    
    
    
    
    
    
    [postDataTask resume];
    
    
    
    
    
    
    
}


- (IBAction)pinbutton:(id)sender
{

        [self.pinTableView reloadData];
    
    if (self.pinTableView.hidden==YES)
   
                {
        
                        self.pinTableView.hidden=NO;
                }
    
                        else
                                    {
        
                                            self.pinTableView.hidden=YES;
        
        
                                    }
    

    
}














            ////////                        PanCard Image Load Or Take Image                /////////////


-(void)setAlertCtrl;
{
    panBool = YES;
    
    if (panBool) {
        
    self.AlertCtrl = [UIAlertController alertControllerWithTitle:@"selectImage" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction *camera = [UIAlertAction actionWithTitle:@"Camera" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                             
                             {
                                 [self handleCamera];
                             }];
    
    UIAlertAction *Library  = [UIAlertAction actionWithTitle:@"Image Gallery" style:UIAlertActionStyleDefault handler:^(UIAlertAction *  action)
                               
                               {
                                   
                                   [self handleGallery];
                               }];
    
    UIAlertAction *Cancel  = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *  action) {
        
    }];
    
    [self.AlertCtrl addAction:camera];
    [self.AlertCtrl addAction:Library];
    [self.AlertCtrl addAction:Cancel];
    
    }
    
}


-(void)handleCamera;
{
    PancCardpicker= [[UIImagePickerController alloc]init];
    
    PancCardpicker .delegate =self;
    
    [PancCardpicker setSourceType:UIImagePickerControllerSourceTypeCamera];
    
    [self presentViewController:PancCardpicker animated:YES completion:nil];
    
}


-(void)handleGallery;
{
    
    checkpan=YES;
    panCardpicker2 = [[UIImagePickerController alloc]init];
    
    panCardpicker2 .delegate =self;
    
    [panCardpicker2 setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    
    [self presentViewController:panCardpicker2 animated:YES completion:nil];
    
   
    
    
}





- (IBAction)uploadImage:(id)sender


{
    
    
    [self presentViewController:self.AlertCtrl animated:YES completion:nil];
    
    
    
    
    
    
}





        ////////////////                   profile pic image load number                          ///////////////



- (IBAction)ProfilePicFetchButton:(id)sender

{
   
    checkpro = YES;
    profilePICKER = [[UIImagePickerController alloc]init];
    
    profilePICKER  .delegate =self;
    
    [profilePICKER  setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    
    [self presentViewController:profilePICKER  animated:YES completion:nil];
        
    
    
    
    
    
}
-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    
    UIImage *pro;
    UIImage *pro1;
    if (checkpro==YES) {
        profileImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        UIImage *pro = [[UIImage alloc]init];
        pro =profileImage;
        self.CompanyImage.image =profileImage;
        checkpro=NO;
        
    }
    if (checkpan==YES) {
        PANimage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        UIImage *pro1 = [[UIImage alloc]init];
        pro1 =PANimage;
        checkpan=NO;
        //self.CompanyImage.image =profileImage;
    }
    [self dismissViewControllerAnimated:YES completion:NULL];
        
    [self ADminAddressORcompanyImage:pro:pro1];
    
    
        
  //  PANimage = [info  objectForKey:@"UIImagePickerControllerOriginalImage"];

  // [panimag setImage:PANimage];
        
        // [self dismissViewControllerAnimated:YES completion:NULL];
    }
    
   
    
    
    
    ////........................  save image in gallery    ........///////
    
        
                              //  UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
    
                                //UIImageWriteToSavedPhotosAlbum(PanImage, nil, nil, nil);

    //......................./////............................/////................////////////..........



-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker

{
    [self dismissViewControllerAnimated:YES completion:NULL];
}











  ///////                   Company / Verify api call json
/*
-(void)ADminAddressORcompanyImage;

{
    
    NSString *panImage = [UIImagePNGRepresentation(profileImage)
                                 base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    
    NSLog(@"the image details is ==  %@",panImage);
    
        NSString *profileCardImage = [UIImagePNGRepresentation(profileImage)
                                  base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    
        NSLog(@"the image details is ==  %@",profileImage);
    

    
    
    
    NSString *cityString = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/verify?cmpId=%@&cmpPanNo=%@&empRegReq=%@&src=%@",@"3288",self.PannumberTextField.text,@"false",@"APP"];
    NSLog(@"%@",cityString);

    
    
    
    NSDictionary *newDatasetInfo = [NSDictionary dictionaryWithObjectsAndKeys:profileCardImage,@"cmpLogo",panImage, @"cmpPan", nil];
    NSLog(@"the image path is = %@",newDatasetInfo);
    
    if([NSJSONSerialization isValidJSONObject:newDatasetInfo]){
        
        
        //convert object to data
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:newDatasetInfo options:kNilOptions error:nil];
        
        
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:cityString]];
        [request setHTTPMethod:@"POST"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        [request setHTTPBody:jsonData];
        
        
        NSURLSessionConfiguration *config=[NSURLSessionConfiguration defaultSessionConfiguration];
        
        NSURLSession *session=[NSURLSession sessionWithConfiguration:config];
        
        NSURLSessionDataTask *task=[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            
            if(response)
            
            {
                NSString *resp = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
                NSLog(@"Echo %@",resp);
                
                
                
            
            }
                                    else{
                
                                        NSLog(@"Timeout");
                                        
                                        
                                        
                
                                    }
                                    
                                    
                                    
                                    }];
        [task resume];
        
    }
    
    
        */
    
     
-(void)ADminAddressORcompanyImage :(UIImage *)profileimag :(UIImage *)pannimage
{
//    NSString *ProfilePicImage = [UIImagePNGRepresentation(image)
//                              base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
//
//    NSLog(@"the image details is ==  %@",ProfilePicImage);
//    
//    NSString *PanCardImage = [UIImagePNGRepresentation(PanImage)
//                              base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
//    
//    NSLog(@"the image details is ==  %@",PanCardImage);
    
    
    NSData *imgData = [NSData dataWithData:UIImagePNGRepresentation(pannimage)];
    // From data to string
    NSString *string = [[NSString alloc] initWithData:imgData encoding:NSUTF8StringEncoding];
    
    //
    NSData *imgData2 = [NSData dataWithData:UIImagePNGRepresentation(profileimag)];
    // From data to string
    NSString *string2 = [[NSString alloc] initWithData:imgData2 encoding:NSUTF8StringEncoding];
    
   
    
       
   NSString *cityString = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/verify?cmpId=%@&cmpPanNo=%@&empRegReq=%@&cmpLogo=%@&cmpPan=%@&src=%@",@"1730",@"123456789w",@"false",string2,string2,@"APP"];
//    NSLog(@"%@",cityString);
//    
   NSURLSessionConfiguration *Config = [NSURLSessionConfiguration defaultSessionConfiguration];
//    
//    
   NSURLSession *SESSIONdata = [NSURLSession sessionWithConfiguration:Config delegate:self delegateQueue:nil];
//    
//    
    NSURL *Link= [NSURL URLWithString:cityString];
    
    
    
    NSMutableURLRequest * SENDreq = [NSMutableURLRequest requestWithURL:Link cachePolicy:
                                     
                                     NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SENDreq addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SENDreq addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    NSString *tokenStringV = @"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI4MDU0NTExMDMxOlJPTEVfU1VQRVJfQURNSU46MTczMCIsImlhdCI6MTQ5MTI3OTI1OH0.KKnIluFymHkR9zEs3PdOK0B04xee8_jPaJ41ix5Z6ik";
    
    NSString *tokenstring = [NSString stringWithString:tokenStringV];
    
    NSLog(@"%@",tokenstring);
    
    [SENDreq addValue:tokenstring forHTTPHeaderField:@"token"];
    
    
    [SENDreq addValue:@"token" forHTTPHeaderField:@"Authorization"];
    

    
    [SENDreq setHTTPMethod:@"POST"];
    
    
    
    // NSData *PanIMG = UIImagePNGRepresentation(PanImage);

    
    
    
    
    NSString *boundary = @"---------------------------14737809831466499882746641449";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [SENDreq addValue:contentType forHTTPHeaderField: @"Content-Type"];
    
    NSMutableData *body = [NSMutableData data];
    
    [body appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Disposition: form-data; name=\"q\"\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:string2,@"cmpPan",string2,@"cmpLogo", nil];
    
    
    [body appendData:[[NSString stringWithFormat:@"%@",dic] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];

    
    
    
    
      //Important File                  //....[self addMultipartDataWithParameters:parameters toURLRequest:SENDreq];
    
    
    ////////////                            Multipart Encoding End                                  ///////
    
    
    
    
     [SENDreq setHTTPBody:body];
    
    
    
    
    NSLog(@"%@",[SENDreq allHTTPHeaderFields]);
    
    NSURLSessionDataTask *postDataTask = [SESSIONdata dataTaskWithRequest:SENDreq completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                  
                                                 NSError *error;
//                                                  
                                                  NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                                  
                                                  
                                                  NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
//
                                                  
                                                  NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                                  
                                                  NSLog(@"The State Response is  ===  %@" ,dict);
    
    
    
                                              });
                                          }];
    
    [postDataTask resume];
    
                ////////................BILLLING Address or other details  all json response or hit /...........


}


- (IBAction)BillingButton:(id)sender

{
   
    
    
    
    if (CheckBox ==NO)
    {
        
        
                 [self.BillingCheckBox setImage:[UIImage imageNamed:@"select.png"]];
        
        
        
    //////              image hide of billing address        ///////
    
        self.BADDImg.hidden =NO;
        self.BSatImg.hidden =NO;
        self.BCITimg.hidden =NO;
        self.BPINimg.hidden =NO;
        
        
        
        
                                    //////              textfield of billing address        ////////
        
        
        self.Billingaddress.hidden =NO;
        self.BillingState.hidden =NO;
        self.BillingCity.hidden =NO;
        self.BillingPinCode.hidden =NO;
        
        self.saveButonAutolayout.constant = 215;
        
        
        
    }
    
    
    else if(CheckBox ==YES)
        
    {
        
        
        [self.BillingCheckBox setImage:[UIImage imageNamed:@"deselect.png"]];
        self.BADDImg.hidden =YES;
        self.BSatImg.hidden =YES;
        self.BCITimg.hidden =YES;
        self.BPINimg.hidden =YES;
        
        
        //////              textfield of billing address        ////////
        
        self.Billingaddress.hidden =YES;
        self.BillingState.hidden =YES;
        self.BillingCity.hidden =YES;
        self.BillingPinCode.hidden =YES;
        
        self.saveButonAutolayout.constant = 8;
        
         }
    
}

    - (IBAction)SaveButton:(id)sender {
    
    
        [self SAVEDATAaddCityCompIdCmpPanNoStateZipType];
    
    }
    
    
    
-(void)SAVEDATAaddCityCompIdCmpPanNoStateZipType

{
    
   
    
    
    
    NSError *linkError;
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *PushLinkUrl = [NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/person/secure/addperson"];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
     NSString *tokenStringV = @"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI4MDU0NTExMDMxOlJPTEVfU1VQRVJfQURNSU46MTczMCIsImlhdCI6MTQ5MTI3OTI1OH0.KKnIluFymHkR9zEs3PdOK0B04xee8_jPaJ41ix5Z6ik";
    
    NSString *tokenstring = [NSString stringWithString:tokenStringV];
    
    NSLog(@"%@",tokenstring);
    
    [SendingRequest addValue:tokenstring forHTTPHeaderField:@"token"];
    
    
    [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];

    

    [SendingRequest setHTTPMethod:@"POST"];
    
    
    if (CheckBox==NO) {
        
        CheckBox= YES;
        
        NSMutableDictionary * BillingCheckedDtaa = [[NSMutableDictionary alloc]
                                                    initWithObjectsAndKeys:self.addressTextField.text,@"add",cityPUSH,@"city", @"1730"  ,@"cmpId",self.PannumberTextField.text,@"cmpPanNo",@"India",@"country",state,@"state",@"BILLING",@"type",ZipData,@"zip",@"APP",@"src",nil];
    
        NSMutableDictionary *OfficeAddressDta = [[NSMutableDictionary alloc]
                                                 initWithObjectsAndKeys:self.addressTextField.text,@"add",cityPUSH,@"city", @"1730"  ,@"cmpId",self.PannumberTextField.text,@"cmpPanNo",@"India",@"country",state,@"state",@"OFFICE",@"type",ZipData,@"zip",@"APP",@"src",nil];
        
        
        NSMutableArray *addressData =[[NSMutableArray alloc]init];
        
        [addressData addObject:OfficeAddressDta];
        
        [addressData addObject:BillingCheckedDtaa];
        
        
        checkOK=[[NSMutableDictionary alloc]initWithObjectsAndKeys:addressData,@"address", nil];
        
        
        [checkOK  setValue:@"1730" forKey:@"cmpId"];
        
        NSLog(@"the json data is = %@",checkOK);
        

        
        SendData= [NSJSONSerialization dataWithJSONObject:checkOK options:kNilOptions error:&linkError];
        
        [SendingRequest setHTTPBody:SendData];
        
    
    }
    
    else if ( CheckBox == YES)
    {
        CheckBox =NO;
        
        self.Billingaddress.text = self.addressTextField.text;
        
        self.BillingCity.text = cityPUSH;
        
        self.BillingState.text = state;
        
        self.BillingPinCode.text = ZipData;
        

        
        NSMutableDictionary* BillingUncheckedDtaa = [[NSMutableDictionary alloc]
                                                     initWithObjectsAndKeys:self.Billingaddress.text,@"add",_BillingCity.text,@"city",self.BillingPinCode.text,@"zip",@"India",@"country",_BillingState.text,@"state",@"BILLING",@"type",@"APP",@"src",nil];
        
        
        
        NSMutableDictionary *OfficeAddressDta = [[NSMutableDictionary alloc]
                                                 initWithObjectsAndKeys:self.addressTextField.text,@"add",cityPUSH,@"city", @"1730"  ,@"cmpId",self.PannumberTextField.text,@"cmpPanNo",@"India",@"country",state,@"state",@"OFFICE",@"type",ZipData,@"zip",@"APP",@"src",nil];
        
        
        NSMutableArray *addressData =[[NSMutableArray alloc]init];
        
        [addressData addObject:OfficeAddressDta];
        
        [addressData addObject:BillingUncheckedDtaa];
        
        
        checkOK=[[NSMutableDictionary alloc]initWithObjectsAndKeys:addressData,@"address", nil];
        
        
        [checkOK  setValue:@"3288" forKey:@"cmpId"];
        
        NSLog(@"the json data is = %@",checkOK);
        
        
        
        SendData= [NSJSONSerialization dataWithJSONObject:checkOK options:kNilOptions error:&linkError];
        
        [SendingRequest setHTTPBody:SendData];
        

    }
    
    
    
    
    
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                  
                                                  NSError *jsonError;
                                                  
                                                  NSArray* PassedJSon =[NSJSONSerialization JSONObjectWithData:data
                                                                        
                                                                                                       options:NSJSONReadingMutableContainers error:&jsonError];
                                                  
                                                  
                                                  
                                                  //NSLog(@"%@",[PassedJSonArray valueForKey:@"cmpId"]);
                                                  
                                                  // NSLog(@"%@",[PassedJSonArray valueForKey:@"token"]);
                                                  
                                                  
                                                  NSLog(@"%@",PassedJSon);
                                                  
                                              });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
    
  


}
@end
