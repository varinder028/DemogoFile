//
//  CorporaeWCsucessViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "CorporaeWCsucessViewController.h"
#import "CorporateHomeViewController.h"
#import "corporateLOginPAgeViewController.h"
#import "CorporateTabBarViewController.h"
#import "ViewController.h"
@interface CorporaeWCsucessViewController ()
@property (strong, nonatomic) IBOutlet UIView *LogLertview;


@end

@implementation CorporaeWCsucessViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
  //  self.navigationController.navigationBar.topItem.title = @"WELCOME";
    
     self.NameString = [self.NameString  stringByReplacingOccurrencesOfString:@"%20" withString: @" "];
    
    self.usernamefillTextfield.text=self.NameString;
    self.userEmailFillTextField.text = self.EmailIDString;
    
    
    self.LogLertview.layer.cornerRadius = 20;
    self.loginoutlet .layer.cornerRadius = 5.5;
    
    self.userEmailFillTextField.layer.cornerRadius = 10;
    self.usernamefillTextfield.layer.cornerRadius = 20;
    
     self.navigationController.navigationBarHidden = YES;
    
    
   
    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)loginButton:(id)sender {
    
    for (UIViewController* viewController in self.navigationController.viewControllers) {
        if ([viewController isKindOfClass:[ViewController class]] ) {
            ViewController *groupViewController = (ViewController*)viewController;
            [self.navigationController popToViewController:groupViewController animated:YES];
        }
    }
    
    
    //    corporateLOginPAgeViewController *log = [self.storyboard instantiateViewControllerWithIdentifier:@"CLOGIN"];
//    [self. navigationController pushViewController:log animated:YES];
}
@end
