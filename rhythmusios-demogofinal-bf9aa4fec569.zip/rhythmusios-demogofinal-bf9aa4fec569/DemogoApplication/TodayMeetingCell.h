//
//  TodayMeetingCell.h
//  DemogoApplication
//
//  Created by katoch on 20/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TodayMeetingCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *txtTime;
@property (strong, nonatomic) IBOutlet UILabel *textDate;
@property (strong, nonatomic) IBOutlet UIImageView *txtImg;
@property (strong, nonatomic) IBOutlet UILabel *textChairperson;
@property (strong, nonatomic) IBOutlet UILabel *textMode;

@end
