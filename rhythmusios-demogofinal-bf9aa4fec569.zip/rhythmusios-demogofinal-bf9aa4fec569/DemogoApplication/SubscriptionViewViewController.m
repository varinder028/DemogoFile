//
//  SubscriptionViewViewController.m
//  DemogoApplication
//
//  Created by Rhythmus on 04/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "SubscriptionViewViewController.h"
#import "CorporateTabBarViewController.h"

@interface SubscriptionViewViewController ()
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *FirstViewAutoLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *SecondViewAutoLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *ThirdViewAutolayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *FourViewAutoLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *FifthViewAutoLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *LAstViewAutoLayout;


    ///////         VIew Outlet

@property (strong, nonatomic) IBOutlet UIView *FisrtView;
- (IBAction)firstButton:(id)sender;


@property (strong, nonatomic) IBOutlet UIView *SecondVIew;
- (IBAction)SecondButton:(id)sender;


@property (strong, nonatomic) IBOutlet UIView *ThirdView;
- (IBAction)ThirdButton:(UIButton *)sender;


@property (strong, nonatomic) IBOutlet UIView *FOurthVIew;

- (IBAction)FourthButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIView *FIFthView;
- (IBAction)FifthButton:(id)sender;


@property (strong, nonatomic) IBOutlet UIView *SixthVIew;
- (IBAction)SixthButton:(id)sender;


//////...........   LabelButton


- (IBAction)FirstSubscribebutton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *FirstButonOutlet;

- (IBAction)SecondSubsCribeButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *SEcondButonOutlet;

- (IBAction)ThirdSubscribeButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *ThirdButonOutlet;

- (IBAction)FourSubsCribeButton:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *FourthButonOutlet;

- (IBAction)FIfthSubsCribeButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *FifthButonOutlet;

- (IBAction)SixthSusbcribeButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *SixButonOutlet;

- (IBAction)BAckButton:(id)sender;



@end

@implementation SubscriptionViewViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    

    self.FisrtView.hidden =YES;
    self.FirstViewAutoLayout.constant = 5;
    
    self.SecondVIew.hidden =YES;
    self.SecondViewAutoLayout.constant = 5;
    
    self.ThirdView.hidden =YES;
    self.ThirdViewAutolayout.constant = 5;
    
    self.FOurthVIew.hidden =YES;
    self.FourViewAutoLayout.constant = 5;
    
    self.FIFthView.hidden =YES;
    self.FifthViewAutoLayout.constant = 5;
    
    self.SixthVIew.hidden =YES;
  //  self.FirstViewAutoLayout.constant =5;
    
    
    
    
    
    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)firstButton:(id)sender
{
    if ([_segment selectedSegmentIndex]==0)
    
    {
    
        if (self.FisrtView.hidden==YES)
        
            {
        
                    self.FisrtView.hidden=NO;
        
                    self.FirstViewAutoLayout .constant = 221;
            }
    
            else
            
                {
        
                    self.FisrtView.hidden=YES;
                    self.FirstViewAutoLayout.constant = 5;
        
                }
    
    }
    
    else if ([_segment selectedSegmentIndex]==1)
        
    {
        
        if (self.FisrtView.hidden==YES)
            
        {
            
            self.FisrtView.hidden=NO;
            
            self.FirstLAbelView2500.text= @"2000";
            
            self.FirstLAbelView0.text= @"2000.0";
            
            self.FirstViewAutoLayout .constant = 221;
        }
        
        else
            
        {
            
            self.FisrtView.hidden=YES;
            self.FirstViewAutoLayout.constant = 5;
            
        }
        
    }

    
    
    
}
- (IBAction)SecondButton:(id)sender
{
  
    
    if ([_segment selectedSegmentIndex]==0)
   
        {
    
        if (self.SecondVIew.hidden==YES)
        
            {
        
                self.SecondVIew.hidden=NO;
        
                self.SecondViewAutoLayout .constant = 221;
            }
    
            else
                
                {
        
                    self.SecondVIew.hidden=YES;
        
                    self.SecondViewAutoLayout.constant = 5;
        
                }

        }
    
    
   else if ([_segment selectedSegmentIndex]==1)
        
    {
        
        if (self.SecondVIew.hidden==YES)
            
        {
            
            self.SecondVIew.hidden=NO;
            
            self.SecondLabelVIew2500.text = @"2000";
            
            self.SecondLAbelVIew0.text = @"2000.0";
            
            self.SecondViewAutoLayout .constant = 221;
        }
        
        else
            
        {
            
            self.SecondVIew.hidden=YES;
            
            self.SecondViewAutoLayout.constant = 5;
            
        }
        
        
    }

    
    
    
    
    
}
- (IBAction)ThirdButton:(UIButton *)sender

{
    if ([_segment selectedSegmentIndex]==0)
    
    {
        
        if (self.ThirdView.hidden==YES)
        
            {
        
                self.ThirdView.hidden=NO;
        
                self.ThirdViewAutolayout .constant = 221;
            }
    
                else
                    
                    {
        
                        self.ThirdView.hidden=YES;
         
                        self.ThirdViewAutolayout.constant = 5;
        
    
                    }

    }
    
    else if ([_segment selectedSegmentIndex]==1)
        
    {
        
        if (self.ThirdView.hidden==YES)
            
        {
            
            self.ThirdView.hidden=NO;
            
            self.thirdLAbelView2500.text = @"2000";
            
            self.ThirdLAbelView0.text = @"2000.0";
            
            self.ThirdViewAutolayout .constant = 221;
        }
        
        else
            
        {
            
            self.ThirdView.hidden=YES;
            
            self.ThirdViewAutolayout.constant = 5;
            
            
        }
        
    }
}
- (IBAction)FourthButton:(id)sender

{
    if ([_segment selectedSegmentIndex]==0)
    
    {
        
        if (self.FOurthVIew.hidden==YES)
        
            {
        
                self.FOurthVIew.hidden=NO;
        
                self.FourViewAutoLayout .constant = 221;
            }
    
                else
   
                    {
        
                        self.FOurthVIew.hidden=YES;
                        
                        self.FourViewAutoLayout.constant = 5;
        
                    }

    }
    
    else if ([_segment selectedSegmentIndex]==1)
        
    {
        
        if (self.FOurthVIew.hidden==YES)
            
        {
            
            self.FOurthVIew.hidden=NO;
            
            self.FourthLAbelView2500.text = @"2000";
            
            self.FOurthAlbelVIew0.text = @"2000.0";
            
            self.FourViewAutoLayout .constant = 221;
        }
        
        else
            
        {
            
            self.FOurthVIew.hidden=YES;
            
            self.FourViewAutoLayout.constant = 5;
            
        }
        
    }

    
}
- (IBAction)FifthButton:(id)sender

{
 
    if ([_segment selectedSegmentIndex]==0)
    
    {
    
            if (self.FIFthView.hidden==YES)
        
            {
        
                    self.FIFthView.hidden=NO;
        
                    self.FifthViewAutoLayout .constant = 221;
            }
    
                else
                    
                {
        
                        self.FIFthView.hidden=YES;
       
                        self.FifthViewAutoLayout.constant = 5;
        
                }

    }
    
  else if ([_segment selectedSegmentIndex]==1)
        
    {
        
        if (self.FIFthView.hidden==YES)
            
        {
            
            self.FIFthView.hidden=NO;
            
            self.FIfthLabelVIew2500.text = @"10";
            
            self.FifthVIewLAbel0.text = @"8.0";
            
            self.FifthViewAutoLayout .constant = 221;
        }
        
        else
            
        {
            
            self.FIFthView.hidden=YES;
            
            self.FifthViewAutoLayout.constant = 5;
            
        }
        
    }

    
}
- (IBAction)SixthButton:(id)sender

{
    
    if ([_segment selectedSegmentIndex]==0)
    
    {
        
            if (self.SixthVIew.hidden==YES)
        
                {
        
                        self.SixthVIew.hidden=NO;
        
                        self.LAstViewAutoLayout.constant = 5;
                }
    
                    else
                        
                        {
        
                            self.SixthVIew.hidden=YES;
        
        
                        }

    }
   
    else if ([_segment selectedSegmentIndex]==1)
        
    {
        
        if (self.SixthVIew.hidden==YES)
            
        {
            
            self.SixthVIew.hidden=NO;
            
            self.SixthLAbelView2500.text = @"30";
            
            self.SixthLAbelVIew0.text = @"30.0";
            
            self.LAstViewAutoLayout.constant = 5;
        }
        
        else
            
        {
            
            self.SixthVIew.hidden=YES;
            
            
        }
        
    }

    
    
}
- (IBAction)BAckButton:(id)sender
{
    
    
    CorporateTabBarViewController * adp = [self.storyboard instantiateViewControllerWithIdentifier:@"CTabBar"];
    
    adp.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    
    [self.navigationController pushViewController:adp animated:YES];
    
}
- (IBAction)SixthSusbcribeButton:(id)sender {
}
- (IBAction)FIfthSubsCribeButton:(id)sender {
}
- (IBAction)FourSubsCribeButton:(id)sender {
}
- (IBAction)ThirdSubscribeButton:(id)sender {
}
- (IBAction)SecondSubsCribeButton:(id)sender {
}
- (IBAction)FirstSubscribebutton:(id)sender {
}
- (IBAction)SegmentControllerButton:(id)sender
{
    
    if ([_segment selectedSegmentIndex]==0)
    {
        self.FIfthDap2500LAbel.text =@"DAP2500xxxx";
        
        self.SixthDAP500xxxxLabel.text =@"DAP500xxxx";
    }
    
    else if ([_segment selectedSegmentIndex]==1)
    {
        self.FirstDAP2500LAbel.text = @"DAPP2500xxxx";
        
        self.SecondDAP2500LAbel.text = @"DAPP2500xxxx";
        
        self.THirdDAP2500Label.text = @"DAPP2500xxxx";
        
        self.FourthDAP2500Label.text = @"DAPP2500xxxx";
        
        self.FIfthDap2500LAbel.text =@"DAPP1000xxxx";
        
        self.SixthDAP500xxxxLabel.text =@"DAPP1000xxxx";
        
    }
    else
    {
        
        UIAlertController *alert
        =[UIAlertController alertControllerWithTitle:@"Pending WOrk" message:@"Error" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* errorPass = [UIAlertAction
                                    actionWithTitle:@"ok"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action)
                                    {
                                    }];
        
        [alert addAction:errorPass];
        
        [self presentViewController:alert animated:YES completion:nil];

    }

    
    
}
@end
