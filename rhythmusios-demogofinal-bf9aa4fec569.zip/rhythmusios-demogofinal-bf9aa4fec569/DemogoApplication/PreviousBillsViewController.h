//
//  PreviousBillsViewController.h
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreviousBillsViewController : UIViewController{
    
    NSString*CompanyId;
    NSString*personId;
    NSString*Tokenid;
    id previousBills ;
    NSString*DateStr;
    
    NSString*tmprd ;
    id accountStatement ;
    NSMutableArray*getAllData ;
    id subscriptionHistory;
    
}

@property(strong,nonatomic)NSString *issub;


@property (strong, nonatomic) IBOutlet UITableView *tableview;
- (IBAction)BAckButon:(id)sender;
@property (strong, nonatomic) IBOutlet UITextField *txtEndDate;
@property (strong, nonatomic) IBOutlet UITextField *txtStartDate;
@property (strong, nonatomic) IBOutlet UIDatePicker *DatePicker;
- (IBAction)doneClicked:(id)sender;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *bottomPicker;
@property (strong, nonatomic) IBOutlet UILabel *txtHeader;
@property (strong, nonatomic) IBOutlet UILabel *txtID;
@property (strong, nonatomic) IBOutlet UILabel *txtDate;
@property (strong, nonatomic) IBOutlet UILabel *txtPayment;
@property (strong, nonatomic) IBOutlet UILabel *txtDownload;
@property(strong,nonatomic)NSString* PrePaid ;



@end
