//
//  MenuVc.m
//  DemogoApplication
//
//  Created by katoch on 22/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "MenuVc.h"
#import "menuCell.h"
#import "cellActionViewController.h"
#import "EmplyeeMAnagementViewController.h"
#import "BillingViewController.h"
#import "SubscriptionVC.h"
#import "LogSucessPasswordViewController.h"
#import "Billing.h"
#import "AppDelegate.h"
#import "EmployeeManagementVc.h"
#import "UIImageView+WebCache.h"
#import "AccountBillViewController.h"
#import "ForgotPAsViewController.h"
#import <AFNetworking/AFNetworking.h>
#import "KVNProgress.h"


@interface MenuVc ()

@end


@implementation MenuVc

- (void)viewDidLoad {
    [super viewDidLoad];

    UITapGestureRecognizer *gesRecognizer4 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hidedROPVIEW)]; // Declare the Gesture.
    gesRecognizer4.delegate = self;
    [self.addAccountView addGestureRecognizer:gesRecognizer4];

    
    _btnForgetPass.layer.cornerRadius = 5.0f ;
    [_btnForgetPass clipsToBounds];
    
    
    _btnLogin.layer.cornerRadius = 5.0f ;
    [_btnLogin clipsToBounds];
    
    NSLog(@"%@",personId);
    
    signUpInfoArray = [[NSMutableArray alloc]init];
    signUpInfoArray = [[NSUserDefaults standardUserDefaults]valueForKey:@"signUpInfo"];
    
//    companyId = [NSString stringWithFormat:@"%@",signUpInfoArray[0]];
//    personId = [NSString stringWithFormat:@"%@",signUpInfoArray[1]];
//    companyToken = [NSString stringWithFormat:@"%@",signUpInfoArray[2]];
//    companyImage = [NSString stringWithFormat:@"%@",signUpInfoArray[3]];
//    NSString* companyName = [NSString stringWithFormat:@"%@",signUpInfoArray[4]];
//    NSString*  CompanyUserName = [NSString stringWithFormat:@"%@",signUpInfoArray[5]];
//    companyStr = [NSString stringWithFormat:@"%@(%@)",companyName,CompanyUserName];
    
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    companyImage = [[NSUserDefaults standardUserDefaults]valueForKey:@"cmpLg"];
    companyName = [[NSUserDefaults standardUserDefaults]valueForKey:@"cmpNm"];
    CompanyUserName = [[NSUserDefaults standardUserDefaults]valueForKey:@"firstName"];
    companyStr = [NSString stringWithFormat:@"%@(%@)",CompanyUserName,companyName];
    companyToken = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    
//    [self.userImg sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://182.76.44.135:8080/%@",companyImage]]placeholderImage:[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"]];
//
    CAGradientLayer *postpaid = [CAGradientLayer layer];
    
    if ([UIScreen mainScreen].bounds.size.width == 414) {  /// 6 plus , 7 plus
        postpaid.frame = CGRectMake(0, 0,414, _gradientView.frame.size.height);
    }else if ([UIScreen mainScreen].bounds.size.width == 768) { /// ipad 9.7  ,ipad 10.5 ,ipad air,ipad air 2
        postpaid.frame = CGRectMake(0, 0,768, _gradientView.frame.size.height);
    }else if ([UIScreen mainScreen].bounds.size.width == 1024) { // ipad 12.5
        postpaid.frame = CGRectMake(0, 0,1024, _gradientView.frame.size.height);
    }else if ([UIScreen mainScreen].bounds.size.width == 375) { //iphone 6 ,6s, 7
        postpaid.frame = CGRectMake(0, 0,375, _gradientView.frame.size.height);
    }
    else if ([UIScreen mainScreen].bounds.size.width == 320) { //iphone 4,4s,5 ,5s
        postpaid.frame = CGRectMake(0, 0,320, _gradientView.frame.size.height);
    }
 //   postpaid.frame = CGRectMake(0, 0,_gradientView.frame.size.width, _gradientView.frame.size.height);
    //_gradientView.bounds;
    postpaid.startPoint = CGPointZero;
    //postpaid.endPoint = CGPointMake(1, 1);
    postpaid.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:34.0/255.0 green:111/255.0 blue:144/255.0 alpha:1.0] CGColor],(id)[[UIColor colorWithRed:145/255.0 green:72.0/255.0 blue:203/255.0 alpha:6.0] CGColor], nil];
    
    [_gradientView.layer  addSublayer:postpaid];
    
    [_gradientView bringSubviewToFront:_txtName];
    [self.gradientView bringSubviewToFront:_txtCity];
    [self.gradientView bringSubviewToFront:_txtUserEmail];
    [_txtUserEmail sizeToFit];
    
    [self.gradientView bringSubviewToFront:_txtMobileImg];
    [self.gradientView bringSubviewToFront:_txtAdmin];
    [self.gradientView bringSubviewToFront:_txtMobileTxt];
    [self.gradientView bringSubviewToFront:_imgCity];
    [self.gradientView bringSubviewToFront:_myProfileImg];
    

    
   
    

    
      
    
    _locationManager = [[CLLocationManager alloc] init];
    [self getLocation];
    
    NSDate *now = [NSDate date];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"hh:mm";
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]];
   
    
    newDateString = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:now]];
    NSLog(@"%@",newDateString);
  
    
    // Convert string to date object
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"hh:mm"];
    NSDate *date = [dateFormat dateFromString:newDateString];
    timeInMiliseconds = [date timeIntervalSince1970]*1000;
   strTime = [NSString stringWithFormat:@"%f",timeInMiliseconds];
    
    

    versionNo= [[NSMutableString alloc]initWithFormat:@"%@",[UIDevice currentDevice].systemVersion];
    
    OperatingNa= [[NSMutableString alloc]initWithFormat:@"%@",[UIDevice currentDevice].systemName];
    
  
    
    
    NSLog(@"%@",versionNo);
    
    NSLog(@"%@",OperatingNa);
    
    [self.addAccountView setHidden:YES];
    
    
    NSAttributedString*selectComp=[[NSAttributedString alloc]
                                   
                                   initWithString:@"Select Company"
                                   
                                   attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.txtAddCompany.attributedPlaceholder = selectComp ;
    
    
    NSAttributedString*selectemail=[[NSAttributedString alloc]
                                   
                                   initWithString:@"Email/Mobile no"
                                   
                                   attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.txtaddEmail.attributedPlaceholder = selectemail ;
    
    
    
    NSAttributedString*selectPassword=[[NSAttributedString alloc]
                                    
                                    initWithString:@"Password"
                                    
                                    attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.txtAddPassword.attributedPlaceholder = selectPassword ;
    
    
    

    
    
    [_txtaddEmail addTarget:self
                  action:@selector(textFieldDidChange:)
        forControlEvents:UIControlEventEditingChanged];
    
    
    _myProfileImg.layer.cornerRadius = _myProfileImg.frame.size.width/2 ;
    _myProfileImg.maskView.layer.masksToBounds = YES;
    
    
    
    _txtCompHeightLayout.constant = 0;
    _txtTopLayout.constant = 0;
    _subViewHeightLayout.constant = 227;
    _txtlblTopLayout.constant = 0 ;
    _txtCompLblLayout.constant = 0;
    
    
  
    
    
//    _gradientView = [[UIView alloc] init];
//    CAGradientLayer *gradient = [CAGradientLayer layer];
//    
//    gradient.frame = _gradientView.bounds;
//    gradient.colors = @[(id)[UIColor colorWithRed:25/255.0f green:787/255.0f blue:0/255.0f alpha:1].CGColor, (id)[UIColor colorWithRed:85/255.0f green:52/255.0f blue:80/255.0f alpha:1].CGColor,(id)[UIColor colorWithRed:25/255.0f green:70/255.0f blue:87/255.0f alpha:1].CGColor] ;
//    
    
    
 //   [_gradientView.layer insertSublayer:gradient atIndex:0];
    
    
    _menuTableView.separatorStyle = UITableViewCellEditingStyleNone ;
    
    
    listArray = [[NSMutableArray alloc]init];
    arrayIcons = [[NSMutableArray alloc]init];
    
    
   strRole =   [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
    

    
    if ([strRole isEqualToString:@"ROLE_HOST"]) {
        
      
        
        listArray =    [[NSMutableArray alloc]initWithObjects:@"Account Details",@"Employee Management",@"Add New Account",@"Change Password",@"Sign Out", nil];
          arrayIcons =  [[NSMutableArray alloc]initWithObjects:@"accounts.png",@"employee.png",@"add.png",@"48x48.png",@"logout.png", nil];
        
        
        
    }else if ([strRole isEqualToString:@"ROLE_PARTICIPANT"]) {
        
        
        
        listArray =    [[NSMutableArray alloc]initWithObjects:@"Account Details",@"Add New Account",@"Change Password",@"Sign Out", nil];
        arrayIcons =  [[NSMutableArray alloc]initWithObjects:@"accounts.png",@"add.png",@"48x48.png",@"logout.png", nil];        
        
    }
    else{
        
        
        listArray =    [[NSMutableArray alloc]initWithObjects:@"Account Details",@"Employee Management",@"Subscription",@"Billing",@"Add New Account",@"Change Password",@"Sign Out", nil];
        
        
        arrayIcons =  [[NSMutableArray alloc]initWithObjects:@"accounts.png",@"employee.png",@"subscription.png",@"billing.png",@"add.png",@"48x48.png",@"logout.png", nil];
        
       
    }
    
    
    
    
  
    
    
    
    // Do any additional setup after loading the view.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [dropDownView closeAnimation];
    [super touchesBegan:touches withEvent:event];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    [self myProfileFromServer];

   
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    
    [delegate.tabView removeFromSuperview];
    
    [self.addAccountView setHidden:YES];
    
    
    
    NSArray *myNibsArray = [[NSBundle mainBundle] loadNibNamed:@"Tab" owner:self options:nil];
    delegate.tabView = [myNibsArray objectAtIndex:0];
    
    if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 90, self.view.frame.size.width, 90);
        
    }else if ([UIScreen mainScreen].bounds.size.width == 1024 ) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 130, self.view.frame.size.width, 130);
        
    }else{

    delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height-delegate.tabView.frame.size.height, self.view.frame.size.width, delegate.tabView.frame.size.height);
    
    }
    [delegate.tabView.btnToday setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnSchedule setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnControlPanel setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnDashboard setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnMenu setBackgroundColor: [UIColor colorWithRed:0/255.0f green:32/255.0f blue:41/255.0f alpha:1]];
    
    if ([strRole isEqualToString:@"ROLE_PARTICIPANT"]) {
        
        if ([UIScreen mainScreen].bounds.size.width == 768){
            delegate.tabView.btnScheduleWidth.constant = -200 ;
            delegate.tabView.btnSchedule.hidden = YES;
            
        }else if ([UIScreen mainScreen].bounds.size.width == 1024) {
            delegate.tabView.btnScheduleWidth.constant = -270 ;
            delegate.tabView.btnSchedule.hidden = YES;
            
        }else{
        
        delegate.tabView.btnScheduleWidth.constant = -77 ;
            
        }
        
        [delegate.tabView.btnSchedule setImage:nil forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setTitle:nil forState:UIControlStateNormal];
        
        
    }else{
        delegate.tabView.btnScheduleWidth.constant = 0 ;
        [delegate.tabView.btnSchedule setImage:[UIImage imageNamed:@"schedule-call.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setTitle:@"Schedule Meeting" forState:UIControlStateNormal];
        
    }

    [self insets];
    
    
    [self.view addSubview:delegate.tabView];
    
    [self GettingStatesFromServer];
    
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}




-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{        
        return listArray.count;
        
    
}




-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
        menuCell *cell = [tableView dequeueReusableCellWithIdentifier:@"menuCell"];
        if (cell==nil) {
            NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"menuCell" owner:self options:nil];
            
            cell= arr[0];
            
        }
    
    cell.txtlbl.text = [listArray objectAtIndex:indexPath.row];
    cell.imgmenu.image = [UIImage imageNamed:[arrayIcons objectAtIndex:indexPath.row]];
  //  cell.arrowImg.image = @"" ;
    
    cell.backgroundColor = [UIColor clearColor];
    
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

{
    
    [self.menuTableView deselectRowAtIndexPath:indexPath animated:YES];
    
   
    
    
    
        if ([listArray[indexPath.row] isEqualToString:@"Account Details"])
            
        {
            
            AccountBillViewController *ce = [self.storyboard  instantiateViewControllerWithIdentifier:@"AccountBillViewController"];

            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [delegate.tabView removeFromSuperview];
            
            [self.navigationController pushViewController:ce animated:YES];
        }
        
        else if ([listArray[indexPath.row] isEqualToString:@"Employee Management"])
            
        {
            
            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [delegate.tabView removeFromSuperview];
            EmployeeManagementVc * empManage = [[EmployeeManagementVc alloc]init];
            
            
      empManage =    [self.storyboard  instantiateViewControllerWithIdentifier:@"EmployeeManagementVc"];
           
             [self.navigationController pushViewController:empManage animated:YES];
            
            // [self.navigationController pushViewController:empManage animated:YES];
            
            
        }
        else if ([listArray[indexPath.row] isEqualToString:@"Subscription"])
            
        {
            
            
            
            SubscriptionVC * Subs = [self.storyboard  instantiateViewControllerWithIdentifier:@"SubscriptionVC"];
            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [delegate.tabView removeFromSuperview];
            
//            Subs .modalTransitionStyle = UIModalTransitionStyleCoverVertical;
            
            [self.navigationController pushViewController:Subs animated:YES];
        }
        
        
        else if ([listArray[indexPath.row] isEqualToString:@"Billing"])
            
        {
            
            Billing * Bill = [self.storyboard  instantiateViewControllerWithIdentifier:@"Billing"];
            
            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [delegate.tabView removeFromSuperview];
            
            [self.navigationController pushViewController:Bill animated:YES];
            
            
            
            
//            Bill.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
//            
//            [self.navigationController pushViewController:Bill animated:YES];
            
            
        }
        
        else if ([listArray[indexPath.row] isEqualToString:@"Add New Account"])
            
        {

            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [delegate.tabView removeFromSuperview];
            
            [self.addAccountView setHidden:NO];
            
        }
        else if ([listArray[indexPath.row] isEqualToString:@"Change Password"])
            
        {
            
            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [delegate.tabView removeFromSuperview];
            NSLog(@"success");
            
            
            LogSucessPasswordViewController *logVc = [[LogSucessPasswordViewController alloc]init];
            logVc = [self.storyboard instantiateViewControllerWithIdentifier:@"LSP"];
            [self.navigationController pushViewController:logVc animated:YES];
          
            
        }
    
        else if ([listArray[indexPath.row] isEqualToString:@"Sign Out"])
            
        {

            
            signOutAlert = [[UIAlertView alloc]initWithTitle:nil message:@"Are you sure you want to Sign out" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
            
    
            [signOutAlert show];
            
            

        }
    
   
   
    
   
    
    }

-(void)kvnProgress{
    
    [KVNProgress dismiss];
    
}


-(void)GettingStatesFromServer{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getprofile?personId=%@",personId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:companyToken forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
        
        profileData = responseObject ;
        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
    
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:companyToken forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//    
//    
////    NSURLSession *session = [NSURLSession sharedSession];
////    [[session dataTaskWithURL:[NSURL URLWithString:apiURLStr]
////            completionHandler:^(NSData *data,
////                                NSURLResponse *response,
////                                NSError *error) {
//                
//                // NSError* error;
//                if (data != nil) {
//                    profileData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//                }
//                
//                
//                NSLog(@"%@",profileData);
//                
//                
//                                  }];
//    
//   [task resume];
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([UIScreen mainScreen].bounds.size.width== 768 || [UIScreen mainScreen].bounds.size.width== 1024) {
        
        return 100 ;
    }else{
    return 55 ;
    }
}

- (IBAction)txtForgetPassword:(id)sender {
    ForgotPAsViewController *pass  = [self.storyboard instantiateViewControllerWithIdentifier:@"f"];
    
    [self.navigationController pushViewController:pass animated:YES];

}
- (IBAction)backClicked:(id)sender {
    
    [self.addAccountView setHidden:YES];
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    

    NSArray *myNibsArray = [[NSBundle mainBundle] loadNibNamed:@"Tab" owner:self options:nil];
    delegate.tabView = [myNibsArray objectAtIndex:0];
    if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 90, self.view.frame.size.width, 90);
        
    }else if ([UIScreen mainScreen].bounds.size.width == 1024) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 130, self.view.frame.size.width, 130);
        
    }else{

    delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height-delegate.tabView.frame.size.height, self.view.frame.size.width, delegate.tabView.frame.size.height);
        
    }
    [self.view addSubview:delegate.tabView];
    
    
    
    strRole =   [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
    NSLog(@"%@",strRole);
    
    
    if ([strRole isEqualToString:@"ROLE_PARTICIPANT"]) {
        
        
        
        delegate.tabView.btnScheduleWidth.constant = -77 ;
        
        [delegate.tabView.btnSchedule setImage:nil forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setTitle:nil forState:UIControlStateNormal];
        
        
    }else{
        delegate.tabView.btnScheduleWidth.constant = 0 ;
        [delegate.tabView.btnSchedule setImage:[UIImage imageNamed:@"schedule-call.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setTitle:@"Schedule Meeting" forState:UIControlStateNormal];
        
    }
    


    
}



-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
   
    
    if (textField == _txtAddPassword) {
        [dropDownView closeAnimation];
        
        
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        if ([_txtaddEmail.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Enter EmailId/Mobile Number first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alert show];
            
            return NO;
            
            
        }else{
            
            if (![_txtAddCompany.text isEqualToString:@""]) {
                
                
                
            }else{
                
                [self SaveDataSecondApi];
                
            }
            
            
            
        }
        
        
    }
    
    else if (textField == _txtaddEmail){
        
        [dropDownView closeAnimation];
      //  [self.txtaddEmail resignFirstResponder];
        [self.txtAddPassword resignFirstResponder];
        
    }
    
    else if (textField == _txtAddCompany) {
        
        
        
//        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
//        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [self.txtaddEmail resignFirstResponder];
        [self SaveDataSecondApi];
        
        return false ;
        
    }
    
    return true ;
    
    
}


-(void)dropDownCellSelected:(NSInteger)returnIndex{
    
  if (_dropDownTxtfield == _txtAddCompany){
        self.txtAddCompany.text = [companyNameArray objectAtIndex:returnIndex];
        
        compId = [[[userEmailID objectForKey:@"cmpList"]valueForKey:@"cmpId"]objectAtIndex:returnIndex];
        
        
        [[NSUserDefaults standardUserDefaults]setValue:compId forKey:@"ComId"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [dropDownView closeAnimation];
        
        
    }
    
    
}


-(void)textFieldDidChange:(UITextField*)textfield{
    
    
    if (userEmailID.count >0) {
        
        
        if ([EMAILDATA  isEqualToString:@"success"]) {
            
            [self SaveDataSecondApi];
            
        }else{
            
            _txtAddCompany.text = @"" ;
            
            compId = @"" ;
            
            
        }
        
        
        
    }
    
}



-(void)SaveDataSecondApi

{
    
    
    NSString* urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/getemaildetails?email=%@",self.txtaddEmail.text];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:companyToken forHTTPHeaderField:@"token"];
    
    [manager GET:urlstring parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
        
        userEmailID = responseObject ;
        
         [self performSelectorOnMainThread:@selector(ShowCompanyField) withObject:nil waitUntilDone:YES];
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    
    
//    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
//    
//    
//    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
//    
//    
//    url = [NSURL URLWithString:urlstring];
//    
//    
//    
//    
//    
//    
//    
//    
//    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
//                                            
//                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
//    
//    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
//    
//    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
//    
//    [SendingRequest setHTTPMethod:@"GET"];
//    
//    
//    
//    
//    
//    
//    GetDicDta = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.txtaddEmail.text,@"email",nil];
//    
//    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
//    
//    
//    
//    
//    
//    
//    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
//                                          
//                                          {
//                                              
//                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
//                                              
//                                              NSLog(@" the databse theXml is  =====  %@",theXML);
//                                              
//                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
//                                              
//                                              
//                                              userEmailID = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
//                                              
//                                              
//                                              
//                                              
//                                             
//                                              
//                                              
//                                              
//                                              NSLog(@" the email deatils is  =   %@",EMAILDATA);
//                                              
//                                              NSLog(@"the email response is = %@",userEmailID);
//                                              
//                                              
//                                          }];
//    
//    
//    
//    
//    
//    
//    
//    [postDataTask resume];
    
  
    
}


-(void)ShowCompanyField{
    
    
    EMAILDATA = [userEmailID valueForKey:@"message"];
    
    
    if ([EMAILDATA isEqualToString:@"Email ID Do not exist"]) {
        NSLog(@" EEE E E E  E E E E E E E  R R R R R R R R  R   O O O O OO O O O  RR  R R R R R  R");
        
        UIAlertView* alertEmail=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the correct emailId/Mobile Number" delegate:self cancelButtonTitle:@"ok" otherButtonTitles: nil];
        
        _txtCompHeightLayout.constant = 0;
        _txtTopLayout.constant = 0;
        _subViewHeightLayout.constant = 227;
        _txtlblTopLayout.constant = 0 ;
        _txtCompLblLayout.constant = 0;
        
        [alertEmail show];
        
        [_txtaddEmail becomeFirstResponder];
        
        
        
    }
    else if ([EMAILDATA isEqualToString:@"success"]){
        
        
        
        companyNameArray = [[userEmailID objectForKey:@"cmpList"]valueForKey:@"cmpNm"];
        
        _txtCompHeightLayout.constant = 30;
        _txtTopLayout.constant = 15;
        _subViewHeightLayout.constant = 269;
        _txtlblTopLayout.constant = 2 ;
        _txtCompLblLayout.constant = 1;
        
        
        [self.view layoutIfNeeded];
        
        
        
        [self performSelectorOnMainThread:@selector(companyDatatable) withObject:nil waitUntilDone:YES];
        
        
        
    }
    
}

-(void)companyDatatable{
    
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    
    
    
    dropDownView = [[DropDownView alloc] initWithArrayData:companyNameArray cellHeight:40 heightTableView:120 paddingTop:0  paddingLeft:0 paddingRight:0 refView:_txtAddCompany animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    [self.addAccountSubview addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    _dropDownTxtfield = _txtAddCompany ;
    
    
    [dropDownView openAnimation];
    
    NSLog(@" SSS  SSSS  S S S S S  USUU U     UUUU  U U U  U");
    
    
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    
    
    return YES ;
}


-(void)SuccessCheck{
    
    
    if ([[PassedJSonArray valueForKey:@"message"] isEqualToString:@"success"]) {
        
       // [accountNameArray addObject:self.txtaddEmail.text];
        
        
    }
    
}


- (IBAction)loginClicked:(id)sender {
    
    if ([self.txtaddEmail.text isEqualToString:@""]){
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Enter the EmailID/Mobile Number" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
    else if ([self.txtAddPassword.text isEqualToString:@""] )
        
    {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Enter your password" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
    
    else if ([self.txtAddCompany.text isEqualToString:@""]){
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select the Company Name" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
    else{
        
        
        [self AddAccountFromServer];
        
    }
    
}


-(void)myProfileFromServer{
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getprofile?personId=%@",personId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:companyToken forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
        
        myProfileData = responseObject ;
        
         [self performSelectorOnMainThread:@selector(MyprofileData) withObject:nil waitUntilDone:YES];
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnProgress) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    

    
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:companyToken forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//    
////    NSURLSession *session = [NSURLSession sharedSession];
////    [[session dataTaskWithURL:[NSURL URLWithString:apiURLStr]
////            completionHandler:^(NSData *data,
////                                NSURLResponse *response,
////                                NSError *error)
////      {
//          if (data != nil) {
//              myProfileData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//          }
//          
//          
//          
//          NSLog(@"%@",myProfileData);
//          
//          
//          [self performSelectorOnMainThread:@selector(MyprofileData) withObject:nil waitUntilDone:YES];
//          
//          
//          
//          //[self performSelectorOnMainThread:@selector(kvnShow) withObject:nil waitUntilDone:YES];
//                                  }];
//    
//   [task resume];
    
    
}


-(void)MyprofileData{
    
    if ([[myProfileData valueForKey:@"message"]isEqualToString:@"success"]) {
        
        self.txtName.text = [myProfileData valueForKey:@"firstName"];
        self.txtCity.text = [myProfileData valueForKey:@"location"];
        self.txtUserEmail.text = [myProfileData valueForKey:@"pemail"];
        self.txtMobileTxt.text = [myProfileData valueForKey:@"pmobile"];
        
        self.myProfileImg.image = nil;
        
        
      
        SDImageCache *imageCache = [SDImageCache sharedImageCache];
        [imageCache clearMemory];
        [imageCache clearDisk];
        
        [self.myProfileImg sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://182.76.44.135:8080/%@",[myProfileData valueForKey:@"proImg"]]]placeholderImage:[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"]];
        
        
        
        self.myProfileImg.layer.cornerRadius = self.myProfileImg.frame.size.width/2 ;
        self.myProfileImg.layer.masksToBounds = YES;
        NSString*roleee  = [NSString stringWithFormat:@"%@",[myProfileData valueForKey:@"role"]];
        
        
        if ([roleee isEqualToString:@"ROLE_SUPER_ADMIN"]) {
            roleee = @"Admin" ;
            
        }else if ([roleee isEqualToString:@"ROLE_HOST"]) {
            roleee = @"Host" ;
            
        }else if ([roleee isEqualToString:@"ROLE_PARTICIPANT"]) {
            roleee = @"Participant" ;
            
        }

        self.txtAdmin.text = roleee ;
        
        
    
    }
    else{
        
        
    }
   
    
    
}


-(void)AddAccountFromServer;
{
    
     NSError *error;
    
    NSString* strPassword= self.txtAddPassword.text;
    
    NSLog(@"%@",strPassword);
    
    NSData *dataTake2 = [strPassword dataUsingEncoding:NSUTF8StringEncoding];
    
    // Convert to Base64 data
    
    NSData *base64Data = [dataTake2 base64EncodedDataWithOptions:0];
    
    Base64encodePassword = [NSString stringWithFormat:@"%@",[NSString stringWithUTF8String:[base64Data bytes]]];
    
    NSLog(@"%@", Base64encodePassword);
    
    
    
    NSString *urlstr  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/checklogin"];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    // NSURLSession *session = [NSURLSession sharedSession];

    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];

    NSURL * urll = [NSURL URLWithString:urlstr];

    NSMutableURLRequest * requestUrl = [NSMutableURLRequest requestWithURL:urll
                                                               cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                           timeoutInterval:60.0];

    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];

    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Accept"];

    [requestUrl setHTTPMethod:@"POST"];


    /////////   Password convert in Base64Encoding   ./////////////


    
    mapData = @{ @"add": @"true",
               @"cmpId": compId,
              @"latitude": latitude,
               @"longitude":longitude,
               @"os": OperatingNa,
               @"username": self.txtaddEmail.text,
               @"password": Base64encodePassword,
                 @"personId": personId,
                  @"version": versionNo};

    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:mapData options:0 error:&error];

    [requestUrl setHTTPBody:postData];



    NSURLSessionDataTask *postDtaat = [session dataTaskWithRequest:requestUrl completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)

                                       {



                                           dispatch_async(dispatch_get_main_queue(),^{


                                               NSError *jsonError;

                                               NSLog(@"theeeeeeeeeeeeee total response is  =        %@",response);
                                               NSLog(@"%@",data);



  result =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];

                                               NSLog(@"%@",result);

                                               NSString *  fetchOTP2 = [NSString stringWithFormat:@"%@",[result valueForKey:@"message"]];

                                               [self performSelectorOnMainThread:@selector(successMessage) withObject:nil waitUntilDone:YES];
                                               

                                               NSLog(@"%@",fetchOTP2);
                                               
                                           
                                               


                                           });


                                       }];

    [postDtaat resume];


}

-(void)successMessage{
    
    if ([[result valueForKey:@"responseCode"] isEqual:[NSNumber numberWithInteger:200]]) {
        
        alertAdded = [[UIAlertView alloc]initWithTitle:nil message:@"User Added successfully" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alertAdded show];
        
        dropDownListArray  = [result valueForKey:@"result"];
        NSLog(@"%@",dropDownListArray);
        
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dropDownListArray];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"Accounts"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        

        
    }else{
        alertAdded = [[UIAlertView alloc]initWithTitle:nil message:result[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alertAdded show];
        
    }
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == alertAdded) {
        if (buttonIndex == 0) {
            
            [self.navigationController popViewControllerAnimated:YES];
            
        }
    }else if (alertView == signOutAlert){
        
        if (buttonIndex == 1) {
            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [delegate.tabView removeFromSuperview];
            
            ViewController*lVc = [[ViewController alloc]init];
            NSString * storyboardName = @"Main";
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
            lVc= [storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
            UINavigationController *navControllr = [[UINavigationController alloc]initWithRootViewController:lVc];
            navControllr.navigationBarHidden = true;
            delegate.window.rootViewController= navControllr;
            [delegate.window makeKeyAndVisible];
            
            
            [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"isFirst"];
            [[NSUserDefaults standardUserDefaults]synchronize];

            
        }
    }
   
}

-(void)getLocation{
    
    self.locationManager = [[CLLocationManager alloc] init];
    
    self.locationManager.delegate = self;
    if([self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]){
        NSUInteger code = [CLLocationManager authorizationStatus];
        if (code == kCLAuthorizationStatusNotDetermined && [self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
            // choose one request according to your business.
            if([[NSBundle mainBundle] objectForInfoDictionaryKey:@"NSLocationWhenInUseUsageDescription"]) {
                [self.locationManager  requestWhenInUseAuthorization];
            } else {
                NSLog(@"Info.plist does not contain NSLocationAlwaysUsageDescription or NSLocationWhenInUseUsageDescription");
            }
        }
    }
    [self.locationManager startUpdatingLocation];
    
    
    
    
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    
    if([CLLocationManager locationServicesEnabled])
    {
        NSLog(@"Enabled");
        
        if([CLLocationManager authorizationStatus]==kCLAuthorizationStatusDenied)
        {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:NSLocalizedString( @"Please turn on Location Services first", @"" ) message:NSLocalizedString( @"Turn On", @"" ) preferredStyle:UIAlertControllerStyleAlert];
            
            //            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString( @"Cancel", @"" ) style:UIAlertActionStyleCancel handler:nil];
            UIAlertAction *settingsAction = [UIAlertAction actionWithTitle:NSLocalizedString( @"Settings", @"" ) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:
                                                            UIApplicationOpenSettingsURLString]];
            }];
            
            //  [alertController addAction:cancelAction];
            [alertController addAction:settingsAction];
            
            [self presentViewController:alertController animated:YES completion:nil];
        }
    }
}




- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    
    
    
    if (currentLocation != nil) {
        latitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
        [[NSUserDefaults standardUserDefaults]setObject:latitude forKey:@"lat"];
        
        longitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        [[NSUserDefaults standardUserDefaults]setObject:longitude forKey:@"long"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
    }
    
    self.locationManager = nil;
    
}

-(void)insets{
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:NO];
    
    
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        if ([strRole isEqualToString:@"ROLE_PARTICIPANT"]) {
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 14, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 17, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
            [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];

            
        }else{
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 14, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 17, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            
        }
        
        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 375) {
        
        if ([strRole isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
            [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
            [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            
            
            
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 25, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 25, 0, 0)];
            
            
        }else{
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -36, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
        [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
        [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
        [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
        [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
        }
    }else if ([UIScreen mainScreen].bounds.size.width == 414) {
        
        if ([strRole isEqualToString:@"ROLE_PARTICIPANT"]) {

            
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 23, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 27, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 27, 0, 0)];

            
        }else{
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 23, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 24, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 24, 0, 0)];
            
        }
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -40, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -28, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        
        
        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        
        [delegate.tabView.btnToday setImage: [UIImage imageNamed:@"ipad-today.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnControlPanel setImage: [UIImage imageNamed:@"ipad-control-panel.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnDashboard setImage: [UIImage imageNamed:@"ipad-dashboard.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setImage: [UIImage imageNamed:@"ipad-schedule-meeting.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnMenu setImage: [UIImage imageNamed:@"ipad-menu.png"] forState:UIControlStateNormal];
        
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:12]];
        
        
        
        
        
        
        if ([strRole isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 43, 20, 83)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(65, -183, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 53, 20, 93)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 63, 20, 73)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(10, 63, 25, 73)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 63, 20, 73)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];

            
            
        }else{
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 20, 45)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(10, 50, 25, 55)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 40, 20, 45)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            
        }
        
    } else if ([UIScreen mainScreen].bounds.size.width == 1024){
        
        [delegate.tabView.btnToday setImage: [UIImage imageNamed:@"ipad-today.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnControlPanel setImage: [UIImage imageNamed:@"ipad-control-panel.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnDashboard setImage: [UIImage imageNamed:@"ipad-dashboard.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setImage: [UIImage imageNamed:@"ipad-schedule-meeting.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnMenu setImage: [UIImage imageNamed:@"ipad-menu.png"] forState:UIControlStateNormal];
        
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:12]];
        
        if ([strRole isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 43, 20, 83)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(95, -183, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 53, 20, 93)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(95, -157, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 63, 20, 73)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(85, -157, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(20, 93, 35, 103)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(95, -157, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 63, 20, 73)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(85, -157, 0, 0)];
            
            
            
        }else{
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 20, 45)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 50, 20, 55)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(20, 63, 35, 73)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(8, 50, 22, 55)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            
        }
        
        
    }


    
}

-(void)hidedROPVIEW{
    
    [dropDownView closeAnimation];
    
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isDescendantOfView:dropDownView.view]  ) {
        
        
        return NO;
    }
        
    
    
    return YES;
}


@end
