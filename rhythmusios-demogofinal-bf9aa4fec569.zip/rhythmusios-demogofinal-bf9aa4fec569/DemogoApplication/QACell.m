//
//  QACell.m
//  DemogoApplication
//
//  Created by Rhythmus on 31/10/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "QACell.h"

@implementation QACell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)btnType:(id)sender {
}
@end
