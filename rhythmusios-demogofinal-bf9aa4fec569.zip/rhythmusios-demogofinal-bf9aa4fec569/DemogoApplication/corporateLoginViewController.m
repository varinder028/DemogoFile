//
//  corporateLoginViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "corporateLoginViewController.h"
#import "CorporateMobileOTPViewController.h"
#import "employeeOTPViewController.h"
#import "KVNProgress.h"
#import "Reachability.h"



@interface corporateLoginViewController ()<UITextFieldDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate>
{
   CorporateMobileOTPViewController *CCotp;
     employeeOTPViewController *Eottp;
        BOOL Cochecked;
        BOOL EmChecked;
    
    
    NSMutableDictionary* PassedJSon;
    
        NSMutableDictionary *GetDicDta;
        
        NSData * SendData;
    
    NSString *COMfetchOTP;
    NSString *EMpfetchOTP;
    NSMutableString*OTPSEND;
    

}



@property (strong, nonatomic) IBOutlet UIView *otpView;

@property (strong, nonatomic) IBOutlet UIButton *CorporateCheckBoxButton;
@property (strong, nonatomic) IBOutlet UIButton *EmployeeCheckBoxbutton;
- (IBAction)employeebutton:(UIButton *)sender;
- (IBAction)corporateButton:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIButton *verifyOutlet;
- (IBAction)verifyButton:(UIButton *)sender;

@end

@implementation corporateLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    [_CorporateCheckBoxButton setSelected:YES];
    [self.EmployeeCheckBoxbutton setSelected:NO];

    [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"CoOprt"];
    [[NSUserDefaults standardUserDefaults]synchronize];

    
    _otpView.layer.cornerRadius = 5.0f ;
    [_otpView clipsToBounds];

    
    
     OTPSEND = [[NSMutableString alloc]init];
    
    PassedJSon = [[NSMutableDictionary alloc]init];
    
    COMfetchOTP = [[NSString alloc]init];
    
    EMpfetchOTP = [[NSString alloc]init];
    
    
     self.navigationController.navigationBarHidden = YES;
    
            self.verifyOutlet.layer.cornerRadius =10.5;
                self.mobileNumberTextField.delegate=self;
   
            self.verifyOutlet.layer.cornerRadius = 10.5;
    
    
    
    
    
            NSAttributedString *str;
   
                            str=[[NSAttributedString alloc]
                                 
                                 initWithString:@"Enter Mobile Number...."
                                 
                                            attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
  
    self.mobileNumberTextField.attributedPlaceholder=str;

   }

-(void)SaveDataSecondApi
{
    NSError *linkError;
    
  
    
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
            NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
                    NSString *stringemail = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/app/reg?mobile=%@",self.mobileNumberTextField.text];
    
                                NSURL *PushLinkUrl = [NSURL URLWithString:stringemail];
    
    
                                            NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    
                                            [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
                                    [SendingRequest setHTTPMethod:@"POST"];
    
                            GetDicDta = [NSMutableDictionary dictionaryWithObject:self.mobileNumberTextField.text forKey:@"mobile"];
  
                    SendData= [NSJSONSerialization dataWithJSONObject:GetDicDta options:kNilOptions error:&linkError];
    
    ///
            [SendingRequest setHTTPBody:SendData];
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              
                                              
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                  
                                                  
                                                  
                                                    NSError *jsonError;
                                                  
                                                  NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                                  
                                                  
                                                  NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                                  //
                                                  
                                                  
                                                  [self performSelectorOnMainThread:@selector(kvnDismss) withObject:nil waitUntilDone:YES];
                                                  
                                                  
                                                  NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&jsonError];
                                                  
                                                  NSLog(@"The State Response is  ===  %@" ,dict);

                                    
                                NSLog(@"%@",dict);
                                               
                    OTPSEND=[dict valueForKey:@"otp"];
                                                  
                                                  
                    if (![dict valueForKey:@"otp"])
                                                  
                        {
                            NSLog(@"error");
                        }
                        else
                                                  
                            {
                                
                                CCotp =[self.storyboard instantiateViewControllerWithIdentifier:@"COROTP"];
                                
                                CCotp.CmpString = self.mobileNumberTextField.text ;
                                
                                
                                CCotp.CmpOTP = [NSMutableString stringWithString:OTPSEND];//[PassedJSon valueForKey:@"otp"];
                                
                                [self.navigationController pushViewController:CCotp animated:YES];
                                
                            }
                                                  
                                                  NSLog(@" the resend otp is  = %@",OTPSEND);
                                                  
//
                                                  
                                                  
                                              });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
    
}



-(void)kvnDismss{
    
    [KVNProgress dismiss];
    
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
    if ([UIScreen mainScreen].bounds.size.height == 480) {
        
        CGRect frm = self.view.frame ;
        frm.origin.y = -130 ;
        
        self.view.frame= frm ;
        
    }
    
    return YES;
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string;
{
    if (textField.text.length == 10 && range.length == 0)
    {
        return NO; // return NO to not change text
    }
    else
    {
        
        return YES;
    
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
   // NSLog(@"touchesBegan:withEvent:");
    CGRect frm = self.view.frame ;
    frm.origin.y = 0 ;
    
    self.view.frame= frm ;
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

    // Do any additional setup after loading the view.

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)employeebutton:(UIButton *)sender {
    
        
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"CoOprt"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [self.EmployeeCheckBoxbutton setSelected:YES];
    [self.CorporateCheckBoxButton setSelected:NO];
    



}
- (IBAction)corporateButton:(UIButton *)sender {
    
    
    
    
    [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"CoOprt"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
     [_CorporateCheckBoxButton setSelected:YES];
    [self.EmployeeCheckBoxbutton setSelected:NO];
    
    

    
}
- (IBAction)verifyButton:(UIButton *)sender {
  
    //int len;
   
    
    NSString *str ;
    
    self.mobileNumberTextField.text  = [self.mobileNumberTextField.text  stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    
    
    if ([self.mobileNumberTextField.text isEqualToString:@""])
        
    {
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Edit Number"
                                              
                                                                                 message:@"Please Enter Mobile Number" preferredStyle:UIAlertControllerStyleAlert];
        
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        
        
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
        
        
    }else if ([self.mobileNumberTextField.text length] != 10){
        
       
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter 10 digit  mobile number" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
        
    }else if (!_EmployeeCheckBoxbutton.isSelected && !_CorporateCheckBoxButton.isSelected){
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please choose Corporate/Employee" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
    }
    
    else{
        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
        if (networkStatus == NotReachable) {
            UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message: @"No Network Connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alert show];
            return;
            
            
        }
        else{
        
        if ([[NSUserDefaults standardUserDefaults]boolForKey:@"CoOprt"]== true) {
            //calling Co-Operate
            
            [KVNProgress show];
            
            [self SaveDataSecondApi];
            
            
            
            
            
        }else{
            
            [KVNProgress show];
             [self SaveDataSecondApi];
            
        }
        
        
        }
        
    }
        
   }


- (IBAction)backClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}
@end
