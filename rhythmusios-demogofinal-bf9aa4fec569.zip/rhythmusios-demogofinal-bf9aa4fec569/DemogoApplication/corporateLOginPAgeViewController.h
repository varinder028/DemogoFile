//
//  corporateLOginPAgeViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface corporateLOginPAgeViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *LOGOImage;
@property (strong, nonatomic) IBOutlet UITextField *usernameTextField;
@property (strong, nonatomic) IBOutlet UITextField *passwordTextField;
@property (strong, nonatomic) IBOutlet UIImageView *userImage;
@property (strong, nonatomic) IBOutlet UIImageView *PasswordImage;
- (IBAction)LOGINButton:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIButton *LoginOutlet;
- (IBAction)forgotPassword:(id)sender;
- (IBAction)SIGNUPbutton:(id)sender;

@end
