//
//  CorporateMobileOTPViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "CorporateMobileOTPViewController.h"
#import "CorporateSignupViewController.h"
#import "corporateLoginViewController.h"
#import "employeeSignUPViewController.h"

@interface CorporateMobileOTPViewController ()<NSURLSessionDelegate,NSURLSessionDataDelegate>
{
    CorporateSignupViewController *signup;
    employeeSignUPViewController *employeeSignup ;
    
    
    NSString *reciveOtp;
    

    
    NSTimer *timer;
        long counterr ;
    
            NSMutableDictionary *GetDicDta;
        
                    NSData * SendData;
    
                            NSString *matchResponse;

                                         NSMutableDictionary* PassedJSon;

    NSString *passMobleOTPresend;
}


   

            @property (strong, nonatomic) IBOutlet UILabel *timeLabel;

                                @property (strong, nonatomic) IBOutlet UIButton *resendOutlet;

                                            @property (strong, nonatomic) IBOutlet UIButton *verifyButton;

@property (strong, nonatomic) IBOutlet UIView *ViewBACK;

- (IBAction)VerifyButtonOutlet:(id)sender;

- (IBAction)resendButton:(id)sender;

@end





@implementation CorporateMobileOTPViewController

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    _ViewBACK.layer.cornerRadius = 5.0f ;
    [_ViewBACK clipsToBounds];
    
    
    [_resendOutlet setBackgroundColor:[UIColor colorWithRed:255/255.0f green:204/255.0f blue:255/255.0f alpha:1]];

    
    //self.navigationController.navigationBar.topItem.title = @"COR.Otp";
    
   reciveOtp = [[NSString alloc]init];
    
    reciveOtp  = self.CmpOTP;
    
    NSLog(@"%@",reciveOtp);
    
    _CmpString2 = [[NSString alloc]init];
    
       passMobleOTPresend = [[NSString alloc]init];
    
    [self setTimer];
    
    
                    self.resendOutlet.layer.cornerRadius=5.5;
    
                            self.ViewBACK.layer.cornerRadius = 10.5;
    
                                    self.verifyButton.layer.cornerRadius = 5.5;
    
    PassedJSon = [[NSMutableDictionary alloc]init];
    
    matchResponse = [[NSString alloc]init];
    

    
    
    
    
        NSAttributedString *str;
    
                str=[[NSAttributedString alloc]initWithString:@"Please Enter OTP Code...."attributes:
                     
                        @{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    
    
    self.OtpNumberCodeTextField.attributedPlaceholder=str;

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}








-(void)setTimer
{
     counterr = 60;
    
    timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(SetTimerConform) userInfo:nil repeats:YES];
    
    
    
    
}






-(void)SetTimerConform
{
    
    
    
    if (counterr==0) {
        
        
        
            [timer invalidate];
        
        _resendOutlet.enabled = YES;
        
        
                   // self.resendOutlet.hidden=NO;
        
        
                            self.resendOutlet.layer.cornerRadius = 10.5;
        
        
        
           [_resendOutlet setBackgroundColor:[UIColor colorWithRed:255/255.0f green:18/255.0f blue:255/255.0f alpha:1]];
        
        
    }
    
    else
        
        
    {
        counterr--;
        
             //   self.resendOutlet.hidden = YES;
        
         _resendOutlet.enabled = NO;
        
         [_resendOutlet setBackgroundColor:[UIColor colorWithRed:255/255.0f green:204/255.0f blue:255/255.0f alpha:1]];
       
            _timeLabel.text = [NSString stringWithFormat:@"%li",counterr];
        
    }
}



-(void)OtpEqualDataWithNumber;
{
 NSString *otdat;
 NSError *linkError;
 
 NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
 
 
 
 
            otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/app/matchotp?mobile=%@&otp=%@",_CmpString,self.OtpNumberCodeTextField.text];
 
 
                        NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
 
 
                                    NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
 
 
                                                NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
 
                                                                NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
 [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
 
        [SendingRequest setHTTPMethod:@"POST"];
 
                GetDicDta = [NSMutableDictionary dictionaryWithObjectsAndKeys:_CmpString ,@"mobile",self.OtpNumberCodeTextField.text,@"otp", nil];
 
 
                        SendData= [NSJSONSerialization dataWithJSONObject:GetDicDta options:kNilOptions error:&linkError];
 
                                    [SendingRequest setHTTPBody:SendData];
 
 
 
 NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
 
 {
 
                    dispatch_async(dispatch_get_main_queue(),^{

                                        NSError *jsonError;

                        
 
 
                        
 
                        PassedJSon =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
     
                        NSLog(@"%@",PassedJSon);
     
                        _CmpString2= [PassedJSon valueForKey:@"message"];
                        
                        
                        
                        
                        
                        if ([_CmpString2 isEqualToString:@"success"])
                                
                                
                                {
                                    
                                    if  ([[NSUserDefaults standardUserDefaults]boolForKey:@"CoOprt"]== true){
                                        
                                        signup = [self.storyboard instantiateViewControllerWithIdentifier:@"CSignup"];
                                        
                                        signup.MobileString=self.CmpString;
                                        
                                        [self.navigationController pushViewController:signup animated:YES];
                                    }
                                    else if ([[NSUserDefaults standardUserDefaults]boolForKey:@"CoOprt"]== false) {
                                        
                                        
                                        employeeSignup = [self.storyboard instantiateViewControllerWithIdentifier:@"ESignup"];
                                        
                                        employeeSignup.MobileString=self.CmpString;
                                        
                                        [self.navigationController pushViewController:employeeSignup animated:YES];
                                        
                                        
                                    }
                                    
                                    
                                }else{
                                    
                                    
                                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:PassedJSon[@"message"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
                                    
                                    [alert show];
                                    
                                    
                                    
                                }
                        
                        
 
                                });
 
 
 
                                        }];
 
 [postDataTask resume];
 
}





- (IBAction)resendButton:(id)sender
{
    
        NSString *otdat;
        NSError *linkError;
        
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        
        
        
    otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/resendotp?mobile=%@&otp=%@",_CmpString,reciveOtp];
    NSLog(@"%@",reciveOtp);
    
        NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
        
        
        NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
        
        
        NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                                
                                                NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
        
        [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        
        
        
        
        
        [SendingRequest setHTTPMethod:@"POST"];
        
    NSMutableDictionary * GetDic = [[NSMutableDictionary alloc]init];
    
                                    [GetDic setObject:_CmpString forKey:@"mobile"];
                                    
                                    [GetDic setObject:reciveOtp forKey:@"otp"];
    
    NSLog(@"%@",GetDic);
    
        NSData * SendDat= [NSJSONSerialization dataWithJSONObject:GetDic options:kNilOptions error:&linkError];
        
        
        
        
        
        [SendingRequest setHTTPBody:SendDat];
        
        NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                              
                                              {
                                                  
                                                  dispatch_async(dispatch_get_main_queue(),^{
                                                      NSError *jsonError;
                                                     
                                                      
       
                                                      
        PassedJS =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                      
                                                      NSLog(@"%@",PassedJS);
                                                      
                                                      [self performSelectorOnMainThread:@selector(alertOtp) withObject:nil waitUntilDone:YES];
                                                      
                                                      
                                                  });
                                                  
                                                  
                                                  
                                              }];
        
        [postDataTask resume];
        
    }
    

-(void)alertOtp{
    
    alertOtp = [[UIAlertView alloc]initWithTitle:nil message:PassedJS[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    
    [alertOtp show];
    
   
    
}
    
    
    
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == alertOtp) {
        if (buttonIndex == 0) {
            
             [self setTimer];
             _resendOutlet.enabled = NO;
            
            
        }
    }
    
    
}
    
    
    






- (IBAction)VerifyButtonOutlet:(id)sender {
    
    
    if ([self.OtpNumberCodeTextField.text isEqualToString:@""])
        
        
        
    {
        
        
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:
                                                  
                        @"OTP Text details" message:@"Please enter OTP Code"
                                                  
                                preferredStyle:UIAlertControllerStyleAlert];
        
        
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        
        
                        [alertController addAction:ok];
        
                                    [self presentViewController:alertController animated:YES completion:nil];
        
        
        
    }else
    {
        
       if  ([[NSUserDefaults standardUserDefaults]boolForKey:@"CoOprt"]== true){
            
              [self OtpEqualDataWithNumber];
           
        }
       else{
           
           [self OtpEqualDataWithNumber];

           
       }
       
        
        
        
    }
    

    
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:
//                                          
//                                @"OTP Code" message:
//                                          
//                                          @"OTP code conform than conform press Other than user Change No. than press Edit No."
//                                          
//                                                        preferredStyle:UIAlertControllerStyleAlert];
//    
//    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"Conform" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
//                        
//                {
//                    if ([_CmpString2 isEqualToString:@"success"])
//                                 
//                                 
//                        {
//                                 
//                            signup = [self.storyboard instantiateViewControllerWithIdentifier:@"CSignup"];
//                                 
//                                 signup.MobileString=self.CmpString;
//                                 
//                                        [self.navigationController pushViewController:signup animated:YES];
//                            
//                        }
//                    
//                            else
//                             
//                                    {
//                                        
//                                        NSLog(@"error");
//                                    }
//                             
//                             
//                }];
//    
//    
//    UIAlertAction* chng = [UIAlertAction actionWithTitle:@"Change Num." style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
//                        
//                           
//                        {
//                             
//                             for (corporateLoginViewController *aViewController in self.navigationController.viewControllers)
//                             
//                             {
//                               
//                                 if ([aViewController isKindOfClass:[corporateLoginViewController class]])
//                                 
//                                        {
//                                    
//                                            [self.navigationController popToViewController:aViewController animated:YES];
//                                        }
//                             }
//
//                         }];
//    
//            [alertController addAction:ok];
//    
//                    [alertController addAction:chng];
//  
//                                [self presentViewController:alertController animated:YES completion:nil];
    
    

}





- (IBAction)bckClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
@end









