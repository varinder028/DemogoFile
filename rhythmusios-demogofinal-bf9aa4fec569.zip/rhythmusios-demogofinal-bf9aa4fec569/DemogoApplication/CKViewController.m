#import <CoreGraphics/CoreGraphics.h>
#import "CKViewController.h"
#import "CKCalendarView.h"
#import "AppDelegate.h"


@interface CKViewController () <CKCalendarDelegate>

@property(nonatomic, weak) CKCalendarView *calendar;
@property(nonatomic, strong) UILabel *dateLabel;
@property(nonatomic, strong) NSDateFormatter *dateFormatter;
@property(nonatomic, strong) NSDate *minimumDate;
@property(nonatomic, strong) NSMutableArray *disabledDates;

@end

@implementation CKViewController

- (id)init {
    self = [super init];
    if (self) {
            }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    
   
    
    
    
    
    
    [self.dateLabel setHidden:YES];
    
//    CKCalendarView *calendar = [[CKCalendarView alloc] initWithStartDay:startMonday];
//    self.calendar = calendar;
//    calendar.delegate = self;
//    
//    self.dateFormatter = [[NSDateFormatter alloc] init];
//    [self.dateFormatter setDateFormat:@"dd-MM-yyyy"];
//    self.minimumDate = [self.dateFormatter dateFromString:@"20-09-2012"];
//    
//    
    CKCalendarView *calendar = [[CKCalendarView alloc] initWithStartDay:startMonday];
    self.calendar = calendar;
    calendar.delegate = self;
    
    self.dateFormatter = [[NSDateFormatter alloc] init];
    [self.dateFormatter setDateFormat:@"dd-MM-yyyy"];
    
    NSCalendar *calendarr = [NSCalendar currentCalendar];
    NSDateComponents *comps = [NSDateComponents new];
    comps.month = -1;
    comps.day   = -1;
    NSDate *date = [calendarr dateByAddingComponents:comps toDate:[NSDate date] options:0];
    NSDateComponents *components = [calendarr components:NSMonthCalendarUnit|NSDayCalendarUnit fromDate:date]; // Get necessary date components
    NSLog(@"Previous month: %ld",(long)[components month]);
    NSLog(@"Previous day  : %ld",(long)[components day]);
    
    
    self.minimumDate = date ;
    
    
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd-MM-yyyy"];
    
    NSDate *now = [NSDate date];
    
    NSMutableArray *results = [NSMutableArray arrayWithCapacity:30];
    
    
    
    for (int i = 0; i < 30; i++)
    {
        NSDate *date = [NSDate dateWithTimeInterval:-(i * (60 * 60 * 24)) sinceDate:now];
        NSString*str = [dateFormatter stringFromDate:date];
        
        
        [results addObject:[dateFormatter dateFromString:str]];
        
    }
    _disabledDates = [[NSMutableArray alloc]init];
    
    
    NSLog(@"%@", results);
    
    for (NSArray*arr in results) {
        
        [_disabledDates addObject:arr];
        
        NSLog(@"%@",_disabledDates);
        
    }

    
    
//    self.disabledDates = @[
//                           [self.dateFormatter dateFromString:@"05-01-2013"],
//                           [self.dateFormatter dateFromString:@"06-01-2013"],
//                           [self.dateFormatter dateFromString:@"06-06-2017"]
//                           ];
    
    calendar.onlyShowCurrentMonth = NO;
    calendar.adaptHeightToNumberOfWeeksInMonth = YES;
    
    calendar.frame = CGRectMake(10, 66, self.view.frame.size.width - 20, self.view.frame.size.width);
    [self.view addSubview:calendar];
    
    self.dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(calendar.frame) + 4, self.view.bounds.size.width, 24)];
    [self.view addSubview:self.dateLabel];
    
    self.view.backgroundColor = [UIColor blackColor];
    
    UIImageView *arrowLeft =[[UIImageView alloc] initWithFrame: CGRectMake(25, 15, 15, 15)];
    arrowLeft.image= [UIImage imageNamed:@"left-arrow.png"];
    
    [_calendar addSubview:arrowLeft];
    
    
    UIImageView *arrowright =[[UIImageView alloc] initWithFrame: CGRectMake(self.calendar.frame.size.width - 35, 15, 15, 15)];
    arrowright.image= [UIImage imageNamed:@"right-arrow.png"];
    
    [_calendar addSubview:arrowright];

    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(localeDidChange) name:NSCurrentLocaleDidChangeNotification object:nil];

	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (void)localeDidChange {
    [self.calendar setLocale:[NSLocale currentLocale]];
}

- (BOOL)dateIsDisabled:(NSDate *)date {
    for (NSDate *disabledDate in self.disabledDates) {
        if ([disabledDate isEqualToDate:date]) {
            return YES;
        }
    }
    return NO;
}

#pragma mark -
#pragma mark - CKCalendarDelegate

- (void)calendar:(CKCalendarView *)calendar configureDateItem:(CKDateItem *)dateItem forDate:(NSDate *)date {
    // TODO: play with the coloring if we want to...
    if ([self dateIsDisabled:date]) {
        dateItem.backgroundColor = [UIColor lightGrayColor];
        
        dateItem.textColor = [UIColor whiteColor];
    }
}

- (BOOL)calendar:(CKCalendarView *)calendar willSelectDate:(NSDate *)date {
    return ![self dateIsDisabled:date];
}

- (void)calendar:(CKCalendarView *)calendar didSelectDate:(NSDate *)date {
    self.dateLabel.text = [self.dateFormatter stringFromDate:date];
    
    [[NSUserDefaults standardUserDefaults]setValue:self.dateLabel.text forKey:@"CalenderDate"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"calender"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [self.navigationController popViewControllerAnimated:YES];
    
    
}

- (BOOL)calendar:(CKCalendarView *)calendar willChangeToMonth:(NSDate *)date {
    if ([date laterDate:self.minimumDate] == date) {
        self.calendar.backgroundColor = [UIColor darkGrayColor];
        return YES;
    } else {
        self.calendar.backgroundColor = [UIColor redColor];
        return NO;
    }
}

- (void)calendar:(CKCalendarView *)calendar didLayoutInRect:(CGRect)frame {
    NSLog(@"calendar layout: %@", NSStringFromCGRect(frame));
}
- (IBAction)bckClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}

@end
