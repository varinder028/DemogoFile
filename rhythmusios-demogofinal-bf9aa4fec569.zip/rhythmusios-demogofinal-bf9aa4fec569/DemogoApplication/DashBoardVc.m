//
//  DashBoardVc.m
//  DemogoApplication
//
//  Created by katoch on 25/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//


#import "DashBoardVc.h"
#import <QuartzCore/QuartzCore.h>
#import "AppDelegate.h"
#import "MapVc.h"
#import "BudgetMeetingViewController.h"
#import "MeetingViewController.h"
#import "PlanSummary.h"
#import "planSumaryViewController.h"
//#import "DemogoApplication-Bridging-Header.h"
//#import "DemogoApplication-Swift.h"
#import "customDashCell.h"

#import "billGraphVC.h"





@interface DashBoardVc ()
//@property (nonatomic , strong) SwiftViewController *LineCharVc;


@end

@implementation DashBoardVc

- (void)viewDidLoad {
    [super viewDidLoad];
   

    
         [self.collectionView registerNib:[UINib nibWithNibName:@"customDashCell" bundle:nil] forCellWithReuseIdentifier:@"customDashCell"];
    
    
    
    self.btnMap.layer.cornerRadius = 5.5f;
    self.btnMeeting.layer.cornerRadius = 5.5f;
    self.btnPlanSummry.layer.cornerRadius = 5.5f;
    self.btnBuggetSummary.layer.cornerRadius = 5.5f;
    self.BtnBillgraph.layer.cornerRadius = 5.5f;
    self.viewDateOrClock.layer.cornerRadius= 5.5f;
    _viewDateOrClock.layer.masksToBounds = YES;

dashArray = [[NSMutableArray alloc]initWithObjects:@"Meeting Details",@"Plan Summary",@"Budget Summary",@"Bill Graph", nil];
   // imgArray = [[NSMutableArray alloc]initWithObjects:@"meeting-detail.png",@"plan-summary.png",@"budget-summary.png",@"bill-graph.png", nil];

    
    imgArray = [[NSMutableArray alloc]initWithObjects:@"ipadmeeting-detail.png",@"ipadplan-summary.png",@"ipad-budget-summary.png",@"ipad-bill-graph", nil];
    
    
    NSCalendar *calendar= [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSCalendarUnit unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit | NSWeekdayCalendarUnit;
    NSDate *date = [NSDate date];
    NSDateComponents *dateComponents = [calendar components:unitFlags fromDate:date];
    
    
    NSInteger month = [dateComponents month];
    NSInteger day = [dateComponents day];
    
    
    NSInteger monthNumber = month;   //November
    NSDateFormatter *df = [[NSDateFormatter alloc] init] ;
    NSString *monthName = [[df monthSymbols] objectAtIndex:(monthNumber-1)];
    
       NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"hh:mm a"];
    NSLog(@"Current Date: %@", [formatter stringFromDate:[NSDate date]]); // Here also returning (null)**
    
    NSString *strTime = [formatter stringFromDate:[NSDate date]];
    
    
    self.txtMonth.text = monthName ;
    self.TxtDate.text = [NSString stringWithFormat:@"%ld",(long)day];
    self.txtTime.text = strTime ;

    
    
    
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        [_btnMeeting setImageEdgeInsets:UIEdgeInsetsMake(-15, 35, 0, 3)];
        [_btnPlanSummry setImageEdgeInsets:UIEdgeInsetsMake(-15, 35, 0, 3)];
        [_btnBuggetSummary setImageEdgeInsets:UIEdgeInsetsMake(-15, 35, 0, 3)];
        [_BtnBillgraph setImageEdgeInsets:UIEdgeInsetsMake(-15, 35, 0, 3)];

    }else if ([UIScreen mainScreen].bounds.size.width == 414) {
        [_btnMeeting setImageEdgeInsets:UIEdgeInsetsMake(-15, 60, 0, 3)];
        [_btnPlanSummry setImageEdgeInsets:UIEdgeInsetsMake(-15, 60, 0, 3)];
        [_btnBuggetSummary setImageEdgeInsets:UIEdgeInsetsMake(-15, 60, 0, 3)];
        [_BtnBillgraph setImageEdgeInsets:UIEdgeInsetsMake(-15, 60, 0, 3)];
        
    }else{
     
        [_btnMeeting setImageEdgeInsets:UIEdgeInsetsMake(-15, 49, 0, 3)];
        [_btnPlanSummry setImageEdgeInsets:UIEdgeInsetsMake(-15, 49, 0, 3)];
        [_btnBuggetSummary setImageEdgeInsets:UIEdgeInsetsMake(-15, 49, 0, 3)];
        [_BtnBillgraph setImageEdgeInsets:UIEdgeInsetsMake(-15, 49, 0, 3)];
        
      
    }
    
   
    
     if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        clockView = [[ClockView alloc] initWithFrame:CGRectMake(self.clockView.frame.origin.x + 5, 5, 140 , 140)];
         
     }else if ([UIScreen mainScreen].bounds.size.width == 1024){
         
         clockView = [[ClockView alloc] initWithFrame:CGRectMake(self.clockView.frame.origin.x + 5, 5, 170 , 170)];
         
     }
     else if ([UIScreen mainScreen].bounds.size.width == 414){
         
         clockView = [[ClockView alloc] initWithFrame:CGRectMake(self.clockView.frame.origin.x + 5, 5, 100 , 100)];
         
     }
     else{
         
         clockView = [[ClockView alloc] initWithFrame:CGRectMake(self.clockView.frame.origin.x + 5, 5, 80 , 80)];
     }
    
    
    
    
    clockView.backgroundColor = [UIColor clearColor];
    [clockView setClockBackgroundImage:[UIImage imageNamed:@"Screen Shot 2017-04-26 at 12.24.01 AM"].CGImage];
    [clockView setHourHandImage:[UIImage imageNamed:@"hourNeedle.png"].CGImage];
    [clockView setMinHandImage:[UIImage imageNamed:@"minuteNeedle.png"].CGImage];
   // [clockView setSecHandImage:[UIImage imageNamed:@"clock-sec-background.png"].CGImage];
    [clockView setSecHandContinuos:YES]; // Move the second's hand continously, Off by default
    [self.clockView addSubview:clockView];
    [clockView start];
    
    
        // Do any additional setup after loading the view.
}

-(void)viewDidLayoutSubviews{
    
    [super viewDidLayoutSubviews];
}
-(BOOL)shouldAutorotate
{
    return NO;
}

-(UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsPortrait(interfaceOrientation);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    
   [delegate.tabView dashboardClicked];
    
    [self TABdATA];
    
    
    if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        
        self.bottomCv.constant = 91 ;
        self.heigthClockView.constant = 150 ;
        self.widthMap.constant = 130 ;
        
         [self.btnMap  setTitleEdgeInsets:UIEdgeInsetsMake(30, -279, -80, -30)];
        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 1024){
        
        self.bottomCv.constant = 131 ;
        self.heigthClockView.constant = 200 ;
        self.widthMap.constant = 150 ;
         [self.btnMap  setTitleEdgeInsets:UIEdgeInsetsMake(30, -279, -80, -30)];
         [self.btnMap  setImageEdgeInsets:UIEdgeInsetsMake(22, 17, 45, 18)];
        
    }else if ([UIScreen mainScreen].bounds.size.width == 375){
        
        self.bottomCv.constant = 58 ;
        self.heigthClockView.constant = 101;
        self.widthMap.constant = 80 ;
        [self.btnMap  setTitleEdgeInsets:UIEdgeInsetsMake(50, -260, 0, 0)];
    }
    else{
        
        self.bottomCv.constant = 58 ;
        
        
    }

    
    
}


-(void)TABdATA{
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView removeFromSuperview];
    
    NSArray *myNibsArray = [[NSBundle mainBundle] loadNibNamed:@"Tab" owner:self options:nil];
    delegate.tabView = [myNibsArray objectAtIndex:0];
    if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 90, self.view.frame.size.width, 90);
        
    }else if ([UIScreen mainScreen].bounds.size.width == 1024) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 130, self.view.frame.size.width, 130);
        
    }else{

    delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height-delegate.tabView.frame.size.height, self.view.frame.size.width, delegate.tabView.frame.size.height);
    }
    
    [delegate.tabView.btnToday setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnSchedule setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnControlPanel setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnDashboard setBackgroundColor: [UIColor colorWithRed:0/255.0f green:32/255.0f blue:41/255.0f alpha:1]];
    
    [delegate.tabView.btnMenu setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    
    RoleStr =   [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
    NSLog(@"%@",RoleStr);
    
    
    if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
        
        
        if ([UIScreen mainScreen].bounds.size.width == 768){
            delegate.tabView.btnScheduleWidth.constant = -200 ;
            delegate.tabView.btnSchedule.hidden = YES;
            
        }else if ([UIScreen mainScreen].bounds.size.width == 1024) {
            delegate.tabView.btnScheduleWidth.constant = -270 ;
            delegate.tabView.btnSchedule.hidden = YES;
            
        }else{
        delegate.tabView.btnScheduleWidth.constant = -77 ;
            
        }
        
        [delegate.tabView.btnSchedule setImage:nil forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setTitle:nil forState:UIControlStateNormal];
        
        
    }else{
        delegate.tabView.btnScheduleWidth.constant = 0 ;
        [delegate.tabView.btnSchedule setImage:[UIImage imageNamed:@"schedule-call.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setTitle:@"Schedule Meeting" forState:UIControlStateNormal];
        
    }
    
    [self insets];
   // self.view.frame = [UIScreen mainScreen].bounds ;
    
    
    [self.view addSubview:delegate.tabView];
    
    
}




- (IBAction)MapButton:(UIButton *)sender {
    
    MapVc *map  = [[MapVc alloc]init];
    map = [self.storyboard instantiateViewControllerWithIdentifier:@"MapVc"];
    [self.navigationController pushViewController:map animated:YES];
    
    
    
    
}
- (IBAction)btnMeeting:(id)sender {
    MeetingViewController *meeting  = [[MeetingViewController alloc]init];
    meeting = [self.storyboard instantiateViewControllerWithIdentifier:@"MeetingViewController"];
    [self.navigationController pushViewController:meeting animated:YES];
}
- (IBAction)palnSummaryClicked:(id)sender {
    planSumaryViewController *PlanSummaryy  = [[planSumaryViewController alloc]init];
    PlanSummaryy = [self.storyboard instantiateViewControllerWithIdentifier:@"planSumaryViewController"];
    [self.navigationController pushViewController:PlanSummaryy animated:YES];
    
}
- (IBAction)btnBugget:(id)sender {
    BudgetMeetingViewController *budgetmeeting  = [[BudgetMeetingViewController alloc]init];
    budgetmeeting = [self.storyboard instantiateViewControllerWithIdentifier:@"Budget"];
    [self.navigationController pushViewController:budgetmeeting animated:YES];
}
- (IBAction)btnBillGraph:(id)sender

{
    
    
    billGraphVC *budgetmeeting  = [[billGraphVC alloc]init];
    budgetmeeting = [self.storyboard instantiateViewControllerWithIdentifier:@"billGraphVC"];
    [self.navigationController pushViewController:budgetmeeting animated:YES];
    
    

}

-(void)insets{
    
    //    _LineCharVc = [self.storyboard instantiateViewControllerWithIdentifier:@"SwiftViewController"];
    //
    //    [self presentViewController:_LineCharVc animated:YES completion:nil];

    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:NO];
    
    
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 14, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 17, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
            [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
            
            

            
        }else{
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 14, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 17, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            
        }
        
        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 375) {
        
        
        if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
            [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
            [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            
            
            
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 25, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 25, 0, 0)];
            
            
        }else{

        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        
        
        [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
        [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
        [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
        [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
        [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];

        }
        
    }else if ([UIScreen mainScreen].bounds.size.width == 414) {
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -40, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -28, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        
        
        
        if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 23, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 27, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 27, 0, 0)];
            
            
        }else{
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 23, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 24, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 24, 0, 0)];
            
        }
    }else if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        
        [delegate.tabView.btnToday setImage: [UIImage imageNamed:@"ipad-today.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnControlPanel setImage: [UIImage imageNamed:@"ipad-control-panel.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnDashboard setImage: [UIImage imageNamed:@"ipad-dashboard.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setImage: [UIImage imageNamed:@"ipad-schedule-meeting.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnMenu setImage: [UIImage imageNamed:@"ipad-menu.png"] forState:UIControlStateNormal];
        
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:12]];
        
        
        
        
        
        
        if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 43, 20, 83)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(65, -183, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 53, 20, 93)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 63, 20, 73)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(10, 63, 25, 73)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 63, 20, 73)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];

            
            
        }else{
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 20, 45)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(10, 50, 25, 55)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 40, 20, 45)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            
        }
        
    } else if ([UIScreen mainScreen].bounds.size.width == 1024){
        
        [delegate.tabView.btnToday setImage: [UIImage imageNamed:@"ipad-today.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnControlPanel setImage: [UIImage imageNamed:@"ipad-control-panel.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnDashboard setImage: [UIImage imageNamed:@"ipad-dashboard.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setImage: [UIImage imageNamed:@"ipad-schedule-meeting.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnMenu setImage: [UIImage imageNamed:@"ipad-menu.png"] forState:UIControlStateNormal];
        
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:12]];
        
        if ([RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 43, 20, 83)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(95, -183, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 53, 20, 93)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(95, -157, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 63, 20, 73)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(85, -157, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(20, 93, 35, 103)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(95, -157, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 63, 20, 73)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(85, -157, 0, 0)];
            
            
            
        }else{
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 20, 45)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 50, 20, 55)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(20, 63, 35, 73)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(8, 50, 22, 55)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            
        }
        
        
    }


    
}

//-(void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
//{
//    NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationMaskLandscape];
//    [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
//    
//}
//
//-(NSUInteger)supportedInterfaceOrientations
//{
//    return UIInterfaceOrientationMaskLandscape;
//}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return dashArray.count;
    
    
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    customDashCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"customDashCell" forIndexPath:indexPath];
    
//    if ([UIScreen mainScreen].bounds.size.width == 1024){
//        CGRect frm = cell.imgDash.frame ;
//        frm.size.height = 500 ;
//        frm.size.width = 500 ;
//        
//        cell.imgDash.frame = frm ;
//        
//        
//        
//    }
//    
    
    cell.txtDash.text = [dashArray objectAtIndex:indexPath.row];
    cell.imgDash.image = [UIImage imageNamed:[imgArray objectAtIndex:indexPath.row]];
    
    
    
    
    
    
    
    return cell;
    
}


- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    float width = collectionView.frame.size.width / 2 - 8;
    float height = collectionView.frame.size.height / 2 - 8;

    return CGSizeMake(width, height);
    
    
    
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0.0;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 5.0;
}

- (UIEdgeInsets)collectionView:
(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    //    return UIEdgeInsetsMake(50, 20, 50, 20);
    return UIEdgeInsetsMake(0,5, 0, 5);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0) {
        MeetingViewController *meeting  = [[MeetingViewController alloc]init];
        meeting = [self.storyboard instantiateViewControllerWithIdentifier:@"MeetingViewController"];
        [self.navigationController pushViewController:meeting animated:YES];

        
    }else if (indexPath.row== 1){
        planSumaryViewController *PlanSummaryy  = [[planSumaryViewController alloc]init];
        PlanSummaryy = [self.storyboard instantiateViewControllerWithIdentifier:@"planSumaryViewController"];
        [self.navigationController pushViewController:PlanSummaryy animated:YES];
        
    }else if (indexPath.row== 2){
        BudgetMeetingViewController *budgetmeeting  = [[BudgetMeetingViewController alloc]init];
        budgetmeeting = [self.storyboard instantiateViewControllerWithIdentifier:@"Budget"];
        [self.navigationController pushViewController:budgetmeeting animated:YES];

        
    }else if (indexPath.row== 3){
        
        billGraphVC *budgetmeeting  = [[billGraphVC alloc]init];
        budgetmeeting = [self.storyboard instantiateViewControllerWithIdentifier:@"billGraphVC"];
        [self.navigationController pushViewController:budgetmeeting animated:YES];

        
    }


}
@end
