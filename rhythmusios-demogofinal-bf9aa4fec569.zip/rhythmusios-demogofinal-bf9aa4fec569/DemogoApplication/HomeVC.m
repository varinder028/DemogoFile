//
//  HomeVC.m
//  DemogoApplication
//
//  Created by katoch on 20/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "HomeVC.h"
#import "TodayMeetingCell.h"
#import <CoreLocation/CoreLocation.h>
#import "AppDelegate.h"
#import "NotificationVC.h"
#import "KVNProgress.h"
#import "CKViewController.h"
#import "NotificationVc.h"
#import <AFNetworking/AFNetworking.h>
#import "ForgotPAsViewController.h"
#import "Reachability.h"
#import "dropCell.h"


@interface HomeVC ()<CLLocationManagerDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate>
{
    
    NSMutableString *versionNo;
    NSMutableString *OperatingNa;
    NSString *latitude;
    NSString *longitude;
    NSString *newDateString;
    NSString* Base64encodePassword;
    
    
}

@end

@implementation HomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _dropTableView.separatorStyle = UITableViewCellSeparatorStyleNone ;

     [self.dropTableView setHidden:YES];
    [self.view bringSubviewToFront:_dropTableView];
    
    _dropTableView.backgroundColor =  [UIColor colorWithRed:36/255.0f green:29/255.0f blue:36/255.0f alpha:1];

    
    
//    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(_gradientConfView.frame.origin.x,_gradientConfView.frame.origin.y,_gradientConfView.frame.size.width,_gradientConfView.frame.size.height)];
//    view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
//    gradient.startPoint = CGPointZero;
//    gradient.endPoint = CGPointMake(1, 1);
//    gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:34.0/255.0 green:211/255.0 blue:198/255.0 alpha:1.0] CGColor],(id)[[UIColor colorWithRed:145/255.0 green:72.0/255.0 blue:203/255.0 alpha:1.0] CGColor], nil];
//    [view.layer addSublayer:gradient];
//    
//    [self.gradientConfView addSubview:view];
//
   
    
//    [_gradientConfView bringSubviewToFront:_txtName];
//    [self.gradientConfView bringSubviewToFront:_txtCity];
//    [self.gradientConfView bringSubviewToFront:_txtUserEmail];
//   
//    
//    [self.gradientView bringSubviewToFront:_txtMobileImg];
//    [self.gradientView bringSubviewToFront:_txtAdmin];
//    [self.gradientView bringSubviewToFront:_txtMobileTxt];
//    [self.gradientView bringSubviewToFront:_imgCity];
//    [self.gradientView bringSubviewToFront:_myProfileImg];
    

    
    
    _confViewDetail.layer.cornerRadius = 5.0f;
    [_confViewDetail clipsToBounds];
    
    
    [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"AlreadyLogin"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    _txtCompanyName.rightViewMode = UITextFieldViewModeAlways;
    _txtCompanyName.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    [self.view bringSubviewToFront:_txtCompanyName.rightView];

    
    NSUserDefaults *defaultvalue = [NSUserDefaults standardUserDefaults];
    
    [defaultvalue setBool:true forKey:@"IncWidth"];
    
    [defaultvalue synchronize];
    
    
    
    
   
    _txtCompanyName.rightViewMode = UITextFieldViewModeAlways;
    _txtCompanyName.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    [self.view bringSubviewToFront:_txtCompanyName.rightView];
    
    _btnAdd.layer.cornerRadius = 5.0f ;
    [_btnAdd clipsToBounds];
    
    
    [self findFiles:@"csv"];
    
    [self ls];
    
    
    
    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"getScheduled"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    companyToken = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    
   
    
//    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"ConfId"];
//    [[NSUserDefaults standardUserDefaults]synchronize];

    [self.conferenceDetailView setHidden:YES];
    self.conferenceDetailView.backgroundColor = [UIColor colorWithRed:0/255.0f green:0/255.0f  blue:0/255.0f  alpha:0.6];
    UITapGestureRecognizer *gesRecognizer4 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(calenderPush)]; // Declare the Gesture.
    gesRecognizer4.delegate = self;
    [_calnderView addGestureRecognizer:gesRecognizer4];
    
    UITapGestureRecognizer *gesRecognizer3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(TapAddAccoountView)]; // Declare the Gesture.
    gesRecognizer3.delegate = self;
    [_addAccountView addGestureRecognizer:gesRecognizer3];
    
    UITapGestureRecognizer *gesRecognizer1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(TapConfView)]; // Declare the Gesture.
    gesRecognizer1.delegate = self;
    [_conferenceDetailView addGestureRecognizer:gesRecognizer1];
    
    UITapGestureRecognizer *gesRecognizerConf = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headerView)]; // Declare the Gesture.
    gesRecognizerConf.delegate = self;
    [self.view addGestureRecognizer:gesRecognizerConf];

    
    calenderDates = [[NSMutableArray alloc]init];
    
   
    
    
    
    
    dropDownListArray = [[NSMutableArray alloc]init];
    
    listCompanies = [[NSMutableArray alloc]init];
    
    //dropDownListArray = [[NSUserDefaults standardUserDefaults]valueForKey:@"Accounts"];
    
    
    
     TodayArray  = [NSArray new];
    todayMeetingArray = [[NSMutableArray alloc]init];
    UpcomingMeetingArray = [[NSMutableArray alloc]init];
    
    
    signUpInfoArray = [[NSMutableArray alloc]init];
    
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:NO];
    
    NSAttributedString*selectComp=[[NSAttributedString alloc]
                                   
                                   initWithString:@"Email/Mobile no"
                                   
                                   attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.txtEmail.attributedPlaceholder = selectComp ;
    
    
    NSAttributedString*selectemail=[[NSAttributedString alloc]
                                    
                                    initWithString:@"Select Company"
                                    
                                    attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.txtCompanyName.attributedPlaceholder = selectemail ;
    
    
    
    NSAttributedString*selectPassword=[[NSAttributedString alloc]
                                       
                                       initWithString:@"Password"
                                       
                                       attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.txtPassword.attributedPlaceholder = selectPassword ;
    
    
    
    
    _todayTableView.separatorStyle = UITableViewCellSelectionStyleNone ;
    _upcomingTableView.separatorStyle = UITableViewCellSelectionStyleNone ;
    
    
    _locationManager = [[CLLocationManager alloc] init];
    [self getLocation];

    
    
    /////       latitude,longitude,datetime, version


    versionNo= [[NSMutableString alloc]initWithFormat:@"%@",[UIDevice currentDevice].systemVersion];
    
    OperatingNa= [[NSMutableString alloc]initWithFormat:@"%@",[UIDevice currentDevice].systemName];
    
    NSLog(@"%@",versionNo);
    
    NSLog(@"%@",OperatingNa);
    
    NSDate * now = [NSDate date];
    
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    
    [outputFormatter setDateFormat:@"hh:mm:ss"];
    
    NSString * newDat = [outputFormatter stringFromDate:now];
    
    newDateString  = [NSString stringWithFormat:@"%ld", (long)[newDat longLongValue]];
    
    NSLog(@"newDateString %@", newDateString);
    
    
    NSLog(@"%@",newDateString);
    
    
    
    
    NSDate *adDate = [NSDate date];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"hh:mm";
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]];
    
    
    NSString*strr = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:now]];
    NSLog(@"%@",strr);

    
    // Convert string to date object
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"hh:mm"];
    NSDate *date1 = [dateFormat dateFromString:strr];
    timeInMiliseconds = [date1 timeIntervalSince1970]*1000;
    strTime = [NSString stringWithFormat:@"%f",timeInMiliseconds];
    
    
    EMAILDATA =[[NSMutableString alloc]init];
    
    userEmailID = [[NSDictionary alloc]init];

    
    [_txtEmail addTarget:self
                           action:@selector(textFieldDidChange:)
                 forControlEvents:UIControlEventEditingChanged];
    
    companyNameArray = [NSMutableArray new];
    
    _addAccountView.backgroundColor = [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:0.7];
    
    _txtCompanyTop.constant = 0;
    _lblTop.constant = 0;
    _addAccountSubViewHeight.constant = 275;
    _lblCompanyLayout.constant = 0 ;
    _txtCompanyHeight.constant = 0;
    
    
    [self.addAccountView setHidden:YES];
    
    NSCalendar *calendar= [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSCalendarUnit unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit | NSWeekdayCalendarUnit;
    NSDate *date = [NSDate date];
    NSDateComponents *dateComponents = [calendar components:unitFlags fromDate:date];
  
    
    NSInteger month = [dateComponents month];
    NSInteger day = [dateComponents day];
    NSInteger weekDay = [dateComponents weekday];
    
    
    NSInteger monthNumber = month;   //November
    NSDateFormatter *df = [[NSDateFormatter alloc] init] ;
    NSString *monthName = [[df monthSymbols] objectAtIndex:(monthNumber-1)];
    
    NSInteger weekDay1 = weekDay;  //tuesday
    NSDateFormatter *df1 = [[NSDateFormatter alloc] init] ;
    NSString *week = [[df1 weekdaySymbols] objectAtIndex:(weekDay1-1)];
    
    self.txtMonth.text = monthName ;
    self.txtTodayDate.text = [NSString stringWithFormat:@"%ld",(long)day];
    self.txtDay.text = week ;
    
    accountNameArray = [NSMutableArray new];
    
    
   
    
    UITapGestureRecognizer *gesRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)]; // Declare the Gesture.
    gesRecognizer.delegate = self;
    [_todaysMeetingView addGestureRecognizer:gesRecognizer]; // Add Gesture to your view.
    
    // Declare the Gesture Recognizer handler method.
    
    
    
    todayMeetingArray = [NSMutableArray new];
    
    
    _userImg.layer.cornerRadius  = _userImg.frame.size.width/2 ;
    
    _txtUserName.rightViewMode = UITextFieldViewModeAlways;
    _txtUserName.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    
    
    
    
    if ([UIScreen mainScreen].bounds.size.width == 768 ){
        
        self.heightTodayLayout.constant = 400;
        _heightImgToday.constant = 230 ;
        _heigthImgUpcoming.constant = 225 ;
        // _bottomLayoutToday.constant = 0;
        [self.view layoutIfNeeded];    }
    else if ([UIScreen mainScreen].bounds.size.width == 1024 ){
        
        self.heightTodayLayout.constant = 600;
        _heightImgToday.constant = 330 ;
        _heigthImgUpcoming.constant = 325 ;
        // _bottomLayoutToday.constant = 0;
        [self.view layoutIfNeeded];
        
    }
    
   else if ([UIScreen mainScreen].bounds.size.width == 320) {
        
        if ([UIScreen mainScreen].bounds.size.height == 568) {
            self.heightTodayLayout.constant = 185;
            _heightImgToday.constant = 120 ;
            _heigthImgUpcoming.constant = 65 ;
            
            //self.imgHeigthLayout.constant = 205 ;
            //  _bottomLayoutToday.constant = 0 ;
            [self.view layoutIfNeeded];
        }else{
            self.heightTodayLayout.constant = 135;
            _heightImgToday.constant = 80 ;
            _heigthImgUpcoming.constant = 60 ;
            
            [self.view layoutIfNeeded];

            
        }
        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 375) {
        
        self.heightTodayLayout.constant = 250;
        _heightImgToday.constant = 140 ;
        _heigthImgUpcoming.constant = 112 ;
        // _bottomLayoutToday.constant = 0;
        [self.view layoutIfNeeded];
    }else if ([UIScreen mainScreen].bounds.size.width == 414) {
        self.heightTodayLayout.constant = 300;
        _heightImgToday.constant = 140 ;
        _heigthImgUpcoming.constant = 112 ;
        // _bottomLayoutToday.constant = 0;
        [self.view layoutIfNeeded];
    }
    
    
    // Do any additional setup after loading the view.
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    isSessionNil = false ;
    
//        sessionhOME = nil ;
    
//        [sessionhOME invalidateAndCancel];
//    [sessionhOME finishTasksAndInvalidate];
    
    
    

    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView removeFromSuperview];
    

    NSArray *myNibsArray = [[NSBundle mainBundle] loadNibNamed:@"Tab" owner:self options:nil];
    delegate.tabView = [myNibsArray objectAtIndex:0];
    
    if ([UIScreen mainScreen].bounds.size.width == 768) {
        
         delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 90, self.view.frame.size.width, 90);
        
    }else if ([UIScreen mainScreen].bounds.size.width == 1024) {
        
        delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height- 130, self.view.frame.size.width, 130);
        
    }else{
   delegate.tabView.frame  = CGRectMake(0, self.view.frame.size.height-delegate.tabView.frame.size.height, self.view.frame.size.width, delegate.tabView.frame.size.height);
        
    }
    
    
    [delegate.tabView.btnToday setBackgroundColor: [UIColor colorWithRed:0/255.0f green:32/255.0f blue:40/255.0f alpha:1]];
    
    [delegate.tabView.btnSchedule setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnControlPanel setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnDashboard setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    
    [delegate.tabView.btnMenu setBackgroundColor: [UIColor colorWithRed:0/255.0f green:73/255.0f blue:92/255.0f alpha:1]];
    

    [self.view addSubview:delegate.tabView];
    
    NSUserDefaults *defaults = [[NSUserDefaults alloc]init];
    
    NSData *dictionaryData = [defaults objectForKey:@"Accounts"];
    dropDownListArray = [NSKeyedUnarchiver unarchiveObjectWithData:dictionaryData];
    
    listCompanies = [dropDownListArray valueForKey:@"cmpNm"];
    NSLog(@"%@",listCompanies);
    
    
    
//    signUpInfoArray = [[NSUserDefaults standardUserDefaults]valueForKey:@"signUpInfo"];
    

    
//    NSData *dictionaryData2 = [defaults objectForKey:@"signUpInfo"];
//    signUpInfoArray = [NSKeyedUnarchiver unarchiveObjectWithData:dictionaryData2];
//
//
    
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    companyImage = [[NSUserDefaults standardUserDefaults]valueForKey:@"comLogo"];
     companyName = [[NSUserDefaults standardUserDefaults]valueForKey:@"cmpNm"];
     NSString*StrName = [[NSUserDefaults standardUserDefaults]valueForKey:@"firstName"];
   // NSString*name = [CompanyDetailArray valueForKey:@"firstName"];
    NSArray *items = [StrName componentsSeparatedByString:@" "];
    
    
    if ([UIScreen mainScreen].bounds.size.width == 320) {
       CompanyUserName = items[0];
        companyStr = [NSString stringWithFormat:@"%@",CompanyUserName];
        
        
    }else{
        CompanyUserName = StrName ;
    companyStr = [NSString stringWithFormat:@"%@",CompanyUserName];
        
    }
    _RoleStr =   [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
    NSLog(@"%@",_RoleStr);

    
    if ([_RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
        
         AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        if ([UIScreen mainScreen].bounds.size.width == 768){
            delegate.tabView.btnScheduleWidth.constant = -200 ;
            delegate.tabView.btnSchedule.hidden = YES;
            
        }else if ([UIScreen mainScreen].bounds.size.width == 1024) {
            delegate.tabView.btnScheduleWidth.constant = -270 ;
            delegate.tabView.btnSchedule.hidden = YES;
            
        }else{
        delegate.tabView.btnScheduleWidth.constant = -77 ;
        }
        
        [delegate.tabView.btnSchedule setImage:nil forState:UIControlStateNormal];
         [delegate.tabView.btnSchedule setTitle:nil forState:UIControlStateNormal];
        
        
    }else{
        delegate.tabView.btnSchedule.hidden = NO;
         delegate.tabView.btnScheduleWidth.constant = 0 ;
        [delegate.tabView.btnSchedule setImage:[UIImage imageNamed:@"schedule-call.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setTitle:@"Schedule Meeting" forState:UIControlStateNormal];
        
    }
    
    [self insets];

    
    [[NSUserDefaults standardUserDefaults]setObject:companyStr forKey:@"cm"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        _txtUserName.font = [UIFont systemFontOfSize:14];
        
        
    }else{
   
        _txtUserName.font = [UIFont systemFontOfSize:14];
    }
     self.txtUserName.text = companyStr ;
  
    [[NSUserDefaults standardUserDefaults]setObject:personId forKey:@"personId"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setObject:companyName forKey:@"cmpNm"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setObject:companyImage forKey:@"comLogo"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setObject:companyId forKey:@"CompanyId"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setObject:CompanyUserName forKey:@"firstName"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [[NSUserDefaults standardUserDefaults]setObject:_RoleStr forKey:@"role"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    

    
    
    [KVNProgress show];
    
  
    [self  GetProfileFromServer];
     [self GetConferenceDat];

   // [self performSelector:@selector(timer) withObject:nil afterDelay:0.1];
    
}

-(void)timer{
    
    
      myTimer =   [NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(GetConferenceDat) userInfo:nil repeats:YES];
    
}


- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    [taskHome  cancel];
    sessionhOME= nil;
    isSessionNil = YES;
    manager = nil ;
    

    
    
}




-(void)TapConfView{
    
    [self.conferenceDetailView setHidden:YES];
    
    
}

+ (CAGradientLayer *)flavescentGradientLayer
{
    UIColor *topColor = [UIColor colorWithRed:34.0/255.0 green:111/255.0 blue:144/255.0 alpha:6.0];
    UIColor *bottomColor = [UIColor colorWithRed:145/255.0 green:72/255.0 blue:203/255.0 alpha:6.0];
    
   
    
    NSArray *gradientColors = [NSArray arrayWithObjects:(id)topColor.CGColor, (id)bottomColor.CGColor, nil];
    NSArray *gradientLocations = [NSArray arrayWithObjects:[NSNumber numberWithInt:0.0],[NSNumber numberWithInt:1.0], nil];
    
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.colors = gradientColors;
    gradientLayer.locations = gradientLocations;
    
    return gradientLayer;
}



    
    //if you want superclass's behaviour...  (and lay outing of children)
    // resize your layers based on the view's new frame



- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id <UIViewControllerTransitionCoordinator>)coordinato{
    
    
}


-(void)viewDidLayoutSubviews{
    
        [super viewDidLayoutSubviews];
   

    
    
//    gradient = [CAGradientLayer layer];
//    gradient.frame = _gradientConfView.bounds;
//    
//    gradient.colors = @[ (__bridge id)[UIColor blueColor].CGColor, (__bridge id)[UIColor blackColor].CGColor ];
//    [self.gradientConfView.layer addSublayer:gradient];
   
//    gradient = [CAGradientLayer layer];
//    gradient.frame = _confViewDetail.bounds;
//    gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor blackColor] CGColor], (id)    [[UIColor whiteColor] CGColor], nil];
//    [_confViewDetail.layer insertSublayer:gradient atIndex:0];
    
    
//    CAGradientLayer *gradient = [CAGradientLayer layer];
//    gradient.frame = _gradientConfView.bounds;
//    gradient.startPoint = CGPointZero;
//    gradient.endPoint = CGPointMake(1, 1);
//    gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:34.0/255.0 green:111/255.0 blue:144/255.0 alpha:1.0] CGColor],(id)[[UIColor colorWithRed:145/255.0 green:72.0/255.0 blue:203/255.0 alpha:6.0] CGColor], nil];
//    
//    [_gradientConfView.layer addSublayer:gradient];
    
    
    NSLog(@"%@",upcomingDuration);
      NSLog(@"%@",Todayduration);
    self.userImg.layer.cornerRadius = self.userImg.frame.size.width/2 ;
    [self.userImg clipsToBounds];
    
    

  
 
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isDescendantOfView:_todayTableView] || [touch.view isDescendantOfView:_upcomingTableView] ) {
        
       [dropDownView  closeAnimation];
        [self.dropTableView setHidden:YES];
        
        
       
        return NO;
    }
    if ([touch.view isDescendantOfView:dropDownView.view]) {
        
      //  [dropDownView closeAnimation];
        
        
        return NO;
    }
    

    if ([touch.view isDescendantOfView:_dropTableView]) {
        
        
        
        return NO;
    }

  
    
    return YES;
}


- (void)handleTap:(UITapGestureRecognizer *)gestureRecognizer{
    
    
    
    
}



-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}




-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //   return 6;
    
    if (tableView == _dropTableView) {
         return [arrList count];
    }
    
   else if (tableView == _todayTableView) {
        
        if (todayMeetingArray.count >0) {
            self.todayImg.hidden = YES;
        }else{
            
             self.todayImg.hidden = NO;
        }
        return todayMeetingArray.count;
    }
    
    else{
        
        if (UpcomingMeetingArray.count >0) {
            self.upcomingImg.hidden = YES;
        }else{
            
            self.upcomingImg.hidden = NO;
        }
        return UpcomingMeetingArray.count;
        
    }
}




-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (tableView == _dropTableView) {
        
        
       
            
                dropCell *cell = [tableView dequeueReusableCellWithIdentifier:@"dropCell"];
                if (cell==nil) {
                    NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"dropCell" owner:self options:nil];
                    
                    cell= arr[0];
                    
                }
        
        
        
        

        
                cell.lblName.text = [NSString stringWithFormat:@"%@",[arrList objectAtIndex:indexPath.row]];
        [cell.btnDelete addTarget:self action:@selector(deleteProfile:) forControlEvents:UIControlEventTouchUpInside];
        
                cell.imageView.image =  [UIImage imageNamed:@"16x16.png"];
                
        cell.backgroundColor = [UIColor clearColor];
        
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.lblName.textColor = [UIColor whiteColor];
        
        cell.btnDelete.tag = indexPath.row ;
        
        
        NSString *strRole = [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
        if ([strRole isEqualToString:@"ROLE_SUPER_ADMIN"]) {
            
            [cell.btnDelete setHidden:NO];
            
        }else{
            [cell.btnDelete setHidden:YES];

            
        }
        
        
        if ([[arrList objectAtIndex:indexPath.row]isEqualToString:@"Add Person"]){
            [cell.btnDelete setHidden:YES];
            
        }else{
                        
        }

        
        
        if (indexPath.row == 0) {
            [cell.btnDelete setHidden:YES];
        }
        

        
                // cell.lblName.text = [NSString stringWithFormat:@"%@",[arrayData objectAtIndex:indexPath.row]];
                
                
                return cell;
                
                
            

    }
    
  else  if (tableView == _todayTableView) {
        TodayMeetingCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TodayMeetingCell"];
        if (cell==nil) {
            NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"TodayMeetingCell" owner:self options:nil];
            
            cell= arr[0];
            
        }
          cell.backgroundColor = [UIColor clearColor];
        [cell.textChairperson setFont:[UIFont systemFontOfSize:10]];
        
       
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        
        if (todayMeetingArray.count>0) {
             self.todayImg.hidden = YES;
            
            
            
            [cell.txtImg sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://182.76.44.135:8080/%@",[[todayMeetingArray valueForKey:@"cmpLg"]objectAtIndex:indexPath.row]]]placeholderImage:[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"]];
            
            
            cell.txtImg.layer.cornerRadius = cell.txtImg.frame.size.width/2 ;
            cell.txtImg.layer.masksToBounds = YES;
    
            
            cell.textMode.text = [[todayMeetingArray valueForKey:@"confDialType"]objectAtIndex:indexPath.row];
            
            cell.textChairperson.text = [[todayMeetingArray valueForKey:@"firstName"]objectAtIndex:indexPath.row];
            NSString *start = [[todayMeetingArray valueForKey:@"strtTime"]objectAtIndex:indexPath.row];
            NSString *end = [[todayMeetingArray valueForKey:@"endTime"]objectAtIndex:indexPath.row];
            
            Todayduration = [[todayMeetingArray valueForKey:@"duration"]objectAtIndex:indexPath.row];
           
            
            
            double startmiliSec = start.doubleValue;
            double endMiliSec = end.doubleValue;
            
            NSDate* startTime = [NSDate dateWithTimeIntervalSince1970:startmiliSec / 1000.0];
            NSDate* EndTime = [NSDate dateWithTimeIntervalSince1970:endMiliSec / 1000.0];
            
            NSDate *FiveMinutesDate = [startTime dateByAddingTimeInterval:-60*5];
            
            
            NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
            [outputFormatter setDateFormat:@"HH:mm"];
            outputFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
            
            
             NSString * currntStr = [outputFormatter stringFromDate:startToday];
            NSString * fiveMStr = [outputFormatter stringFromDate:FiveMinutesDate];
            
            NSString * StartTimeStr = [outputFormatter stringFromDate:startTime];
            NSString * EndTimeStr = [outputFormatter stringFromDate:EndTime];
            cell.txtTime.text =  StartTimeStr;
            
            
            
            
            //  for green cOLOR BEFORE cONFERENCEE
        NSString *dd = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"date"]objectAtIndex:indexPath.row]];
            dd = [dd stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
            
            
        NSString *dd2 = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"endOffDate"]objectAtIndex:indexPath.row]];
            dd2 = [dd2 stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
            
            
                       // convertingTodate
                        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                        dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
                         dateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
                        NSDate *datecurrent = [dateFormatter dateFromString:dd];
            
                        NSDate *dateEnd = [dateFormatter dateFromString:dd2];
                         NSDate *datebeforeFive = [datecurrent dateByAddingTimeInterval:-60*5];
            
            NSString*strConId  = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"confId"]objectAtIndex:0]];
            
            [[NSUserDefaults standardUserDefaults]setObject:strConId forKey:@"ConfId"];
            [[NSUserDefaults standardUserDefaults]synchronize];

            
           

            
            if ([startToday compare:datebeforeFive]>=0 && [startToday compare:dateEnd]<0){
                
                cell.contentView.backgroundColor = [UIColor colorWithRed:0/255.0f green:100/255.0f blue:0/255.0f alpha:1];
                
                NSString*strConId  = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"confId"]objectAtIndex:0]];
                
                if (startToday >= datecurrent) {
                    
                
                    [[NSUserDefaults standardUserDefaults]setObject:strConId forKey:@"ConfId"];
                    [[NSUserDefaults standardUserDefaults]synchronize];

                }
                
                
                

            }else if ([[[confernceDetailArray objectAtIndex:indexPath.row] valueForKey:@"confStatus"]  isEqualToString:@"Running"] ) {
                
                cell.contentView.backgroundColor = [UIColor colorWithRed:0/255.0f green:100/255.0f blue:0/255.0f alpha:1];
                
                NSString*strConId  = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"confId"]objectAtIndex:0]];
                
                [[NSUserDefaults standardUserDefaults]setObject:strConId forKey:@"ConfId"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                
                
            }else{
                
                cell.contentView.backgroundColor = [UIColor blackColor];
                
                
            }

            
           
            
            
           
            
            ///todaydate
            
            NSString *dateString = [[todayMeetingArray valueForKey:@"confDateTime"]objectAtIndex:indexPath.row];
            double datemiliSec = dateString.doubleValue;
          NSDate* dateTime = [NSDate dateWithTimeIntervalSince1970:datemiliSec / 1000.0];
            
            
            NSDateFormatter *formattr = [[NSDateFormatter alloc] init];
            [formattr setDateFormat:@"dd-MMM-yyyy"];
            formattr.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
            
            NSString * dateTimeStr = [formattr stringFromDate:dateTime];
            NSLog(@"%@",dateTimeStr) ;
            
            
            cell.textDate.text = dateTimeStr ;
            
            

        }else{
            
            self.todayImg.hidden = NO;
//            [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"ConfId"];
//            [[NSUserDefaults standardUserDefaults]synchronize];
            
        }
        
        
//        cell.textChairperson.numberOfLines = 1;
//        cell.textChairperson.minimumFontSize = 8;
//        cell.textChairperson.adjustsFontSizeToFitWidth = YES;
        
        return cell;
        
    }
    
    else if (tableView == _upcomingTableView) {
        TodayMeetingCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TodayMeetingCell"];
        if (cell==nil) {
            NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"TodayMeetingCell" owner:self options:nil];
            
            cell= arr[0];
            
            
        }
        
        if (UpcomingMeetingArray.count>0) {
            self.upcomingImg.hidden = YES;
            
           cell.textMode.text = [[UpcomingMeetingArray valueForKey:@"confDialType"]objectAtIndex:indexPath.row];
            
            cell.textChairperson.text = [[UpcomingMeetingArray valueForKey:@"firstName"]objectAtIndex:indexPath.row];


        NSString *start = [[UpcomingMeetingArray valueForKey:@"strtTime"]objectAtIndex:indexPath.row];
        NSString *end = [[UpcomingMeetingArray valueForKey:@"endTime"]objectAtIndex:indexPath.row];
        upcomingDuration = [[UpcomingMeetingArray valueForKey:@"duration"]objectAtIndex:indexPath.row];
        
        double startmiliSec = start.doubleValue;
        double endMiliSec = end.doubleValue;
        NSDate* startTime = [NSDate dateWithTimeIntervalSince1970:startmiliSec / 1000.0];
        NSDate* EndTime = [NSDate dateWithTimeIntervalSince1970:endMiliSec / 1000.0];
            
        NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
        [outputFormatter setDateFormat:@"HH:mm"];
        outputFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        
      
        
        NSString * StartTimeStr = [outputFormatter stringFromDate:startTime];
        NSString * EndTimeStr = [outputFormatter stringFromDate:EndTime];
        
        cell.txtTime.text =  StartTimeStr;
            
            cell.txtImg.layer.cornerRadius = cell.txtImg.frame.size.width/2 ;

        
        NSString *dateString = [[UpcomingMeetingArray valueForKey:@"confDateTime"]objectAtIndex:indexPath.row];
        double datemiliSec = dateString.doubleValue;
        NSDate* dateTime = [NSDate dateWithTimeIntervalSince1970:datemiliSec / 1000.0];
        NSTimeInterval seconds = 5.30 * 60 *60;
        NSDate *Ofdate = [dateTime dateByAddingTimeInterval:seconds];
        
        NSDateFormatter *formattr = [[NSDateFormatter alloc] init];
        [formattr setDateFormat:@"dd-MMM-yyyy"];
        formattr.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        
        NSString * dateTimeStr = [formattr stringFromDate:Ofdate];
        NSLog(@"%@",dateTimeStr) ;
       cell.textDate.text = dateTimeStr ;
            
               [cell.txtImg sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://182.76.44.135:8080/%@",[[UpcomingMeetingArray valueForKey:@"cmpLg"]objectAtIndex:indexPath.row]]]placeholderImage:[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"]];
            
            cell.txtImg.layer.masksToBounds = YES;
            
        cell.backgroundColor = [UIColor clearColor];
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
       
            
            
        }else{
            
            self.upcomingImg.hidden = NO;

            
        }
        
         return cell;
        
    }
    
    else{
        
        return 0 ;
    }
    
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

{
    
    dropCell *cell = [[dropCell alloc]init];
    
    
    if (tableView == _dropTableView) {
        if ([[arrList objectAtIndex:indexPath.row]isEqualToString:@"Add Person"] ) {
            
            
            NSLog(@"Add person");
            [self.addAccountView setHidden:NO];
            [self.dropTableView setHidden:YES];
            
            
            
            
        }else{
           
            if ([UIScreen mainScreen].bounds.size.width == 320) {
                _txtUserName.text = [arrList objectAtIndex:indexPath.row];
                
                CompanyDetailArray = [[NSMutableArray alloc]init];
                CompanyDetailArray = [dropDownListArray objectAtIndex:indexPath.row];
                NSLog(@"%@",CompanyDetailArray);
                
                companyId = [CompanyDetailArray valueForKey:@"cmpId"];
                personId = [CompanyDetailArray valueForKey:@"personId"];
                companyImage = [CompanyDetailArray valueForKey:@"cmpLg"];
                companyName = [CompanyDetailArray valueForKey:@"cmpNm"];
                
                
                NSString*name = [CompanyDetailArray valueForKey:@"firstName"];
                NSArray *items = [name componentsSeparatedByString:@" "];
                CompanyUserName = items[0];
                
                companyStr = [NSString stringWithFormat:@"%@",CompanyUserName];
            }else{
                
                _txtUserName.text = [arrList objectAtIndex:indexPath.row];
                
                CompanyDetailArray = [[NSMutableArray alloc]init];
                CompanyDetailArray = [dropDownListArray objectAtIndex:indexPath.row];
                NSLog(@"%@",CompanyDetailArray);
                
                companyId = [CompanyDetailArray valueForKey:@"cmpId"];
                personId = [CompanyDetailArray valueForKey:@"personId"];
                companyImage = [CompanyDetailArray valueForKey:@"cmpLg"];
                companyName = [CompanyDetailArray valueForKey:@"cmpNm"];
                NSString*name = [CompanyDetailArray valueForKey:@"firstName"];
                NSArray *items = [name componentsSeparatedByString:@","];
                CompanyUserName = items[0];
                
                companyStr = [NSString stringWithFormat:@"%@(%@)",CompanyUserName,companyName];
                
            }
            
            
            
          
            
            
            NSString *role = [CompanyDetailArray valueForKey:@"role"];
            
            
            
            
            [[NSUserDefaults standardUserDefaults]setObject:personId forKey:@"personId"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [[NSUserDefaults standardUserDefaults]setObject:companyName forKey:@"cmpNm"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [[NSUserDefaults standardUserDefaults]setObject:companyImage forKey:@"comLogo"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [[NSUserDefaults standardUserDefaults]setObject:companyId forKey:@"CompanyId"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [[NSUserDefaults standardUserDefaults]setObject:CompanyUserName forKey:@"firstName"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [[NSUserDefaults standardUserDefaults]setObject:role forKey:@"role"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            
            [self.dropTableView setHidden:YES];
            
            
            
            [self viewWillAppear:YES];

        
    }
    
    }
  else if (tableView == _todayTableView) {
        
        [self.conferenceDetailView setHidden:NO];

        NSLog(@"%@",todayMeetingArray);
        //confSub
        
        
        
         NSString *memberPin = [[todayMeetingArray valueForKey:@"memberPin"]objectAtIndex:indexPath.row];
          NSString *conType = [[todayMeetingArray valueForKey:@"confDialType"]objectAtIndex:indexPath.row];
        
         self.lblPin.text = [NSString stringWithFormat:@"Your Dialin pin is %@",memberPin];
         dialInNumber = [[todayMeetingArray valueForKey:@"dialinnumber"]objectAtIndex:indexPath.row];
        
       
        
        
        //  for green cOLOR BEFORE cONFERENCEE
        NSString *dd = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"date"]objectAtIndex:indexPath.row]];
        dd = [dd stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
        
        
        NSString *dd2 = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"endOffDate"]objectAtIndex:indexPath.row]];
        dd2 = [dd2 stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
        
        
        // convertingTodate
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
        dateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        NSDate *datecurrent = [dateFormatter dateFromString:dd];
        
        NSDate *dateEnd = [dateFormatter dateFromString:dd2];
        NSDate *datebeforeFive = [datecurrent dateByAddingTimeInterval:-60*5];
        
        
        
        
        if ([startToday compare:datebeforeFive]>=0 && [startToday compare:dateEnd]<0){
            
          
            
            NSString*strConId  = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"confId"]objectAtIndex:indexPath.row]];
            
            if (startToday >= datecurrent) {
                
                
                [[NSUserDefaults standardUserDefaults]setObject:strConId forKey:@"ConfId"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                if ([conType isEqualToString:@"dialin"]) {
                    self.subConfHeight.constant = 208 ;
                    self.confHeight.constant = 260 ;
                 [self.btnJoinNow setHidden:NO];
                    self.lblPin.hidden = NO;
                    
                    
                    
                }
                else{
                    self.subConfHeight.constant = 130 ;
                    self.confHeight.constant = 180;
                    self.lblPin.text = @"";
                    [self.btnJoinNow setHidden:YES];
                     self.lblPin.hidden = YES;
                    
                    
                    
                }
                
                
            }else{
                self.subConfHeight.constant = 130 ;
                self.confHeight.constant = 180;
                self.lblPin.hidden = YES;
                [self.btnJoinNow setHidden:YES];
            }
            
        }else{
            
            self.subConfHeight.constant = 130 ;
            self.confHeight.constant = 180;
                 self.lblPin.hidden = YES;
             [self.btnJoinNow setHidden:YES];
            
            
        }
        

        
        
        
        
        
        
         NSString *confSub = [[todayMeetingArray valueForKey:@"confSub"]objectAtIndex:indexPath.row];
        
        //gettingTime
        NSString *start = [[todayMeetingArray valueForKey:@"strtTime"]objectAtIndex:indexPath.row];
        NSString *end = [[todayMeetingArray valueForKey:@"endTime"]objectAtIndex:indexPath.row];
       
        
        double startmiliSec = start.doubleValue;
        double endMiliSec = end.doubleValue;
        NSDate* startTime = [NSDate dateWithTimeIntervalSince1970:startmiliSec / 1000.0];
        NSDate* EndTime = [NSDate dateWithTimeIntervalSince1970:endMiliSec / 1000.0];
        
        NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
        [outputFormatter setDateFormat:@"hh:mm"];
        outputFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        
        
        
        NSString * StartTimeStr = [outputFormatter stringFromDate:startTime];
        NSString * EndTimeStr = [outputFormatter stringFromDate:EndTime];
        
        self.txtTime.text = [NSString stringWithFormat:@"%@ to %@" ,StartTimeStr,EndTimeStr];
        self.txtSubject.text = confSub ;
        
 //getDate
        
        NSString *dateString = [[todayMeetingArray valueForKey:@"confDateTime"]objectAtIndex:indexPath.row];
        double datemiliSec = dateString.doubleValue;
        NSDate* dateTime = [NSDate dateWithTimeIntervalSince1970:datemiliSec / 1000.0];
        
        
        NSDateFormatter *formattr = [[NSDateFormatter alloc] init];
        [formattr setDateFormat:@"dd-MM-yyyy"];
        formattr.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        
        NSString * dateTimeStr = [formattr stringFromDate:dateTime];
        NSLog(@"%@",dateTimeStr) ;
        
        
        self.txtDate.text = dateTimeStr ;
        
        [self.todayTableView deselectRowAtIndexPath:indexPath animated:YES];
        
    }else if (tableView == _upcomingTableView) {
        
        [self.conferenceDetailView setHidden:YES];

//        NSLog(@"%@",UpcomingMeetingArray);
//        //confSub
//        
//        self.subConfHeight.constant = 130 ;
//        self.confHeight.constant = 180;
//        self.lblPin.text = @"";
//        [self.btnJoinNow setHidden:YES];
//        
//        
//        
//        NSString *confSub = [[_upcomingTableView valueForKey:@"confSub"]objectAtIndex:indexPath.row];
//        
//        //gettingTime
//        NSString *start = [[_upcomingTableView valueForKey:@"strtTime"]objectAtIndex:indexPath.row];
//        NSString *end = [[_upcomingTableView valueForKey:@"endTime"]objectAtIndex:indexPath.row];
//        
//        
//        double startmiliSec = start.doubleValue;
//        double endMiliSec = end.doubleValue;
//        NSDate* startTime = [NSDate dateWithTimeIntervalSince1970:startmiliSec / 1000.0];
//        NSDate* EndTime = [NSDate dateWithTimeIntervalSince1970:endMiliSec / 1000.0];
//        
//        NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
//        [outputFormatter setDateFormat:@"hh:mm"];
//        outputFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
//        
//        
//        
//        NSString * StartTimeStr = [outputFormatter stringFromDate:startTime];
//        NSString * EndTimeStr = [outputFormatter stringFromDate:EndTime];
//        
//        self.txtTime.text = [NSString stringWithFormat:@"%@ to %@" ,StartTimeStr,EndTimeStr];
//        self.txtSubject.text = confSub ;
//        
//        //getDate
//        
//        NSString *dateString = [[_upcomingTableView valueForKey:@"confDateTime"]objectAtIndex:indexPath.row];
//        double datemiliSec = dateString.doubleValue;
//        NSDate* dateTime = [NSDate dateWithTimeIntervalSince1970:datemiliSec / 1000.0];
//        
//        
//        NSDateFormatter *formattr = [[NSDateFormatter alloc] init];
//        [formattr setDateFormat:@"dd-MM-yyyy"];
//        formattr.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
//        
//        NSString * dateTimeStr = [formattr stringFromDate:dateTime];
//        NSLog(@"%@",dateTimeStr) ;
//        
//        
//        self.txtDate.text = dateTimeStr ;
        [self.upcomingTableView deselectRowAtIndexPath:indexPath animated:YES];

        
    }
    
   
    
    
}


- (IBAction)todayMeetingClicked:(id)sender {
    
    [self.todayTableView reloadData];

    if (!_btnTodayMeeting.isSelected) {
        
        [_btnTodayMeeting setSelected:YES];
        _heightImgToday.constant = 0 ;
       
        
        _heightTodayLayout.constant = 0 ;
        _imgHeigthLayout.constant = 0 ;
        [self.view layoutIfNeeded];

        
        
    }
    else{
        if ([UIScreen mainScreen].bounds.size.width == 768){
            
            self.heightTodayLayout.constant = 400;
            _heightImgToday.constant = 230 ;
            _heigthImgUpcoming.constant = 225 ;
            // _bottomLayoutToday.constant = 0;
            [self.view layoutIfNeeded];
        } else if ([UIScreen mainScreen].bounds.size.width == 1024 ){
            
            self.heightTodayLayout.constant = 600;
            _heightImgToday.constant = 330 ;
            _heigthImgUpcoming.constant = 325 ;
            // _bottomLayoutToday.constant = 0;
            [self.view layoutIfNeeded];
            
        }
        
        else if ([UIScreen mainScreen].bounds.size.width == 320) {
            
            if ([UIScreen mainScreen].bounds.size.height == 568) {
                self.heightTodayLayout.constant = 185;
                _heightImgToday.constant = 120 ;
                _heigthImgUpcoming.constant = 65 ;
                
                //self.imgHeigthLayout.constant = 205 ;
                //  _bottomLayoutToday.constant = 0 ;
                [self.view layoutIfNeeded];
            }else{
                self.heightTodayLayout.constant = 135;
                _heightImgToday.constant = 80 ;
                _heigthImgUpcoming.constant = 60 ;
                
                [self.view layoutIfNeeded];
                
                
            }
            
            
        }else if ([UIScreen mainScreen].bounds.size.width == 375) {
            
            self.heightTodayLayout.constant = 250;
            _heightImgToday.constant = 140 ;
            _heigthImgUpcoming.constant = 112 ;
            // _bottomLayoutToday.constant = 0;
            [self.view layoutIfNeeded];
        }else if ([UIScreen mainScreen].bounds.size.width == 414) {
            self.heightTodayLayout.constant = 300;
            _heightImgToday.constant = 140 ;
            _heigthImgUpcoming.constant = 112 ;
            // _bottomLayoutToday.constant = 0;
            [self.view layoutIfNeeded];
        }
        
        [_btnTodayMeeting setSelected:NO];
        
        
    }
    
}


- (IBAction)upcomingMeetingClicked:(id)sender {
    
    [self.upcomingTableView reloadData];
    if (!_btnUpcomingMeeting.isSelected) {
            [_btnUpcomingMeeting setSelected:YES];
        
        [self.upcomingTableView setHidden:YES];
        
        
        [self.upcomingImg setHidden:YES];
        
    }else {
        
        [self.upcomingTableView setHidden:NO];
        
       [_btnUpcomingMeeting setSelected:NO];
        
        
        if (todayMeetingArray.count > 0) {
             [self.upcomingImg setHidden:YES];
            
        }else{
            
        [self.upcomingImg setHidden:NO];
            
        }
        
    }

}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
        
         if ( textField == _txtUserName){
            
            
//             [dropDownView closeAnimation];
//             
//             
//            if (dropDownView != nil) {
//                [dropDownView.view removeFromSuperview];
//                dropDownView = nil;
//            }
            
             

             [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"DropHome"];
             [[NSUserDefaults standardUserDefaults]synchronize];
             
             [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"Dropcell"];
             [[NSUserDefaults standardUserDefaults]synchronize];

             
             if ([dropDownListArray containsObject:@"Add Person"]) {
                 
                 [dropDownListArray removeObject:@"Add Person"];
                 
             }
             
             [[NSUserDefaults standardUserDefaults]setValue:arrList forKey:@"List"];
             [[NSUserDefaults standardUserDefaults]synchronize];
             
             
            arrList = [[NSMutableArray alloc]init];
             
             listCompanies = [[NSMutableArray alloc]init];
             
            
             for (NSDictionary*dict in dropDownListArray) {
                 
                 NSString*comNm =[NSString stringWithFormat:@"%@",[dict valueForKey:@"cmpNm"]];
                  NSString*strName =[NSString stringWithFormat:@"%@",[dict valueForKey:@"firstName"]];
                 
                 
                 if ([strName isEqualToString:@"null"] || strName == nil || [strName isKindOfClass:(id)[NSNull null]]) {
                     strName = @"" ;
                     
                 }
                 
                 NSString*str = [NSString stringWithFormat:@"%@(%@)",strName,comNm];
                 
                 
                 [listCompanies addObject:str];
                 

             }
            
             arrList = [NSMutableArray arrayWithArray:listCompanies];
             [arrList insertObject:@"Add Person" atIndex:listCompanies.count];

              [self.dropTableView setHidden:NO];
             [self.dropTableView reloadData];
            
             
             
//          NSMutableArray*arr = [NSMutableArray arrayWithArray:[dropDownListArray valueForKey:@"cmpNm"],[dropDownListArray valueForKey:@"firstName"]];
             
             
          //   listCompanies = [[NSMutableArray alloc]initWithArray: [dropDownListArray valueForKey:@"cmpNm"]];
             
             
            //   NSMutableArray*fN = [[NSMutableArray alloc]initWithArray: [dropDownListArray valueForKey:@"firstName"]];
             
             
             
            // listCompanies
             
             
             
          //   [listCompanies insertObject:@"Add Person" atIndex: listCompanies.count -1 ];
           
             
           //  [listCompanies insertObject:@"Add Person" atIndex: listCompanies.count];
             
             long maxHeight = 350 ;
             long  TableHeight = arrList.count *44 ;
             
             
             if (TableHeight >=maxHeight ) {
                 
                 TableHeight = 350 ;
             }
             else{
                 
                 TableHeight = arrList.count *44 ;
                 
             }
             
             CGRect frm = self.dropTableView.frame ;
             frm.size.height = TableHeight ;
             self.dropTableView.frame = frm ;
             
             
             
//
//            dropDownView = [[DropDownView alloc] initWithArrayData:arrList  cellHeight:40 heightTableView:TableHeight paddingTop:0 paddingLeft:0 paddingRight:0 refView:textField animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
//             
//             
//              self.dropDownTxtfield = textField ;
//            
//            dropDownView.delegate = self;
//            
//            [self.view addSubview:dropDownView.view];
//             [self.view bringSubviewToFront:dropDownView.view];
//             
//             
//            self.txtUserName = textField ;
//            
//            [dropDownView openAnimation];
            
            return false;
            
            
         }
    
    if (textField == _txtPassword) {
        
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        if ([_txtEmail.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Enter EmailId/Mobile Number first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alert show];
            
            return NO;
            
            
        }else{
            
            if (![_txtCompanyName.text isEqualToString:@""]) {
                
                
                
            }else{
                
                [self SaveDataSecondApi];
                
            }
            
            
            
        }
        
        
    }
    
    
    
    else if (textField == _txtCompanyName) {
        
        
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [self.txtEmail resignFirstResponder];
        [self SaveDataSecondApi];
        
        return false ;
        
    }

    return true ;
    
    
}


-(void)dropDownCellSelected:(NSInteger)returnIndex{
    
    if (_dropDownTxtfield == _txtUserName) {
        
    if ([[arrList objectAtIndex:returnIndex]isEqualToString:@"Add Person"] ) {
        NSLog(@"Add person");
        [self.addAccountView setHidden:NO];
        
        
        
    }else{
    
        if ([UIScreen mainScreen].bounds.size.width == 320) {
            _txtUserName.text = [arrList objectAtIndex:returnIndex];
            
            CompanyDetailArray = [[NSMutableArray alloc]init];
            CompanyDetailArray = [dropDownListArray objectAtIndex:returnIndex];
            NSLog(@"%@",CompanyDetailArray);
            
            companyId = [CompanyDetailArray valueForKey:@"cmpId"];
            personId = [CompanyDetailArray valueForKey:@"personId"];
            companyImage = [CompanyDetailArray valueForKey:@"cmpLg"];
            companyName = [CompanyDetailArray valueForKey:@"cmpNm"];
            
            
            NSString*name = [CompanyDetailArray valueForKey:@"firstName"];
            NSArray *items = [name componentsSeparatedByString:@" "];
            CompanyUserName = items[0];

            companyStr = [NSString stringWithFormat:@"%@",CompanyUserName];
        }else{
        
        _txtUserName.text = [arrList objectAtIndex:returnIndex];
        
        CompanyDetailArray = [[NSMutableArray alloc]init];
        CompanyDetailArray = [dropDownListArray objectAtIndex:returnIndex];
        NSLog(@"%@",CompanyDetailArray);
        
        companyId = [CompanyDetailArray valueForKey:@"cmpId"];
        personId = [CompanyDetailArray valueForKey:@"personId"];
        companyImage = [CompanyDetailArray valueForKey:@"cmpLg"];
       companyName = [CompanyDetailArray valueForKey:@"cmpNm"];
         NSString*name = [CompanyDetailArray valueForKey:@"firstName"];
            NSArray *items = [name componentsSeparatedByString:@","];
            CompanyUserName = items[0];

        companyStr = [NSString stringWithFormat:@"%@(%@)",CompanyUserName,companyName];
            
        }
        
        
       
        
        NSString *role = [CompanyDetailArray valueForKey:@"role"];
        
       
        
        
        [[NSUserDefaults standardUserDefaults]setObject:personId forKey:@"personId"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [[NSUserDefaults standardUserDefaults]setObject:companyName forKey:@"cmpNm"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [[NSUserDefaults standardUserDefaults]setObject:companyImage forKey:@"comLogo"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [[NSUserDefaults standardUserDefaults]setObject:companyId forKey:@"CompanyId"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [[NSUserDefaults standardUserDefaults]setObject:CompanyUserName forKey:@"firstName"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [[NSUserDefaults standardUserDefaults]setObject:role forKey:@"role"];
        [[NSUserDefaults standardUserDefaults]synchronize];


        
        
        
        [self viewWillAppear:YES];
        
        
      //  [self GetConferenceDat];
        
    }
        
  
    [dropDownView closeAnimation];
        
        
        
    }else if (_dropDownTxtfield == _txtCompanyName){
        self.txtCompanyName.text = [companyNameArray objectAtIndex:returnIndex];
        
        compId = [[[userEmailID objectForKey:@"cmpList"]valueForKey:@"cmpId"]objectAtIndex:returnIndex];
        
        
        [[NSUserDefaults standardUserDefaults]setValue:compId forKey:@"ComId"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [dropDownView closeAnimation];

        
    }
    
    
}


-(void)textFieldDidChange:(UITextField*)textfield{
    
    
    if (userEmailID.count >0) {
        
        
        if ([EMAILDATA  isEqualToString:@"success"]) {
            
            [self SaveDataSecondApi];
            
        }else{
            
            _txtCompanyName.text = @"" ;
            
            compId = @"" ;
            
            
        }
        
        
        
    }
    
}


- (IBAction)closeBtn:(id)sender {
    
    [self.addAccountView setHidden:YES];
    self.txtEmail.text = @"" ;
    self.txtCompanyName.text = @"";
    self.txtPassword.text = @"";
    _txtCompanyTop.constant = 0;
    _lblTop.constant = 0;
    _addAccountSubViewHeight.constant = 275;
    _lblCompanyLayout.constant = 0 ;
    _txtCompanyHeight.constant = 0;
    [self.view layoutIfNeeded];
    [_txtEmail becomeFirstResponder];
    
    
    
}
- (IBAction)forgetPassword:(id)sender {
    ForgotPAsViewController *pass  = [self.storyboard instantiateViewControllerWithIdentifier:@"f"];
    
    [self.navigationController pushViewController:pass animated:YES];
    
}


-(void)SaveDataSecondApi

{
    
   NSString* urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/getemaildetails?email=%@",self.txtEmail.text];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    url = [NSURL URLWithString:urlstring];
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
 //   [SendingRequest addValue:companyToken forHTTPHeaderField:@"token"];
    
    
    [SendingRequest setHTTPMethod:@"GET"];
  
    GetDicDta = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.txtEmail.text,@"email",nil];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
 
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
                                              NSLog(@" the databse theXml is  =====  %@",theXML);
                                              
                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
                                              userEmailID = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                              
                                              
                                              
                                              
                                              [self performSelectorOnMainThread:@selector(ShowCompanyField) withObject:nil waitUntilDone:YES];
                                              
                                              
                                              
                                              NSLog(@" the email deatils is  =   %@",EMAILDATA);
                                              
                                              NSLog(@"the email response is = %@",userEmailID);
                                              
                                              
                                          }];
    
    
    [postDataTask resume];
    
    
}


-(void)ShowCompanyField{
    
    
    EMAILDATA = [userEmailID valueForKey:@"message"];
    
    
    if ([EMAILDATA isEqualToString:@"Email ID Do not exist"]) {
        NSLog(@" EEE E E E  E E E E E E E  R R R R R R R R  R   O O O O OO O O O  RR  R R R R R  R");
        
        UIAlertView* alertEmail=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the correct emailId/Mobile Number" delegate:self cancelButtonTitle:@"ok" otherButtonTitles: nil];
        
        _txtCompanyTop.constant = 0;
        _lblTop.constant = 0;
        _addAccountSubViewHeight.constant = 275;
        _lblCompanyLayout.constant = 0 ;
        _txtCompanyHeight.constant = 0;
                [self.view layoutIfNeeded];
        
        [alertEmail show];
        
        [_txtEmail becomeFirstResponder];
        
        
        
    }
    else if ([EMAILDATA isEqualToString:@"success"]){
        
        
        
        companyNameArray = [[userEmailID objectForKey:@"cmpList"]valueForKey:@"cmpNm"];
        
        
            _txtCompanyTop.constant = 15;
            _lblTop.constant = 2;
            _lblCompanyLayout.constant = 1 ;
          _txtCompanyHeight.constant = 30;
          _addAccountSubViewHeight.constant = 320;
        [self.view layoutIfNeeded];


        
        [self performSelectorOnMainThread:@selector(companyDatatable) withObject:nil waitUntilDone:YES];
      
        
    }
    
}


-(void)companyDatatable{
    
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    
    
    long maxHeight = 350 ;
  long  TableHeight = companyNameArray.count *30 ;
    
    
    if (TableHeight >=maxHeight ) {
        
        TableHeight = 350 ;
    }
    else{
        
        TableHeight = companyNameArray.count *30;
        
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:companyNameArray cellHeight:40 heightTableView:TableHeight paddingTop:0  paddingLeft:0 paddingRight:0 refView:_txtCompanyName animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    
    
    dropDownView.delegate = self;
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    _dropDownTxtfield = _txtCompanyName ;
    
    
    [dropDownView openAnimation];
    
    NSLog(@" SSS  SSSS  S S S S S  USUU U     UUUU  U U U  U");
    
    
    
}

- (IBAction)addClicked:(id)sender {
    
    if ([self.txtEmail.text isEqualToString:@""]){
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Enter the EmailID/Mobile Number" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
    else if ([self.txtPassword.text isEqualToString:@""] )
        
    {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Enter your password" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
    
    else if ([self.txtCompanyName.text isEqualToString:@""]){
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select the Company Name" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
    else{
        
        [KVNProgress show];
        
        [self AddAccountFromServer];
        
    }

}

- (IBAction)notificationClicked:(id)sender {
    
    NotificationVc *notVc = [[NotificationVc alloc]init];
    notVc = [self.storyboard instantiateViewControllerWithIdentifier:@"NotificationVc"];
    [self.navigationController pushViewController:notVc animated:YES];
    
    
}

-(void)calenderPush{
    
    CKViewController *CkVC = [[CKViewController alloc]init];
    
    CkVC = [self.storyboard instantiateViewControllerWithIdentifier:@"CKViewController"];
    [self.navigationController pushViewController:CkVC animated:YES];
    

}


- (IBAction)calenderClicked:(id)sender {
    
    CKViewController *CkVC = [[CKViewController alloc]init];
    
    CkVC = [self.storyboard instantiateViewControllerWithIdentifier:@"CKViewController"];
    [self.navigationController pushViewController:CkVC animated:YES];
    
    
    
}




//-(void)FirstAPIPostMethodUSed;
//{
//    NSString *urlstr  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/checklogin"];//?add=%@&cmpId=%@&latitude=%@&logintym=%@&longitude=%@&os=%@&username=%@&password=%@&version=%@",@"false",compId,latitude,newDateString ,longitude,OperatingNa,self.txtEmail.text,Base64encodePassword,versionNo];
//    
//    
//    NSError *error;
//    
//    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
//    // NSURLSession *session = [NSURLSession sharedSession];
//    
//    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
//    
//    NSURL * urll = [NSURL URLWithString:urlstr];
//    
//    NSMutableURLRequest * requestUrl = [NSMutableURLRequest requestWithURL:urll
//                                                               cachePolicy:NSURLRequestUseProtocolCachePolicy
//                                                           timeoutInterval:60.0];
//    
//    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
//    
//    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Accept"];
//    
//    [requestUrl setHTTPMethod:@"POST"];
//    
//    
//    
//    
//    
//    /////////   Password convert in Base64Encoding   ./////////////
//    
//    
//    NSString * strPassword= self.txtPassword.text;
//    
//    NSLog(@"%@",strPassword);
//    
//    NSData *dataTake2 = [strPassword dataUsingEncoding:NSUTF8StringEncoding];
//    
//    // Convert to Base64 data
//    
//    NSData *base64Data = [dataTake2 base64EncodedDataWithOptions:0];
//    
//      Base64encodePassword = [NSString stringWithFormat:@"%@",[NSString stringWithUTF8String:[base64Data bytes]]];
//    
//    NSLog(@"%@", Base64encodePassword);
//    
//    
//    
//    
//    NSDictionary * mapData = [[NSDictionary alloc] initWithObjectsAndKeys:@"false",@"add",compId,@"cmpId",latitude,@"latitude",
//               
//               newDateString ,@"logintym",longitude,@"longitude",OperatingNa,@"os",self.txtEmail.text,@"username",
//               
//               Base64encodePassword,@"password",versionNo,@"version",nil];
//    
//    
//    
//    
//    NSLog(@" %@",mapData);
//    
//    NSData *postData = [NSJSONSerialization dataWithJSONObject:mapData options:0 error:&error];
//    
//    [requestUrl setHTTPBody:postData];
//    
//    
//    
//    
//    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:requestUrl completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
//                                          
//                                          {
//                                              
//                                              
//                                              
//                                              dispatch_async(dispatch_get_main_queue(),^{
//                                                  
//                                                  
//                                                  NSError *jsonError;
//                                                  
//                                                  NSLog(@"theeeeeeeeeeeeee total response is  =        %@",response);
//                                                  NSLog(@"%@",data);
//                                                  
//                                                  
//                                                  
//                                                 PassedJSonArray =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
//                                                  NSLog(@"%@",PassedJSonArray);
//                                                  
//                                                  [self performSelectorOnMainThread:@selector(SuccessCheck) withObject:nil waitUntilDone:YES];
//                                                  
//                                                  
//            
//                                              });
//                                                             
//
//                                          }];
//    [postDataTask resume];
//}
//
//
//-(void)SuccessCheck{
//    
//    
//    if ([[PassedJSonArray valueForKey:@"message"] isEqualToString:@"success"]) {
//      
//        [accountNameArray addObject:self.txtEmail.text];
//        
//        
//    }
//    
//}


-(void)getLocation{
    
    self.locationManager = [[CLLocationManager alloc] init];
    
    self.locationManager.delegate = self;
    if([self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]){
        NSUInteger code = [CLLocationManager authorizationStatus];
        if (code == kCLAuthorizationStatusNotDetermined && [self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
            // choose one request according to your business.
            if([[NSBundle mainBundle] objectForInfoDictionaryKey:@"NSLocationWhenInUseUsageDescription"]) {
                [self.locationManager  requestWhenInUseAuthorization];
            } else {
                NSLog(@"Info.plist does not contain NSLocationAlwaysUsageDescription or NSLocationWhenInUseUsageDescription");
            }
        }
    }
    [self.locationManager startUpdatingLocation];
    
    
    
    
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    
    if([CLLocationManager locationServicesEnabled])
    {
        NSLog(@"Enabled");
        
        if([CLLocationManager authorizationStatus]==kCLAuthorizationStatusDenied)
        {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:NSLocalizedString( @"Please turn on Location Services first", @"" ) message:NSLocalizedString( @"Turn On", @"" ) preferredStyle:UIAlertControllerStyleAlert];
            
            //            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString( @"Cancel", @"" ) style:UIAlertActionStyleCancel handler:nil];
            UIAlertAction *settingsAction = [UIAlertAction actionWithTitle:NSLocalizedString( @"Settings", @"" ) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:
                                                            UIApplicationOpenSettingsURLString]];
            }];
            
            //  [alertController addAction:cancelAction];
            [alertController addAction:settingsAction];
            
            [self presentViewController:alertController animated:YES completion:nil];
        }
    }
}



- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    
    
    
    if (currentLocation != nil) {
        latitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
        [[NSUserDefaults standardUserDefaults]setObject:latitude forKey:@"lat"];
        
        longitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        [[NSUserDefaults standardUserDefaults]setObject:longitude forKey:@"long"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
    }
    
    self.locationManager = nil;
    
    
    
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    
    
    return YES ;
}




-(void)GetConferenceDat{
    
   
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getConference?cmpId=%@&personId=%@",companyId,personId];
    
     manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:companyToken forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
            
            
            GetConfernceData = responseObject ;
            
            [self performSelectorOnMainThread:@selector(getConfernceDetails) withObject:nil waitUntilDone:YES];
            
            
            
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:companyToken forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    sessionhOME = [NSURLSession sharedSession];
//    taskHome = [sessionhOME dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//
//    
//                                      
//    
//
//                if (data != nil) {
//                    GetConfernceData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//                }
//                
//                
//                NSLog(@"%@",GetConfernceData);
//                                    
//              [self performSelectorOnMainThread:@selector(getConfernceDetails) withObject:nil waitUntilDone:YES];
//                
//                                      
//                          //  [self GetConferenceDat];
//                                      
//                    }];
//    
//   [taskHome resume];
}








-(void)getConfernceDetails{
    
    if ([[GetConfernceData valueForKey:@"message"] isEqualToString:@"success"]) {
        
  
        NSMutableArray *confernceDetails = [GetConfernceData valueForKey:@"confData" ];
        NSMutableArray *arr1 = [[NSMutableArray alloc]init];
        
        
        
        NSLog(@"%@",confernceDetails);
        
        for (NSDictionary *dic in confernceDetails) {
            
            [arr1 addObject:[dic valueForKey:@"confDateTime"]];
           
        }
        
          NSMutableArray *dataArray = [[NSMutableArray alloc]init];
        enddataArray = [[NSMutableArray alloc]init];
        onlyDates = [[NSMutableArray alloc]init];
        
        
        for (int i =0 ; i < arr1.count; i++) {
            
            NSString *str = [NSString stringWithFormat:@"%@",arr1[i]];
            double miliSec = str.doubleValue;
            NSDate* takeOffDate = [NSDate dateWithTimeIntervalSince1970:miliSec/1000];
            NSLog(@"%@",takeOffDate);
            
            ///onlyDate
            NSDateFormatter *formattr = [[NSDateFormatter alloc] init];
            [formattr setDateFormat:@"dd-MM-yyyy"];
            formattr.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
            NSString * dateOnly = [formattr stringFromDate:takeOffDate];
            [onlyDates addObject:dateOnly];
            
            
            
            
            NSTimeInterval seconds = 5.51 * 60 *60;
            NSDate *Ofdate = [takeOffDate dateByAddingTimeInterval:seconds];
            
            [dataArray addObject:Ofdate];
            
              NSString *duration = [NSString stringWithFormat:@"%@",[confernceDetails[i] valueForKey:@"duration"]];
            
            int dur = [duration intValue];
            
            NSTimeInterval secondsInEightHours = dur * 60 ;
            NSDate *endOffdate = [Ofdate dateByAddingTimeInterval:secondsInEightHours];
            
          
            
           [enddataArray addObject:endOffdate];
            
            
                        NSString *str1 = [NSString stringWithFormat:@"%@",[confernceDetails[i] valueForKey:@"confDateTime"]];
            
                        NSString *strrrr = [str1 stringByReplacingOccurrencesOfString:str1 withString:[NSString stringWithFormat:@"%@",dataArray[i]]];
            
                        NSLog(@"%@",strrrr);
            
            
            
        }
        
       
        
        NSLog(@"%@",objectDict);
        
        int count = 0 ;
        
        confernceDetailArray = [[NSMutableArray alloc]init];
        
        
        for(NSMutableDictionary *dic in confernceDetails){
            
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
            
            dict = [[NSMutableDictionary alloc]initWithDictionary:dic];
            count = count + 1 ;
            int i = count - 1 ;
            
            [dict setObject:dataArray[i] forKey:@"date"];
            [dict setObject:enddataArray[i] forKey:@"endOffDate"];
            [dict setObject:onlyDates[i] forKey:@"OnlyDate"];
            
            [confernceDetailArray addObject:dict];
        
        }
        
        NSLog(@"%@",confernceDetailArray);
    
        
        [self CheckTodaysDate];
        
       
        
    }
    
    
    
    
}

-(void)CheckTodaysDate{
    
    NSDate *dateDay = [NSDate date];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"MM-dd-yyyy HH:mm:ss";
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]];
    newDateString = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:dateDay]];
    NSLog(@"%@",newDateString);
    
    dateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    startToday = [dateFormatter dateFromString:newDateString];
    NSLog(@"%@",startToday);
    
    
    
    NSDate* today = [[NSDate alloc] init];
    
    NSCalendar* currentCalendar = [NSCalendar currentCalendar];
    [currentCalendar setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    
    NSDateComponents* dateComponents = [currentCalendar components:NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitYear fromDate:today];
    
    NSInteger thisMonth = [dateComponents month];
    NSInteger thisDay = [dateComponents day];
    NSInteger thisYear = [dateComponents year];
    
    
    
    NSDateComponents* endOdDayComponents = [[NSDateComponents alloc] init];
    [endOdDayComponents setDay:thisDay];
    [endOdDayComponents setMonth:thisMonth];
    [endOdDayComponents setYear:thisYear];
    [endOdDayComponents setHour:23];
    [endOdDayComponents setMinute:59];
    [endOdDayComponents setSecond:59];
    
    NSDate *endToday  = [currentCalendar dateFromComponents:endOdDayComponents];
    NSLog(@"%@",endToday);
    
    
    NSDateComponents* statOdDayComponents = [[NSDateComponents alloc] init];
    [statOdDayComponents setDay:thisDay];
    [statOdDayComponents setMonth:thisMonth];
    [statOdDayComponents setYear:thisYear];
    [statOdDayComponents setHour:00];
    [statOdDayComponents setMinute:00];
    [statOdDayComponents setSecond:00];
    
    NSDate *beginTodayTime  = [currentCalendar dateFromComponents:statOdDayComponents];
    NSLog(@"%@",beginTodayTime);
    
    
    
    int count =  0;
    
    
    
    NSMutableArray *todayMeet =  [[NSMutableArray alloc]init];
    
    NSPredicate*predicate = [NSPredicate predicateWithFormat:@"((date >= %@) AND (date < %@))",beginTodayTime,endToday];
    
    TodayArray = [confernceDetailArray filteredArrayUsingPredicate:predicate];
    
    
    
    for (NSDictionary*dict in TodayArray) {
        
        count = count + 1;
        
        int i = count - 1 ;
        
        
        
        NSMutableArray *arr = [TodayArray valueForKey:@"endOffDate"];
      //  NSString*end = @"2017-05-17 04:55:00";
        NSString*end = [NSString stringWithFormat:@"%@",[arr objectAtIndex:i]];
        
        end = [end stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        dateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];

        NSDate *EndTime = [dateFormatter dateFromString:end];
        NSLog(@"%@",EndTime);

        
        if ([[[confernceDetailArray objectAtIndex:i] valueForKey:@"confStatus"]  isEqualToString:@"Running"] ) {
            
            [todayMeet addObject:TodayArray[i]];
            
            
        }else{
        NSComparisonResult resultDates;
        //has three possible values: NSOrderedSame,NSOrderedDescending, NSOrderedAscending
        
        resultDates = [startToday compare:EndTime]; //
        
        if(resultDates==NSOrderedAscending){
            
             [todayMeet addObject:TodayArray[i]];
            
        }
            NSLog(@"startToday is less");
     
        }
   }
    
    NSLog(@"%@",todayMeet);
    
    


    todayMeetingArray = [NSMutableArray arrayWithArray:todayMeet];
    
    NSSortDescriptor * brandDescriptor = [[NSSortDescriptor alloc] initWithKey:@"date" ascending:YES];
    NSArray * sortDescriptors = [NSArray arrayWithObject:brandDescriptor];
    NSArray * sortedArray = [todayMeetingArray sortedArrayUsingDescriptors:sortDescriptors];
    NSLog(@"sortedArray %@",sortedArray);
    
    todayMeetingArray = [[NSMutableArray alloc]init];
    
    todayMeetingArray = [NSMutableArray arrayWithArray:sortedArray];
    
    
//    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:NO];
//    NSArray *sortedArray = [todayMeetingArray sortArrayUsingDescriptors:@[sortDescriptor]];
//
    
    
    NSPredicate *upcomingPredicate = [NSPredicate predicateWithFormat:@"(date >= %@)",endToday];
     NSArray * UpcomingArray = [confernceDetailArray filteredArrayUsingPredicate:upcomingPredicate];
    UpcomingMeetingArray = [NSMutableArray arrayWithArray:UpcomingArray];
    
    NSSortDescriptor * brandDescriptor1 = [[NSSortDescriptor alloc] initWithKey:@"date" ascending:YES];
    NSArray * sortDescriptors1 = [NSArray arrayWithObject:brandDescriptor1];
    NSArray * sortedArray2 = [UpcomingMeetingArray sortedArrayUsingDescriptors:sortDescriptors1];
    NSLog(@"sortedArray %@",sortedArray);
    
    UpcomingMeetingArray = [[NSMutableArray alloc]init];
    
    UpcomingMeetingArray = [NSMutableArray arrayWithArray:sortedArray2];
    
    //SearchByCalenderDate
    
    NSString *calenderstr = [[NSUserDefaults standardUserDefaults]valueForKey:@"CalenderDate"];
    
    
    if ([[NSUserDefaults standardUserDefaults]boolForKey:@"calender"]== true) {
        
        NSPredicate *upcomingPredicate = [NSPredicate predicateWithFormat: @"OnlyDate ==%@",calenderstr];
        NSArray * UpcomingArrayy = [confernceDetailArray filteredArrayUsingPredicate:upcomingPredicate];
        
        
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"calender"];
        [[NSUserDefaults standardUserDefaults]synchronize];

        
        if (confernceDetailArray.count > 0) {
            UpcomingMeetingArray = [[NSMutableArray alloc]init];
             UpcomingMeetingArray = [NSMutableArray arrayWithArray:UpcomingArrayy];
        }
        else{
            UpcomingMeetingArray = [[NSMutableArray alloc]init];
            
            
        }
       
        
    
    }

    
    [self.todayTableView reloadData];
    [self.upcomingTableView reloadData];
    
   
    
    
}


-(void)PostAddAccountapi{
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/checklogin"];
    
     
    
    NSString *dataStr = [NSString stringWithFormat:@"{\"add\":\"%@\",\"cmpId\":\"%@\",\"latitude\":\"%@\",\"logintym\":\"%@\",\"longitude\":\"%@\",\"OperatingNa\":\"%@\",\"username\":\"%@\",\"password\":\"%@\",\"personId\":\"%@\",\"version\":\"%@\"}",@"true",companyId,latitude,@"10",longitude,@"os",self.txtEmail.text,Base64encodePassword,personId,versionNo];
    
    NSLog(@"%@",dataStr);
    
    
    NSString *strpostlength=[NSString stringWithFormat:@"%lu",(unsigned long)[dataStr length]];
    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
    
    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
    [urlrequest setHTTPMethod:@"POST"];
    [urlrequest setValue:strpostlength forHTTPHeaderField:@"Content-Length"];
    [urlrequest setHTTPBody:[dataStr dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
                                            completionHandler:
                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
                                      
                                    id  jsonResponseData=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
                                      NSLog(@"%@",jsonResponseData);
                                  }];
    [task resume];
}


-(void)AddAccountFromServer;
{
    
    NSError *error;
    
    NSString* strPassword= self.txtPassword.text;
    
    NSLog(@"%@",strPassword);
    
    NSData *dataTake2 = [strPassword dataUsingEncoding:NSUTF8StringEncoding];
    
    // Convert to Base64 data
    
    NSData *base64Data = [dataTake2 base64EncodedDataWithOptions:0];
    
    Base64encodePassword = [NSString stringWithFormat:@"%@",[NSString stringWithUTF8String:[base64Data bytes]]];
    
    NSLog(@"%@", Base64encodePassword);
    
    
    
    NSString *apiURLStr  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/checklogin"];
//    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    // NSURLSession *session = [NSURLSession sharedSession];
    
//    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
//    
//    NSURL * urll = [NSURL URLWithString:urlstr];
//    
//    NSMutableURLRequest * requestUrl = [NSMutableURLRequest requestWithURL:urll
//                                                               cachePolicy:NSURLRequestUseProtocolCachePolicy
//                                                           timeoutInterval:60.0];
//    
//    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
//    
//    [requestUrl addValue:@"application/json" forHTTPHeaderField:@"Accept"];
//    
//    [requestUrl setHTTPMethod:@"POST"];
    
    
    /////////   Password convert in Base64Encoding   ./////////////
    
    
    if (latitude.length == 0 || latitude == nil || [latitude isKindOfClass:(id)[NSNull null]]) {
         [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        UIAlertView *ALERT = [[UIAlertView alloc]initWithTitle:nil message:@"Please turn on Location Services first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [ALERT show];
        
        
    }else{
        
        mapData = @{ @"add": @"true",
                     @"cmpId": compId,
                     @"latitude": latitude,
                     @"longitude":longitude,
                     @"os": OperatingNa,
                     @"username": self.txtEmail.text,
                     @"password": Base64encodePassword,
                     @"personId": personId,
                     @"version": versionNo};
        
        AFHTTPSessionManager * managerr = [AFHTTPSessionManager manager];
        managerr.requestSerializer = [AFJSONRequestSerializer serializer];
        [managerr.requestSerializer setValue:companyToken forHTTPHeaderField:@"token"];
        
        [managerr POST:apiURLStr parameters:mapData success:^(NSURLSessionTask *task, id responseObject) {
            NSLog(@"PLIST: %@", responseObject);
            [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
            
            
            result = responseObject ;
            
            [self performSelectorOnMainThread:@selector(successMessage) withObject:nil waitUntilDone:YES];
            
            
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
            NSLog(@"Error: %@", error);
            
            
            
        }];


    }
    
   
    
   
    
//    NSData *postData = [NSJSONSerialization dataWithJSONObject:mapData options:0 error:&error];
//    
//    [requestUrl setHTTPBody:postData];
//    
//    
//    
//    NSURLSessionDataTask *postDtaat = [session dataTaskWithRequest:requestUrl completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
//                                       
//                                       {
//                                           
//                                           [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
//                                           
//                                           dispatch_async(dispatch_get_main_queue(),^{
//                                               
//                                               
//                                               NSError *jsonError;
//                                               
//                                               NSLog(@"theeeeeeeeeeeeee total response is  =        %@",response);
//                                               NSLog(@"%@",data);
//                                               
//                                               
//                                               
//                                               result =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
//                                               
//                                               NSLog(@"%@",result);
//                                               
//                                               NSString *  fetchOTP2 = [NSString stringWithFormat:@"%@",[result valueForKey:@"message"]];
//                                               
//                                               [self performSelectorOnMainThread:@selector(successMessage) withObject:nil waitUntilDone:YES];
//                                               
//                                               
//                                               NSLog(@"%@",fetchOTP2);
//                                               
//                                               
//                                           });
//                                           
//                                           
//                                       }];
//    
//    [postDtaat resume];
    
    
}

-(void)successMessage{
    
    if ([[result valueForKey:@"responseCode"] isEqual:[NSNumber numberWithInteger:200]]) {
        
        alertAdded = [[UIAlertView alloc]initWithTitle:nil message:@"User Added successfully" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alertAdded show];
        
        dropDownListArray  = [result valueForKey:@"result"];
        NSLog(@"%@",dropDownListArray);
        
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dropDownListArray];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"Accounts"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        
        
        
    }else{
        
        NSString*str = [NSString stringWithFormat:@"%@",[result valueForKey:@"message"]];
        if ([str isEqualToString:@"<null>"] || [str isKindOfClass:(id)[NSNull null]] || str == nil) {
            alertAdded = [[UIAlertView alloc]initWithTitle:nil message:@"Please Varify the company first" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alertAdded show];

        }else{
        
        
        alertAdded = [[UIAlertView alloc]initWithTitle:nil message:result[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alertAdded show];
            
        }
        
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == alertAdded) {
        if (buttonIndex == 0) {
            
            [self.addAccountView setHidden:YES];
            
            
        }
    }
    else if (alertView == deleteAlert){
        
        if (buttonIndex == 1) {
            companyId = [CompanyDetailArray valueForKey:@"cmpId"];
            DeleteRowStr = [CompanyDetailArray valueForKey:@"personId"];
            companyImage = [CompanyDetailArray valueForKey:@"cmpLg"];
            companyName = [CompanyDetailArray valueForKey:@"cmpNm"];
            
            
            NSString*name = [CompanyDetailArray valueForKey:@"firstName"];
            NSArray *items = [name componentsSeparatedByString:@" "];
            CompanyUserName = items[0];
            
            companyStr = [NSString stringWithFormat:@"%@",CompanyUserName];
            
            
            
            [self deleteApiFromServer];
        }
        
       

    }
    
}



-(void)GetProfileFromServer{
    
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable) {
        UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message: @"No Network Connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        [alert show];
        return;
        
        
    }else{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getprofile?personId=%@",personId];
    
//    if (sessionhOME.tas == NSURLSessionTaskStateRunning) {
//        
        sessionhOME = nil ;
    manager = nil ;
    
        [sessionhOME invalidateAndCancel];
    
    [sessionhOME finishTasksAndInvalidate];
    
    
    if (taskHome.state == NSURLSessionTaskStateRunning) {
        [taskHome cancel];
    }
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:companyToken forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        if ([[responseObject valueForKey:@"message"] isEqualToString:@"success"]) {
            
            
        listCompanies = [[responseObject valueForKey:@"accountdata"]valueForKey:@"cmpNm"];
            
            profileData = responseObject ;
            
            
            NSString*mobile = [NSString stringWithFormat:@"%@",[profileData valueForKey:@"pmobile"]];
            
            
        [[NSUserDefaults standardUserDefaults]setValue:mobile forKey:@"pmobile"];
         [[NSUserDefaults standardUserDefaults]synchronize];
            
            
            
            
        }
         [self performSelectorOnMainThread:@selector(getProfileData) withObject:nil waitUntilDone:YES];
        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
    
}
}

-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}


-(void)getProfileData{
    NSString*compnyImg = [profileData valueForKey:@"cmpLg"];
    
    if ([compnyImg isEqualToString:@"no image"]) {
        
        self.userImg.image =[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"];
        

    }else{
    
  [self.userImg sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://182.76.44.135:8080/%@",compnyImg]]placeholderImage:[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"]];
        
    }
    
    _userImg.layer.cornerRadius = _userImg.frame.size.width/2 ;
    [_userImg clipsToBounds];
   _userImg.layer.masksToBounds = YES;
    
  
    
    
    
}

- (IBAction)joinNowClicked:(id)sender {
    NSLog(@"%@",dialInNumber);
    dialInNumber = [dialInNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    
    NSString *phoneNumber = [@"tel://" stringByAppendingString:dialInNumber];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
    
    

}
- (IBAction)joinNow:(id)sender {
}

-(NSArray *)findFiles:(NSString *)extension{
    
    NSMutableArray *matches = [[NSMutableArray alloc]init];
    NSFileManager *fManager = [NSFileManager defaultManager];
    NSString *item;
    NSArray *contents = [fManager contentsOfDirectoryAtPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] error:nil];
    
    // >>> this section here adds all files with the chosen extension to an array
    for (item in contents){
        if ([[item pathExtension] isEqualToString:extension]) {
            [matches addObject:item];
        }
    }
    return matches;

}


- (NSArray *)ls {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSArray *directoryContent = [[NSFileManager defaultManager] directoryContentsAtPath: documentsDirectory];
    
    NSLog(@"%@", documentsDirectory);
    return directoryContent;
}


-(void)headerView{
    
    [self.conferenceDetailView setHidden:YES];
    [dropDownView closeAnimation];
    [_dropTableView setHidden:YES];

    
    
}

- (void)scrollViewDidScroll:(UIScrollView *)aScrollView {
    
    if (isSessionNil) {
        return ;
    }else{
        
        [self   GetConferenceDat];
        
    }

}

-(void)insets{
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:NO];
    
    
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        
        
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -32, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        if ([_RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 14, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 17, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
            
             [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
            
        }else{
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 14, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 17, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            
        }
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:7]];

        
        
    }else if ([UIScreen mainScreen].bounds.size.width == 375) {
        
        if ([_RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {

            [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
            [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
            [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
            
            
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 25, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 25, 0, 0)];

            
        }else{
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -38, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -30, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -34, 0, 0)];
        
        
        
        [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
        [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
        [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 19, 0, 0)];
        [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
        [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 21, 0, 0)];
            

            
        }
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:7]];

        
    }else if ([UIScreen mainScreen].bounds.size.width == 414) {
        
        [delegate.tabView.btnToday setTitleEdgeInsets:UIEdgeInsetsMake(38, -40, 0, 0)];
        [delegate.tabView.btnMenu setTitleEdgeInsets:UIEdgeInsetsMake(38, -28, 0, 0)];
        [delegate.tabView.btnSchedule setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        [delegate.tabView.btnDashboard setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        [delegate.tabView.btnControlPanel setTitleEdgeInsets:UIEdgeInsetsMake(38, -35, 0, 0)];
        
        if ([_RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 23, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 27, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 27, 0, 0)];
            
            
        }else{
            [delegate.tabView.btnToday setImageEdgeInsets:UIEdgeInsetsMake(-5, 15, 0, 0)];
            [delegate.tabView.btnMenu setImageEdgeInsets:UIEdgeInsetsMake(-5, 16, 0, 0)];
            [delegate.tabView.btnSchedule setImageEdgeInsets:UIEdgeInsetsMake(-5, 23, 0, 0)];
            [delegate.tabView.btnDashboard setImageEdgeInsets:UIEdgeInsetsMake(-5, 24, 0, 0)];
            [delegate.tabView.btnControlPanel setImageEdgeInsets:UIEdgeInsetsMake(-5, 24, 0, 0)];
            
        }
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:7]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:7]];

        
        
    }
    
    else if ([UIScreen mainScreen].bounds.size.width == 768 ) {
        
        [delegate.tabView.btnToday setImage: [UIImage imageNamed:@"ipad-today.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnControlPanel setImage: [UIImage imageNamed:@"ipad-control-panel.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnDashboard setImage: [UIImage imageNamed:@"ipad-dashboard.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setImage: [UIImage imageNamed:@"ipad-schedule-meeting.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnMenu setImage: [UIImage imageNamed:@"ipad-menu.png"] forState:UIControlStateNormal];
        
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:12]];
        
        if ([_RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 43, 20, 83)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(65, -183, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 53, 20, 93)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 63, 20, 73)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(10, 63, 25, 73)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 63, 20, 73)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(65, -157, 0, 0)];
            
            
            
        }else{
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 20, 45)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(10, 50, 25, 55)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(5, 40, 20, 45)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(65, -150, 0, 0)];
            
            
        }
        //
        //
    } else if ([UIScreen mainScreen].bounds.size.width == 1024){
        
        [delegate.tabView.btnToday setImage: [UIImage imageNamed:@"ipad-today.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnControlPanel setImage: [UIImage imageNamed:@"ipad-control-panel.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnDashboard setImage: [UIImage imageNamed:@"ipad-dashboard.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnSchedule setImage: [UIImage imageNamed:@"ipad-schedule-meeting.png"] forState:UIControlStateNormal];
        [delegate.tabView.btnMenu setImage: [UIImage imageNamed:@"ipad-menu.png"] forState:UIControlStateNormal];
        
        
        [delegate.tabView.btnToday setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnControlPanel setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnDashboard setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnSchedule setFont:[UIFont systemFontOfSize:12]];
        [delegate.tabView.btnMenu setFont:[UIFont systemFontOfSize:12]];
        
        if ([_RoleStr isEqualToString:@"ROLE_PARTICIPANT"]) {
            
            
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 43, 20, 83)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(95, -183, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 53, 20, 93)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(95, -157, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(10, 85, 25, 93)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(95, -152, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(20, 93, 35, 103)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(95, -157, 0, 0)];
        
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(10, 85, 25, 93)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(95, -157, 0, 0)];
            
            
        }else{
            [delegate.tabView.btnToday  setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 20, 45)];
            [delegate.tabView.btnToday  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnSchedule  setImageEdgeInsets:UIEdgeInsetsMake(3, 40, 20, 45)];
            [delegate.tabView.btnSchedule  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnControlPanel  setImageEdgeInsets:UIEdgeInsetsMake(3, 50, 20, 55)];
            [delegate.tabView.btnControlPanel  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnMenu  setImageEdgeInsets:UIEdgeInsetsMake(20, 63, 35, 73)];
            [delegate.tabView.btnMenu  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            [delegate.tabView.btnDashboard  setImageEdgeInsets:UIEdgeInsetsMake(8, 50, 22, 55)];
            [delegate.tabView.btnDashboard  setTitleEdgeInsets:UIEdgeInsetsMake(95, -150, 0, 0)];
            
            
        }

        
    }

    
}

-(void)TapAddAccoountView{
    
    [dropDownView closeAnimation];
    [self.txtEmail resignFirstResponder];
    [_txtPassword resignFirstResponder];
    [_txtCompanyName resignFirstResponder];
    [_dropTableView setHidden:YES];
    
    
    
}


-(void)deleteProfile:(id)sender{
    
    UIButton*btn = (UIButton*)sender ;
    NSLog(@"%ld",(long)btn.tag);
    
    
    CompanyDetailArray = [[NSMutableArray alloc]init];
    CompanyDetailArray = [dropDownListArray objectAtIndex:btn.tag];
    NSLog(@"%@",CompanyDetailArray);
    
    
    deleteAlert = [[UIAlertView alloc]initWithTitle:nil message:@"Are you sure you want to remove" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
    [deleteAlert show];
    
    
    
    
}

-(void)deleteApiFromServer{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/secure/removeaccount?personId=%@&removeId=%@",personId,DeleteRowStr];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:companyToken forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        deleteData = responseObject ;
        
        dropDownListArray = [deleteData valueForKey:@"result"];
        
        if (dropDownListArray.count>0) {
            NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dropDownListArray];
            [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"Accounts"];
            [[NSUserDefaults standardUserDefaults]synchronize];

        }
        else{
            NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dropDownListArray];
            [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"adminAccount"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            NSUserDefaults *defaults = [[NSUserDefaults alloc]init];
            
            NSData *dictionaryData = [defaults objectForKey:@"Accounts"];
            dropDownListArray = [NSKeyedUnarchiver unarchiveObjectWithData:dictionaryData];
            
 
           
        }
       
        [self.dropTableView setHidden:YES];
        
        
        
       // [self.dropTableView reloadData];
        
        
//        [self  GetProfileFromServer];
        
        
//        Roledetails = [deleteData valueForKey:@"result"];
//        
//        [self AccountDetailsFromServer];
//        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
}



@end
