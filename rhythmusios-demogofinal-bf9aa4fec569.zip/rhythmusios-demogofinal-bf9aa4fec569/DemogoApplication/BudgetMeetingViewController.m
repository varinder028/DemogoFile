//
//  meetingdetailsViewController.m
//  excelSheetUpload
//
//  Created by Rhythmus on 22/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "BudgetMeetingViewController.h"
#import "PNChartDelegate.h"
#import "PNChart.h"
#import <AFNetworking/AFNetworking.h>
#import "KVNProgress.h"


@interface BudgetMeetingViewController ()<NSURLSessionDelegate,NSURLSessionDataDelegate>
{
    NSString *  Logincmpid;

    NSString *  Tokenstr;
    
    NSMutableArray *pieArray;
    
    NSString *addempolyee;
    NSString *removeemploye;
    
}
@property (strong, nonatomic) IBOutlet UIView *summaryVIew;

@end

@implementation BudgetMeetingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if ([UIScreen mainScreen].bounds.size.height == 480) {
//        self.grphHeght.constant = 200;
        self.widthGraph.constant = 100 ;
    self.heightGraph.constant = 100 ;
        
    }
    
    [self.view layoutIfNeeded];
    
    Tokenstr = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    Logincmpid = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
  //  personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];

//    Logincmpid = @"1770";
    
    pieArray = [[NSMutableArray alloc]init];
    
    
  
    
    [self JoinUpdateMeeting];
  }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
  //  [self pieChartView];
    
    
    
   

}

-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}


-(void)JoinUpdateMeeting
{
    NSString*strNum ;
    strNum =@"2";
    
    //6678
        NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/dashboard/secure/currentplanuses?cmpId=%@",Logincmpid];
    
    
    AFHTTPSessionManager * managerr = [AFHTTPSessionManager manager];
    managerr.requestSerializer = [AFJSONRequestSerializer serializer];
    [managerr.requestSerializer setValue:Tokenstr forHTTPHeaderField:@"token"];
    
    [managerr GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"PLIST: %@", responseObject);
        cities = [[NSMutableDictionary alloc]init];
        
        cities = responseObject ;
        [self performSelectorOnMainThread:@selector(getJoinUpdate) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    
    
}

-(void)getJoinUpdate{
    NSString*succ = @"success";
    
    
    
    if ([succ isEqualToString:[cities valueForKey:@"message"]])
    {
        NSString *totalValue = [[cities valueForKey:@"currentplanusesdto"]valueForKey:@"totalfcv"];
        
        NSString *usedData = [[cities valueForKey:@"currentplanusesdto"]valueForKey:@"usedfcv"];
        NSLog(@"%@",usedData);
        
        NSLog(@"%@",totalValue);
        
        self.labelUsed.text =[NSString stringWithFormat:@"Used FCV: %@", usedData];
        
        
        double a = ([totalValue doubleValue]);
        double b = ([usedData doubleValue]);
        
        
        
        
        
        
        NSString *unuseduser=[NSString stringWithFormat:@"Unused FCV : %.02f",a-b];
        self.LabelUnused.text =unuseduser;
        
        
        
        double totalDa = [totalValue doubleValue];
        
        
        double totalProgree = b/totalDa ;
        
        NSString *str = [NSString stringWithFormat:@"%.02f",totalProgree];
        
        double valueProg = [str doubleValue];
        
        self.progressBar.progress =valueProg;
        
        
    
        [self CurrentMonthEmp];
        [self performSelectorOnMainThread:@selector(relaodTable) withObject:nil waitUntilDone:YES];
    }
}

    
    


-(void)relaodTable
{
    NSLog(@"sucess");
   
    
}
-(void)CurrentMonthEmp
{
    NSString*strNum ;
    strNum =@"2";
    
    //6678
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/dashboard/secure/currentmonthemp?cmpId=%@",Logincmpid];
    
    
    AFHTTPSessionManager * managerr = [AFHTTPSessionManager manager];
    managerr.requestSerializer = [AFJSONRequestSerializer serializer];
    [managerr.requestSerializer setValue:Tokenstr forHTTPHeaderField:@"token"];
    
    [managerr GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"PLIST: %@", responseObject);
cities = [[NSMutableDictionary alloc]init];
        cities = responseObject ;
        [self performSelectorOnMainThread:@selector(getCurrentMonthEmp) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

 
}

-(void)getCurrentMonthEmp{
    
    NSString*succ = @"success";
    
    if ([succ isEqualToString:[cities valueForKey:@"message"]])
    {
        addempolyee = [[cities valueForKey:@"empmonthstatus"]valueForKey:@"addemp"];
        
        removeemploye = [[cities valueForKey:@"empmonthstatus"]valueForKey:@"removeemp"];
        
        NSString *totalemploye = [[cities valueForKey:@"empmonthstatus"]valueForKey:@"totalemp"];
        
        self.LabeltotalUser.text =[NSString stringWithFormat:@"Total User : %@",totalemploye];
        
        NSLog(@"%@",addempolyee);
        
        NSLog(@"%@",removeemploye);
        
        NSLog(@"%@",totalemploye);
        
        
        
        [self pieChartView];
        
        
        
      
    }
}



-(void)pieChartView
{
    
    double remvePerson = [addempolyee doubleValue];
    double AddPerson = [removeemploye doubleValue];
    
    NSMutableArray *items =[[NSMutableArray alloc]initWithObjects:[PNPieChartDataItem dataItemWithValue:remvePerson color:[UIColor colorWithRed:1.00 green:0.50 blue:0.00 alpha:1.0]],[PNPieChartDataItem dataItemWithValue:AddPerson color:[UIColor colorWithRed:0.25 green:0.50 blue:0.00 alpha:1.0]] , nil];
    
    //@[[PNPieChartDataItem dataItemWithValue:remvePerson color:PNLightGreen],
    
      if ([UIScreen mainScreen].bounds.size.height == 480) {
          
          self.pieChart = [[PNPieChart alloc] initWithFrame:CGRectMake((CGFloat) (SCREEN_WIDTH / 2.2 - 100), 5, 100.0, 100.0) items:items];
      }else{
    
    self.pieChart = [[PNPieChart alloc] initWithFrame:CGRectMake((CGFloat) (SCREEN_WIDTH / 2.2 - 100), 5, 200.0, 200.0) items:items];
          
      }
       self.pieChart.descriptionTextColor = [UIColor whiteColor];
    // self.pieChart.descriptionTextFont = [UIFont fontWithName:@"Avenir-Medium" size:11.0];
    self.pieChart.descriptionTextShadowColor = [UIColor blueColor];
    self.pieChart.showAbsoluteValues = YES;
    self.pieChart.showOnlyValues = NO;
    [self.pieChart strokeChart];
    self.pieChart.legendStyle = PNLegendItemStyleStacked;
    self.pieChart.legendFont = [UIFont boldSystemFontOfSize:12.0f];
    [self.graphView addSubview:self.pieChart];
    
    
}


    
//    double removeUser = [removeemploye doubleValue];
//    
//    for (int i =0; i<removeUser; i++)
//    
//    {
//        
//        NSNumber *removeUserDetails = [NSNumber numberWithInt:rand()%60+20];
//        
//        [pieArray addObject:removeUserDetails];
//        
//    }




- (IBAction)bckBudgetSummary:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
    
}
@end
