//
//  BillsCell.h
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BillsCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *monthsLAbel;
@property (strong, nonatomic) IBOutlet UILabel *dateLAbel;
@property (strong, nonatomic) IBOutlet UIImageView *RupeesImage;
@property (strong, nonatomic) IBOutlet UILabel *paymentLabel;
@property (strong, nonatomic) IBOutlet UIButton *PDfDownloadButton;

@end
