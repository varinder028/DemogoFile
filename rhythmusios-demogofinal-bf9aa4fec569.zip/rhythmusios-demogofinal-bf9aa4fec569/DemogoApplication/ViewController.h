//
//  ViewController.h
//  DemogoApplication
//
//  Created by varinder singh on 1/23/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"
#import <CoreLocation/CoreLocation.h>
//#import <TesseractOCR/TesseractOCR.h>
#import "Reachability.h"

@interface ViewController : UIViewController<DropDownViewDelegate,UITextFieldDelegate,UIGestureRecognizerDelegate>{
    
    DropDownView *dropDownView;
    
    NSMutableArray *companyNameArray;
     NSString * passStatus ;
    NSString *varifyStr;
    NSMutableArray *dropDownListArray;
    
    UIGestureRecognizer *tapScrollView ;
    
    
    
}
@property (weak, nonatomic) IBOutlet UIImageView *imageToRecognize;
@property (nonatomic, strong) NSOperationQueue *operationQueue;

@property (nonatomic, strong) CLLocationManager *locationManager;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtCompanyHeight;

@property (strong, nonatomic) IBOutlet UITableView *TableCompanyList;

@property (strong, nonatomic) IBOutlet UITextField *txtCompnay;
@property (strong, nonatomic) IBOutlet UIView *viewAddAccount;

@end

