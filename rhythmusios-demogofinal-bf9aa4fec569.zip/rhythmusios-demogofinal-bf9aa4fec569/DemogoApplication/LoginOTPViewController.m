//
//  LoginOTPViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "LoginOTPViewController.h"
#import "ViewController.h"

#import "CorporateTabBarViewController.h"
#import "LogSucessPasswordViewController.h"
#import "ParticipantTabBar.h"
#import "AppDelegate.h"
#import "HomeVC.h"
#import "LogSucessPasswordViewController.h"


#import "VarifyAdminVC.h"

@interface LoginOTPViewController ()<UIGestureRecognizerDelegate,UIScrollViewDelegate,UITextFieldDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate,UINavigationBarDelegate>
{
    LogSucessPasswordViewController *LSPassword;
    
    
    NSTimer *timer;
    long counterr ;
    NSString *OTPStringNumber;
    NSAttributedString *strd;
    
    
}
@property (weak, nonatomic) IBOutlet UITextField *otptextfield;
@property (weak, nonatomic) IBOutlet UILabel *Timelabel;
- (IBAction)verifyButton:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *verifyOutlet;
- (IBAction)resendOTP:(UIButton *)sender;


@property (strong, nonatomic) IBOutlet UIScrollView *SCROLLotp;

@end

@implementation LoginOTPViewController


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}


- (void)viewDidLoad {
    [super viewDidLoad];

    _otpView.layer.cornerRadius = 5.0f ;
    [_otpView clipsToBounds];
    
    
    
    NSLog(@"%@",_passStatus);
    

    NSLog(@"%@",_varify);
    
    counterr =60;
    [self setTimer];
    self.resendOtpOUTLET.enabled=NO;
    
    self.resendOtpOUTLET.backgroundColor = [UIColor colorWithRed:255/255.0f green:155/255.0f blue:255/255.0f alpha:1];
    
    
    self.navigationController.navigationBarHidden = YES;
    
    //self.navigationController.navigationBar.topItem.title = @"Login Otp";
    
    
 //   [self.navigationController.navigationBar setBackgroundColor:[self colorWithHexString:@"021e29"]];   // [[UINavigationBar appearance] setBarTintColor: (021e29)];
    
 //    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
//    <NSURLSessionDelegate,NSURLSessionDataDelegate>
    
    
    
    //////   Verify Button Corner Redius   /////
    
    
    self.verifyOutlet.layer.cornerRadius = 5.5;
    
    self.resendOtpOUTLET.layer.cornerRadius = 5.5;
    
 
    
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dissmisskeyboard)];
    [self.view addGestureRecognizer:tap];
    
    
    self.otptextfield.keyboardType =UIKeyboardTypeNumberPad;
    
        strd=[[NSAttributedString alloc]
         
              initWithString:@"Please Enter OTP Code...."
        
                        attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
                                self.otptextfield.attributedPlaceholder=strd;
    
    
    
    
    
    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dissmisskeyboard;
{
       [self.otptextfield resignFirstResponder];
    
    
}






-(void)textFieldDidBeginEditing:(UITextField *)textField


{
    CGPoint scrollPoint = CGPointMake(0,0); //textField.frame.origin.y);
    [_SCROLLotp setContentOffset:scrollPoint animated:YES];
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    [_SCROLLotp setContentOffset:CGPointZero animated:YES];
}




-(void)setTimer
{
    
      counterr = 60;
    
    timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(SetTimerConform) userInfo:nil repeats:YES];
    
    
}
-(void)SetTimerConform
{
    if (counterr==0) {
        [timer invalidate];
        
       
        
        _resendOtpOUTLET.enabled= YES;
         self.resendOtpOUTLET.backgroundColor = [UIColor colorWithRed:255/255.0f green:0/255.0f blue:255/255.0f alpha:1];
        
       // self.resendOutlet.layer.cornerRadius = 10.5;
        
    }else
    {
        counterr--;
        self.resendOtpOUTLET.enabled=NO;
         self.resendOtpOUTLET.backgroundColor = [UIColor colorWithRed:255/255.0f green:155/255.0f blue:255/255.0f alpha:1];
      //  self.resendOutlet.hidden = YES;
        _Timelabel.text = [NSString stringWithFormat:@"%li",counterr];
    }
}










////////////////////          Pending WORKING For Otp API        //////////////////////////



-(void)OtpEqualDataWithNumber;
{
    NSString *otdat;
    NSError *linkError;
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
   // http://182.76.44.135:8080/demogomobile
    
    otdat = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/resendotp?mobile=%@&otp=%@",self.PassMobileNUm,_StringOTP];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *PushLinkUrl = [NSURL URLWithString:otdat];
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
    
    
    
    
    [SendingRequest setHTTPMethod:@"POST"];
    
    NSMutableDictionary * GetDicDta = [NSMutableDictionary dictionaryWithObjectsAndKeys:self.PassMobileNUm,@"mobile",_StringOTP,@"otp", nil];
    
    
   NSData * SendData= [NSJSONSerialization dataWithJSONObject:GetDicDta options:kNilOptions error:&linkError];
    
    
    
    
    
    [SendingRequest setHTTPBody:SendData];
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                  NSError *jsonError;
                                                  
                                                  
                                                  
                                                  PassedJSon =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                                                  
                                                  NSLog(@"%@",PassedJSon);
                                                  
                                                  [self performSelectorOnMainThread:@selector(alertOtp) withObject:nil waitUntilDone:YES];
                                                  
                                                  
                                              });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
}


-(void)alertOtp{
    
    alertOtp = [[UIAlertView alloc]initWithTitle:nil message:PassedJSon[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    
    [alertOtp show];
    
    
    
}



- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView == alertOtp) {
        if (buttonIndex == 0) {
            
            [self setTimer];
            _resendOtpOUTLET.enabled = NO;
            
            
        }
    }
    
    
}
 
 
 
                    /////////////////           VERIFY OTP NUMBER        /////////////////


 
- (IBAction)verifyButton:(UIButton *)sender {
    

    
    
    
    if ([self.otptextfield.text isEqualToString: _StringOTP])
    
    
    
    {
//        NSString *PARTid = [[NSString alloc]initWithString:self.PartiCipantClient];
//        
//        NSLog(@"%@",PARTid);
        
        
        if ([_varify isEqualToString:@"0"]) {
            
            if ([_passStatus isEqualToString:@"0"]) {
                
                LogSucessPasswordViewController *logSucces = [[LogSucessPasswordViewController alloc]init];
                [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"isFirst"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                logSucces = [self.storyboard instantiateViewControllerWithIdentifier:@"LSP"];
                [self.navigationController pushViewController:logSucces animated:YES];
                
                
                
            }else{
                
                NSString *strr  = [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
                
                if ([strr isEqualToString:@"ROLE_SUPER_ADMIN"]) {
                    VarifyAdminVC *varifyVc = [[VarifyAdminVC alloc]init];
                    
                    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"isFirst"];
                    [[NSUserDefaults standardUserDefaults]synchronize];
                    varifyVc = [self.storyboard instantiateViewControllerWithIdentifier:@"VarifyAdminVC"];
                    [self.navigationController pushViewController:varifyVc animated:YES];

                }else{
                    
                    
                    [self PushToHome];
                    

                }
            

            }
        }    else  if ([_varify isEqualToString:@"1"]) {
            
            if ([_passStatus isEqualToString:@"0"]) {
                
                LogSucessPasswordViewController *logSucces = [[LogSucessPasswordViewController alloc]init];
                [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"isFirst"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                logSucces = [self.storyboard instantiateViewControllerWithIdentifier:@"LSP"];
                [self.navigationController pushViewController:logSucces animated:YES];
                
                
                
            }else{
                [self   PushToHome];
            }
        }

        else{
        
            
        NSLog(@"%@",_PartiCipantClient);
        
        NSLog(@"%@",_NAMEofClient);
            
            
            [self   PushToHome];
            
            
        
//        if ([_PartiCipantClient isEqualToString:@"ROLE_PARTICIPANT"])
//        
//        {
            
            
                     // 4 tab view
                                        
//            [_tabView scheduleMeetingClicked];
//            [_tabView dashboardClicked];
//            [_tabView  menuClicked];
//            [_tabView controlPanel];
            
                                        
            
  //      }
        
//        else if ([_PartiCipantClient isEqualToString:@"ROLE_HOST"])
//            
//        {
//            
//                              //5  tab view 
//            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
//            
//            
//            
//            HomeVC *hVc = [[HomeVC alloc]init];
//            UIStoryboard *story =[UIStoryboard storyboardWithName:@"Main" bundle:nil];
//            hVc =[story instantiateViewControllerWithIdentifier:@"HomeVC"];
//            UINavigationController *navVc = [[UINavigationController alloc]initWithRootViewController:hVc];
//            
//            
//            
//            [navVc setViewControllers: @[hVc] animated: YES];
//            navVc.navigationBarHidden = true;
//            
//            NSArray *myNibsArray = [[NSBundle mainBundle] loadNibNamed:@"Tab" owner:self options:nil];
//            _tabView = [myNibsArray objectAtIndex:0];
//            
//            
//            
//            
//            delegate.window.rootViewController= navVc;
//            
//            
//            [delegate.window makeKeyAndVisible];
//            
//            _tabView.frame  = CGRectMake(0, delegate.window.rootViewController.view.frame.size.height-_tabView.frame.size.height, delegate.window.rootViewController.view.frame.size.width, _tabView.frame.size.height);
//            [delegate.window.rootViewController.view addSubview:_tabView];
//            
//            [_tabView todayClicked];
////            [_tabView scheduleMeetingClicked];
////            [_tabView dashboardClicked];
////            [_tabView  menuClicked];
////            [_tabView controlPanel];
//            
//        }
//        
//        else if ([_PartiCipantClient isEqualToString:@"ROLE_SUPER_ADMIN"])
//            
//        {
//        
//            
//            
//            AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
//            
//            
//            
//            HomeVC *hVc = [[HomeVC alloc]init];
//            UIStoryboard *story =[UIStoryboard storyboardWithName:@"Main" bundle:nil];
//            hVc =[story instantiateViewControllerWithIdentifier:@"HomeVC"];
//            UINavigationController *navVc = [[UINavigationController alloc]initWithRootViewController:hVc];
//            
//            
//            
//            [navVc setViewControllers: @[hVc] animated: YES];
//            navVc.navigationBarHidden = true;
//            
//            NSArray *myNibsArray = [[NSBundle mainBundle] loadNibNamed:@"Tab" owner:self options:nil];
//            _tabView = [myNibsArray objectAtIndex:0];
//            
//            
//            
//            
//            delegate.window.rootViewController= navVc;
//            
//            
//            [delegate.window makeKeyAndVisible];
//            
//            _tabView.frame  = CGRectMake(0, delegate.window.rootViewController.view.frame.size.height-_tabView.frame.size.height, delegate.window.rootViewController.view.frame.size.width, _tabView.frame.size.height);
//            [delegate.window.rootViewController.view addSubview:_tabView];
//            
//            [_tabView todayClicked];
////            [_tabView scheduleMeetingClicked];
////            [_tabView dashboardClicked];
////            [_tabView  menuClicked];
////            [_tabView controlPanel];
//
//
//            
//                  
//        }

        
        
        
        
    }
    
        
    }
    else
        
    {
        
        
        UIAlertController * alert= [UIAlertController alertControllerWithTitle: @"OTP Don't Match"
                                                                       message: @"Your OTP is Wrong,Please fill correct OTP number"
                                                                preferredStyle:UIAlertControllerStyleAlert];
        
        
        UIAlertAction* Login = [UIAlertAction
                                actionWithTitle:@"TRY Again"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
                                {
                                    
                                    
                                }];
        
               [alert addAction:Login];
               [self presentViewController:alert animated:YES completion:nil];
        

        
        
        
        
        
        
    }
        
    
      
    
    
}
- (IBAction)resendOTP:(UIButton *)sender


{
    
    [self OtpEqualDataWithNumber];
    
    
}






-(UIColor*)colorWithHexString:(NSString*)hex
{
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor grayColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}






- (IBAction)backClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
    
}

-(void)PushToHome{
    
    
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView removeFromSuperview];
    
    
    [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"isFirst"];
    [[NSUserDefaults standardUserDefaults]synchronize];

    
    HomeVC *hVc = [[HomeVC alloc]init];
    UIStoryboard *story =[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    hVc =[story instantiateViewControllerWithIdentifier:@"HomeVC"];
      NSString *strr  = [[NSUserDefaults standardUserDefaults]valueForKey:@"role"];
    if ([strr isEqualToString:@"ROLE_PARTICIPANT"])
              {
                  hVc.RoleStr = @"PARTICIPANT" ;
                  
                 
                  
                  
              }
    else if ([strr isEqualToString:@"ROLE_HOST"])
                  {
                      hVc.RoleStr = @"HOST" ;
                  }
    else if ([strr isEqualToString:@"ROLE_SUPER_ADMIN"])
                        {
                         hVc.RoleStr = @"ADMIN" ;
                            
                        }
    
   
    UINavigationController *navVc = [[UINavigationController alloc]initWithRootViewController:hVc];
    
    
    
    [navVc setViewControllers: @[hVc] animated: YES];
    navVc.navigationBarHidden = true;
    
    delegate.window.rootViewController= navVc;
//    NSArray *myNibsArray = [[NSBundle mainBundle] loadNibNamed:@"Tab" owner:self options:nil];
//    _tabView = [myNibsArray objectAtIndex:0];
//
//
//    [delegate.window makeKeyAndVisible];
//    
//    _tabView.frame  = CGRectMake(0, delegate.window.rootViewController.view.frame.size.height-_tabView.frame.size.height, delegate.window.rootViewController.view.frame.size.width, _tabView.frame.size.height);
//    [delegate.window.rootViewController.view addSubview:_tabView];
    
    [_tabView todayClicked];

}
@end
