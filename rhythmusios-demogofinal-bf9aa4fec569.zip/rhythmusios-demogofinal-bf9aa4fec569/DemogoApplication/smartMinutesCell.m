//
//  smartMinutesCell.m
//  DemogoApplication
//
//  Created by katoch on 24/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "smartMinutesCell.h"

@implementation smartMinutesCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
