//
//  LiveParticipantViewController.h
//  nbng
//
//  Created by Rhythmus on 28/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AFNetworking/AFNetworking.h>


@interface LiveParticipantViewController : UIViewController<UIAlertViewDelegate>{
    
    id activeInactive ;
    NSString*companyId;
    NSString*Tokenid;
    NSString*ConfId ;
    NSString*personId;
    NSString*MobileStr;
     NSString*singleConfID;
    NSTimer *timer ;
    NSString*confDialType ;
    NSURLSession *activeInactiveSession;
     NSURLSessionDataTask *actInactTask;
    
    BOOL isSessionNil ;
     BOOL isSessNil ;
    
    id selfDrop ;
    id singleParticipantMute;
     id singleParticipantUnMute;
    id singleParticipantEndCall;
    id RetrySingleDianlinResult;
    id RetrySingleDialOut ;
    id ConfDRopApi ;
    id  confAllMute;
    id  confAllUnMute;
    id remindAll ;
    id dialOut;
    UIButton *singleMuteTag;
    
 NSString *confTyep ;
    AFHTTPSessionManager * managerAf;
    AFHTTPSessionManager * managerAfConf;
    NSTimer *aTimer;
    UIAlertView *endConfalert;
    UIButton *singleEndCallTag;
    UIAlertView*singleEndAlert ;
    UIButton *singleRefreshTag;
    
    id confSelfunMute ;
    id controlConferernce ;
    NSString*status;
    id dialMe ;
    NSString*allParticipantsMute;
    NSString*end;

     NSString*liverecording;
    NSString*selfmute;
    
    NSTimer *bTimer ;
    
    UIButton*redBtn;
    NSTimer* timerBtnRtry ;
    
    
    
    
    
    
}
@property (strong, nonatomic) IBOutlet UILabel *txtInviteLive;
@property (strong, nonatomic) IBOutlet UILabel *txtJoinedLive;
@property (strong, nonatomic) IBOutlet UILabel *txtNotJoinedLive;
@property (strong, nonatomic) IBOutlet UILabel *txtDialOutLive;

@property (strong, nonatomic) IBOutlet UILabel *LiveInvite;
@property (strong, nonatomic) IBOutlet UILabel *LiveJoined;
@property (strong, nonatomic) IBOutlet UILabel *LiveNotJoined;
@property (strong, nonatomic) IBOutlet UILabel *LiveDialOut;

@property (strong, nonatomic) IBOutlet UITableView *tableview;

    ////   invvite ,joined,notjoined, dialout  BAck Views Outlet
@property (strong, nonatomic) IBOutlet UIView *ViewLiveInvite;

@property (strong, nonatomic) IBOutlet UIView *ViewLiveNotJoined;

@property (strong, nonatomic) IBOutlet UIView *ViewLiveDialOut;

@property (strong, nonatomic) IBOutlet UIView *ViewLiveJoined;



- (IBAction)btnBack:(UIButton *)sender;

- (IBAction)endAllConfClicked:(id)sender;
- (IBAction)muteClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnAllMute;
- (IBAction)dialOutClicked:(id)sender;
- (IBAction)remindAllClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnRemindAll;
@property (strong, nonatomic) IBOutlet UIButton *btnAllConfEnd;

@end
