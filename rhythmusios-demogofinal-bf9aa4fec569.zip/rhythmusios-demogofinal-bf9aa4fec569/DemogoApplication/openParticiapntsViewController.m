//
//  openParticiapntsViewController.m
//  schedulePAgeDesign
//
//  Created by Rhythmus on 26/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "openParticiapntsViewController.h"


@interface openParticiapntsViewController ()

@end

@implementation openParticiapntsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.textViews.layer.cornerRadius=10.5;
    
     self.btnDone.layer.cornerRadius=10.5;
    
    
    
    
    
      
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnDone:(id)sender {
}
- (IBAction)BtnBack:(id)sender {
     [self dismissViewControllerAnimated:YES completion:nil];
}
@end
