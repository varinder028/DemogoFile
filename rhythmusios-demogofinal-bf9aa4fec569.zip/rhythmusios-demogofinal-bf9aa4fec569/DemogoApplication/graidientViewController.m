//
//  graidientViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/30/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "graidientViewController.h"

@interface graidientViewController ()
{
    UIScrollView *bluescroll;
}
@property (strong, nonatomic) IBOutlet UIButton *btnOutleet;
@property (strong, nonatomic) IBOutlet UIView *dyanmicview;

@end

@implementation graidientViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(showkeyboard) name:UIKeyboardDidShowNotification object:nil];
    
    
    
    bluescroll = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,self.view.frame.size.height)];
    
    bluescroll.backgroundColor = [UIColor blueColor];
    [self.view addSubview:bluescroll];
    
    [bluescroll setContentSize:CGSizeMake(0, self.view.frame.size.height+30)];
    
    //UIView *viewBack = [[UIView alloc]initWithFrame:CGRectMake(0, 0, bluescroll.frame.size.width, bluescroll.frame.size.height)];
    self.dyanmicview.backgroundColor = [UIColor redColor];
    
    
    [bluescroll addSubview:self.dyanmicview];
   


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)showkeyboard
{
    if ([[UIScreen mainScreen]bounds].size.height == 568) {
        [bluescroll setFrame:CGRectMake(0, 20, 320, 560)];
        
    }else
        
    {
        [bluescroll setFrame:CGRectMake(0, 20, 320, 460)];
        //[self.signUP setFrame: CGRectMake(0,20, 320, 460 )];
    }

}


@end
/* CAGradientLayer *layerColour = [CAGradientLayer layer];
 layerColour.frame = self.view.bounds;
 layerColour.colors =[NSArray arrayWithObjects:[UIColor colorWithRed:40 green:50 blue:60 alpha:1],nil];
 layerColour.startPoint = CGPointMake(1.00, 0.00);
 layerColour.endPoint = CGPointMake(0.00, 1.00);
 [self.view.layer insertSublayer:layerColour atIndex:0];
 
 CAGradientLayer *gradient = [CAGradientLayer layer];
 gradient.frame = CGRectMake(0, 0, 350, 80);
 gradient.startPoint = CGPointZero;
 gradient.endPoint = CGPointMake(1, 1);
 gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:34.0/255.0 green:211/200 blue:200/255.0 alpha:1.0] CGColor],(id)[[UIColor colorWithRed:70/200.0 green:80.0/120.0 blue:303/100.0 alpha:1.0] CGColor], nil];
 [self.btnOutleet.layer addSublayer:gradient];
 
 // Do any additional setup after loading the view.
 */
