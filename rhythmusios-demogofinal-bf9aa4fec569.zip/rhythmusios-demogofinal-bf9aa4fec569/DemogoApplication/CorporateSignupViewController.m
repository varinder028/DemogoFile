//
//  CorporateSignupViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/24/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "CorporateSignupViewController.h"
#import "CorporaeWCsucessViewController.h"
#import "Reachability.h"
#define ACCEPTABLE_CHARACTERS @"0123456789"

@interface CorporateSignupViewController ()<UITextFieldDelegate,UIScrollViewDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate,UITextFieldDelegate>



{
    
    
    CorporaeWCsucessViewController * WCPassData;
    
    
    
    NSAttributedString *str;
    NSAttributedString *str2;
    NSAttributedString *str3;
    NSAttributedString *str4;
    NSAttributedString *str5;
    NSAttributedString *str6;
    

    NSMutableURLRequest *request;
    NSURL *url;
    NSDictionary *mapData ;
    long value;
    NSMutableArray *act;
    
    
    
    NSMutableDictionary *tmpDict;
    NSMutableString *theXML;
    NSMutableString *XMLData;
    long success;
    NSData * SendData;
    
    
    UIScrollView *scrollview;
    NSDictionary *mapDataError ;
    NSDictionary *mapDataToken ;
    NSArray * PassedJSonArray;
    BOOL checked;
}

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *viewconstantt;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *demogoCOnstant;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *AgreeCOnstant;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *radioCOnstant;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *signupCOnstant;












@property (weak, nonatomic) IBOutlet UIScrollView *scrolll;

@property (strong, nonatomic) IBOutlet NSURLConnection *loginconnection;

@property (strong, nonatomic) IBOutlet NSMutableData *responsedata;

@property (strong, nonatomic) IBOutlet NSMutableData *DataResPonse;

@property (strong, nonatomic) IBOutlet NSMutableData *resData;

@property (strong, nonatomic) IBOutlet UITextField *stringdata;




@property (strong, nonatomic) IBOutlet UIScrollView *scrollview;

@property (strong, nonatomic) IBOutlet UIButton *signUP;

@property (strong, nonatomic) IBOutlet UIView *viewBack;

@property (strong, nonatomic) IBOutlet UIImageView *logo;







@end

@implementation CorporateSignupViewController

-(void)viewDidAppear:(BOOL)animated
{
    
    
    if ([UIScreen mainScreen].bounds.size.height == 480) {
        CGRect frme = self.viewBack.frame ;
        frme.size.height = 275 ;
        self.viewBack.frame = frme ;
        
        
        
    }
    
    _viewBack.layer.cornerRadius = 5.0f ;
    [_viewBack clipsToBounds];

    
    self.Number.userInteractionEnabled = NO;
    
    _scrolll.showsVerticalScrollIndicator=YES;
    _scrolll.scrollEnabled=YES;
    _scrolll.userInteractionEnabled=YES;
    
    _scrolll.contentSize = CGSizeMake(0,self.scrolll.frame.size.height);
    
    
    // [self.scrollViewVertically setContentOffset: CGPointMake(0, self.scrollViewVertically.contentOffset.y)];
    // self.scrollViewVertically.directionalLockEnabled = YES;
}
-(void)viewDidLayoutSubviews{
    
    [super viewDidLayoutSubviews];
    
    if ([UIScreen mainScreen].bounds.size.height == 480) {
        CGRect frme = self.viewBack.frame ;
        frme.size.height = 275 ;
        self.viewBack.frame = frme ;
        
        
        
    }

}


-(UIColor*)colorWithHexString:(NSString*)hex
{
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor grayColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}





-(BOOL)validateEmail:(NSString *)user;

{
    NSString *emailstring = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    
    NSPredicate *emailtest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",emailstring];
    
    return[emailtest evaluateWithObject: user];

}



- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [[UINavigationBar  appearance]setBarTintColor:[self colorWithHexString:@"021e29"]];
    //[self.view setBackgroundColor:[self colorWithHexString:@"021e29"]];
//
  //  [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(KeybordDidShow:) name:UIKeyboardDidShowNotification object:nil];
//    
  //   [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(KeybordDidHide:) name:UIKeyboardDidHideNotification object:nil];
//    
    
     checked=NO;
    
    //self.scrollview.frame = CGRectMake(0, 135, 375, 532);
    
    
   // self.navigationController.navigationBar.topItem.title = @"COR.SIGNUP";
    //self.navigationController.navigationBarHidden = YES;
     self.navigationController.navigationBarHidden = YES;
    
    
    self.signUP.layer.cornerRadius = 5.5;
    
    
    
    
UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dissmisskeyboard:)];
    
       [self.view addGestureRecognizer:tap];
    
    
    

    
   
    
    
    //    1.      ////////////            CompanyName TextField PlaceHolder           /////////////////
    
    str=[[NSAttributedString alloc]initWithString:@"Company Name"
        
                                       attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
                                                self.CompanyName.attributedPlaceholder=str;
    self.CompanyName.tag= 1;
    
    
    
    
    
    //  2.        ////////////            Official Email ID TextField PlaceHolder           /////////////////
    

        str2=[[NSAttributedString alloc]initWithString:@"Company's General Email ID"
          
                                        attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
   
                                                self.officialEmailId.attributedPlaceholder=str2;
    
    
    self.officialEmailId.tag= 2;
    
    
    //  3.          ////////////            OFFICIAL CONTACT NUMBER TextField PlaceHolder           /////////////////

    
    str3=[[NSAttributedString alloc]initWithString:@"Company's Landline No."
          
                                        attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
                                                self.OfficialContactNum.attributedPlaceholder=str3;
    
                                                            self.OfficialContactNum.keyboardType =UIKeyboardTypeNumberPad;
    
    
    
    self.OfficialContactNum.tag= 3;
    
    //   4.             ////////////            CoNTACT PERSON NAME TextField PlaceHolder           /////////////////

    
    
    str4=[[NSAttributedString alloc]initWithString:@"Admin Spoc's Person Name"
         
                                        attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
   
                                                            self.FirstName.attributedPlaceholder=str4;
    
    
    
    self.FirstName.tag= 4;
    
    //   5.           ////////////            PERSONAL MOBILE NUM TextField PlaceHolder           /////////////////

    
    str5=[[NSAttributedString alloc]initWithString:@"Personal Mobile No"
          
                                        attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
   
                                                       self.Number.attributedPlaceholder=str5;
    
                                                                        self.Number.text = self.MobileString;
    
    
    
    self.Number.tag= 5;
    
    //     6.          ////////////            PERSONAL EMAIL ID TextField PlaceHolder           /////////////////
    
    
    str6=[[NSAttributedString alloc]initWithString:@"Admin Spoc's Email ID"
         
                                        attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
   
                                                self.EmailID.attributedPlaceholder=str6;

    
   
    self.EmailID.tag= 6;
    
    
    }



#pragma mark- TextField Delegates

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    
    if (textField == self.FirstName) {
        
        [UIView animateWithDuration:0.5 animations:^{
            _topLayout.constant = -100  ;
            [self.view layoutIfNeeded];
        }];
        
        
    }else if (textField == self.Number) {
        [UIView animateWithDuration:0.5 animations:^{
            _topLayout.constant = -100  ;
            [self.view layoutIfNeeded];
        }];
       
        
    }else if (textField == self.EmailID) {
        
        [UIView animateWithDuration:0.5 animations:^{
            _topLayout.constant = -168 ;
            [self.view layoutIfNeeded];
        }];
        
        
    
    }
    else{
        
        
        _topLayout.constant = 0 ;
        [self.view layoutIfNeeded];
    }
    
   

    
//    if ([self.CompanyName becomeFirstResponder]) {
//         [self animateTextField: textField up: NO];
//    }else if ([self.officialEmailId becomeFirstResponder]) {
//        [self animateTextField: textField up: NO];
//    }else if ([self.OfficialContactNum becomeFirstResponder]) {
//        [self animateTextField: textField up: NO];
//    }
//    [self animateTextField: textField up: YES];
    
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    
    [UIView animateWithDuration:0.5 animations:^{
        _topLayout.constant = 0  ;
        [self.view layoutIfNeeded];

    }];
    
    [textField resignFirstResponder];
    
    
    return YES ;
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    //[self animateTextField: textField up: NO];
}

- (void) animateTextField: (UITextField*) textField up: (BOOL) up
{
    //    if ([signupView needsUpdateConstraints]== YES) {
    //
    //        NSLog(@"uodat is needed");
    //
    //        [signupView setNeedsUpdateConstraints];ssss
    //    }
    
    const int movementDistance = 110; // tweak as needed
    
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"anim" context: nil];
    
    [UIView setAnimationBeginsFromCurrentState: YES];
    
    [UIView setAnimationDuration: movementDuration];
    
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    
    [UIView commitAnimations];
}







//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
//    NSLog(@"touchesBegan:withEvent:");
//    [self.view endEditing:YES];
//    [super touchesBegan:touches withEvent:event];
//}
//
//
-(void)dissmisskeyboard:(UIGestureRecognizer *) sender
{
    [self.view endEditing:YES];
    [UIView animateWithDuration:0.5 animations:^{
        _topLayout.constant = 0  ;
        [self.view layoutIfNeeded];
        
    }];
    
    
}
//
//
//
//-(void)KeybordDidShow:(NSNotification *)notification
//{
////    CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
////    
////    [UIView animateWithDuration:0.3 animations:^{
////        CGRect f = self.view.frame;
////        f.origin.y = -keyboardSize.height;
////        self.view.frame = f;
////    }];
//    
//    if (self.CompanyName.tag==1)
//    
//    {
//        
//       // self.navigationController.navigationBarHidden = YES;
//        
//        [self.view setFrame:CGRectMake(0, -100, 320, 560)];
//        
//    }
//    else
//    
//    if ([[UIScreen mainScreen]bounds].size.height == 200) {
//        
//       // self.navigationController.navigationBarHidden = YES;
//        
//     //  [ self.CompanyName setFrame:setFrame:CGRectMake(0, -130, 320, 560)];
//        [self.view setFrame:CGRectMake(0, -130, 320, 560)];
//        
//       // [self.view setFrame:CGRectMake(0, -150, 320, 560)];
//    }else
//        
//    {
//        [self.view setFrame:CGRectMake(0, -10, 320, 460)];
//       // [self.signUP setFrame:CGRectMake(0, -10, 320, 460)];
//    }
//}
//-(void)KeybordDidHide:(NSNotification *)notification
//{
//    if ([[UIScreen mainScreen]bounds].size.height == 568) {
//        [self.view setFrame:CGRectMake(0, 20, 320, 560)];
//        
//        
//        
//    }else
//        
//    {
//        [self.view setFrame:CGRectMake(0, 20, 320, 460)];
//        //[self.signUP setFrame: CGRectMake(0,20, 320, 460 )];
//    }
//}
//
//
//




//-(void)textFieldDidBeginEditing:(UITextField *)textField
//{
//    
//    
//    CGPoint scrollPoint = CGPointMake(0,0); //textField.frame.origin.y);
//   
//                        [_scrollview setContentOffset:scrollPoint animated:YES];
//
//
//
//}
//
//-(void)textFieldDidEndEditing:(UITextField *)textField
//
//{
//    
//    
//                [_scrollview setContentOffset:CGPointZero animated:YES];
//
//
//}
//
//







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}










-(void)SaveDataSecondApi

{
    NSError *linkError;
    
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
            NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
                NSURL *PushLinkUrl = [NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/person/secure/addperson"];
    
    
                    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:PushLinkUrl cachePolicy:
                                            
                        NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
                            [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    
                                [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
                                    NSString *tokenstring = [NSString stringWithFormat:@"%@",[PassedJSonArray valueForKey:@"token"]];
    
                                        NSLog(@"%@",tokenstring);
 
                                            [SendingRequest addValue:tokenstring forHTTPHeaderField:@"token"];
    
    
                                                [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
    
                                                    [SendingRequest setHTTPMethod:@"POST"];
    
    
                                                        NSMutableDictionary *emailDicDta = [[NSMutableDictionary alloc]
                                                            initWithObjectsAndKeys:@"PRIMARY",@"type",self.EmailID.text,@"value", nil];
    
    
                                                                    NSMutableArray * emailArray =[[NSMutableArray alloc]init];
    
                                                                        [emailArray addObject:emailDicDta];
    
    
                                                                            NSMutableDictionary *mobileDicDta =
                                                                                [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"PRIMARY",@"type",self.Number.text,@"value", nil];
    
    
    
    
    NSMutableArray *mobileArray =[[NSMutableArray alloc]init];
   
            [mobileArray addObject:mobileDicDta];
    
    
                    NSMutableDictionary *GetDicDta = [[NSMutableDictionary alloc]initWithObjectsAndKeys:
                                     
                            self.FirstName.text,@"firstName",
                                      
                                      @"ROLE_SUPER_ADMIN",@"role", nil];
    
    //NSLog(@"%@",cmp);
    
                                                [GetDicDta  setValue:[PassedJSonArray valueForKey:@"cmpId"] forKey:@"cmpId"];
   
                                                        [GetDicDta  setValue:emailArray forKey:@"email"];
    
                                                                [GetDicDta  setValue:mobileArray forKey:@"mobile"];
    
      self.FirstName.text = [[GetDicDta valueForKey:@"firstName"] stringByReplacingOccurrencesOfString:@" " withString: @"%20"];
    
    
                    SendData= [NSJSONSerialization dataWithJSONObject:GetDicDta options:kNilOptions error:&linkError];
    
                        [SendingRequest setHTTPBody:SendData];
    
                                    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                 
                                                  NSError *jsonError;
                                                  
                                                            NSArray* PassedJSon =[NSJSONSerialization JSONObjectWithData:data
                                                                
                                                                   options:NSJSONReadingMutableContainers error:&jsonError];
                                                  
                                                  
                                                  
                                                  
                                                  //NSLog(@"%@",[PassedJSonArray valueForKey:@"cmpId"]);
                                                  
                                                  // NSLog(@"%@",[PassedJSonArray valueForKey:@"token"]);
                                                  
                                                  
                                                  NSLog(@"%@",PassedJSon);
                                                  
            if ([[PassedJSonArray valueForKey:@"message"] isEqualToString:@"Successfully Signup"]) {
                                                  
                                                                                                            WCPassData = [self.storyboard instantiateViewControllerWithIdentifier:@"WC"];
                                                  
                                                                                                            WCPassData.NameString = self.FirstName.text;
                                                  
                                                  
                                                                                                            WCPassData.EmailIDString = self.EmailID.text;
                                                  
                                                                                                            [self.navigationController pushViewController:WCPassData animated:YES];
                                                  
                                                  
                                                  
                                                                }else{
                                                                                                        
                                                                                                        
                                                                                                  UIAlertView *alert =      [[UIAlertView alloc]initWithTitle:nil message:[PassedJSonArray valueForKey:@"message"]  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
                                                                                                        
                                                                                                        [alert show];
                                                                                                        
                                                                                                    }
                                                  
                                                  
                                              });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
    
    
    
    
}







-(void)Getresponse:(NSData *)ResponseGetData


{
    
    
    
        _DataResPonse = [[NSMutableData alloc]init];
    
                        [_DataResPonse appendData:ResponseGetData];
    
                                        NSMutableString *RESStr= [[NSMutableString alloc]initWithBytes:[self.DataResPonse mutableBytes]
                              
                                                            length:[self.DataResPonse length]
                              
                                                          encoding:NSUTF8StringEncoding];
    
    NSLog(@"%@",RESStr);
    
}



















-(void)FirstAPIPostMethodUSed;
{
    

    

    
    NSError *error;
    
        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    
            NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
    
                url = [NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/company/signup"];
    
                    request = [NSMutableURLRequest requestWithURL:url
                                      cachePolicy:NSURLRequestUseProtocolCachePolicy
                                  timeoutInterval:60.0];
    
                            [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
                                [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
                                    [request setHTTPMethod:@"POST"];
    
                                        mapData = [[NSDictionary alloc] initWithObjectsAndKeys: self.officialEmailId.text,@"cmpEml",
                                                self.OfficialContactNum.text,@"cmpMbl",
                                                   self.CompanyName.text,@"cmpNm",
                                                      nil];
    
    
   self.CompanyName.text = [[mapData valueForKey:@"cmpNm"] stringByReplacingOccurrencesOfString:@" " withString: @"%20"];
    

    
    
    
    
        // NSLog(@" %@",mapData);
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:mapData options:0 error:&error];
    
                [request setHTTPBody:postData];
    
    
   NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                            
                                              
                                              dispatch_async(dispatch_get_main_queue(),^{
                                                  
                                                  
                                                  NSError *jsonError;
                                                
                                                            PassedJSonArray =[NSJSONSerialization JSONObjectWithData:data options:
                                                                              
                                                                    NSJSONReadingMutableContainers error:&jsonError];
                                                  
                                                  
                                                  if([PassedJSonArray valueForKey:@"token"])
                                                 
                                                  {
                                                
                                                      [self SaveDataSecondApi];
                                                      
                                                  }
                                                  
                                                  
                                                  NSLog(@"%@",PassedJSonArray);
                                                  
                                                  
//                                                  if ([[PassedJSonArray valueForKey:@"message"] isEqualToString:@"success"]) {
//                                                      
//                                                          WCPassData = [self.storyboard instantiateViewControllerWithIdentifier:@"WC"];
//                                                      
//                                                          WCPassData.NameString = self.FirstName.text;
//                                                      
//                                                          
//                                                          WCPassData.EmailIDString = self.EmailID.text;
//                                                          
//                                                          [self.navigationController pushViewController:WCPassData animated:YES];
//                                                      
//                                                      
//                                                      
//                                                  }else{
//                                                      
//                                                      
//                                                UIAlertView *alert =      [[UIAlertView alloc]initWithTitle:nil message:[PassedJSonArray valueForKey:@"message"]  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
//                                                      
//                                                      [alert show];
//                                                      
//                                                  }
                                                  
                                              });
                                              
                                              
                                              
                                          }];
    
    [postDataTask resume];
    
    
    
    
}





- (IBAction)AgreeCheckButton:(id)sender {
    
    
    if (!self.radiobutton.isSelected) {
        [self.radiobutton setSelected:YES];
        
    }else{
        [self.radiobutton setSelected:NO];
        
    }
    
    
}

- (IBAction)SignUPButton:(id)sender {
    
    
    if ([self.CompanyName.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the company name" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        
    }
    
  
    
   else if ([self.OfficialContactNum.text isEqualToString:@""]) {
       UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the official Contact Number " delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
       [alert show];
       
   }
    
   else if (!([self.OfficialContactNum.text length] >= 10)){
       UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the valid official Contact Number" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
       [alert show];
       
   }

   else if ([self.FirstName.text isEqualToString:@""]) {
       UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the Admin Spoc's Person Name" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
       [alert show];
       
   }else if ([self.EmailID.text isEqualToString:@""]) {
       UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the Admin Spoc's Email ID " delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
       [alert show];

    
   }
   else if (![self emailStringIsValidEmail :self.EmailID.text]) {
       UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the  correct Admin Spoc's Email ID " delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
       [alert show];
       
   }
    
    
   
   else if (!self.radiobutton.isSelected) {
       UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please check the terms and conditions first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
       [alert show];
       
       
   }
   else{
       
       Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
       NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
       if (networkStatus == NotReachable) {
           UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message: @"No Network Connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
           
           [alert show];
           return;
           
           
       }else
       {
       [self FirstAPIPostMethodUSed];
       }
   }
    
            
//   else if (![self.officialEmailId.text isEqualToString:@""]) {
//       
//       
//       if (![self emailStringIsValidEmail:_officialEmailId.text]) {
//           UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the correct company's General Email ID " delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
//           [alert show];
//       }
//       
//   }
    
    
    
    
    
}


-(BOOL)emailStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = NO;
    // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
    
}


- (IBAction)bckclicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string;
{
    
    if (textField == _OfficialContactNum) {
        NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
        
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
        
        if (textField.text.length == 15 && range.length == 0)
        {
            return NO; // return NO to not change text
        }
        return [string isEqualToString:filtered];
        
        
    }
    else if ( textField == _FirstName) {
        NSCharacterSet *invalidCharSet = [[NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"] invertedSet];
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:invalidCharSet] componentsJoinedByString:@""];
        return [string isEqualToString:filtered];
        
        
    }
   
    
    
        
    return YES ;

    
}




@end





