//
//  AppDelegate.m
//  DemogoApplication
//
//  Created by varinder singh on 1/23/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "AppDelegate.h"
#import "TabView.h"
#import "HomeVC.h"
#import "ViewController.h"
#import "billGraphVC.h"

@interface AppDelegate ()<UIWebViewDelegate,NSURLSessionDataDelegate>
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    NSLog(@"Success");
   // https://itunes.apple.com/in/app/demogo/id1248721931?mt=8
//    
//    NSURL *url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"http://itunes.apple.com/lookup?id=%@",@"1248721931"]];
//    
//    NSURLRequest *request = [NSURLRequest requestWithURL:url];
//    
//    [NSURLConnection sendAsynchronousRequest:request
//                                       queue:[NSOperationQueue mainQueue]
//                           completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
//                               if (!error) {
//                                   NSError* parseError;
//                                   NSDictionary *appMetadataDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&parseError];
//                                   NSArray *resultsArray = (appMetadataDictionary)?[appMetadataDictionary objectForKey:@"results"]:nil;
//                                   NSDictionary *resultsDic = [resultsArray firstObject];
//                                   if (resultsDic) {
//                                       // compare version with your apps local version
//                                       NSString *iTunesVersion = [resultsDic objectForKey:@"version"];
//                                       
//                                       NSString *appVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString*)@"CFBundleShortVersionString"];
//                                       if (iTunesVersion && [appVersion compare:iTunesVersion] != NSOrderedSame) { // new version exists
//                                           // inform user new version exists, give option that links to the app store to update your app - see AliSoftware's answer for the app update link
//                                           UIAlertView*alert = [[UIAlertView alloc]initWithTitle:@"DemoGo" message:[NSString stringWithFormat:@"New version %@ available. Update required.",iTunesVersion]  delegate:self cancelButtonTitle:@"Update" otherButtonTitles:nil, nil];
//                                           
//                                           
//                                           alert.tag = 201 ;
//                                           
//                                           [alert show];
//
//                                       }else{
//                                           
//                                           
//                                           
//                                       }
//                                       
//                                       
//                                       
//                                   }
//                               } else {
//                                   // error occurred with http(s) request
//                                   NSLog(@"error occurred communicating with iTunes");
//                               }
//                           }];
    
    
    _locationManager = [[CLLocationManager alloc] init];
//    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"synchContacts"];
//    [[NSUserDefaults standardUserDefaults]synchronize];

    
    if ([[NSUserDefaults standardUserDefaults]boolForKey:@"synchContacts"] == false)
    {

        _SynchContacts = NO ;
        
      
        
    }else{
        
        _SynchContacts = YES;
        
    }
   
    if ([[NSUserDefaults standardUserDefaults]boolForKey:@"isFirst"] == false)
    {
        ViewController*lVc = [[ViewController alloc]init];
        NSString * storyboardName = @"Main";
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        lVc= [storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
        UINavigationController *navControllr = [[UINavigationController alloc]initWithRootViewController:lVc];
        navControllr.navigationBarHidden = true;
        self.window.rootViewController= navControllr;
        [self.window makeKeyAndVisible];


        
    }else{

        HomeVC *hVc = [[HomeVC alloc]init];
        UIStoryboard *story =[UIStoryboard storyboardWithName:@"Main" bundle:nil];
        hVc =[story instantiateViewControllerWithIdentifier:@"HomeVC"];
        UINavigationController *navVc = [[UINavigationController alloc]initWithRootViewController:hVc];
        [navVc setViewControllers: @[hVc] animated: YES];
        navVc.navigationBarHidden = true;
        self.window.rootViewController= navVc;
        [self.window makeKeyAndVisible];


    }

           return YES;
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 201) {
        
        if (buttonIndex == 0) {
            
            NSString *iTunesLink = [NSString stringWithFormat:@"itms://itunes.apple.com/us/app/apple-store/id%@?mt=8",@"1248721931"];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:iTunesLink]];
            
        }
    }
    
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}



- (void)application:(UIApplication *)application willChangeStatusBarFrame:(CGRect)newStatusBarFrame{
    [UIView animateWithDuration:0.35 animations:^{
        CGRect windowFrame = ((UINavigationController *)((UITabBarController *)self.window.rootViewController).viewControllers[0]).view.frame;
        if (newStatusBarFrame.size.height > 20) {
            windowFrame.origin.y = 0.0 ;// old status bar frame is 20
        }
        else{
            windowFrame.origin.y = 0.0;
        }
        ((UINavigationController *)((UITabBarController *)self.window.rootViewController).viewControllers[0]).view.frame = windowFrame;
    }];
    
}

-(void)getLocation{
    
    self.locationManager = [[CLLocationManager alloc] init];
    
    self.locationManager.delegate = self;
    if([self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]){
        NSUInteger code = [CLLocationManager authorizationStatus];
        if (code == kCLAuthorizationStatusNotDetermined && [self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
            // choose one request according to your business.
            if([[NSBundle mainBundle] objectForInfoDictionaryKey:@"NSLocationWhenInUseUsageDescription"]) {
                [self.locationManager  requestWhenInUseAuthorization];
            } else {
                NSLog(@"Info.plist does not contain NSLocationAlwaysUsageDescription or NSLocationWhenInUseUsageDescription");
            }
        }
    }
    [self.locationManager startUpdatingLocation];
    
   
    
    
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    
    if([CLLocationManager locationServicesEnabled])
    {
        NSLog(@"Enabled");
        
        if([CLLocationManager authorizationStatus]==kCLAuthorizationStatusDenied)
        {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:NSLocalizedString( @"Location Error", @"" ) message:NSLocalizedString( @"Turn need to turn on your location", @"" ) preferredStyle:UIAlertControllerStyleAlert];
            
            //            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString( @"Cancel", @"" ) style:UIAlertActionStyleCancel handler:nil];
            UIAlertAction *settingsAction = [UIAlertAction actionWithTitle:NSLocalizedString( @"Settings", @"" ) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:
                                                            UIApplicationOpenSettingsURLString]];
            }];
            
            //  [alertController addAction:cancelAction];
            [alertController addAction:settingsAction];
            
         //   [self presentViewController:alertController animated:YES completion:nil];
        }
    }

}


- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    
    if (currentLocation != nil) {
        _latStr = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        [[NSUserDefaults standardUserDefaults]setObject:_latStr forKey:@"lat"];
        
        _longStr = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
        [[NSUserDefaults standardUserDefaults]setObject:_longStr forKey:@"long"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
    }
}

-(UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window{
    if (self.shouldRotate){
        return UIInterfaceOrientationMaskLandscapeLeft;
        
    }
    else{
        
        
        
        return UIInterfaceOrientationMaskPortrait;
            
        
        
    }
}





@end
