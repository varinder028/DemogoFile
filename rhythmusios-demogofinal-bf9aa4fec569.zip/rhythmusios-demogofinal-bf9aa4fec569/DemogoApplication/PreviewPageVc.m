//
//  PreviewPageVc.m
//  DemogoApplication
//
//  Created by Rhythmus on 01/06/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "PreviewPageVc.h"

@interface PreviewPageVc ()

@end

@implementation PreviewPageVc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _txtDate.text = _DateStr ;
    _txtHeaderDate.text = _headerDate ;
    _txtStartTime.text = _startTime ;
    _txtEndTime.text = _EndTime ;
    _txtMode.text = _mode ;
    _txtSubject.text = _subject ;
    _txtDateeee.text = _DateStr ;
    _txtDear.text = @"Dear Participants";
    
    
    NSString*strName = [[NSUserDefaults standardUserDefaults]valueForKey:@"firstName"];
    
    
    _txtDetails.text = [NSString stringWithFormat:@"You have a conference call invite,from %@ Bhargava we request you to kindly block your calender according to the details mentioned below",strName];
    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)backClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}
@end
