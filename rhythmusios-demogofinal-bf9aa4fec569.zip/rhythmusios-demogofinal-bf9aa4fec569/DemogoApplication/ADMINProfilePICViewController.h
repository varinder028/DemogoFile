//
//  ADMINProfilePICViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 31/03/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ViewController.h"

@interface ADMINProfilePICViewController : ViewController
@property (strong, nonatomic) IBOutlet UITableView *tableview;
@property (strong, nonatomic) IBOutlet UILabel *NameLabel;
@property (strong, nonatomic) IBOutlet UILabel *CountryNameLabel;
@property (strong, nonatomic) IBOutlet UILabel *EmailNameLAbel;
@property (strong, nonatomic) IBOutlet UILabel *MobileNumberLAbel;
@property (strong, nonatomic) IBOutlet UILabel *AdminOrHostNameLAbel;

@property (weak, nonatomic) IBOutlet NSString *PersonIDAHP;

@end
