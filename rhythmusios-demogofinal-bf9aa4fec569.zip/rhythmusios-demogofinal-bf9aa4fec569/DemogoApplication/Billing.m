//
//  Billing.m
//  DemogoApplication
//
//  Created by katoch on 24/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "Billing.h"
#import "MyBillViewController.h"
#import "MyPlanViewController.h"
#import "PreviousBillsViewController.h"
#import "AccountBillViewController.h"
#import "KVNProgress.h"
#import <AFNetworking/AFNetworking.h>



@interface Billing ()

@end

@implementation Billing

- (void)viewDidLoad {
    [super viewDidLoad];
    
    isPrepaid = @"Pre";
    
    
    [self.postPaidView setHidden:YES];
    [self.tableView setHidden:YES];
    _segmentcontroller.layer.cornerRadius = 5.0f;
    
    [_segmentcontroller clipsToBounds];
    
    [_segmentcontroller.layer masksToBounds];
    
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone ;
    
    
    _segmentHeightLayout.constant = 35 ;
    [self.view layoutIfNeeded];
    
    
    [[UISegmentedControl appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]} forState:UIControlStateSelected];
    
   // cellArrayName = [[NSMutableArray alloc]initWithObjects:@"My Plan",@"Subscription History", nil];
    
    
     cellArrayName = [[NSMutableArray alloc]initWithObjects:@"My Plan", nil];

    CompanyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];

  [self  varifiyingPlans];
    
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  cellArrayName.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *celid  =@"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:celid];
    
    if (cell ==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:celid];
        cell.selectedBackgroundView.backgroundColor = [UIColor colorWithRed:0.30 green:0.30 blue:0.30 alpha:1.0];
    }
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@",[cellArrayName objectAtIndex:indexPath.row]];
    cell.backgroundColor = [UIColor blackColor];
    
    
    cell.textLabel.textColor = [UIColor whiteColor];
    
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    if ([cellArrayName[indexPath.row] isEqualToString:@"My Bill"]) {
        
        
        MyBillViewController *action = [self.storyboard instantiateViewControllerWithIdentifier:@"MyBill"];
        
        action.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        
        
        [self.navigationController  pushViewController:action animated:YES];
        // [self presentViewController:action animated:YES completion:nil];
      
    }else if ([cellArrayName[indexPath.row] isEqualToString:@"My Plan"]){
        
        
        MyPlanViewController *action = [self.storyboard instantiateViewControllerWithIdentifier:@"MyPlan"];
        
        action.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        subScrStr = @"" ;

        
        [self.navigationController  pushViewController:action animated:YES];
        // [self presentViewController:action animated:YES completion:nil];
        
        
        
        
    }else if ([cellArrayName[indexPath.row] isEqualToString:@"Previous Bills"]) {
        
        PreviousBillsViewController *action = [self.storyboard instantiateViewControllerWithIdentifier:@"PreviousBills"];
        
        action.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        
        [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"previousBills"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        action.PrePaid = isPrepaid ;
        
        subScrStr = @"" ;

        [self.navigationController  pushViewController:action animated:YES];
        // [self presentViewController:action animated:YES completion:nil];
        
        
        
        
    }else if ([cellArrayName[indexPath.row] isEqualToString:@"Account Statement"]) {
        
        PreviousBillsViewController *action = [self.storyboard instantiateViewControllerWithIdentifier:@"PreviousBills"];
        
        action.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
         action.PrePaid = isPrepaid ;
        
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"previousBills"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        subScrStr = @"" ;
        
        [self.navigationController  pushViewController:action animated:YES];
        // [self presentViewController:action animated:YES completion:nil];
        
        
        
        
    }
    else if ([cellArrayName[indexPath.row] isEqualToString:@"Subscription History"]) {
        
        PreviousBillsViewController *action = [self.storyboard instantiateViewControllerWithIdentifier:@"PreviousBills"];
        
        action.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        action.PrePaid = @"Pre" ;
        
        subScrStr = @"Sub" ;
        
        action.issub = subScrStr ;
        
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"previousBills"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        [self.navigationController  pushViewController:action animated:YES];
        // [self presentViewController:action animated:YES completion:nil];
        
        
        
        
    }
    
    
    
    
}


- (IBAction)segmentAction:(id)sender

{
    if (_segmentcontroller.selectedSegmentIndex==0)
        
    {
        
        NSString*str = [NSString stringWithFormat:@"%@",[isVarified  valueForKey:@"isverify"]];
        
        
        
        if ([str isEqualToString:@"0"]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please subscribe Any plan First" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            
            [alert show];
            
        }else{

        
         isPrepaid = @"Pre";
        self.segmentcontroller.hidden =NO;
        [KVNProgress show];
        
      // cellArrayName = [[NSMutableArray alloc]initWithObjects:@"My Plan",@"Subscription History", nil];
            cellArrayName = [[NSMutableArray alloc]initWithObjects:@"My Plan", nil];

        [self GetPrepaidvalidityFromServer];
            
        }
        
    }else if (_segmentcontroller.selectedSegmentIndex==1)
    {
        
        
        NSString*str = [NSString stringWithFormat:@"%@",[isVarified  valueForKey:@"isverify"]];
        if ([str isEqualToString:@"0"]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please subscribe Any plan First" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            
            [alert show];
            
        }else{

         isPrepaid = @"Post";
        self.PrepaidView.hidden = YES;
        
        [KVNProgress show];
        
       // cellArrayName = [[NSMutableArray alloc]initWithObjects:@"My Bill",@"My Plan",@"Previous Bills",@"Account Statement", nil];
            
                    cellArrayName = [[NSMutableArray alloc]initWithObjects:@"My Plan", nil];
            
            [self POstpaidvalidityFromServer];
            
            
    }
        
    }
    
    
}


- (IBAction)backBtn:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)varifiyingPlans{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/secure/isverify?cmpId=%@",CompanyId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
        
        
        
        isVarified = responseObject ;
        [self performSelectorOnMainThread:@selector(planType) withObject:nil waitUntilDone:YES];
        NSLog(@"%@",isVarified);
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    

    
}


-(void)planType{
    
    NSString*str = [NSString stringWithFormat:@"%@",[isVarified  valueForKey:@"isverify"]];
    
    NSString*planType = [NSString stringWithFormat:@"%@",[isVarified valueForKey:@"planType"]];
    
    if ([planType isEqualToString:@"No plan selected"]) {
        
       NoPlanAlert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Subscribe any plan first" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        NoPlanAlert.delegate = self ;
        
        
        [NoPlanAlert show];
    }
    else{

    if ([str isEqualToString:@"0"]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Subscribe the Plan First" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
    else{
    
    
    if ([[isVarified valueForKey:@"planType"] isEqualToString:@"No plan selected"]) {
        
        if ([checkPlan isEqualToString:@"SmartMinutes"]) {
            
            planNameCHeck = @"No plan selected" ;
            
            
        }
        
        
    }else if ([[isVarified valueForKey:@"planType"] isEqualToString:@"prepaid"]){
        
        
        planNameCHeck = @"prepaid" ;
        [self.postPaidView setHidden:NO];
        [self.tableView setHidden:NO];
        
        
        
      
        
        [self GetPrepaidvalidityFromServer];
        
      
        
    }else if ([[isVarified valueForKey:@"planType"] isEqualToString:@"postpaid"]){
        
        planNameCHeck = @"postpaid" ;
        
        [self.postPaidView setHidden:YES];
        [self.tableView setHidden:YES];
        
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"You have already subscribe postpaid plan" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        

    }
    
    
   
    
    [_tableView reloadData];
    
    }
    
    }
}

-(void)GetPrepaidvalidityFromServer{
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/plan/secure/prepaidvalidity?cmpid=%@",CompanyId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
        
        
        _postPaidView.hidden = NO;
        self.tableView.hidden =NO;

        prePaidValididy = responseObject ;
        [self performSelectorOnMainThread:@selector(prePaidValididy) withObject:nil waitUntilDone:YES];
        
        [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        NSLog(@"%@",prePaidValididy);
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        _postPaidView.hidden = YES;
        self.tableView.hidden =YES;

        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"You Have already subscribe Postpaid Plan" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];

        
        [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      
//                                      
//                                      [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
//                                      
//                                      // NSError* error;
//                                      if (data != nil) {
//                                          prePaidValididy =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//                                      }
//                                      
//                                      
//                                      [self performSelectorOnMainThread:@selector(prePaidValididy) withObject:nil waitUntilDone:YES];
//                                      
//                                      
//                                      NSLog(@"%@",prePaidValididy);
//                                      
//                                      
//                                  }];
//    
//    [task resume];

    
}

-(void)kvnProgess{
    
    [KVNProgress dismiss];
    
}

-(void)prePaidValididy{
    if ([[prePaidValididy valueForKey:@"message"] isEqualToString:@"success"]) {
        
        
        NSString*balnce = [NSString stringWithFormat:@"%@",[prePaidValididy valueForKey:@"remainvalue"]];
        
        
        
        
        
        self.txtPlanName.text =@"" ;
        
       // self.txtValidity.text = [NSString stringWithFormat:@"%@",[prePaidValididy valueForKey:@"remainvalue"]];
        NSString*remainingValue = [NSString stringWithFormat:@"%@",[[prePaidValididy valueForKey:@"validityvalue"]valueForKey:@"remainvalue"]];
        NSString*totalValue = [NSString stringWithFormat:@"%@",[[prePaidValididy valueForKey:@"validityvalue"]valueForKey:@"totalvalue"]];
      //  NSString*expiryValue = [NSString stringWithFormat:@"%@",[prePaidValididy valueForKey:@"expiredate"]];
        
        
        double validit = [[prePaidValididy valueForKey:@"expiredate"]doubleValue];
        NSDate* Time = [NSDate dateWithTimeIntervalSince1970:validit / 1000.0];
        NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
        [outputFormatter setDateFormat:@"dd-MM-yyyy"];
        outputFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        NSString * currntStr = [outputFormatter stringFromDate:Time];

    
        self.txtValidity.text   = currntStr ;
        _txtTotalValue.text  = [NSString stringWithFormat:@"%@",totalValue];
        _txtBalnce.text  = [NSString stringWithFormat:@"%@",remainingValue];
        _customerId.text = @" " ;
        

        
        self.txtTotalValue.text = totalValue ;
        
//        float balnceamount = [balnce floatValue];
//        float totalAmount = [totalValue floatValue];
//        
//        double usedBalnce = totalAmount - balnceamount ;
        
     //   self.txtBalnce.text =  [NSString stringWithFormat:@"%.2f",usedBalnce];
        
        
        
       // self.customerId.text = [NSString stringWithFormat:@"%@",[prePaidValididy valueForKey:@"customerId"]];
        
    }else{
        
       
        
        _postPaidView.hidden = YES;
        self.tableView.hidden =YES;

        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"You Have already subscribe Postpaid Plan" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        
    }
    
}
-(void)POstpaidvalidityFromServer{
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/plan/secure/postpaidvalidity?cmpid=%@",CompanyId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
        
        
        _postPaidView.hidden = NO;
        self.tableView.hidden =NO;

        PostpaidValidity = responseObject ;
         [self performSelectorOnMainThread:@selector(PostpaidValidityData) withObject:nil waitUntilDone:YES];
        NSLog(@"%@",PostpaidValidity);
        [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        _postPaidView.hidden = YES;
        self.tableView.hidden =YES;

        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"You Have already Subscribe Prepaid Plan" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];

        [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
        
    }];

    
    
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      [self performSelectorOnMainThread:@selector(kvnProgess) withObject:nil waitUntilDone:YES];
//                                      // NSError* error;
//                                      if (data != nil) {
//                                          PostpaidValidity =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//                                      }
//                                      
//                                      
//                                      [self performSelectorOnMainThread:@selector(PostpaidValidityData) withObject:nil waitUntilDone:YES];
//                                      
//                                      
//                                      NSLog(@"%@",PostpaidValidity);
//                                      
//                                      
//                                  }];
//    
//    [task resume];
    
    
}
-(void)PostpaidValidityData{
    
    if ([[PostpaidValidity valueForKey:@"responseCode"] isEqual:[NSNumber numberWithInteger:200]]) {
        
       NSString*balnce = [NSString stringWithFormat:@"%@",[PostpaidValidity valueForKey:@"remainvalue"]];
                self.txtPlanName.text = [NSString stringWithFormat:@"%@",[PostpaidValidity valueForKey:@"planName"]];
        self.txtValidity.text = [NSString stringWithFormat:@"%@",[PostpaidValidity valueForKey:@"expiredate"]];
        
        double validit = [[PostpaidValidity valueForKey:@"expiredate"]doubleValue];
        NSDate* Time = [NSDate dateWithTimeIntervalSince1970:validit / 1000.0];
                NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
        [outputFormatter setDateFormat:@"dd-MM-yyyy"];
        outputFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        NSString * currntStr = [outputFormatter stringFromDate:Time];
        _txtValidity.text = currntStr ;
        
        
        
NSString*totalValue = [NSString stringWithFormat:@"%@",[PostpaidValidity valueForKey:@"totalvalue"]];
        self.txtTotalValue.text = totalValue ;
        
        float balnceamount = [balnce floatValue];
        float totalAmount = [totalValue floatValue];
        
        double usedBalnce = totalAmount - balnceamount ;
        
        self.txtBalnce.text =  [NSString stringWithFormat:@"%.2f",usedBalnce];
        
        
        
        self.customerId.text = [NSString stringWithFormat:@"%@",[PostpaidValidity valueForKey:@"customerId"]];
               
        
    }else{
        
        _postPaidView.hidden = YES;
        self.tableView.hidden =YES;

        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"You Have already subscribe Prepaid Plan" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];

        
    }
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    
    if (alertView == NoPlanAlert) {
        
        [self.navigationController popViewControllerAnimated:YES];
        
        
    }
    
}

@end
