//
//  PaymentVc.h
//  DemogoApplication
//
//  Created by Rhythmus on 15/06/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PaymentVc : UIViewController<UIAlertViewDelegate>{
    UIAlertView *alert;
    NSString*CompanyId ;
    NSString*Tokenid ;
    NSString*getPaymentData ;
    
        
    
}
@property(strong,nonatomic)NSString *htmlText ;
@property(strong,nonatomic)NSString *transStatus ;

@property (strong, nonatomic) IBOutlet UILabel *txtResult;

@property (strong, nonatomic) IBOutlet UIButton *btnContinue;
- (IBAction)continueClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UIImageView *transImage;
@end
