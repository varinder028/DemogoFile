//
//  EmplyeeMAnagementViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 04/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ViewController.h"

@interface EmplyeeMAnagementViewController : ViewController

/////   Upper Button or searchBarButton button
- (IBAction)ADDButtonNew:(UIButton *)sender;


@property (strong, nonatomic) IBOutlet UIButton *ADDbuttonOutlet;

@property (strong, nonatomic) IBOutlet UIButton *SelectPersonGroupOutlet;

- (IBAction)SelectPersonButton:(UIButton *)sender;

- (IBAction)BlockPersonButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *BlockPersonOutlet;

- (IBAction)UnblockPersonButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *UnblockPersonOutlet;

@property (strong, nonatomic) IBOutlet UISearchBar *SearchBar;



///////     CHeck or need labels outlet 

- (IBAction)CheckButton:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *CheckButtonOutlet;

@property (strong, nonatomic) IBOutlet UILabel *MobileumLabel;

@property (strong, nonatomic) IBOutlet UILabel *NAmeLabel;

@property (strong, nonatomic) IBOutlet UILabel *RoleLAbel;

- (IBAction)BAckButton:(id)sender;



////////////       ADD USer Details VIew or Objects

@property (strong, nonatomic) IBOutlet UIView *USerDetailsView;

@property (strong, nonatomic) IBOutlet UILabel *USerdetailsLabel;

@property (strong, nonatomic) IBOutlet UITableView *tableViewADDPerson;



//////....   Group Add Person View deatials or attributes

- (IBAction)ADDGroup:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *AddGroupOutlet;

@property (strong, nonatomic) IBOutlet UISearchBar *GroupSearchBar;

- (IBAction)GroupAllCheckBox:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *GoupAllCheckBoxOUtlet;

@property (strong, nonatomic) IBOutlet UILabel *group;

@property (strong, nonatomic) IBOutlet UILabel *groupmembersLbelname;

@property (strong, nonatomic) IBOutlet UILabel *GorupCenterDateLAbel;

@property (strong, nonatomic) IBOutlet UITableView *GroupTabelViewData;







@end
