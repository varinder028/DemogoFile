//
//  MyMeetingsVc.m
//  DemogoApplication
//
//  Created by katoch on 25/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "MyMeetingsVc.h"
#import "MeetingCell.h"
#import "schduleVc.h"
#import "KVNProgress.h"
#import "HomeVC.h"
#import <AFNetworking/AFNetworking.h>
#import <SSZipArchive.h>
#import "ALAssetsLibrary+CustomPhotoAlbum.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <CloudKit/CloudKit.h>



@interface MyMeetingsVc ()

@end

@implementation MyMeetingsVc

- (void)viewDidLoad {
    [super viewDidLoad];
   
 
    previousData = [[NSMutableArray alloc]init];
    
    _historyTableView.separatorStyle= UITableViewCellSelectionStyleNone ;
    _meetingTableView.separatorStyle= UITableViewCellSelectionStyleNone ;
    todayMeetingArray = [[NSMutableArray alloc]init];
    UpcomingMeetingArray =  [[NSMutableArray alloc]init];
    
    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"getScheduled"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    NSLog(@"%@",personId);
    
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    NSLog(@"%@",Tokenid);
    
   
    
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear: animated];
    [KVNProgress show];
    
     [self GetConferenceDat];
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)touchScreen{
    
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    if (tableView ==_meetingTableView ){
    return todayMeetingArray.count;
        
    }else if (tableView ==_historyTableView){
        
        return previousData.count ;
    }
    return  0;
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    
    
    if (tableView ==_meetingTableView ) {
        
        MeetingCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MeetCell"];
        if (cell==nil) {
            NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"MeetingCell" owner:self options:nil];
            
            cell= arr[0];
            
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone ;
        if (todayMeetingArray.count >0) {
            NSString*StartTime = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"date"]objectAtIndex:indexPath.row]];
            
            StartTime = [StartTime stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
            
            //// / convertingTodate
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
            dateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
            NSDate *datecurrent = [dateFormatter dateFromString:StartTime];
            NSLog(@"%@",datecurrent);
            
            
            NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
            dateFormatter1.dateFormat = @"yyyy-MM-dd";
            dateFormatter1.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
            NSString*dateSt = [dateFormatter1 stringFromDate:datecurrent];
            
            NSLog(@"%@",dateSt);
            
            NSDateFormatter *dateFormatter2 = [[NSDateFormatter alloc] init];
            dateFormatter2.dateFormat = @"HH:mm";
            dateFormatter2.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
            NSString*StartTi = [dateFormatter2 stringFromDate:datecurrent];
            
            NSLog(@"%@",StartTi);
            
            
            NSString*EndTime = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"endOffDate"]objectAtIndex:indexPath.row]];
            EndTime = [EndTime stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
            
            //// / convertingTodate
            NSDateFormatter *EnddateFormatter = [[NSDateFormatter alloc] init];
            EnddateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
            EnddateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
            NSDate *endDate = [EnddateFormatter dateFromString:EndTime];
            NSLog(@"%@",endDate);
            NSDateFormatter *endTimeFormatter = [[NSDateFormatter alloc] init];
            endTimeFormatter.dateFormat = @"HH:mm";
            endTimeFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
            NSString*endTi = [endTimeFormatter stringFromDate:endDate];
            
            NSLog(@"%@",endTi);
            
            
            cell.txtStartTime.text = StartTi;
            cell.txtEndTime.text = endTi ;
            cell.txtDate.text = dateSt ;
            
            cell.textChairPerson.text = [NSString stringWithFormat:@"%@",[[todayMeetingArray valueForKey:@"firstName"]objectAtIndex:indexPath.row]];
            
            [cell.btnEdit addTarget:self action:@selector(editBtn:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.btnEdit.tag = indexPath.row ;
            
            [cell.btnDelete addTarget:self action:@selector(deleteBtn:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.btnEdit.tag = indexPath.row ;
            [cell.btnEdit setHidden:NO ];
            [cell.btnDelete setHidden:NO ];
            [cell.btnDownload setHidden:YES ];

            
        }
        
        
        
        return  cell;
    }
    
    else if (tableView == _historyTableView){
        MeetingCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MeetCell"];
        if (cell==nil) {
            NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"MeetingCell" owner:self options:nil];
            
            cell= arr[0];
            
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone ;
        
        NSString*StrtTime = [[previousData valueForKey:@"strtTime"] objectAtIndex:indexPath.row];
        
        double st = [StrtTime doubleValue];
        NSDate *Stdate = [NSDate dateWithTimeIntervalSince1970:(st / 1000.0)];
        NSDateFormatter *StartTimeFormatter = [[NSDateFormatter alloc] init];
        StartTimeFormatter.dateFormat = @"HH:mm";
        StartTimeFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        NSString*StartTi = [StartTimeFormatter stringFromDate:Stdate];
        
        NSLog(@"%@",StartTi);
        cell.txtStartTime.text = [NSString stringWithFormat:@"%@",StartTi];
        
        
         NSString*EndTime = [[previousData valueForKey:@"endTime"] objectAtIndex:indexPath.row];
        double Et = [EndTime doubleValue];
        NSDate *Etdate = [NSDate dateWithTimeIntervalSince1970:(Et / 1000.0)];
        NSDateFormatter *EndTimeFormatter = [[NSDateFormatter alloc] init];
        EndTimeFormatter.dateFormat = @"HH:mm";
        EndTimeFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        NSString*EndTi = [EndTimeFormatter stringFromDate:Etdate];
        
        NSLog(@"%@",EndTi);

     
        cell.txtEndTime.text = [NSString stringWithFormat:@"%@",EndTi];


         NSString*Date = [[previousData valueForKey:@"confdate"] objectAtIndex:indexPath.row];
        double Dt = [Date doubleValue];
        
        NSDate *dt = [NSDate dateWithTimeIntervalSince1970:(Dt / 1000.0)];
        NSDateFormatter *TimeFormatter = [[NSDateFormatter alloc] init];
        TimeFormatter.dateFormat = @"dd-MM-yyyy";
        TimeFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        NSString*DatTi = [TimeFormatter stringFromDate:dt];
        NSLog(@"%@",DatTi);
        
 
        

        
        cell.txtDate.text = [NSString stringWithFormat:@"%@",DatTi];
        
        NSString*recording = [[previousData valueForKey:@"recording"] objectAtIndex:indexPath.row];
        
        if ([recording isEqual:[NSNumber numberWithInt:0]]){
            
             [cell.btnDownload setHidden:YES];
        }else
        {
             [cell.btnDownload setHidden:NO];
        }
        
        [cell.btnEdit setHidden:YES ];
        [cell.btnDelete setHidden:YES ];
        

        [cell.btnDownload addTarget:self action:@selector(DwonloadBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.btnDownload.tag = indexPath.row ;
        
        
          return  cell;
    }
    
   
    return 0 ;
    
}

-(void)DwonloadBtn:(id)sender{
    
    UIButton *downloadBtn = (UIButton*)sender ;
    
    NSLog(@"%ld",(long)downloadBtn.tag);
   pltId = [[previousData valueForKey:@"confPltFmId"] objectAtIndex:downloadBtn.tag];
    
    NSString *string =  [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/file/getconfrecording?confPltId=%@",pltId];

    
    NSURL *url = [NSURL URLWithString:string];
    
    NSData* myData = [NSData dataWithContentsOfURL:url];
    
    
    NSArray *aArray = [string componentsSeparatedByString:@"="];
    
    NSString *sub2  = [ aArray objectAtIndex:1];
    NSString *sub3 =    [NSString stringWithFormat:@"%@.zip",sub2];
    
    [myData writeToFile:[NSHomeDirectory() stringByAppendingPathComponent:sub3] atomically:YES];
    
    
    NSURL *url3 = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingString:sub3]];
    NSData *data = myData;
    [data writeToURL:url3 atomically:NO];
    UIActivityViewController *activityViewController = [[UIActivityViewController alloc] initWithActivityItems:@[url3] applicationActivities:nil];
     [self presentViewController:activityViewController animated:YES completion:nil];

    
}


-(void)editBtn:(id)sender{
    
    UIButton *editBtn = (UIButton*)sender ;
    
    NSLog(@"%ld",(long)editBtn.tag);
    
    
    [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"getScheduled"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    NSMutableArray *arrayEdit = [todayMeetingArray objectAtIndex:editBtn.tag];
    
    
    //[_delegate sendDataToA:arrayEdit];
    
 
    
    schduleVc * schVc = [[schduleVc alloc]init];
    schVc = [self.storyboard instantiateViewControllerWithIdentifier:@"schduleVc"];
    [self.delegate sendDataToA:arrayEdit];
    [self.navigationController popViewControllerAnimated:YES];

             

    
}

-(void)deleteBtn:(id)sender{
    
    deleteBtn = (UIButton*)sender ;
    
    NSLog(@"%ld",(long)deleteBtn.tag);
    
    cancelConfId = [[todayMeetingArray valueForKey:@"confId"]objectAtIndex:deleteBtn.tag];
    

 alertDeleteConf = [[UIAlertView alloc]initWithTitle:nil message:@"Are you sure to want to delete the conference" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    
    [alertDeleteConf show];
    
    
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (alertView == alertDeleteConf) {
        
        if (buttonIndex == 1) {
            
            [KVNProgress show];
          [self CancelConfernce];

        }
        
        
        
    }else if (alertView == ALERTMAP) {
        
     //   [self.navigationController popViewControllerAnimated:YES];
        
        
    }
    
    
}



-(void)GetConferenceDat{
    
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getConference?cmpId=%@&personId=%@",companyId,personId];
    
     manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        GetConfernceData = responseObject ;
        
        
        [self performSelectorOnMainThread:@selector(getConfernceDetails) withObject:nil waitUntilDone:YES];
        
        
        // [self GetConferenceDat];
        
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

}








-(void)getConfernceDetails{
    
    if ([[GetConfernceData valueForKey:@"message"] isEqualToString:@"success"]) {
        
        
       
        
        
        NSMutableArray *confernceDetails = [GetConfernceData valueForKey:@"confData" ];
        NSMutableArray *arr1 = [[NSMutableArray alloc]init];
        
        
        
        NSLog(@"%@",confernceDetails);
        
        for (NSDictionary *dic in confernceDetails) {
            
            [arr1 addObject:[dic valueForKey:@"confDateTime"]];
            
        }
        
        NSMutableArray *dataArray = [[NSMutableArray alloc]init];
        NSMutableArray *dateBeforeTWoMinutes = [[NSMutableArray alloc]init];
        enddataArray = [[NSMutableArray alloc]init];
        onlyDates = [[NSMutableArray alloc]init];
        
        
        for (int i =0 ; i < arr1.count; i++) {
            
            NSString *str = [NSString stringWithFormat:@"%@",arr1[i]];
            double miliSec = str.doubleValue;
            NSDate* takeOffDate = [NSDate dateWithTimeIntervalSince1970:miliSec/1000];
            NSLog(@"%@",takeOffDate);
            
            ///onlyDate
            NSDateFormatter *formattr = [[NSDateFormatter alloc] init];
            [formattr setDateFormat:@"yyyy-MM-dd"];
            formattr.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
            NSString * dateOnly = [formattr stringFromDate:takeOffDate];
            [onlyDates addObject:dateOnly];
            
            
            
            
            NSTimeInterval seconds = 5.51 * 60 *60;
            NSDate *Ofdate = [takeOffDate dateByAddingTimeInterval:seconds];
            NSDate*dateBeforeTwo = [Ofdate dateByAddingTimeInterval:-60*2];
           
            
            [dataArray addObject:Ofdate];
            [dateBeforeTWoMinutes addObject:dateBeforeTwo];
            
            
            NSString *duration = [NSString stringWithFormat:@"%@",[confernceDetails[i] valueForKey:@"duration"]];
            
            int dur = [duration intValue];
            
            NSTimeInterval secondsInEightHours = dur * 60 ;
            NSDate *endOffdate = [Ofdate dateByAddingTimeInterval:secondsInEightHours];
            
            
            
            [enddataArray addObject:endOffdate];
            
            
            NSString *str1 = [NSString stringWithFormat:@"%@",[confernceDetails[i] valueForKey:@"confDateTime"]];
            
            NSString *strrrr = [str1 stringByReplacingOccurrencesOfString:str1 withString:[NSString stringWithFormat:@"%@",dataArray[i]]];
            
            NSLog(@"%@",strrrr);
            
            
            
        }
        
        
        
       
        
        int count = 0 ;
        
        confernceDetailArray = [[NSMutableArray alloc]init];
        
        
        for(NSMutableDictionary *dic in confernceDetails){
            
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
            
            dict = [[NSMutableDictionary alloc]initWithDictionary:dic];

            count = count + 1 ;
            
            int i = count - 1 ;
            [dict setObject:dataArray[i] forKey:@"date"];
            [dict setObject:enddataArray[i] forKey:@"endOffDate"];
            [dict setObject:onlyDates[i] forKey:@"OnlyDate"];
            [dict setObject:dateBeforeTWoMinutes[i] forKey:@"twoMinutesBefore"];
            [confernceDetailArray addObject:dict];
            
        }
        
        NSLog(@"%@",confernceDetailArray);
        
        
        NSPredicate *Predicate = [NSPredicate predicateWithFormat: @"hostId ==%@",personId];
       // NSArray * AllConferences = [confernceDetailArray filteredArrayUsingPredicate:Predicate];
        NSMutableArray * AllConferences = [[NSMutableArray alloc]init];
        
        
        for (NSDictionary*dict in confernceDetailArray) {
            
            if ([[dict valueForKey:@"hostId"] isEqualToString:[NSString stringWithFormat:@"%@",personId]]) {
                
                [AllConferences addObject:dict];
                
                
            }
        }
        
        NSLog(@"%@",AllConferences);
        
        
        NSDate *dateDay = [NSDate date];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = @"MM-dd-yyyy HH:mm:ss";
        [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]];
        newDateString = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:dateDay]];
        NSLog(@"%@",newDateString);
        
        dateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        startToday = [dateFormatter dateFromString:newDateString];
        NSLog(@"%@",startToday);
        
        
        
        NSPredicate*predicate2 = [NSPredicate predicateWithFormat:@"(twoMinutesBefore > %@)",startToday];
        
        NSArray*arrr2 = [AllConferences filteredArrayUsingPredicate:predicate2];

        
        
        todayMeetingArray = [NSMutableArray arrayWithArray:arrr2];
        NSLog(@"%@",todayMeetingArray);
        
        if (todayMeetingArray.count>0) {
            [self.meetingTableView reloadData];
            [self.meetingTableView setHidden:NO];
            
        }else{
             if (pageNo==1) {
                 
             }else{
            
            
            ALERTMAP= [[UIAlertView alloc]initWithTitle:nil message:@"No meetings" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            
            [ALERTMAP show];
                 
             }
            
            
            [self.meetingTableView setHidden:YES];
            
        }
        
        
    }
    
    
    
    
}


- (IBAction)backBTn:(id)sender

{
    [self.navigationController popViewControllerAnimated:YES];
    
}




-(void)CancelConfernce{
   // http://182.76.44.135:8080/demogomobile/conference/getconfbydate?cmpId=1000&date=1503599400000
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/cancelconference?confId=%@",cancelConfId];
    
    AFHTTPSessionManager * managerr = [AFHTTPSessionManager manager];
    managerr.requestSerializer = [AFJSONRequestSerializer serializer];
    [managerr.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [managerr GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        cancelConference = responseObject ;
        [self performSelectorOnMainThread:@selector(cancelledConferenceData) withObject:nil waitUntilDone:YES];
        
        
      
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
    
}

-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}

-(void)cancelledConferenceData{
    
    
    if ([[cancelConference valueForKey:@"message"] isEqualToString:@"success"]) {
//        HomeVC *home = [[HomeVC alloc]init];
//        home = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
//        [self.navigationController pushViewController:home animated:YES];
        
        [self.navigationController popViewControllerAnimated:YES];
        

    }else{
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
    }

}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    
    pageNo = round(_scrollView.contentOffset.x / self.scrollView.frame.size.width);
    NSLog(@"Page number is %i", pageNo);
    
    if (pageNo==1) {
        
        
        _xSlide.constant = self.btnUpcoming.frame.size.width;
        
        NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:[NSDate date]];
        
        NSInteger day = [components day];
        NSInteger month = [components month];
        NSInteger year = [components year];
        
        NSString *string = [NSString stringWithFormat:@"%ld-%ld-%ld", (long)day, (long)month, (long)year];
        
        self.txtDate.text = string ;
     
    }else{
        
        _xSlide.constant = 0;
    }
    
    [self.view layoutIfNeeded];
    
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
     if (pageNo==1) {
         
            [self GetHistoryConfernces];
         
     }
    
}

- (IBAction)upcomingClicked:(id)sender {
      [_scrollView setContentOffset:CGPointMake(0, 0)animated:YES];
}

- (IBAction)historyClicked:(id)sender {
    [_scrollView setContentOffset:CGPointMake(_scrollView.frame.size.width, 0)animated:YES];
    NSLog(@"%f",_scrollView.frame.origin.x);
    
//    if (pageNo==1) {
    
        [self GetHistoryConfernces];
        
//    }
    
    

}



-(void)GetHistoryConfernces{

    
    NSString *selectedDate = _txtDate.text ;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd-MM-yyyy"];
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString = [dateFormatter dateFromString:selectedDate];
    NSTimeInterval timeInMiliseconds = [dateFromString timeIntervalSince1970]*1000;
    long dateValue = timeInMiliseconds ;
   
    
  NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/getconfbydate?cmpId=%@&date=%ld",companyId,dateValue];
    //NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/getconfbydate?cmpId=1000&date=1503599400000"];

    
    AFHTTPSessionManager * managerr = [AFHTTPSessionManager manager];
    managerr.requestSerializer = [AFJSONRequestSerializer serializer];
   // [managerr.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [managerr GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        historyMeetings = responseObject ;
        [self performSelectorOnMainThread:@selector(previousConferenceDetails) withObject:nil waitUntilDone:YES];
        
        
        
    }
          failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    
}

-(void)previousConferenceDetails{
    
    NSString *response = [NSString stringWithFormat:@"%@",[historyMeetings  valueForKey:@"responseCode"]];
    
    
    if ([[historyMeetings valueForKey:@"responseCode"] isEqual:[NSNumber numberWithInteger:400]]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:[historyMeetings valueForKey:@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
    }else{
        
        
        
        previousData = [historyMeetings valueForKey:@"confData"];
        
        
    //pltId =   [NSString stringWithFormat:@"%@",[historyMeetings valueForKey:@"confPltFmId"]];
        
        
        
        NSLog(@"%@",previousData);
        
        [self.historyTableView reloadData];
        
    }
    
    
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField;
{
    
    
    if (textField == self.txtDate)
        
    {
        
        
      
        
        [self selectDate];
        
        
    }
    
    return NO ;
    
    
    
}
    - (BOOL)textFieldShouldReturn:(UITextField *)textField{
        
        [textField resignFirstResponder];
        
        return YES;
        
    }

    
    
-(void)selectDate
{
        
        [UIView animateWithDuration:0.5 animations:^{
            
            self.ConstantPickerDate.constant = 0;
            

            
        }];
    
}


-(void)ShowSelectedDate
{
    
    
        NSDateFormatter *formatter=[[NSDateFormatter alloc]init];

        [formatter setDateFormat:@"dd-MM-yyyy"];
        
        NSString *str=[NSString stringWithFormat:@"%@",[formatter stringFromDate:_datePicker.date]];
    
        self.txtDate.text=str;
    
    [self  GetHistoryConfernces];
    
    
}

- (IBAction)doneClicked:(id)sender
{
    [UIView animateWithDuration:0.5 animations:^{
        
        self.ConstantPickerDate.constant = -218;
        
        [self.view layoutIfNeeded];
        
        [self ShowSelectedDate];
    }];
}

- (void)addAssetURL:(NSURL*)assetURL toAlbum:(NSString*)albumName
    {
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
        
        [library enumerateGroupsWithTypes:ALAssetsGroupAlbum usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
            if ([albumName compare: [group valueForProperty:ALAssetsGroupPropertyName]]==NSOrderedSame) {
                //If album found
                [library assetForURL:assetURL resultBlock:^(ALAsset *asset) {
                    //add asset to album
                    [group addAsset:asset];
                } failureBlock:nil];
            }
            else {
                //if album not found create an album
                [library addAssetsGroupAlbumWithName:albumName resultBlock:^(ALAssetsGroup *group)     {
                    [self addAssetURL:assetURL toAlbum:albumName];
                } failureBlock:nil];
            }
        } failureBlock: nil];
    }
    
@end
