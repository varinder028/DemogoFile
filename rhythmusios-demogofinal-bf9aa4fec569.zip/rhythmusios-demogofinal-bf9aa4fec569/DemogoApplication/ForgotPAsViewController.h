//
//  ForgotPAsViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 07/03/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"


@interface ForgotPAsViewController : UIViewController<DropDownViewDelegate,UIAlertViewDelegate>{
    
     DropDownView *dropDownView;
    NSMutableArray *dataArray ;
    NSDictionary *itemsDR;
    NSString *strMessage ;
    UIAlertView *alert;
}
@property (strong, nonatomic) IBOutlet UITableView *tableview;
@property (strong, nonatomic) IBOutlet UIView *viewList;
@property (strong, nonatomic) IBOutlet UIImageView *companyImage;
@property (strong, nonatomic) IBOutlet UIVisualEffectView *blurview;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *heightForgetLayout;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *imgHeightLayout;
@property (strong, nonatomic) IBOutlet UITextField *txtComanyName;
- (IBAction)backClicked:(id)sender;

@end
