//
//  ViewController.h
//  UserSavedDetails
//
//  Created by Rhythmus on 27/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIImageView+WebCache.h"

@interface UpdateAccountViewController : UIViewController<UIImagePickerControllerDelegate,UITextFieldDelegate,UIAlertViewDelegate>{
    
    NSString *personId ;
    UIImage*chosenImage;
    id profileData ;
    NSArray *listCompanies ;
    NSString * Tokenid;
    UIAlertView *alertSave ;
    UIAlertView *alertImage;
    id  savedData ;
    NSString *filename;
}
@property (strong, nonatomic) IBOutlet UIButton *btnCancel;
@property (strong, nonatomic) IBOutlet UIButton *btnSave;
@property (strong, nonatomic) IBOutlet UIAlertController *AlertCtrl;

@property (strong, nonatomic) IBOutlet UITextField *txtName;
@property (strong, nonatomic) IBOutlet UITextField *txtLastName;
@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtPhone;
@property (strong, nonatomic) IBOutlet UITextField *txtLocation;
@property (strong, nonatomic) IBOutlet UITextField *txtAdmin;
@property (strong, nonatomic) IBOutlet UIButton *btnCancell;
- (IBAction)cancelClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIImageView *imgProfile;

@property (strong, nonatomic) NSArray *detailsArray ;


- (IBAction)saveClickedd:(id)sender;

- (IBAction)uploadClicked:(id)sender;

- (IBAction)backClicked:(id)sender;

@end

