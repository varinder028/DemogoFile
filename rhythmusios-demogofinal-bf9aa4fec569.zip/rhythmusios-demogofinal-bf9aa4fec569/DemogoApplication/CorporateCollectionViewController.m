//
//  CorporateCollectionViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/30/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "CorporateCollectionViewController.h"

#import "corporateCellCollectionViewCell.h"
@interface CorporateCollectionViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>
{
    NSMutableArray * array ;
    NSMutableArray * Pics ;
    CAGradientLayer *gradient;
}















@end

@implementation CorporateCollectionViewController

//static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
        ///////////////////     Create Name OF collection Row in MutableArray    ///////////////
    
    
   array = [[NSMutableArray alloc]initWithObjects:@"participants",@"Self Mute",@"Participant mute",@"Recording",@"Add on",@"Q & A",@"Lecture Mode",@"Lock Conference",@"Quiz",@"Help",@"End Call", nil];
    
    
    
    //////////////////////       Add Image in Colletion cell .NSArray             //////////////
   

   // Pics = [[NSMutableArray alloc]initWithObjects:@"mobile.png",@"otp_button.png",@"newlogo.png",@"username.png",@"password.png",@"house-7.png",@"menu",@"calendar.png",@"Lock,png",@"circleCheck1.png",@"Lock.png", nil];
   
    
    

    
    
    
  }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return [array count];
}

- (corporateCellCollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *IdentifierID = @"cell";
    
    corporateCellCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:IdentifierID forIndexPath:indexPath];
    
    if (cell==nil)
    {
        cell = [[corporateCellCollectionViewCell alloc]init];
        
    }
    
    
              ////////////////// imageViewData create properties in CorporateCell     //////////
    
    cell.imageViewData.backgroundColor = [UIColor blueColor];//image=[UIImage imageNamed: [Pics objectAtIndex:indexPath.row]];
    cell.imageViewData.layer.cornerRadius = 30;
    
    cell.ViewImageBAck.layer.cornerRadius = 35;
       ////////////////// TextData create properties in CorporateCell     //////////
    
    
    cell.TExtData.text = [array objectAtIndex:indexPath.row];
    
   // cell.layer.cornerRadius =55.5f;
  
   // cell.backgroundColor= [UIColor grayColor];
    // Configure the cellgradient   = [CAGradientLayer layer];

    
    return cell;
}



@end
