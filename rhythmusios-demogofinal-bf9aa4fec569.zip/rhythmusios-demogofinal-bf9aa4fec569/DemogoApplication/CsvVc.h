//
//  CsvVc.h
//  DemogoApplication
//
//  Created by katoch on 15/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CsvVc : UIViewController{
    
    NSArray*documentArray;
    NSMutableArray*csvFileArray ;
    NSMutableArray*arrayCsv;
    NSInteger selectedIndex ;
    NSIndexPath* checkedIndexPath;
    
    
    
}
@property (nonatomic, retain) NSIndexPath* checkedIndexPath;
@property(strong,nonatomic)NSMutableArray*checkArray;

@property (strong, nonatomic) IBOutlet UITableView *csvTableView;
- (IBAction)btnBack:(id)sender;
- (IBAction)doneClicked:(id)sender;


@end
