//
//  cellActionViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 31/03/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ViewController.h"

@interface cellActionViewController : ViewController


@property (strong, nonatomic) NSString *CountryName;
@property (strong, nonatomic) NSString *roleNAmedata;
@property (strong, nonatomic) NSString *Accountname;
@property (strong, nonatomic) NSString *MobileNUmberString;


@property (strong, nonatomic) IBOutlet UILabel *txtName;

@property (strong, nonatomic) IBOutlet UIScrollView *ScrollView2;
@property (strong, nonatomic) IBOutlet UIVisualEffectView *BlurView2;
@property (strong, nonatomic) IBOutlet UITextField *FirstNAmeSaveTextField;

@property (strong, nonatomic) IBOutlet UITextField *LAstNAmeSaveTextField;
@property (strong, nonatomic) IBOutlet UITextField *EmsilSaveTextField;
@property (strong, nonatomic) IBOutlet UITextField *LocationSaveTextField;
@property (strong, nonatomic) IBOutlet UILabel *MobileSaveTExtField;
@property (strong, nonatomic) IBOutlet UILabel *DepartmentSaveTEXtField;
@property (strong, nonatomic) IBOutlet UILabel *ADminSaveTExtField;








- (IBAction)UPloadPictureButton:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIImageView *UploadImageVIew;
- (IBAction)backClicked:(id)sender;

@end
