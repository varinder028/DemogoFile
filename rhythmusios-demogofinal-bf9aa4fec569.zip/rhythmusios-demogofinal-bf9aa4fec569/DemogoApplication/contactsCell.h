//
//  contactsCell.h
//  DemogoApplication
//
//  Created by Rhythmus on 23/06/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>



@class APContact;

@interface contactsCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *txtContactName;
@property (strong, nonatomic) IBOutlet UILabel *textContactNo;
@property (strong, nonatomic) IBOutlet UIButton *btnCheckContact;
@property (strong, nonatomic) IBOutlet UIImageView *imgContacts;

- (void)updateWithContact:(APContact *)contact;

@end
