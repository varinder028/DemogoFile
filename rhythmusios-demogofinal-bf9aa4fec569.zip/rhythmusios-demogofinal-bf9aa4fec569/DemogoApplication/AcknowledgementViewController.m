//
//  AcknowledgementViewController.m
//  nbng
//
//  Created by Rhythmus on 28/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "AcknowledgementViewController.h"

#import "AcknowledgmentCell.h"
#import "KVNProgress.h"
#import <AFNetworking/AFNetworking.h>

@interface AcknowledgementViewController ()<UITableViewDataSource,UITableViewDelegate>

{
    NSMutableArray * nameid;
    
    NSMutableArray * company;
    
    NSMutableArray * mobileNo;
    
    NSMutableArray * Response;
    
    NSString *btntitle;
}

@end

@implementation AcknowledgementViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    companyArray = [[NSMutableArray alloc]init];
     NameArray = [[NSMutableArray alloc]init];
    ResponseArray = [[NSMutableArray alloc]init];
    
    totalContacts = [[NSMutableArray alloc]init];

    
    _ViewInvite.layer.cornerRadius = 5.0f ;
    [_ViewInvite clipsToBounds];
    
    
    _viewAccepted.layer.cornerRadius = 5.0f ;
    [_viewAccepted clipsToBounds];
    
    
    _viewRejected.layer.cornerRadius = 5.0f ;
    [_viewRejected clipsToBounds];
    
    _viewPending.layer.cornerRadius = 5.0f ;
    [_viewPending clipsToBounds];
    
    self.acknowledgeTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.acknowledgeTableView.backgroundColor =[UIColor clearColor];
    
    
     personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    ConfId = [[NSUserDefaults standardUserDefaults]valueForKey:@"ConfId"];
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    NSLog(@"%@",Tokenid);

    
    self.ViewInvite.layer.cornerRadius = 5.5f;
    
    self.ViewInvite.layer.masksToBounds = YES;
    
    
    self.viewAccepted.layer.cornerRadius = 5.5;
    self.viewAccepted.layer.masksToBounds = YES;
    
    self.viewRejected.layer.cornerRadius = 5.5;
    self.viewRejected.layer.masksToBounds = YES;
    
    self.viewPending.layer.cornerRadius = 5.5;
    self.viewPending.layer.masksToBounds = YES;
    
    [self GetConfDetails];
    
    
    
    
   // nameid = [[NSMutableArray alloc]initWithObjects:@"NA","NA", nil];
    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [KVNProgress show];
    [self GetApiAcceptReject];
    
    
    
}




-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    
   // return [[acceptRejectData valueForKey:@"noresponsedemp"] count];
    return totalContacts.count ;
    
}

-(AcknowledgmentCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *cellID = @"cell";
    
    AcknowledgmentCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AcknowledgmentCell"];
    
    if (cell == nil)
    
    {
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone ;
        
        
        NSArray *cellarray = [[NSBundle mainBundle]loadNibNamed:@"AcknowledgmentCell" owner:self options:nil];
        
        cell = cellarray[0];
        
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone ;
    
   NSString*namee  = [name objectAtIndex:indexPath.row];
     cell.txtName.text = namee ;
    

    
   
    NSString*Companystr  = [cmpNm objectAtIndex:indexPath.row];
    cell.txtCompany.text = Companystr ;
    
     cell.txtMobile.text = [totalContacts objectAtIndex:indexPath.row];
    
    NSString*strStatus = [perSts objectAtIndex:indexPath.row];
   
    

    
    
    
    cell.lblStatus.textColor = [UIColor whiteColor];

    cell.lblStatus.layer.cornerRadius= 5.0f;
    [cell.lblStatus clipsToBounds];
    cell.lblStatus.layer.masksToBounds = YES;

    
    
    if ([strStatus isEqualToString:@"no response"]) {
        cell.lblStatus.text = @"Pending" ;
        cell.lblStatus.backgroundColor = [UIColor colorWithRed:52/255.0f green:175/255.0f blue:193/255.0f alpha:1];

        
    }else if ([strStatus isEqualToString:@"maybe"]){
        cell.lblStatus.text = @"maybe" ;
        cell.lblStatus.backgroundColor = [UIColor colorWithRed:255/255.0f green:109/255.0f blue:57/255.0f alpha:1];
    }
    

    else{
        
        cell.lblStatus.text = strStatus ;
        cell.lblStatus.backgroundColor = [UIColor colorWithRed:8/255.0f green:138/255.0f blue:8/255.0f alpha:1];
        
        
    }
    
    
    
    cell.btnAccpeted.layer.cornerRadius = 5.5;
//

    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row) {
        NSLog(@"sucess");
    }
}



- (IBAction)bckBtn:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}


-(void)GetApiAcceptReject{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/acceptreject?confId=%@",ConfId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        acceptRejectData = responseObject ;
        
        [self performSelectorOnMainThread:@selector(getAllData) withObject:nil waitUntilDone:YES];
        
          [self.acknowledgeTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    
    }
         failure:^(NSURLSessionTask *operation, NSError *error)
    {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        NSLog(@"Error: %@", error);
        
    }];

    

    
}


-(void)getAllData{
    
        NSArray*mayBeComp = [[NSMutableArray alloc]initWithArray:[[acceptRejectData  valueForKey:@"maybeemp"]valueForKey:@"cmpNm"]];
    NSArray*mayBename = [[NSMutableArray alloc]initWithArray:[[acceptRejectData  valueForKey:@"maybeemp"]valueForKey:@"name"]];
    NSArray*mayBemobile = [[NSMutableArray alloc]initWithArray:[[acceptRejectData  valueForKey:@"maybeemp"]valueForKey:@"mobile"]];
     NSArray*mayBeResponse = [[NSMutableArray alloc]initWithArray:[[acceptRejectData  valueForKey:@"maybeemp"]valueForKey:@"perSts"]];

    
    
    NSArray*arrMobile = [[NSMutableArray alloc]initWithArray:[[acceptRejectData  valueForKey:@"noresponsedemp"]valueForKey:@"mobile"]];
     NSArray*arrMobile2 = [[NSMutableArray alloc]initWithArray:[acceptRejectData  valueForKey:@"openparticipant"]];
    NSArray*arrMobile3 = [[NSMutableArray alloc]initWithArray:[acceptRejectData  valueForKey:@"fileparticipant"]];
    
    NSMutableArray*arrBulk = [NSMutableArray new];
    
    
    
    
    NSCharacterSet* notDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    for (NSString *str in arrMobile3) {
        
        //  NSString*strrr = [str stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        
        NSString* strrr = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        [arrBulk addObject:strrr];
        
        
    }

    NSMutableArray*arrUpload = [NSMutableArray new];
    for (NSString *strr in arrBulk) {
        
        if ([strr rangeOfCharacterFromSet:notDigits].location == NSNotFound)
        {
            if (strr.length == 10) {
                [arrUpload addObject:strr];
            }
            
            
            // newString consists only of the digits 0 through 9
        }
        else{
            
            
            
        }
        
        
    }

    
    
    
    
    [totalContacts addObjectsFromArray:arrMobile];
    
    [totalContacts addObjectsFromArray:arrMobile2];
      [totalContacts addObjectsFromArray:arrUpload];
    
    
    
 companyArray =   [[acceptRejectData  valueForKey:@"noresponsedemp"]valueForKey:@"cmpNm"];
 ResponseArray =   [[acceptRejectData  valueForKey:@"noresponsedemp"]valueForKey:@"perSts"];
 NameArray =   [[acceptRejectData  valueForKey:@"noresponsedemp"]valueForKey:@"name"];

    
    
    
 
    NSArray*arr = acceptRejectData[@"noresponsedemp"];
    
    
   
    
   cmpNm = [[NSMutableArray alloc]init];
 perSts = [[NSMutableArray alloc]init];
    name = [[NSMutableArray alloc]init];
    
    
    
   
    
    for (int i = 0; i< [totalContacts count]; i++) {
        
        if ([arr count] > i && [arr objectAtIndex:i] !=nil){
//        if ([[arr objectAtIndex:i] containsObject:@"cmpNm"]) {
            
            [cmpNm addObject:[[[acceptRejectData  valueForKey:@"noresponsedemp"]valueForKey:@"cmpNm"]objectAtIndex:i]];
            
            
             
        }else{
            
            [cmpNm addObject:@"N/A"];
            
        }
        
        NSLog(@"%@",cmpNm);

         if ([arr count] > i && [arr objectAtIndex:i] !=nil) {
            
            [perSts addObject:[[[acceptRejectData  valueForKey:@"noresponsedemp"]valueForKey:@"perSts"]objectAtIndex:i]];
            
            
        }else{
            
            [perSts addObject:@"Accepted"];
            
        }
        
        
        
        
         if ([arr count] > i && [arr objectAtIndex:i] !=nil) {
            
            [name addObject:[[[acceptRejectData  valueForKey:@"noresponsedemp"]valueForKey:@"name"]objectAtIndex:i]];
            
            
        }else{
            
            [name addObject:@"N/A"];
            
        }
        
        
        
    }
    NSLog(@"%@",name);
    
    [cmpNm addObjectsFromArray:mayBeComp];
    [perSts addObjectsFromArray:mayBeResponse];
    [name addObjectsFromArray:mayBename];
    
    [totalContacts addObjectsFromArray:mayBemobile];
    
    
    
    
        NSArray *acceptedemp  = [acceptRejectData valueForKey:@"acceptedemp"];
        NSArray *fileparticipant  = [acceptRejectData valueForKey:@"fileparticipant"];
        int accpeted1;
        int accpeted ;
        int accpeted2 ;
        if (acceptedemp.count > 0) {
            accpeted1  = (int)acceptedemp.count ;
        }else{
            accpeted1 = 0;
    
        }
    
        if (fileparticipant.count > 0) {
            accpeted2  = (int)fileparticipant.count ;
        }else{
            accpeted2 = 0;
    
        }
    
    
        NSArray *acceptedData  = [acceptRejectData valueForKey:@"openparticipant"];
    
    
        if (acceptedData.count>0) {
            accpeted  = (int)acceptedData.count ;
    
    
        }
    
        else{
            accpeted = 0;
    
    
        }
    
    
        int totalAccepted  = accpeted + accpeted1 +  accpeted2;
       NSString*accepted  =  [NSString stringWithFormat:@"%d",accpeted + accpeted1 +  accpeted2] ;
    _txtAccpetedValue.text = [NSString stringWithFormat:@"%@",accepted];
    
    
    //_txtAccpetedValue.text
    
        NSArray *rejectedData  = [acceptRejectData valueForKey:@"rejectedemp"];
        if (rejectedData.count>0) {
            int rejected  = (int)rejectedData.count ;
          NSString*strRejected   =  [NSString stringWithFormat:@"%lu",(unsigned long)rejectedData.count];
            _txtRejectedValue.text = [NSString stringWithFormat:@"%@",strRejected];

        }
        else{
            _txtRejectedValue.text = @"0";
        }
    
    
     NSString*totalInvite   = [NSString stringWithFormat:@"%@",[acceptRejectData valueForKey:@"totalinvitee"]];
    int valueTotal =  [totalInvite intValue];
    valueTotal  = valueTotal - 1  ;
    
    
    
    self.txtInviteValue.text =  [NSString stringWithFormat:@"%d",valueTotal];
  //
        NSMutableArray*arrNoResponse = [[NSMutableArray alloc]init];
    
    
        for (NSString*str  in perSts ) {
    
    
            if ( [str isEqualToString:@"no response"]) {
    
                [arrNoResponse addObject:str];
                
                
            }
                   
        }
        
        NSLog(@"%@",arrNoResponse);
        
        
        
        int i = (int)arrNoResponse.count ;
        NSString*pendingValue = [NSString stringWithFormat:@"%lu",(unsigned long)arrNoResponse.count];

     self.txtPendingVlaue.text = [NSString stringWithFormat:@"%@",pendingValue];
   
         //   self.txtPendingVlaue.text
    
}



-(void)GetConfDetails{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/conference/secure/getConferenceDetails?confId=%@",ConfId];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        
        
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        
        getConfDetail = responseObject ;
        
        
       NSLog(@"%@",getConfDetail);
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];


    
}



-(void)kvnDismiss{
    
    [KVNProgress dismiss ];
    
}

-(void)acknowlgData{
    
    NSString *accepted = [NSString stringWithFormat:@"%@",[acceptRejectData valueForKey:@"acceptedemp"]];
     NSString *Invite = [NSString stringWithFormat:@"%@",[acceptRejectData valueForKey:@"totalinvitee"]];
    
     NSString *rejected = [NSString stringWithFormat:@"%@",[acceptRejectData valueForKey:@"rejectedemp"]];
    
    
    NSString*str = @"no response";
    
    NSPredicate*predicate = [NSPredicate predicateWithFormat:@"perSts ==%@",str];
    
  NSArray*noResponseArray = [[acceptRejectData valueForKey:@"noresponsedemp"] filteredArrayUsingPredicate:predicate];
    
    
    
    NSArray*InviteArray = [acceptRejectData valueForKey:@"totalinvitee"];
                           
    NSArray*acceptedArray = [acceptRejectData valueForKey:@"acceptedemp"];
    
     NSArray*rejectArray = [[acceptRejectData valueForKey:@"rejectedemp"] filteredArrayUsingPredicate:predicate];
    
    
    
    if ([accepted isEqualToString:@""]) {
        accepted = @"0";
        
    }
    if ([Invite isEqualToString:@""]) {
        Invite = @"0";
        
    }
    
    
    if ([rejected isEqualToString:@""]) {
        rejected = @"0";
        
    }
    
    
    
    int i = (int)noResponseArray.count ;
   int  accept = (int)acceptedArray.count ;
   
   
    
     int reject = (int)rejectArray.count ;
    
    
    self.txtInviteValue.text = Invite ;
    
    self.txtAccpetedValue.text = [NSString stringWithFormat:@"%d",accept];
    
    self.txtPendingVlaue.text = [NSString stringWithFormat:@"%d",i];
    
    self.txtRejectedValue.text = [NSString stringWithFormat:@"%d",reject];
    
}

@end
