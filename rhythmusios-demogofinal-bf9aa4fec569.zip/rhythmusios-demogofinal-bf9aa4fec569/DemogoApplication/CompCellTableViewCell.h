//
//  CompCellTableViewCell.h
//  DemogoApplication
//
//  Created by Rhythmus on 03/02/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompCellTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *LAbelName;
@property (strong, nonatomic) IBOutlet UIImageView *ProfileImage;



//////// . . . . . . .  ACCOUNT DETAILS CELL

@property (strong, nonatomic) IBOutlet UILabel *CompanyNameLAbel;
@property (strong, nonatomic) IBOutlet UILabel *RoleLabel;

@property (strong, nonatomic) IBOutlet UILabel *ACcountTypeLabel;


////////..  . . . . . . . . . .. 

@property (strong, nonatomic) IBOutlet UIButton *udateButton;
@property (strong, nonatomic) IBOutlet UILabel *CompanyNAme;
@property (strong, nonatomic) IBOutlet UILabel *RoleNAme;
@property (strong, nonatomic) IBOutlet UILabel *AccountName;
@property (strong, nonatomic) IBOutlet UITextView *CmpTextView;





////////.....>>>>>>>> EMployeeManagement Cell Data


@property (strong, nonatomic) IBOutlet UIButton *CheckCellButtonOutlet;
@property (strong, nonatomic) IBOutlet UILabel *MobileNAmeCell;
@property (strong, nonatomic) IBOutlet UILabel *NameCell;
@property (strong, nonatomic) IBOutlet UILabel *RoleCell;


/////......>>>>>>> ADD User Details

@property (strong, nonatomic) IBOutlet UITextField *firstName;
@property (strong, nonatomic) IBOutlet UITextField *lastNAme;
@property (strong, nonatomic) IBOutlet UITextField *MobileNo;
@property (strong, nonatomic) IBOutlet UITextField *Email;
@property (strong, nonatomic) IBOutlet UITextField *EMployeeId;





- (IBAction)Rolebutton:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIButton *RoleOutlet;


@property (strong, nonatomic) IBOutlet UIButton *SelectDepartmentOutlet;
- (IBAction)SelectDepartmentButton:(id)sender;

- (IBAction)Addbutton:(id)sender;

//////..........     EMployeemanageent ADD ACCOunt Cell Data

@property (strong, nonatomic) IBOutlet UILabel *CmpLISTREQ;

////////   Employee Management Add Grrup Cell

@property (strong, nonatomic) IBOutlet UIButton *GroupCheckBoxCell;

@property (strong, nonatomic) IBOutlet UILabel *GroupLabelNAme;
@property (strong, nonatomic) IBOutlet UILabel *GroupMembersLAbelName;
@property (strong, nonatomic) IBOutlet UILabel *GroupCnterDatelabel;



@end
