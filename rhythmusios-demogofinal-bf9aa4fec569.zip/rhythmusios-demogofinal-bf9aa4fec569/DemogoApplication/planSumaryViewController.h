//
//  planSumaryViewController.h
//  excelSheetUpload
//
//  Created by Rhythmus on 29/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"
#import "PieChart.h"


@interface planSumaryViewController : UIViewController<UIGestureRecognizerDelegate>
{
    NSMutableArray *SelctDpOrHostArray;
    NSMutableArray *selectYearArray;
    NSMutableArray *SelctMonthArray;
    DropDownView *dropDownView;
    NSMutableArray *dropDownListArray;
    NSMutableArray*monthsCount ;
    NSMutableArray* dataarray ;
    NSArray*allValuedata;
    NSArray*allKeydata;
    NSMutableDictionary *cities;
    NSString *keys;
    PieChart *chart ;
    NSString *CompanyId;
   
}
@property (strong, nonatomic) IBOutlet UITextField *txtselectDepartmentOrHost;
@property (strong, nonatomic) IBOutlet UITextField *txtYears;
@property (strong, nonatomic) IBOutlet UITextField *txtMonth;
@property (strong, nonatomic) UITextField *dropDownTxtfield;
@property (strong, nonatomic) IBOutlet UILabel *lablSelectValue;




- (IBAction)btnBAck:(id)sender;


@property (strong, nonatomic) IBOutlet UIView *graphViews;


@end


