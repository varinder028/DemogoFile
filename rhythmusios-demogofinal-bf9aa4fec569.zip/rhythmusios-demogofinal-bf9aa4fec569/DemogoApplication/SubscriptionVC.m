//
//  SubscriptionVC.m
//  DemogoApplication
//
//  Created by katoch on 22/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "SubscriptionVC.h"
#import "SubscriptionCell.h"
#import "smartMinutesCell.h"
#import "AppDelegate.h"
#import "CCWebViewController.h"
#import "KVNProgress.h"
#import <AFNetworking/AFNetworking.h>
#import "MenuVc.h"



@interface SubscriptionVC ()

@end

@implementation SubscriptionVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    

    _prepaidView.layer.cornerRadius = 5.0f ;
    [_prepaidView clipsToBounds];
    
    
    _btnBuyNow.layer.cornerRadius= 5.0f ;
   [_btnBuyNow clipsToBounds];
    
    
    _btnPostpaidProceed.layer.cornerRadius= 5.0f ;
    
    [_btnPostpaidProceed clipsToBounds];
    
    
    _btnCancelPostpaid.layer.cornerRadius= 5.0f ;
    
    [_btnCancelPostpaid clipsToBounds];
    
    
    _btnPrepaid.layer.cornerRadius= 5.0f ;
    
    [_btnPrepaid clipsToBounds];
    
    
    _btnPostpaid.layer.cornerRadius= 5.0f ;
    
    [_btnPostpaid clipsToBounds];
    
    
    
    _btnSmartMinutes.layer.cornerRadius= 5.0f ;
    
    [_btnSmartMinutes clipsToBounds];
    
    
    _btnPay.layer.cornerRadius= 5.0f ;
    
    [_btnPay clipsToBounds];
    
//    CAGradientLayer *postpaid = [CAGradientLayer layer];
//    postpaid.frame = _viewPostPaidProceed.bounds;
//    postpaid.startPoint = CGPointZero;
//    postpaid.endPoint = CGPointMake(1, 1);
//    postpaid.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:34.0/255.0 green:111/255.0 blue:144/255.0 alpha:1.0] CGColor],(id)[[UIColor colorWithRed:145/255.0 green:72.0/255.0 blue:203/255.0 alpha:6.0] CGColor], nil];
//    [_viewPostPaidProceed.layer addSublayer:postpaid];

    

    
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    _viewPay.hidden = YES;
    
    _scrollView.contentInset = UIEdgeInsetsZero ;
    
//    CompanyId"
//    personId
    
    self.viewPlanDetail.backgroundColor = [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:0.6];
    
    
      self.viewPlanDetail.hidden = YES;
    
    CompanyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    
    
    
    dataSubscription = [NSMutableArray new];
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:YES];
    
    smartMinutesArray = [[NSMutableArray alloc]init];
    
    
    
    _subscriptionTableView.backgroundColor = [UIColor clearColor];
    _subscriptionTableView.separatorStyle = UITableViewCellSeparatorStyleNone ;
    
   
    [_btnPrepaid setBackgroundColor:[UIColor colorWithRed:32/255.0f green:176/255.0f blue:191/255.0f alpha:1]];
    
    [_btnPostpaid setBackgroundColor: [UIColor clearColor]];
    [_btnSmartMinutes setBackgroundColor: [UIColor clearColor]];
    
    
    _subscriptionSelectionView.layer.borderColor = [UIColor colorWithRed:32/255.0f green:176/255.0f blue:191/255.0f alpha:1].CGColor;
    
    _subscriptionSelectionView.layer.borderWidth = 1.5f ;
     _subscriptionSelectionView.layer.cornerRadius = 5.0f ;
    [_subscriptionSelectionView clipsToBounds];

    
    
    dataDict = [[NSMutableDictionary alloc]init];
    
    NSMutableArray *Fcvarr = [[NSMutableArray alloc]initWithObjects:@"13",@"123",@"121", nil];
     NSMutableArray *Mrvarr = [[NSMutableArray alloc]initWithObjects:@"2500",@"3000",@"4000", nil];
     NSMutableArray *International = [[NSMutableArray alloc]initWithObjects:@"1",@"1",@"1", nil];
    NSMutableArray *Ind = [[NSMutableArray alloc]initWithObjects:@"10",@"10",@"10", nil];

    
    
        
        [dataDict setValue:Fcvarr forKey:@"FCV"];
        [dataDict setValue:Ind forKey:@"IND"];
        [dataDict setValue:International forKey:@"International"];
        [dataDict setValue:Mrvarr forKey:@"MRV"];

        
        
    
        [KVNProgress show];
    
    [self EmployeeManagementPrepaid];

    
    // Do any additional setup after loading the view.
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
   
    
}

-(void)viewDidLayoutSubviews{
    
    [super viewDidLayoutSubviews];
    
    [_btnPrepaid setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_btnPostpaid setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_btnSmartMinutes setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    CAGradientLayer *gradient = [CAGradientLayer layer];
//    gradient.frame = _prepaidView.bounds;
//    gradient.startPoint = CGPointZero;
//    gradient.endPoint = CGPointMake(1, 1);
//    gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:34.0/255.0 green:111/255.0 blue:144/255.0 alpha:1.0] CGColor],(id)[[UIColor colorWithRed:145/255.0 green:72.0/255.0 blue:203/255.0 alpha:6.0] CGColor], nil];
//    [_prepaidView.layer addSublayer:gradient];
//    [_prepaidView bringSubviewToFront:_txtId];
//    [_prepaidView bringSubviewToFront:_txtName];
    

    
     [self varifiyingPlans];
    
    
    
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView


{
    if (tableView == _subscriptionTableView) {
        
        if ([checkPlan isEqualToString:@"SmartMinutes"]) {
            return 1 ;
        }
        else{
            
            return  [dataSubscription count];
            
                
            }

        
    }
    else{
        
        return 1 ;
    }
    
        
    }


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if (tableView == self.subscriptionTableView){
        
        if ([checkPlan isEqualToString:@"SmartMinutes"]) {
            
            return   smartMinutesArray.count ;
        }
        else{
        
        if (closeSection) {
            
            return 0;
            
        }
        else {
            
            if (section == lastIndex)
            {
                
                
                if (reloadTblVw)
                {
                    
//                    NSArray *arrr11 = dataPrepaid[section] ;
                    
                    
                    
                    return 1;
                }
                
            }else{
                return 0;
            }
        }
    }
        
    }
    return 0;
    
}




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
     if (tableView == _subscriptionTableView){
        
         
         if ([checkPlan isEqualToString:@"SmartMinutes"]){
         
             
             smartMinutesCell *cell = [tableView dequeueReusableCellWithIdentifier:@"smartMinutesCell"];
             if (cell==nil) {
                 NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"smartMinutesCell" owner:self options:nil];
                 
                 cell= arr[0];
                 
             }
             
             cell.btnSubscribe.layer.borderColor = [UIColor colorWithRed:32/255.0f green:176/255.0f blue:191/255.0f alpha:1].CGColor;
             
             cell.btnSubscribe.layer.borderWidth = 1.5f ;
            cell.btnSubscribe.layer.cornerRadius = 5.0f ;
             [cell.btnSubscribe clipsToBounds];
             
             cell.txtPlanName.text = [NSString stringWithFormat:@"%@",[[smartMinutesArray objectAtIndex:indexPath.row]valueForKey:@"planName"]];
             
                                      
           
             cell.lblCount.text = [NSString stringWithFormat:@"%@",[[smartMinutesArray objectAtIndex:indexPath.row]valueForKey:@"mrv"]];
             
                           
            
             [cell.btnSubscribe addTarget:self action:@selector(smartMinutesSubscribe:) forControlEvents:UIControlEventTouchUpInside];
             
             
             cell.btnSubscribe.tag = indexPath.row ;
             
             
             return cell ;
             
             
             
         }else{
        
        SubscriptionCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SubscriptionCell"];
        if (cell==nil) {
            NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"SubscriptionCell" owner:self options:nil];
            
            cell= arr[0];
            
        }
                    NSArray* arr = dataSubscription[indexPath.section];
                 
                 NSString *str = [NSString stringWithFormat:@"%@",[arr valueForKey:@"fcv"]];
                 NSLog(@"%@",str);
                 cell.textFcv.text = str ;
                 
                 cell.txtMRV.text = [NSString stringWithFormat:@"%@",[arr valueForKey:@"mrv"]];
                 cell.txtInternational.text= [NSString stringWithFormat:@"%@",[arr valueForKey:@"dialinPulse"]];
                 cell.txtIND.text = [NSString stringWithFormat:@"%@",[arr valueForKey:@"dialoutPulse"]];
                 cell.txtFort.text = [NSString stringWithFormat:@"%@",[arr valueForKey:@"port"]];
            
             
             
             [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
            
             [self.subscriptionTableView deselectRowAtIndexPath:indexPath animated:YES];

       
            return cell;
             
         }
         
            
        }
        
    
    
    return nil;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

{
    
    [self.subscriptionTableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (tableView == _subscriptionTableView) {
        
         if ([checkPlan isEqualToString:@"SmartMinutes"]){
             
             
             
             
             
         }else{
        
        UIView *sectionView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,63)];
        sectionView.tag=section;
        
      //  sectionView.backgroundColor = [UIColor colorWithRed:0/255.0f green:0/255.0 blue:0/255.0 alpha:1];
        
        
        UIView *HEADERView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,60)];
        HEADERView.tag=section;
        HEADERView.backgroundColor=[UIColor blackColor];
        [sectionView addSubview:HEADERView];
        
        
       UIButton *btnSubscribe=[[UIButton alloc]initWithFrame:CGRectMake(HEADERView.frame.size.width/2 + 5, 20, 120, 30)];
        [btnSubscribe setTitle:@"Subscribe" forState:UIControlStateNormal];
        btnSubscribe.titleLabel.font = [UIFont systemFontOfSize:14];
        
        [btnSubscribe setBackgroundColor:[UIColor clearColor]];
        [btnSubscribe setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [HEADERView addSubview:btnSubscribe];
         [btnSubscribe addTarget:self action:@selector(subscribeTappedClicked:) forControlEvents:UIControlEventTouchUpInside];
        btnSubscribe.tag = section;
        
        btnSubscribe.layer.borderColor = [UIColor colorWithRed:32/255.0f green:176/255.0f blue:191/255.0f alpha:1].CGColor;
        
        btnSubscribe.layer.borderWidth = 1.5f ;
        btnSubscribe.layer.cornerRadius = 5.0f ;
        [btnSubscribe clipsToBounds];
        
        
        

        UILabel *viewLabel=[[UILabel alloc]initWithFrame:CGRectMake(5, 20, self.subscriptionTableView.frame.size.width-10, HEADERView.frame.size.height/2)];

        viewLabel.backgroundColor=[UIColor clearColor];
        viewLabel.textColor=[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1];
        
        viewLabel.font=[UIFont systemFontOfSize:15];
        viewLabel.text=[NSString stringWithFormat:@"%@",[[dataSubscription valueForKey:@"planName"] objectAtIndex:section]];
        
        NSLog(@"%@",[[dataSubscription valueForKey:@"planName"] objectAtIndex:section]);
        
        CGSize size = [[[dataSubscription valueForKey:@"planName"] objectAtIndex:section] sizeWithFont:[UIFont systemFontOfSize:18] constrainedToSize:CGSizeMake(250, 30) lineBreakMode:NSLineBreakByWordWrapping];
        
        
        img = [[UIImageView alloc]initWithFrame:CGRectMake(HEADERView.frame.size.width - 20  ,btnSubscribe.frame.origin.y + 10 , 15, 15)];
        // img.image = [UIImage imageNamed:@"sidearrow"];
        
        [HEADERView addSubview:viewLabel];
        [HEADERView addSubview:img];
        
        
        
//        
//        btn =[[UIButton alloc]initWithFrame:CGRectMake(self.goalAcjievedTableView.frame.size.width-130, 10, 110, 30)];
//        btn.backgroundColor = [UIColor colorWithRed:0/255.0f green:15/255.0f blue:159/255.0f alpha:1];
//        
//        btn.tag = section;
        
        
//        
//       NSArray* arr = [dataDict valueForKey:[NSString stringWithFormat:@"%@",subscriptionListArray[section]]];
//        
//        
//        if (arr.count == 0) {
//            [btn setTitle:@"No Entry" forState:UIControlStateNormal];
//            
//        }else if (arr.count == 1){
//            [btn setTitle:[NSString stringWithFormat:@"%lu Entry" , (unsigned long)arr.count] forState:UIControlStateNormal];
//            
//            
//        }
//        else if (arr.count > 1){
//            [btn setTitle:[NSString stringWithFormat:@"%lu Entries" , (unsigned long)arr.count] forState:UIControlStateNormal];
//            
//            
//        }
//        
//        btn.titleLabel.font = [UIFont systemFontOfSize:14];
        
        
 
        if (closeSection) {
            //[btn setImage:[UIImage imageNamed:@"sidearrow"] forState:UIControlStateNormal];
            img.image = [UIImage imageNamed:@"down-arrow (2) copy.png"];
        }
        else {
            if (section == lastIndex)
            {
                if (reloadTblVw)
                {
                    img.image = [UIImage imageNamed:@"down-arrow (1).png"];
                }else{
                    img.image = [UIImage imageNamed:@"down-arrow (2) copy.png"];
                }
            }
            else {
                img.image = [UIImage imageNamed:@"down-arrow (2) copy.png"];
            }
        }
       // [sectionView addSubview:btn];
        
        
        UITapGestureRecognizer *dropTableGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(sectionHeaderTapped:)];
        sectionView.tag = section ;
        sectionView.userInteractionEnabled = YES;
        [dropTableGesture setNumberOfTouchesRequired:1];
        [dropTableGesture setDelegate:self];
        [sectionView addGestureRecognizer:dropTableGesture];
        
        
        return  sectionView;
    }
        
    }
    
    return nil;
    
}

-(void)subscribeTappedClicked:(id)sender{
    UIButton *btn = (UIButton*)sender ;
    NSLog(@"%ld",(long)btn.tag);
    
    
   NSString *strPostpaid =[NSString stringWithFormat:@"%@",[[dataSubscription valueForKey:@"planType" ] objectAtIndex:btn.tag]];
    
    NSLog(@"%@",strPostpaid);
    
    if ([strPostpaid isEqualToString:@"postpaid"]) {
        
//        if ([PlanName isEqualToString:@"prepaid"]) {
//            
//           migratePrepaidAlert = [[UIAlertView alloc]initWithTitle:nil message:@"Do you want to migrate from prepaid to postpaid" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"Yes", nil];
//            [migratePrepaidAlert show];
//            
//            
//        }else
//        {
        planid =  [[dataSubscription valueForKey:@"planId" ] objectAtIndex:btn.tag];
        NSLog(@"%@",planid);
        
        isPostpaid = true ;
        
        [self.viewPostPaidProceed setHidden:NO];
        [self.prepaidView setHidden:YES];
        
        self.viewPlanDetail.hidden = NO ;
        [self.viewPay setHidden:YES];
        
   // }
    
        
    }
   else if ([strPostpaid isEqualToString:@"prepaid"]) {
       
      
       
       if ([planNameCHeck isEqualToString:@"postpaid"]) {
           
            planid =  [NSString stringWithFormat:@"%@",[[dataSubscription valueForKey:@"planId" ] objectAtIndex:btn.tag]];
           
           [KVNProgress show];
           
           [self  PostpaidPlans];
           
           
       }else
       {
        planid =  [NSString stringWithFormat:@"%@",[[dataSubscription valueForKey:@"planId" ] objectAtIndex:btn.tag]];
        NSLog(@"%@",planid);
       NSLog(@"%@",planid);
       isPostpaid = false ;
           [KVNProgress  show];
           
           
        [self subscribePrepaidPost];
        
        
    }
    
   }
    
   
    
    
    
    
}

- (void)sectionHeaderTapped:(UITapGestureRecognizer *)gestureRecognizer{
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:gestureRecognizer.view.tag];
    // [arrayTitle replaceObjectAtIndex:indexPath.section withObject:[UIImage imageNamed:@"arrowUpBtn"]];
    
    if (reloadTblVw) {
        if (lastIndex == gestureRecognizer.view.tag && !closeSection) {
            closeSection = true;
            //[arrayTitle replaceObjectAtIndex:indexPath.section withObject:[UIImage imageNamed:@"arrowDownBtn"]];
            
        }
        else {
            closeSection = false;
        }
    }
    else {
        closeSection = false;
    }
    reloadTblVw = true;
    lastIndex = indexPath.section;
    
    [self.subscriptionTableView reloadData];
    
    if (!closeSection) {
        
      //  [self.subscriptionTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:lastIndex] atScrollPosition:UITableViewScrollPositionTop animated:true];
    }
    
    
}


-(IBAction)ButtonHeaderTappedClicked:(id)sender
{
    
    UIButton *button = (UIButton* )sender;
    NSInteger bTn = button.tag;
    // [arrayTitle replaceObjectAtIndex:bTag withObject:[UIImage imageNamed:@"arrowUpBtn"]];
    
    NSLog(@"%ld",(long)bTn);
    
    PlanName = @"" ;
    
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:bTn];
    
    if (reloadTblVw) {
        if (lastIndex == bTn && !closeSection) {
            closeSection = true;
            //[arrayTitle replaceObjectAtIndex:bTag withObject:[UIImage imageNamed:@"arrowDownBtn"]];
            
        }
        else {
            closeSection = false;
        }
    }
    else {
        closeSection = false;
    }
    reloadTblVw = true;
    lastIndex = indexPath.section;
    
    [self.subscriptionTableView reloadData];
    
    if (!closeSection) {
        
        [self.subscriptionTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:lastIndex] atScrollPosition:UITableViewScrollPositionTop animated:true];
    }
    
}


-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (tableView== _subscriptionTableView) {
        
        if ([checkPlan isEqualToString:@"SmartMinutes"]){
            
            
            return 0 ;
            
            
        }
        return 63;
    }
    else{
        
    }
    return 0;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (tableView== _subscriptionTableView) {
    if ([checkPlan isEqualToString:@"SmartMinutes"]){
        
        
        return  72 ;
        
        
    }else{
    return 216;
        
    }
        
    }
    else{
        
        return 0;
        
    }
    
}


- (IBAction)btnPrepaid:(id)sender {
    
    IsProceed = false ;
    
     checkPlan = @"Prepaid";
        [_btnPrepaid setBackgroundColor:[UIColor colorWithRed:32/255.0f green:176/255.0f blue:191/255.0f alpha:1]];
        
        [_btnPostpaid setBackgroundColor: [UIColor clearColor]];
        [_btnSmartMinutes setBackgroundColor: [UIColor clearColor]];
    
    [_btnPrepaid setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_btnPostpaid setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_btnSmartMinutes setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    
    [self.subscriptionTableView reloadData];
    
    [KVNProgress show];
    
    
    [self EmployeeManagementPrepaid];
    
    
 
}

- (IBAction)btnPostpaid:(id)sender {
    
    checkPlan = @"Postpaid";
    
        [_btnPostpaid setBackgroundColor:[UIColor colorWithRed:32/255.0f green:176/255.0f blue:191/255.0f alpha:1]];
        [_btnPrepaid setBackgroundColor: [UIColor clearColor]];
        [_btnSmartMinutes setBackgroundColor: [UIColor clearColor]];
    [_btnPrepaid setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_btnPostpaid setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_btnSmartMinutes setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
           [self.subscriptionTableView reloadData];
    
    [KVNProgress show];
    
    
    [self EmployeeManagementPostPaid];
    
    


}

- (IBAction)btnSmartMinutes:(id)sender {
   // if (!_btnSmartMinutes.isSelected) {
    
    
    checkPlan = @"SmartMinutes";
    
    
        [_btnSmartMinutes setBackgroundColor:[UIColor colorWithRed:32/255.0f green:176/255.0f blue:191/255.0f alpha:1]];
;
       
        [_btnPrepaid setBackgroundColor: [UIColor clearColor]];
        [_btnPostpaid setBackgroundColor: [UIColor clearColor]];
    [_btnPrepaid setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_btnPostpaid setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_btnSmartMinutes setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [KVNProgress show];
    
    [self  EmployeeManagementTopUp];
    
    
  
}

-(void)smartMinutesSubscribe:(id)sender{
    UIButton *btn  = (UIButton*)sender;
     NSLog(@"%ld",(long)btn.tag);
    if ([planNameCHeck isEqualToString:@"prepaid"]) {
       planid =[NSString stringWithFormat:@"%@",[[smartMinutesArray valueForKey:@"planId" ] objectAtIndex:btn.tag]];
        
        
        [self subscribeTopUp];
    }else{
        
        UIAlertView*alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Buy the Prepaid plan first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        
    }
    
  
    
    
}
- (IBAction)backClicked:(id)sender {
    
    MenuVc*menu = [[MenuVc alloc]init];
    menu = [self.storyboard instantiateViewControllerWithIdentifier:@"MenuVc"];
    
    [self.navigationController pushViewController:menu animated:YES];
    

    
}


////////employeeManagement api's

-(void)EmployeeManagementPrepaid{
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/plan/secure/prepaid"];
    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        if ([[responseObject valueForKey:@"message"] isEqualToString:@"success"]) {
            
            dataSubscription =  [responseObject valueForKey:@"prepaidplan"];
            
            
        }
        
        
        [self.subscriptionTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];

        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      
//                                      [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
//                                      
//                                      
//          if (data != nil) {
//              prepaidData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//          }
//          
//          
//          
//          NSLog(@"%@",prepaidData);
//          
//          
//          [self performSelectorOnMainThread:@selector(prepaidData) withObject:nil waitUntilDone:YES];
//          
//          
//        [self.subscriptionTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
//          
//                                  }];
//   [task resume];
    
    
}

//-(void)prepaidData{
//    
//    if ([[prepaidData valueForKey:@"message"] isEqualToString:@"success"]) {
//        
//       dataSubscription =  [prepaidData valueForKey:@"prepaidplan"];
//       
//        
//    }
//    
//}

-(void)kvnDismiss{
    
    
    [ KVNProgress dismiss];
    
}


-(void)EmployeeManagementPostPaid{
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/plan/secure/postpaid"];
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        if ([[responseObject valueForKey:@"message"] isEqualToString:@"success"]) {
            
            dataSubscription =  [responseObject valueForKey:@"postpaidplan"];
            
            
        }
        
        
        [self.subscriptionTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];
    

    
//    
//    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
//    
//    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
//    [urlrequest setHTTPMethod:@"GET"];
//    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
//    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
//                                            completionHandler:
//                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
//                                      
//                                       [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
//          if (data != nil) {
//              PostpaidData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
//          }
//          
//          
//          
//          NSLog(@"%@",PostpaidData);
//          
//          
//          [self performSelectorOnMainThread:@selector(postpaidData) withObject:nil waitUntilDone:YES];
//          
//          [self.subscriptionTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
//          
//          //[self performSelectorOnMainThread:@selector(kvnShow) withObject:nil waitUntilDone:YES];
//                                  }];
//    
//   [task resume];
    
    
}
-(void)postpaidData{
    
    if ([[prepaidData valueForKey:@"message"] isEqualToString:@"success"]) {
        
        dataSubscription =  [PostpaidData valueForKey:@"postpaidplan"];
        
        
    }
    
    
}




-(void)EmployeeManagementTopUp{
    
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/plan/secure/topup"];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        if ([[responseObject valueForKey:@"message"] isEqualToString:@"success"]) {
            
            smartMinutesArray =  [responseObject valueForKey:@"topupplan"];
            
            [self.subscriptionTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        }

        
        [self.subscriptionTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
    
}

-(void)toptupPlan{
    if ([[topUpData valueForKey:@"message"] isEqualToString:@"success"]) {
        
        smartMinutesArray =  [topUpData valueForKey:@"topupplan"];
        
        [self.subscriptionTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    }
    
    
}




-(void)subscribePrepaidPost{
    
    
    NSDictionary *headers = @{ @"content-type": @"application/json",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"74b3dbff-b9d5-c8dd-f00f-468412450986" };
    
    NSDictionary *parameters = @{ @"cmpId": CompanyId,
                                  @"personId": personId,
                                  @"planId": planid };
    
    NSString*apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/order/secure/placeorder"];
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:parameters success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        prepaidSubscribe = responseObject ;
        
        if (IsProceed== true) {
            
                    if ([checkPlan isEqualToString:@"Postpaid"]) {
            
                        [self performSelectorOnMainThread:@selector(postpaid) withObject:nil waitUntilDone:YES];
            
                         }else
            
                    {
                    if ([planNameCHeck isEqualToString:@"postpaid"]) {
            
                [self performSelectorOnMainThread:@selector(showPrepaiddata) withObject:nil waitUntilDone:YES];
            
                       }else{
            
                            [self performSelectorOnMainThread:@selector(postpaid) withObject:nil waitUntilDone:YES];
            
                        }
                                    }
            
                            }
            
                    else{
            
            
                [self performSelectorOnMainThread:@selector(showPrepaiddata) withObject:nil waitUntilDone:YES];
                                                                        
                                                                    }
                                                                    
                                                                }
     

        
     failure:^(NSURLSessionTask *operation, NSError *error) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        NSLog(@"Error: %@", error);
        
    }];

    
    
}



-(void)subscribeTopUp{
    

    
    NSDictionary *parameters = @{ @"cmpId": CompanyId,
                                  @"personId": personId,
                                  @"planId": planid };
    
    NSString*apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/order/secure/placeorder"];
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager POST:apiURLStr parameters:parameters success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        prepaidSubscribe = responseObject ;
        
        
                    
                    [self performSelectorOnMainThread:@selector(showPrepaiddata) withObject:nil waitUntilDone:YES];
                    
        
            
        }
        
     
     
     
          failure:^(NSURLSessionTask *operation, NSError *error) {
              [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
              NSLog(@"Error: %@", error);
              
          }];

}


-(void)TopUpData{
    
    
    
}

-(void)postpaid{
    
    [self.viewPlanDetail setHidden:YES];
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Your Request has been Submitted Successfully" message:@"Your plan will be Activated within 24 hour" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    
    [alert show];

}

-(void)showPrepaiddata{
    
    
        _txtName.text = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"plan"]valueForKey:@"planName"]];
        
        _txtType.text = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"plan"]valueForKey:@"planType"]];
        
        _txtId.text = [NSString stringWithFormat:@"%@",[prepaidSubscribe valueForKey:@"orderId"]];
        
        
        _txtPlanName.text = _txtName.text;
        _txtPlanType.text =   _txtType.text ;
        _txtPlanId.text = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"plan"] valueForKey:@"planId"]];
        
        _txtCompanyName.text = [NSString stringWithFormat:@"%@",[prepaidSubscribe valueForKey:@"cmpNm"]];
        
        _txtEmail.text = [NSString stringWithFormat:@"%@",[prepaidSubscribe valueForKey:@"pemail"]];
    
    if ([planNameCHeck isEqualToString:@"postpaid"]) {
        
        NSString *amountstr = [NSString stringWithFormat:@"%@",[[dueAmount valueForKey:@"dueField"]valueForKey:@"amount"]];
        
        _txtAmount.text = [NSString stringWithFormat:@"%@",amountstr];
        
    }else{

        _txtAmount.text = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"plan"]valueForKey:@"mrv"]];
        
    }
    
        NSString *str  =  [NSString stringWithFormat:@"%@",[prepaidSubscribe valueForKey:@"orderDate"]];
    
    
    double validit = [str doubleValue];
    
    NSDate* Time = [NSDate dateWithTimeIntervalSince1970:validit / 1000.0];
    
    
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    [outputFormatter setDateFormat:@"dd-MMM-yyyy"];
    outputFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    
    
    NSString * currntStr = [outputFormatter stringFromDate:Time];
    
    
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:[str intValue]];
        NSLog(@"%@",date);
    
    
        NSString*str1 = [NSString stringWithFormat:@"%@",date];
        
        self.txtOrderDate.text = currntStr ;
    
    
        [self.viewPostPaidProceed setHidden:YES];
        [self.prepaidView setHidden:NO];
        
        self.viewPlanDetail.hidden = NO ;
          
    
    
    }
    
    
   
    
//    self.viewPlanDetail.hidden = NO ;
    
    



-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
        
        
      
        int y = 0 ;
        
        if (textField == self.txtPlanName) {
            y = 0 ;
        }
        else  if (textField == self.txtPlanType) {
            y = 0 ;
        }
        else if (textField == self.txtCompanyName) {
            y = 70 ;
        }
        
        else if (textField == self.txtEmail){
            
            y= 150 ;
            
        }
        else if (textField == self.txtAmount){
            
            y= 320 ;
            
        }
        else if (textField == self.txtOrderDate){
            
            y= 400 ;
            
        }
        
        
        [UIView animateWithDuration:0.5 animations:^{
            self.scrollView.contentOffset = CGPointMake(0, y);
            
        }];
        
        return true ;
        
    
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    int y = 0 ;
    [UIView animateWithDuration:0.5 animations:^{
        self.scrollView.contentOffset = CGPointMake(0, y);
        
    }];
    
    return true;
}



- (IBAction)buyClicked:(id)sender {
     _viewPay.hidden = NO;
}
- (IBAction)txtPlanType:(id)sender {
    
}
- (IBAction)PayClicked:(id)sender {
    CCWebViewController* controller = [self.storyboard instantiateViewControllerWithIdentifier:@"CCWebViewController"];
    controller.orderId = _txtId.text ;
    controller.amount = _txtAmount.text;
    controller.billing_name = _txtCompanyName.text ;
    controller.billing_city = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"address"] valueForKey:@"city"]];
     controller.billing_address = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"address"] valueForKey:@"add"]];
    
     controller.billing_zip = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"address"] valueForKey:@"zip"]];
      controller.billing_state = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"address"] valueForKey:@"state"]];
    controller.billing_tel = [NSString stringWithFormat:@"%@",[prepaidSubscribe valueForKey:@"pmobile"]];
     controller.billing_email = [NSString stringWithFormat:@"%@",[prepaidSubscribe valueForKey:@"pemail"]];
    
    [self.viewPay setHidden:YES];
    [self.viewPlanDetail setHidden:YES];
    
    controller.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentViewController:controller animated:YES completion:nil];

    
}
- (IBAction)backPay:(id)sender {
    
    [self.viewPay setHidden:YES];
    
}

- (IBAction)closeClicked:(id)sender {
    
    [self.viewPlanDetail setHidden:YES];
    
    
    
}
- (IBAction)proceedClicked:(id)sender {
    
    IsProceed = true ;
    isPostpaid =true ;
    
     [self.viewPay setHidden:YES];
    
    [KVNProgress show];
      [self subscribePrepaidPost];
    
    
}
- (IBAction)btnCancelClicked:(id)sender {
    
    [self.viewPay setHidden:YES];
    [self.viewPlanDetail setHidden:YES];
}


-(void)varifiyingPlans{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/secure/isverify?cmpId=%@",CompanyId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        isVarified = responseObject ;
        [self performSelectorOnMainThread:@selector(planType) withObject:nil waitUntilDone:YES];
        
    }
     
          failure:^(NSURLSessionTask *operation, NSError *error) {
              [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
              NSLog(@"Error: %@", error);
              
          }];
    

    
}


-(void)planType{
    
    if ([[isVarified valueForKey:@"planType"] isEqualToString:@"No plan selected"]) {
        
        if ([checkPlan isEqualToString:@"SmartMinutes"]) {
            
            planNameCHeck = @"No plan selected" ;
            
        }
      
     
    }else if ([[isVarified valueForKey:@"planType"] isEqualToString:@"prepaid"]){
        
        
        planNameCHeck = @"prepaid" ;
        
    }else if ([[isVarified valueForKey:@"planType"] isEqualToString:@"postpaid"]){
        
         planNameCHeck = @"postpaid" ;
    }

}


-(void)PostpaidPlans{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/plan/secure/postpaiddueamt?cmpid=%@",CompanyId];
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
    
    [manager GET:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"PLIST: %@", responseObject);
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        
        dueAmount = responseObject ;
        [self performSelectorOnMainThread:@selector(planType) withObject:nil waitUntilDone:YES];
        
        
                        NSLog(@"%@",dueAmount);
        
                        [self performSelectorOnMainThread:@selector(duePlan) withObject:nil waitUntilDone:YES];
        
    }
     
         failure:^(NSURLSessionTask *operation, NSError *error) {
             [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
             NSLog(@"Error: %@", error);
             
         }];
    
    
}
-(void)duePlan{
    
    
    
    NSString *amountstr = [NSString stringWithFormat:@"%@",[[dueAmount valueForKey:@"dueField"]valueForKey:@"amount"]];
    
    
    migratePrepaidAlert = [[UIAlertView alloc]initWithTitle:nil message:[NSString stringWithFormat:@"Your due Amount is %@ if you want to migrate from postpaid to prepaid then click on Proceed",amountstr] delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Proceed", nil];
    [migratePrepaidAlert show];

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    
    if (alertView == migratePrepaidAlert) {
        if (buttonIndex == 0) {
            NSLog(@"nO");
            
        }else if (buttonIndex == 1) {
            IsProceed = true ;
            isPostpaid =true ;
            
            [self.viewPay setHidden:YES];
            [self subscribePrepaidPost];
            
        }
    }
    
}

-(UIColor*)colorWithHexString:(NSString*)hex
{
    
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor whiteColor];
    
    // strip 0X if it appears
    if ([cString hasSuffix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor whiteColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
    
}

@end
