//
//  graphicsViewController.h
//  excelSheetUpload
//
//  Created by Rhythmus on 23/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PNChartDelegate.h"
#import "PNChart.h"
#import "DropDownView.h"
@interface MeetingViewController : UIViewController<PNChartDelegate,DropDownViewDelegate,UIGestureRecognizerDelegate,UIAlertViewDelegate>
{
    DropDownView *dropDownView;
    
    NSMutableArray *dropDownListArray;
    
    NSString * ActivePerson;
    NSString * InactivePerson;
    NSString * NotJoinPerson;
    NSString * InviteLabel;
    NSString * StartTimeString;
    NSString * DurationString;
    NSString * MetingDurationTime;
    NSArray*  RejectData ;
    NSDictionary *cities;
    NSString*PersonID;
    NSString*companyId;
    NSDictionary *dicData;
    UIAlertView *alertviewMeetings;
    
    
}
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *widthGraph;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *heightGraph;

@property (strong, nonatomic) UITextField *dropDownTxtfield;
@property (strong, nonatomic) IBOutlet UIProgressView *progressBar;
@property (strong, nonatomic) IBOutlet UILabel *LabelInviteSMs;
@property (strong, nonatomic) IBOutlet UILabel *labelConferenceStatus;
@property (nonatomic) PNPieChart *pieChart;
@property (strong, nonatomic) IBOutlet UIView *pieView;
@property (strong, nonatomic) IBOutlet UIView *graphView;
@property (strong, nonatomic) IBOutlet UITextField *txtSelectDepartment;
@property (strong, nonatomic) IBOutlet UITextField *txtSelectOption;
@property (strong, nonatomic) IBOutlet UILabel *Labelendtime;
- (IBAction)bckClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *Boxnotjoind;

@property (strong, nonatomic) IBOutlet UILabel *LabelnotJoined;
                

@end





