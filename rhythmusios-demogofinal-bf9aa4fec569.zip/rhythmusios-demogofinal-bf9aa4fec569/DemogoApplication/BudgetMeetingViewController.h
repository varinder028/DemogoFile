//
//  meetingdetailsViewController.h
//  excelSheetUpload
//
//  Created by Rhythmus on 22/05/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PNChartDelegate.h"
#import "PNChart.h"

@interface BudgetMeetingViewController : UIViewController<PNChartDelegate>{
    
      NSDictionary *cities;
}
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *grphHeght;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *widthGraph;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *heightGraph;

@property (strong, nonatomic) IBOutlet UILabel *labelUsed;
@property (strong, nonatomic) IBOutlet UILabel *LabelUnused;
@property (strong, nonatomic) IBOutlet UILabel *LabeltotalUser;
@property (strong, nonatomic) IBOutlet UIProgressView *progressBar;

@property (nonatomic) PNPieChart *pieChart;

@property (strong, nonatomic) IBOutlet UIView *pieView;

@property (strong, nonatomic) IBOutlet UIView *graphView;
- (IBAction)bckBudgetSummary:(id)sender;






@end
