//
//  SubscriptionCell.m
//  DemogoApplication
//
//  Created by katoch on 22/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "SubscriptionCell.h"

@implementation SubscriptionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
