//
//  TabView.h
//  DemogoApplication
//
//  Created by katoch on 24/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabView : UIView

- (IBAction)todayClicked:(id)sender;
- (IBAction)scheduleMeetingClicked:(id)sender;
- (IBAction)controlPanel:(id)sender;

-(void)todayClicked;
-(void)dashboardClicked;
-(void)menuClicked;
-(void)controlPanel;
-(void)scheduleMeetingClicked;

@property (strong, nonatomic) IBOutlet UIButton *btnToday;
@property (strong, nonatomic) IBOutlet UIButton *btnSchedule;

@property (strong, nonatomic) IBOutlet UIButton *btnControlPanel;
@property (strong, nonatomic) IBOutlet UIButton *btnDashboard;
@property (strong, nonatomic) IBOutlet UIButton *btnMenu;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *btnScheduleWidth;
@end
