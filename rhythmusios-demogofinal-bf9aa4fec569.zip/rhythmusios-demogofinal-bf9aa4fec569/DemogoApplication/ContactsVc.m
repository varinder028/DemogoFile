//
//  ContactsVc.m
//  DemogoApplication
//
//  Created by katoch on 11/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ContactsVc.h"
#import <AddressBook/AddressBook.h>
#import <AddressBookUI/AddressBookUI.h>
#import <Contacts/Contacts.h>
#import <ContactsUI/ContactsUI.h>
#import "AppDelegate.h"


@interface ContactsVc ()

@end

@implementation ContactsVc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _contactsTableView.separatorStyle = UITableViewCellSelectionStyleNone ;
    
    
    arrayContacts = [[NSMutableArray alloc]init];
    
    
    
    _checkArray = [[NSMutableArray alloc]init];
    nameList = [[NSMutableArray alloc]init];
    
    
    
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:YES];

    
    arrayContacts = [NSMutableArray new];
    
    contactNumbersArray = [[NSMutableArray alloc]init];
    
  
    
    [_checkArray addObjectsFromArray:[[NSUserDefaults standardUserDefaults]
                                    objectForKey:@"checked"]];
 
    [arrayContacts addObjectsFromArray:[[NSUserDefaults standardUserDefaults]
                                      objectForKey:@"PD"]];
    [self fetchContactsandAuthorization];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  [contactNumbersArray count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static  NSString *strCell = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:strCell];
    if(cell==nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:strCell];
    }
    
    
    cell.selectionStyle = UITableViewCellSeparatorStyleNone ;
    
    
    cell.backgroundColor = [UIColor clearColor];
    
    
    
    if ([self.checkArray containsObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]]) {
        
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        
    }
    
    else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    
    
    }
    
    
    
    cell.textLabel.textColor= [UIColor whiteColor];
     cell.detailTextLabel.textColor= [UIColor whiteColor];
    
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@",[nameList objectAtIndex:indexPath.row] ];
    
    
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@",[contactNumbersArray objectAtIndex:indexPath.row] ];
    
   
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    NSLog(@"%@",self.checkArray);
    
     NSUInteger row = [indexPath row] ;
    
     UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    if ([self.checkArray containsObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]]) {
        
        
        [self.checkArray removeObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
        cell.accessoryType = UITableViewCellAccessoryNone;
         [arrayContacts removeObject:contactNumbersArray[indexPath.row]];
       
        
    }else{
        
        
        [self.checkArray addObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
         [arrayContacts addObject:contactNumbersArray[row]];
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        
    }

    
//    NSUInteger row = [indexPath row] ;
//    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
//    if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
//        cell.accessoryType = UITableViewCellAccessoryNone;
//        [arrayContacts removeObject:contactNumbersArray[indexPath.row]];
//        
//       
//    }
//    else {
//        cell.accessoryType = UITableViewCellAccessoryCheckmark;
//          [arrayContacts addObject:contactNumbersArray[row]];
//    }
//    
//    [tableView deselectRowAtIndexPath:indexPath animated:YES];
//    
    
    [[NSUserDefaults standardUserDefaults]setValue:_checkArray forKey:@"checked"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    [[NSUserDefaults standardUserDefaults]setValue:arrayContacts forKey:@"PD"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    

}

-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
   // [[self.contactsTableView cellForRowAtIndexPath:indexPath] setAccessoryType:UITableViewCellAccessoryNone];
}

//This is for fetching contacts from iPhone.Also It asks authorization permission.
-(void)fetchContactsandAuthorization
{
    // Request authorization to Contacts
    CNContactStore *store = [[CNContactStore alloc] init];
    [store requestAccessForEntityType:CNEntityTypeContacts completionHandler:^(BOOL granted, NSError * _Nullable error)
     {
         if (granted == YES)
         {
             //keys with fetching properties
             NSArray *keys = @[CNContactFamilyNameKey, CNContactGivenNameKey, CNContactPhoneNumbersKey, CNContactImageDataKey];
             NSString *containerId = store.defaultContainerIdentifier;
             NSPredicate *predicate = [CNContact predicateForContactsInContainerWithIdentifier:containerId];
             NSError *error;
             NSArray *cnContacts = [store unifiedContactsMatchingPredicate:predicate keysToFetch:keys error:&error];
             if (error)
             {
                 NSLog(@"error fetching contacts %@", error);
             }
             else
             {
                 NSString *fullName;
                 NSString *firstName;
                 NSString *lastName;
                 UIImage *profileImage;
                 
                 for (CNContact *contact in cnContacts) {
                     
                     
                     
                     firstName = contact.givenName;
                     
                     
                     if (lastName == nil) {
                         fullName=[NSString stringWithFormat:@"%@",firstName];
                     }else if (firstName == nil){
                         fullName=[NSString stringWithFormat:@"%@",lastName];
                     }
                     
                     for (CNLabeledValue *label in contact.phoneNumbers)
                         
                     {
                         phone = [label.value stringValue];
                         
                         
                         
                         //NSLog(@"%@",phone);
                         if ([phone length] > 0)
                             
                         {
                             
                             dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:phone,@"Numberkey",fullName,@"Name", nil];
                             
                             NSLog(@"%@",dict);
                             
                             
                             
                             [contactNumbersArray addObject:[dict valueForKey:@"Numberkey"]];
                              [nameList addObject:[dict valueForKey:@"Name"]];
                             
                             
                             
                         }
                     }
                     
                     
                 }
                 
                 [self.contactsTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
                 
                 
                 
             }
         }
     }];
}


- (IBAction)bckClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)doneClicked:(id)sender {
    
     [self.navigationController popViewControllerAnimated:YES];
    
}



@end
