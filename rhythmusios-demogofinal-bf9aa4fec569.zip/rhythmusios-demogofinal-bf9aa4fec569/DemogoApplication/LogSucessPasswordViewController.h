//
//  LogSucessPasswordViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 14/03/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TabView.h"




@interface LogSucessPasswordViewController : UIViewController<UITextFieldDelegate>
- (IBAction)submitButton:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *submitOUTLET;

@property (strong, nonatomic) TabView *tabView;

@property (strong, nonatomic) NSString *personID;

@property (strong, nonatomic) NSString *CMPID;

- (IBAction)SendCmpID:(id)sender;

- (IBAction)backClicked:(id)sender;

@end
