//
//  AccountBillViewController.h
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UpdateAccountViewController.h"


@interface AccountBillViewController : UIViewController<UIAlertViewDelegate>{
    
    NSString*personId ;
    id detailData ;
    NSArray *Roledetails ;
    id deleteData ;
    NSString *DeleteRowStr ;
    
    NSMutableArray *infoArray ;
    id personDetails ;
    NSString *strPersonID;

    UIButton *btnUpdate ;
    int count ;
    NSString *Tokenid;
    NSString*CompanyId;
    UIButton *btn ;
    
    UIAlertView* deleteAlert;
    
    
}

@property (strong, nonatomic) IBOutlet UITableView *tableAccountDetails;

- (IBAction)BAckBUtton:(id)sender;

@end
