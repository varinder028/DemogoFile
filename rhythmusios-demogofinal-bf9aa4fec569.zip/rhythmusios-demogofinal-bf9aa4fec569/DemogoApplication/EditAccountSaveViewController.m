//
//  EditAccountSaveViewController.m
//  DemogoApplication
//
//  Created by Rhythmus on 01/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "EditAccountSaveViewController.h"
#import "cellActionViewController.h"

@interface EditAccountSaveViewController ()<NSURLSessionDataDelegate,NSURLSessionDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>
{
    UIImagePickerController *imagepickerd;
}
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;
@property (strong, nonatomic) IBOutlet UIView *ViewBAck;
- (IBAction)backButton:(id)sender;


@end

@implementation EditAccountSaveViewController

-(void)viewDidAppear:(BOOL)animated
{
    _scroll.showsVerticalScrollIndicator=YES;
    _scroll.scrollEnabled=YES;
    _scroll.userInteractionEnabled=YES;
    
    _scroll.contentSize = CGSizeMake(0,self.scroll.frame.size.height+60);
    
//    CGPoint scrollPoint = CGPointMake(0,0); //textField.frame.origin.y);
//    
//                            [_scrollview setContentOffset:scrollPoint animated:YES];

    // [self.scrollViewVertically setContentOffset: CGPointMake(0, self.scrollViewVertically.contentOffset.y)];
    // self.scrollViewVertically.directionalLockEnabled = YES;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.FirstNameLAbel.text = self.FirstLAbel;
    
    self.LAstNameLAbel.text = self.LAstLAbel;
    
    self.EmailNAmeLabel.text = self.EmailLabel;
    
    self.MobileNumberLabel.text = self.MobileString;
    
    self.LocationLAbel.text = self.LocationL;
    
    self.DepartmentLabel.text = self.DepartLabel;
    
    self.AdminNAmeLAbel.text = self.AdminLAbel;
    
    
    self.SaveButtonOutlet.layer .cornerRadius = 10.5;
    
    self.CancelButtonOutlet.layer .cornerRadius = 10.5;
    
    self.uploadpictureoutlet.layer.cornerRadius = 10.5;
    
    self.UploadImage.layer.cornerRadius =50;
    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)UploadPictureButton:(UIButton *)sender {
    
    imagepickerd = [[UIImagePickerController alloc]init];
    
    imagepickerd .delegate =self;
    
    [imagepickerd  setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    
    [self presentViewController:imagepickerd animated:YES completion:nil];
    
    
    
    
}
    
    
-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
    {
        UIImage *imag ;
        
         imag = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    
        
        [self.UploadImage  setImage:imag];
        
        [self dismissViewControllerAnimated:YES completion:NULL];
    }
    
   
-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker
    
{
    
        [self dismissViewControllerAnimated:YES completion:NULL];

}
    

- (IBAction)SaveButton:(UIButton *)sender
{
    [self PersonIdSetInServer];
}

-(void)PersonIdSetInServer;

{
    
    NSError *error;
    NSString * urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/editperson"];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
    NSURL *url = [NSURL URLWithString:urlstring];
    
    
    
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [SendingRequest setHTTPMethod:@"PUT"];
    
    
    
    
    
    NSMutableDictionary *emailDicDta = [[NSMutableDictionary alloc]
                                        initWithObjectsAndKeys:@"PRIMARY",@"type",self.EmailNAmeLabel.text,@"value", nil];
    
    
    NSMutableArray * emailArray =[[NSMutableArray alloc]init];
    
    [emailArray addObject:emailDicDta];
    
    
    NSMutableDictionary *mobileDicDta =
    [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"PRIMARY",@"type",self.MobileNumberLabel.text,@"value", nil];
    
    
    
    
    NSMutableArray *mobileArray =[[NSMutableArray alloc]init];
    
    [mobileArray addObject:mobileDicDta];
    
    
    NSMutableDictionary *GetDicDta = [[NSMutableDictionary alloc]initWithObjectsAndKeys:
                                      @"1752",@"cmpId",emailArray,@"email",mobileArray,@"mobile",
        self.FirstNameLAbel.text,@"firstName",
        self.LAstNameLAbel.text,@"lastName",
        self.LocationLAbel.text,@"location",
        self.LAstNameLAbel.text,@"depName",
        self.AdminNAmeLAbel.text,@"role",
        @"3713",@"personId",@"3713",@"hostId",@"3713",@"loginId",
        @"true",@"empSts",
        @"ROLE_SUPER_ADMIN",@"role", nil];
    
    //NSLog(@"%@",cmp);
    
    NSLog(@"%@",GetDicDta);
    
    NSData* SendData= [NSJSONSerialization dataWithJSONObject:GetDicDta options:kNilOptions error:&error];
    
    [SendingRequest setHTTPBody:SendData];
    
    NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                                          {
                                              
                                              NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
                                              NSLog(@" the databse theXml is  =====  %@",theXML);
                                              
                                              NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                              
                                              
                                              NSMutableDictionary * userEmailID = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                                              
                                              NSLog(@"The State Response is  ===  %@" , userEmailID);
                                              
                                              NSLog(@"The State Response is  ===  %@" , [userEmailID valueForKey:@"responseCode"]);
                                              
                                              
                                              
                                          }];
    
    [self.TableCompanyList reloadData];
    
    [postDataTask resume];
    
}






- (IBAction)backButton:(id)sender

{
    
    cellActionViewController * actio = [self.storyboard instantiateViewControllerWithIdentifier:@"action"];
    
    actio.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    
    [self.navigationController pushViewController:actio animated:YES];
    

    
}
@end
