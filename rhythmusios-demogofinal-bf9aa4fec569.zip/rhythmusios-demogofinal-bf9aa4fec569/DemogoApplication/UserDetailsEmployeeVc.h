//
//  UserDetailsEmployeeVc.h
//  DemogoApplication
//
//  Created by katoch on 26/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropDownView.h"

@interface UserDetailsEmployeeVc : UIViewController<UITextFieldDelegate,DropDownViewDelegate,UIGestureRecognizerDelegate>{
    
    
    NSMutableArray *roleArray ;
    DropDownView *dropDownView ;
    id departmentData ;
    NSString*companyId ;
    NSString * personid;
    NSString *tokenid;
    id  updateUser ;
    NSMutableDictionary * userEmailID;
    
}

@property (strong, nonatomic) NSString *EditStr;
@property (strong, nonatomic) NSMutableArray *editDetailArray;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *DetailHeightLayout;
//549

@property (strong, nonatomic) IBOutlet UITextField *dropDownTxtfield;
@property (strong, nonatomic) IBOutlet UITextField *firstName;

@property (strong, nonatomic) IBOutlet UITextField *lastName;

@property (strong, nonatomic) IBOutlet UITextField *mobileNo;

@property (strong, nonatomic) IBOutlet UITextField *emailId;

@property (strong, nonatomic) IBOutlet UITextField *txtLocation;

@property (strong, nonatomic) IBOutlet UITextField *txtRole;


@property (strong, nonatomic) IBOutlet UITextField *txtDepartment;




@property (strong, nonatomic) IBOutlet UILabel *lblFirstName;
@property (strong, nonatomic) IBOutlet UILabel *lblLastName;

@property (strong, nonatomic) IBOutlet UILabel *lblMobile;
@property (strong, nonatomic) IBOutlet UILabel *lblEmail;
@property (strong, nonatomic) IBOutlet UILabel *lblLocation;
@property (strong, nonatomic) IBOutlet UILabel *lblRole;

@property (strong, nonatomic) IBOutlet UILabel *lblEMPLOYEE;
@property (strong, nonatomic) IBOutlet UILabel *lblPorts;
@property (strong, nonatomic) IBOutlet UITextField *txtEmployeeId;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *topLayout;
@property (strong, nonatomic) IBOutlet UITextField *txtPort;
@property (strong, nonatomic) IBOutlet UIView *scrollSubView;
- (IBAction)backClicked:(id)sender;

- (IBAction)btnADD:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *lblUserDetails;

@property (strong, nonatomic) IBOutlet UILabel *lbleditUser;


@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtRoleheight;

//
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtRoleTop;
//28
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtPortTop;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *txtPortHeight;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *lblPortTop;
@property (strong, nonatomic) IBOutlet UIButton *txtAddbtn;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *lblRoleHeight;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *lblRoleTop;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *lblPortHeight;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;

@end
