//
//  MyBillViewController.m
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "MyBillViewController.h"
#import "Billing.h"
#import "KVNProgress.h"
#import "CCWebViewController.h"
#import <AFNetworking.h>


@interface MyBillViewController ()
- (IBAction)BAckButton:(id)sender;

@end

@implementation MyBillViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _PayBtnOutlet.layer.cornerRadius = 5.0f ;
    
    [_PayBtnOutlet clipsToBounds];

    
    
    CompanyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];

    
    
    self.PayBtnOutlet.layer.cornerRadius =10.5;
    
     self.viewData.layer.cornerRadius =10.5;
    
    
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    
    [self MybillApiFromServer];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)MybillApiFromServer
{
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/bill/secure/postpaidmybill?cmpid=%@",CompanyId];
    
    NSMutableURLRequest *urlrequest=[[NSMutableURLRequest alloc]init];
    
    [urlrequest setURL:[NSURL URLWithString:apiURLStr]];
    [urlrequest setHTTPMethod:@"POST"];
    [urlrequest setValue:Tokenid forHTTPHeaderField:@"token"];
    [urlrequest setHTTPBody:[apiURLStr dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:urlrequest
                                            completionHandler:
                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
                                      
                                      [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
                                      
                                      
                                      myBills=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
                                      [self performSelectorOnMainThread:@selector(myBillsData) withObject:nil waitUntilDone:YES];
                                  }];
    [task resume];
    
    
}
-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}


-(void)myBillsData{
    
    NSLog(@"%@",myBills);
    
    if ([[myBills valueForKey:@"message"] isEqualToString:@"success"]) {
        NSString *currentAmt = [NSString stringWithFormat:@"%@",[[myBills valueForKey:@"myBill"]valueForKey:@"currentAmt"]];
        NSString *previousAmt = [NSString stringWithFormat:@"%@",[[myBills valueForKey:@"myBill"]valueForKey:@"amount"]];
        NSString *paymentRecieved = [NSString stringWithFormat:@"%@",[[myBills valueForKey:@"myBill"]valueForKey:@"payment"]];
        NSString *dueAmt = [NSString stringWithFormat:@"%@",[[myBills valueForKey:@"myBill"]valueForKey:@"dueAmt"]];
        
        
        self.LbLCurrentValue.text = currentAmt ;
        self.LblPaymentRecieved.text = paymentRecieved ;
        self.LbLPreviousBalance.text = previousAmt ;
        self.LbLTotalAmountByDueDate.text = dueAmt ;

    }
    
    
    
}

- (IBAction)BAckButton:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
   
}
- (IBAction)PayButton:(id)sender {
    CCWebViewController* controller = [self.storyboard instantiateViewControllerWithIdentifier:@"CCWebViewController"];
//    controller.orderId = _txtId.text ;
//    controller.amount = _txtAmount.text;
//    controller.billing_name = _txtCompanyName.text ;
//    controller.billing_city = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"address"] valueForKey:@"city"]];
//    controller.billing_address = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"address"] valueForKey:@"add"]];
//    
//    controller.billing_zip = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"address"] valueForKey:@"zip"]];
//    controller.billing_state = [NSString stringWithFormat:@"%@",[[prepaidSubscribe valueForKey:@"address"] valueForKey:@"state"]];
//    controller.billing_tel = [NSString stringWithFormat:@"%@",[prepaidSubscribe valueForKey:@"pmobile"]];
//    controller.billing_email = [NSString stringWithFormat:@"%@",[prepaidSubscribe valueForKey:@"pemail"]];
//    
//    [self.viewPay setHidden:YES];
//    [self.viewPlanDetail setHidden:YES];
    
    
    
    controller.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentViewController:controller animated:YES completion:nil];
    
}
- (IBAction)DownloadButon:(id)sender {
}


- (IBAction)backPay:(id)sender {
}

//-(void)myDueBillApi{
//    
//    
//        NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/order/secure/dueorder?"];
//    
//        
//        AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
//        manager.requestSerializer = [AFJSONRequestSerializer serializer];
//        [manager.requestSerializer setValue:Tokenid forHTTPHeaderField:@"token"];
//        
//        [manager POST:apiURLStr parameters:nil success:^(NSURLSessionTask *task, id responseObject) {
//            NSLog(@"PLIST: %@", responseObject);
//            [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
//            
//            
//            
//            dueData = responseObject ;
//            [self performSelectorOnMainThread:@selector(dueAllData) withObject:nil waitUntilDone:YES];
//          
//            
//            
//        } failure:^(NSURLSessionTask *operation, NSError *error) {
//            [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
//            NSLog(@"Error: %@", error);
//            
//            
//        }];
//}
//
//-(void)dueAllData{
//    
//      NSLog(@"%@",dueData);
//    
//    
//}

@end
