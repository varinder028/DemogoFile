//
//  BillsCell.m
//  designDemogostoryboard
//
//  Created by Rhythmus on 24/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "BillsCell.h"

@implementation BillsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
