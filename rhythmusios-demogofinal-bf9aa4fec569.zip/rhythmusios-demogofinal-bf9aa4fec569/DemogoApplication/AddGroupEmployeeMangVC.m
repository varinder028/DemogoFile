//
//  AddGroupEmployeeMangVC.m
//  DemogoApplication
//
//  Created by Rhythmus on 03/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "AddGroupEmployeeMangVC.h"
#import "EmployeeManagementCell.h"
#import "UIImageView+Letters.h"
#import "UIImageView+WebCache.h"


@interface AddGroupEmployeeMangVC ()

@end

@implementation AddGroupEmployeeMangVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone ;
    
    
   self.lblEditGroup.layer.cornerRadius = 5.0f;
    [_lblEditGroup clipsToBounds];
    [_lblEditGroup.layer masksToBounds];
    
    
    
    self.BtnCancel.layer.cornerRadius = 5.5f;
    self.BtnCreateGroup.layer.cornerRadius = 5.5f;
    
    
    
     [self.searchBar setBackgroundImage:[[UIImage alloc]init]];
    
    _lblEditGroup.layer.cornerRadius = 5.0f ;
    [_lblEditGroup clipsToBounds];
    
    
    groupcheckmarkArray = [[NSMutableArray alloc]init];
    selectedGroups = [[NSMutableArray alloc]init];
    
    
    
    if ([_isGroup isEqualToString:@"isGroup"]) {
        _lblEditGroup.text = @"Edit Group Details";
        [_BtnCreateGroup setTitle:@"Update Group" forState:UIControlStateNormal];
        
        
        _txtTextViewAddGroup.text = @"" ;
        
          _lblAddUser.text = @"Edit Group Details" ;
        
        NSArray*arr = [_editDetailArray valueForKey:@"personId"];
        
        joinedString = [arr componentsJoinedByString:@","];

        _txtTextViewAddGroup.text = joinedString ;

        
        _txtGroupName.text = [_editDetailArray valueForKey:@"grpName"] ;
        _txtGroupDescription.text = [_editDetailArray valueForKey:@"grpDesc"];
        
        
    }else{
        
        _lblEditGroup.text = @"Group Details";
        [_BtnCreateGroup setTitle:@"Create Group" forState:UIControlStateNormal];
        
        _txtTextViewAddGroup.text = @"" ;
        _txtGroupName.text = @"" ;
        _txtGroupDescription.text = @"";
        _lblAddUser.text = @"Add Users to Group" ;
        
        
        
    }
    
  personId = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    NSLog(@"%@",personId);
    
    
     self.addGroupView.hidden = YES;
    
    blockCheckedArray = [[NSMutableArray alloc]init];
    userListArray = [[NSMutableArray alloc]init];
    
    
    companyId = [[NSUserDefaults standardUserDefaults]valueForKey:@"CompanyId"];
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    NSLog(@"%@",Tokenid);
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    [self  GetProfileFromServer];
    
    
}




- (IBAction)btnAddGroup:(id)sender {
     self.addGroupView.hidden = NO;
    
    if ([_txtTextViewAddGroup.text isEqualToString:@""]) {
        
    }
    else{
        
        
    
        selectedGroups = [[NSMutableArray alloc]init];
       
        NSString*strPersonIdss = [NSString stringWithFormat:@"%@",_txtTextViewAddGroup.text];
        
        NSArray* arrPerson = [strPersonIdss componentsSeparatedByString:@","];
        NSLog(@"%@",arrPerson);
        
        
        int countTotal = (int)userListArray.count ;
        
        
        for (NSString*str  in arrPerson) {
            int  count = 0 ;
            
            
            for (NSString*strKey  in [userListArray valueForKey:@"personId"]) {
                
                count = count + 1;
                
                int j = count - 1 ;
                
                if ([strKey isEqual:[NSNumber numberWithDouble:[str doubleValue]]]) {
                    [selectedGroups addObject:str];
                    
                    
                    k = j ;
                    
                    NSLog(@"%d",k);
                    
                    
                    
                    
                }else{
                    
                }
                
            }
            NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:[userListArray objectAtIndex:k]];
            for (NSDictionary *dicts in array) {
                
                [dictt addEntriesFromDictionary:dicts];
                
            }
            
            [dictt setObject:@"YES" forKey:@"checked"];
            [userListArray  replaceObjectAtIndex:k withObject:dictt];

            search_tableContents = [[NSMutableArray alloc]initWithArray:userListArray];

            
            
         //   [groupcheckmarkArray replaceObjectAtIndex:k withObject:@"YES"];
            
            
            
        }

    
    }
    

    
    
    [self.tableView reloadData];
    
    [self.view bringSubviewToFront:_addGroupView];
    
    
}
- (IBAction)btnCreateGroup:(id)sender {
    
    
    if ([_isGroup isEqualToString:@"isGroup"]){
        
        if ([_txtGroupName.text isEqualToString:@""]) {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the Group Name" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            
            
            
        }else if ([_txtGroupDescription.text isEqualToString:@""]){
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the Group Description" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            
            
            
        }else if ([_txtTextViewAddGroup.text isEqualToString:@""]){
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select the groups" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            
        }else{
            [self updateDataFromServer];
            
        }
 
    }else{
        
        if ([_txtGroupName.text isEqualToString:@""]) {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the Group Name" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            
            
            
        }else if ([_txtGroupDescription.text isEqualToString:@""]){
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please enter the Group Description" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];

            
            
        }else if ([_txtTextViewAddGroup.text isEqualToString:@""]){
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select the groups" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
           
        }
        
        else{
        
         [self CreateGroup];
            
        }
    }
   
    
}

- (IBAction)btnCancel:(id)sender {
    
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnback:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}




-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}




-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return userListArray.count;
    
    
}




-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    EmployeeManagementCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EmployeeManagementCell"];
    if (cell==nil) {
        NSArray *arr = [[NSBundle mainBundle]loadNibNamed:@"EmployeeManagementCell" owner:self options:nil];
        
        cell= arr[0];
        
    }
    
    cell.txtRole.hidden = YES;
    cell.imgEmpyee.hidden = NO;
    

    
        if (userListArray.count>0) {
             NSString *str = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"checked"]objectAtIndex:indexPath.row]];
            
            if(![str isEqualToString:@"NO"])
            {
                
                [cell.btnCheck setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
                
                
                //  [cell.btnCheck setSelected:YES];
                
            }
            
            else if ([[userListArray valueForKey:@"checked"] containsObject:[userListArray objectAtIndex:indexPath.row]])
            {
                
                [cell.btnCheck setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
            }
            else
            {
                
                
                [cell.btnCheck setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
                
            }
            
            
            
            [cell.btnCheck addTarget:self action:@selector(checkedClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            
            
            cell.txtMobile.text = [[userListArray valueForKey:@"pmobile"]objectAtIndex:indexPath.row];
            
          NSString*firstNaME  =  [[userListArray valueForKey:@"firstName"]objectAtIndex:indexPath.row];
             NSString*SECONDNAME  =  [[userListArray valueForKey:@"lastName"]objectAtIndex:indexPath.row];
            
            cell.textName.text = [NSString stringWithFormat:@"%@ %@",firstNaME,SECONDNAME];
            
            
           NSString*roleee  = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"role"]objectAtIndex:indexPath.row]];
            
            if ([roleee isEqualToString:@"ROLE_SUPER_ADMIN"]) {
                roleee = @"Admin" ;
                
            }else if ([roleee isEqualToString:@"ROLE_HOST"]) {
                roleee = @"Host" ;
                
            }else if ([roleee isEqualToString:@"ROLE_PARTICIPANT"]) {
                roleee = @"Participant" ;
                
            }
            cell.txtRole.text = roleee ;
            
            cell.imgEmpyee.layer.cornerRadius = cell.imgEmpyee.frame.size.width/2; //
            
            [cell.imgEmpyee.layer masksToBounds];
            
            cell.imgEmpyee.layer.borderWidth = 1.0f;
            
            cell.imgEmpyee.layer.masksToBounds = YES;
            
            cell.imgEmpyee.clipsToBounds = YES;
            
            NSString*proImg = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"proImg"]objectAtIndex:indexPath.row]];
            
            if ([proImg isEqualToString:@"no image"]) {
                
                [cell.imgEmpyee setImageWithString:cell.textName.text color:nil circular:YES];
                
            }else{
                
                [cell.imgEmpyee sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://182.76.44.135:8080/%@",[userListArray valueForKey:@"proImg"]]]placeholderImage:[UIImage imageNamed:@"Image 20-04-17 at 12.11 PM.jpg"]];
                
            }

           // [cell.imgEmpyee setImageWithString:cell.textName.text color:nil circular:YES];

            
            [cell.btnCheck addTarget:self action:@selector(checkedClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.btnCheck.tag = indexPath.row ;
            
        }
    cell.backgroundColor = [UIColor clearColor];
    
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
    }
    
    




//
//    if (!_checkAllBtn.isSelected) {
//        
//        [cell.btnCheck setSelected:NO];
//        
//    }else{
//        
//        [cell.btnCheck setSelected:YES];
//    }
    
    //  cell.arrowImg.image = @"" ;
    
    
    
    
    
    
    
    

    


-(void)checkedClicked:(id)sender{
    
    [self.checkAllBtn setSelected:NO];
    
    
    UIButton *btnTagg = (UIButton*)sender ;
    
    
    if(![[[userListArray valueForKey:@"checked"] objectAtIndex:btnTagg.tag] isEqualToString:@"NO"])
    {
        
        [btnTag setImage:[UIImage imageNamed:@"deselect.png"] forState:UIControlStateNormal];
        
//        NSMutableArray *tempArray = [[NSMutableArray alloc]init];
//        [tempArray addObjectsFromArray:groupcheckmarkArray];
//        
//        NSMutableArray *selectArray = [[NSMutableArray alloc]init];
//        [selectArray addObjectsFromArray:selectedGroups];
//        
//        groupcheckmarkArray = [[NSMutableArray alloc]init];
//        [groupcheckmarkArray addObjectsFromArray:tempArray];
//        
      //  selectedGroups = [[NSMutableArray alloc]init];
//        [selectedGroups addObjectsFromArray:selectArray];
        
        
       // [tempArray replaceObjectAtIndex:btnTagg.tag withObject:@"NO"];
        
        NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
        
        NSMutableArray *array = [NSMutableArray new];
        [array addObject:[userListArray objectAtIndex:btnTagg.tag]];
        for (NSDictionary *dicts in array) {
            
            [dictt addEntriesFromDictionary:dicts];
            
        }
        
        [dictt setObject:@"NO" forKey:@"checked"];
        [userListArray  replaceObjectAtIndex:btnTagg.tag withObject:dictt];
        
        NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
        
        [arrCheck addObject:dictt];
        for (int h = 0; h < [search_tableContents count]; h++) {
            if ([[arrCheck[0] valueForKey:@"firstName"] isEqualToString:[[search_tableContents  objectAtIndex:h] valueForKey:@"firstName"]]) {
                
                [search_tableContents replaceObjectAtIndex:h withObject:arrCheck[0]];
                
                
            }
            
        }

        
//        [groupcheckmarkArray replaceObjectAtIndex:btnTagg.tag withObject:@"NO"];
        
        
//        [selectedGroups removeObject: [userListArray valueForKey:@"personId"]objectAtIndex:btnTagg.tag]];
        NSLog(@"%@",selectedGroups);
        
//        
        NSString*strID = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"personId"] objectAtIndex:btnTagg.tag]];
//                          
        [selectedGroups removeObject: strID];
        NSLog(@"%@",selectedGroups);
        
    }
    else
    {
        [btnTag setImage:[UIImage imageNamed:@"select.png"] forState:UIControlStateNormal];
        NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
        
        NSMutableArray *array = [NSMutableArray new];
        [array addObject:[userListArray objectAtIndex:btnTagg.tag]];
        for (NSDictionary *dicts in array) {
            
            [dictt addEntriesFromDictionary:dicts];
            
        }
        
        [dictt setObject:@"YES" forKey:@"checked"];
        [userListArray  replaceObjectAtIndex:btnTagg.tag withObject:dictt];
        
        NSMutableArray*arrCheck = [[NSMutableArray alloc]init];
        
        [arrCheck addObject:dictt];
        for (int h = 0; h < [search_tableContents count]; h++) {
            if ([[arrCheck[0] valueForKey:@"firstName"] isEqualToString:[[search_tableContents  objectAtIndex:h] valueForKey:@"firstName"]]) {
                
                [search_tableContents replaceObjectAtIndex:h withObject:arrCheck[0]];
                
                
            }
            
        }
        
        NSString*strID = [NSString stringWithFormat:@"%@",[[userListArray valueForKey:@"personId"] objectAtIndex:btnTagg.tag]];
        
      //  [groupcheckmarkArray replaceObjectAtIndex:btnTagg.tag withObject:@"YES"];
        
        [selectedGroups addObject: strID ];

        
    }
    
    [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    
    
}



//    btnTag  = (UIButton*)sender ;
//    NSLog(@"%ld",(long)btnTag.tag);
//
//
//    NSString* indexx = [NSString stringWithFormat:@"%ld",(long)btnTag.tag];
//
//
//
//    if (!btnTag.selected) {
//        [btnTag setSelected:YES];
//        
//        [blockCheckedArray addObject: [[userListArray valueForKey:@"personId"] objectAtIndex:btnTag.tag]];
//        
//        [indexArr addObject:  [NSString stringWithFormat:@"%@",indexx]];
//        
//    }else{
//        
//        [btnTag setSelected:NO];
//        
//        [blockCheckedArray removeObject:[[userListArray valueForKey:@"personId"] objectAtIndex:btnTag.tag]];
//        
//        
//        
//        [indexArr removeObject:  [NSString stringWithFormat:@"%@",indexx]];
//        
//        NSLog(@"%@",indexArr);
//        
//        
//        
//    }
    
    

- (IBAction)CheckAllClicked:(id)sender {
    
    selectedGroups = [[NSMutableArray alloc]init];
    
    
    if (!_checkAllBtn.isSelected) {
        
        [_checkAllBtn setSelected:YES];
        
        
        
        for (int j=0; j<[userListArray count]; j++)
        {
            
            
            NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
            
            NSMutableArray *array = [NSMutableArray new];
            [array addObject:[userListArray objectAtIndex:j]];
            for (NSDictionary *dicts in array) {
                
                [dictt addEntriesFromDictionary:dicts];
                
            }
            
            [dictt setObject:@"YES" forKey:@"checked"];
            [userListArray  replaceObjectAtIndex:j withObject:dictt];

           // [groupcheckmarkArray replaceObjectAtIndex:j withObject:@"YES"];
            [selectedGroups addObject: [[userListArray valueForKey:@"personId"] objectAtIndex:j]];
            
        }
        
        
    }else{
        
        [_checkAllBtn setSelected:NO];
        for (int j=0; j<[userListArray count]; j++) // Number of Rows count
        {
            
            for (int j=0; j<[userListArray count]; j++)
            {
                
                NSMutableDictionary *dictt = [[NSMutableDictionary alloc]init];
                
                NSMutableArray *array = [NSMutableArray new];
                [array addObject:[userListArray objectAtIndex:j]];
                for (NSDictionary *dicts in array) {
                    
                    [dictt addEntriesFromDictionary:dicts];
                    
                }
                
                [dictt setObject:@"NO" forKey:@"checked"];
                [userListArray  replaceObjectAtIndex:j withObject:dictt];

               // [groupcheckmarkArray replaceObjectAtIndex:j withObject:@"NO"];
                
                [selectedGroups removeObject: [[userListArray valueForKey:@"personId"] objectAtIndex:j]];
                
                
                
            }
            
            
            
        }
        
        
        
    }
    
    
    [self.tableView reloadData];
  
    
}

-(void)GetProfileFromServer{
    
    NSDictionary *headers = @{ @"token": Tokenid,
                               @"cache-control": @"no-cache",
                               @"postman-token": @"5c8c4abb-a239-f17b-0991-dcdb17e4af81" };
    
    NSString *str = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/person/secure/getperson?cmpId=%@&filterType=ALL&page=20&limit=20",companyId];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"GET"];
    [request setAllHTTPHeaderFields:headers];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                        
                                                        if (data != nil) {
                                                            profileData =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                                            
                                                        }
                                                        
                                                        
                                                        
                                                        [self performSelectorOnMainThread:@selector(getuserDetails) withObject:nil waitUntilDone:YES];
                                                        
                                                        
                                                    }
                                                }];
    [dataTask resume];
    
    
}

-(void)getuserDetails{
    
    

    
       int count = 0 ;
    userListArray = [[NSMutableArray alloc]init];
    NSMutableArray* ListArray = [[NSMutableArray alloc]init];
    ListArray = [profileData valueForKey:@"prsnData"];
 
    NSString*strPersonIds = self.txtTextViewAddGroup.text ;
    
    
    
    
    
    
    
    
    
    NSArray *pId = [strPersonIds componentsSeparatedByString:@","];
    NSLog(@"%@",pId);
    
    
    NSArray*arrayP = [ListArray valueForKey:@"personId"];

    NSString*personIdd = [[NSUserDefaults standardUserDefaults]valueForKey:@"personId"];
    
    double idPerson = [personIdd doubleValue];
    
    
    NSMutableArray*listArrayy = [[NSMutableArray alloc]init];
    userListArray = [[NSMutableArray alloc]init];
    
    
    for (NSDictionary *dict in ListArray){
        
        
        NSString*list = [NSString stringWithFormat:@"%@",[dict valueForKey:@"empSts"]];
        NSString*roleNme = [NSString stringWithFormat:@"%@",[dict valueForKey:@"role"]];
        
        NSMutableDictionary *dicData = [[NSMutableDictionary alloc]init];
        
        [dicData addEntriesFromDictionary:dict];
        [dicData setValue:@"NO" forKey:@"checked"];

        
        if ([list isEqualToString:@"1"]) {
            
            if ([[dict valueForKey:@"personId"] isEqual:[NSNumber numberWithDouble:idPerson]]) {
                
            }else{
            
            [userListArray addObject:dicData];
                
            }
            
            
        }
        
        
        
    }
    
    search_tableContents = [[NSMutableArray alloc]initWithArray:userListArray];
    for (int j=0; j<[userListArray count]; j++) // Number of Rows count
    {
        
        
        [groupcheckmarkArray addObject:@"NO"];
        
        
        
        
    }
    
    [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    
    
}


- (IBAction)backBtn:(id)sender {
    
    [self.addGroupView setHidden:YES];
    
     
}

- (IBAction)btnSave:(id)sender {
    
    self.addGroupView.hidden = YES;
    
    
   joinedString = [selectedGroups componentsJoinedByString:@","];
    
    _txtTextViewAddGroup.text = joinedString ;
    
    [[NSUserDefaults standardUserDefaults]setObject:selectedGroups forKey:@"selectedGroup"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:userListArray];
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"groupCheck"];
    [[NSUserDefaults standardUserDefaults]synchronize];

    
//   [[NSUserDefaults standardUserDefaults]setObject:userListArray forKey:@"groupCheck"];
//    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    
    
    
    
}

-(void)CreateGroup{
        
    
    
    NSDictionary *headers = @{ @"content-type": @"application/json",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"114064f8-851c-fbfd-d2a4-1d246fcf7aec" };
    NSDictionary *parameters = @{ @"cmpId": companyId,
                                  @"grpDesc":  _txtGroupDescription.text,
                                  @"grpName": _txtGroupName.text,
                                  @"hostId": personId,
                                  @"personId": selectedGroups};
    
    
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/group/secure/addgroup"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    [request setValue:Tokenid forHTTPHeaderField:@"token"];
    
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                        id  updateUser =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                                        
                                                        [self performSelectorOnMainThread:@selector(pushBack) withObject:nil waitUntilDone:YES];
                                                        
                                                        
                                                        NSLog(@"%@",updateUser);
                                                        
                                                        
                                                        
                                                        
                                                    }
                                                }];
    [dataTask resume];
}


-(void)pushBack{
    
    [self.navigationController popViewControllerAnimated:YES];
    
}


-(void)updateDataFromServer{
    
    

    
    
    NSDictionary *headers = @{ @"content-type": @"application/json",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"114064f8-851c-fbfd-d2a4-1d246fcf7aec" };
    
    
   
       NSMutableArray *arr = [self.editDetailArray mutableCopy];
    
    
    
    NSString*strPersonIds = [NSString stringWithFormat:@"%@",_txtTextViewAddGroup.text];
    
    arrPersonId = [strPersonIds componentsSeparatedByString:@","];
    NSLog(@"%@",arrPersonId);
    
    
    
    NSString *cmpId = [arr valueForKey:@"cmpId"];
 
    
    
    NSMutableDictionary* parameters = [[NSMutableDictionary alloc] init];
    [parameters setObject:cmpId forKey:@"cmpId"];
    [parameters setObject:self.txtGroupDescription.text forKey:@"grpDesc"];
    [parameters setObject:[arr valueForKey:@"grpId"] forKey:@"grpId"];
        [parameters setObject:[arr valueForKey:@"grpSts"] forKey:@"grpSts"];
        [parameters setObject:[arr valueForKey:@"hostId"] forKey:@"hostId"];
    [parameters setObject:arrPersonId forKey:@"personId"];
    [parameters setObject:self.txtGroupName.text forKey:@"grpName"];
    [parameters setObject:[arr valueForKey:@"totalmember"] forKey:@"totalmember"];
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://182.76.44.135:8080/demogomobile/group/secure/editgroup"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"PUT"];
    [request setAllHTTPHeaderFields:headers];
    [request setValue:Tokenid forHTTPHeaderField:@"token"];
    [request setHTTPBody:postData];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                        id  updateUser =  [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error: &error];
                                                        
                                                        
                                                        NSLog(@"%@",updateUser);
                                                        
                                                        
                                                        [self performSelectorOnMainThread:@selector(uPDATE) withObject:nil waitUntilDone:YES];
                                                        
                                                        
                                                        
                                                        
                                                    }
                                                }];
    [dataTask resume];
}

-(void)uPDATE{
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
    return YES;
    
}



-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText

{
   
        
        NSMutableArray *arrSearch = [[NSMutableArray alloc]init];
        // arrSearch = [[NSMutableArray alloc]initWithArray: [userListArray valueForKey:@"firstName"]];
        
        NSString *searchTextt = self.searchBar.text ;
        
        
        
        userListArray = [[NSMutableArray alloc] initWithArray:search_tableContents];
        
        if ([searchText isEqualToString:@""]) {
            [self.tableView reloadData];
            
            
            
        }else{
            NSPredicate *predicate = [NSPredicate
                                      predicateWithFormat:@"SELF.firstName contains %@",
                                      searchText];
            
            userListArray = [NSMutableArray arrayWithArray:[userListArray filteredArrayUsingPredicate:predicate]];
            NSLog(@"filtered count %lu ",(unsigned long)userListArray.count);
            
            [self.tableView reloadData];
        }
        
        
        
        
        
        
    }
    





-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar

{
    
    
    [self.searchBar resignFirstResponder];
    
    
    
}


- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    
    //hide keyboard
    
    [_searchBar resignFirstResponder];
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([UIScreen mainScreen].bounds.size.width== 768 || [UIScreen mainScreen].bounds.size.width== 1024) {
        
        return 100 ;
    }else{
        
            
            return  44 ;
            
        }
        
        
    }
@end
