//
//  ViewController.m
//  chart
//
//  Created by katoch on 01/06/17.
//  Copyright © 2017 katoch. All rights reserved.
//

#import "PlanSummary.h"
#import "LegendPlanSumryTableViewCell.h"
@interface PlanSummary ()<XYPieChartDelegate,XYPieChartDataSource,NSURLSessionDelegate,NSURLSessionDataDelegate,DropDownViewDelegate,UITableViewDelegate,UITableViewDataSource>
{
    NSString *strignmonth;
    NSString *Tokenstr;
    NSMutableArray *legendArray;
    NSMutableArray*legendColorArr;
}

@end

@implementation PlanSummary

- (void)viewDidLoad {
    [super viewDidLoad];
    
    legendArray = [[NSMutableArray alloc]init];
    legendColorArr = [[NSMutableArray alloc]init];
    
//    Tokenstr = @"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MDExMDU2MTg3OlJPTEVfU1VQRVJfQURNSU46MTc3MCIsImlhdCI6MTQ5NDgzNDE4OH0.YrwI-7Ma2bqZE58yTRjB79rgXn0g8jzyi58aK_C3DXg";
     Tokenstr = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];
    
    
    // NSMutableArray *array = [[NSMutableArray alloc]init];
    dropDownListArray = [NSMutableArray new];
    
    
    _txtselectDepartmentOrHost.rightViewMode = UITextFieldViewModeAlways;
    _txtselectDepartmentOrHost.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    _txtMonth.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    
    _txtYears.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    
    [self.view bringSubviewToFront:_txtYears.rightView];
    [self.view bringSubviewToFront:_txtMonth.rightView];
    [self.view bringSubviewToFront:_txtselectDepartmentOrHost.rightView];
    

    
    _txtMonth .text = @"jan";
    
    _txtYears.text = @"2017";
    
    monthsCount = [NSMutableArray new];
    
    SelctDpOrHostArray = [[NSMutableArray alloc]initWithObjects:@"Plan used by Department",@"Plan used by Host", nil];
    
    SelctMonthArray = [[NSMutableArray alloc]initWithObjects:@"Jan",@"Feb",@"Mar",@"Apr",@"May",@"Jun",@"Jul",@"Aug",@"Stp",@"Oct",@"Nov",@"Dev", nil];
    
    
    
    selectYearArray = [NSMutableArray arrayWithObjects:@"2017",@"2016",@"2015",@"2014",@"2013",@"2012", nil];
    
    _lablSelectValue.text = [NSString stringWithFormat:@"Plan used by %@ in %@ month",_txtselectDepartmentOrHost.text,_txtMonth.text];
    
    
    strignmonth = @"01";
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (textField == self.txtselectDepartmentOrHost)
    {
        self.dropDownTxtfield = textField ;
        
        [self SelectChoiceMethod];
        
    }
    
    else if(textField == self.txtYears)
        
    {
        
        self.dropDownTxtfield = textField ;
        
        [self YearMethod];
    }else
        
    {
        self.dropDownTxtfield = textField ;
        
        
        [self MonthMethod];
    }
    
    
    
    
    //
    return NO ;
    
}


-(void)SelectChoiceMethod
{
    if (dropDownView != nil) {
        
        [dropDownView.view removeFromSuperview];
        
        dropDownView = nil;
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:SelctDpOrHostArray cellHeight:40 heightTableView:120 paddingTop:self.viewBackButtons.frame.origin.y  paddingLeft:self.viewBackButtons.frame.origin.x paddingRight:0 refView:self.txtselectDepartmentOrHost animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    
    
}

-(void)YearMethod
{
    if (dropDownView != nil) {
        
        [dropDownView.view removeFromSuperview];
        
        dropDownView = nil;
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:selectYearArray cellHeight:40 heightTableView:210 paddingTop:self.viewBackButtons.frame.origin.y  paddingLeft:self.viewBackButtons.frame.origin.x paddingRight:0 refView:_txtYears animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    
    
}

-(void)MonthMethod{
    
    if (dropDownView != nil)
        
    {
        
        [dropDownView.view removeFromSuperview];
        
        dropDownView = nil;
        
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:SelctMonthArray cellHeight:40 heightTableView:280 paddingTop:self.viewBackButtons.frame.origin.y  paddingLeft:self.viewBackButtons.frame.origin.x paddingRight:0 refView:_txtMonth animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    
}

-(void)dropDownCellSelected:(NSInteger)returnIndex{
    
    
    if (_dropDownTxtfield == self.txtselectDepartmentOrHost)
        
    {
        [dropDownView openAnimation];
        
        self.txtselectDepartmentOrHost.text = [SelctDpOrHostArray objectAtIndex:returnIndex];
        //       //  _txtselectDepartmentOrHost.text = @"Department";
        
        if ([_txtselectDepartmentOrHost.text isEqualToString:@"Plan used by Department"])
            
        {
            
            _lablSelectValue.text = [NSString stringWithFormat:@"%@ in %@ month",_txtselectDepartmentOrHost.text,_txtMonth.text];
            
            _txtselectDepartmentOrHost.text = @"Department";
            
            [self yearData];
            
        }else if ([_txtselectDepartmentOrHost.text isEqualToString:@"Plan used by Host"])
            
        {
            
            _lablSelectValue.text = [NSString stringWithFormat:@"%@ in %@ month",_txtselectDepartmentOrHost.text,_txtMonth.text];
            
            _txtselectDepartmentOrHost.text = @"Host";
            
            [self yearData];
            
        }
        
        
    }
    
    else if(_dropDownTxtfield == self.txtYears)
        
    {
        [dropDownView openAnimation];
        
        self.txtYears.text = [selectYearArray objectAtIndex:returnIndex];
        
        [self yearData];
        
    }
    
    else if(_dropDownTxtfield == self.txtMonth)
        
    {
        [dropDownView openAnimation];
        
        self.txtMonth.text = [SelctMonthArray objectAtIndex:returnIndex];
        
        _lablSelectValue.text = [NSString stringWithFormat:@"Plan used by %@ in %@ month",_txtselectDepartmentOrHost.text,_txtMonth.text];
        
        for (int i = 1; i<= [SelctMonthArray count] ; i++)
            
        {
            
            NSString *strMonth   = [NSString stringWithFormat:@"0%d",i];
            NSLog(@"%@",strMonth);
            
            
            [monthsCount addObject:strMonth];
            
            ///  [array addObject:[NSString stringWithFormat:@"%d",i]];
            
        }
        
        strignmonth= [monthsCount objectAtIndex:returnIndex];
        NSLog(@"%@",strignmonth);
        [self yearData];
        
    }
    
    [dropDownView closeAnimation];
    
}



-(void)yearData
{
    
    NSString *CompanyId = @"1770";
    NSString *MonthYear = [NSString stringWithFormat:@"%@-%@",strignmonth,_txtYears.text];
    NSString *filter = _txtselectDepartmentOrHost.text;
    
    filter = [filter stringByReplacingOccurrencesOfString:@"Plan used by " withString:@""];
    
    NSString * apiURLStr = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/dashboard/secure/departmentplanusesbymonth?cmpId=%@&monthyear=%@&filter=%@",CompanyId,MonthYear,filter];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    NSURL*LinkUrl = [NSURL URLWithString:apiURLStr];
    NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:LinkUrl cachePolicy:
                                            
                                            NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    [SendingRequest addValue:Tokenstr forHTTPHeaderField:@"token"];
    
    
    [SendingRequest addValue:@"token" forHTTPHeaderField:@"Authorization"];
    
    [SendingRequest setHTTPMethod:@"GET"];
    
    
    NSURLSessionDataTask *postData = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                      
                                      {
                                          dispatch_async(dispatch_get_main_queue(),^
                                                         {
                                                             NSError* error;
                                                            
                                                                 cities =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                                                                 NSLog(@"%@",cities);
                                                                 
                                                                 NSString *MsgSuccess = [NSString stringWithFormat:@"%@",[cities valueForKey:@"message"]];
                                                                 
                                                                 if ([MsgSuccess isEqualToString:[cities valueForKey:@"message"]]) {
                                                                     
                                                                     [self performSelectorOnMainThread:@selector(pieChartView) withObject:nil waitUntilDone:YES];
                                                                     
                                                                 }
                                                                 else {
                                                                     NSLog(@"the data is empty");
                                                                 }
                                                                 //                                              NSString*succ = @"success";
                                                             
                                                         });
                                          
                                          
                                      }];
    [postData resume];
}
-(void)pieChartView
{
    
    
  //  self.pieChartLeft.frame =  CGRectMake(self.graphvieeww.frame.origin.x+20, self.graphvieeww.frame.origin.y+130, self.graphvieeww.frame.size.width, self.graphvieeww.frame.size.width);
    
    
    [self.pieChartLeft setDataSource:self];
    [self.pieChartLeft setStartPieAngle:M_PI_2];
    [self.pieChartLeft setAnimationSpeed:1.0];
    [self.pieChartLeft setLabelFont:[UIFont fontWithName:@"DBLCDTempBlack" size:12]];
    [self.pieChartLeft setLabelColor:[UIColor whiteColor]];
    [self.pieChartLeft setLabelRadius:80];
    [self.pieChartLeft setShowPercentage:NO];
    [self.pieChartLeft setPieBackgroundColor:[UIColor colorWithWhite:0.95 alpha:1]];
    [self.pieChartLeft setPieCenter:CGPointMake(self.graphvieeww.frame.size.width+190, self.graphvieeww.frame.size.height+130)];
    [self.pieChartLeft setUserInteractionEnabled:NO];
    [self.pieChartLeft setLabelShadowColor:[UIColor blackColor]];
    
    
    self.sliceColors =[NSArray arrayWithObjects:
                       [UIColor  redColor],
                       [UIColor greenColor],
                       [UIColor yellowColor],
                       [UIColor blueColor],
                       [UIColor grayColor],nil];
    
    
    
    long account = [[[cities valueForKey:@"departmentuses"]valueForKey:@"Accounts"] longValue];
    NSLog(@"%ld",account);
    
    long admin =  [[[cities valueForKey:@"departmentuses"]valueForKey:@"Administration"] longValue];
    NSLog(@"%ld",admin);
    
    long manage = [[[cities valueForKey:@"departmentuses"]valueForKey:@"Management"]longValue];
    NSLog(@"%ld",manage);
    
    
    long market =[[[cities valueForKey:@"departmentuses"]valueForKey:@"Marketing"]longValue];
    NSLog(@"%ld",market);
    
    
    long tech =[[[cities valueForKey:@"departmentuses"]valueForKey:@"Technical"]longValue];
    NSLog(@"%ld",tech);
    
    
    NSString *accountData = [NSString stringWithFormat:@"%ld",account];
    
    NSString *Administration = [NSString stringWithFormat:@"%ld",admin];
    
    
    NSString *Management = [NSString stringWithFormat:@"%ld",manage];
    
    NSString *Marketing = [NSString stringWithFormat:@"%ld",market];
    
    NSString *Technical = [NSString stringWithFormat:@"%ld",tech];
    
    self.slices= [[NSMutableArray alloc]initWithObjects:accountData,Administration,Management,Marketing,Technical, nil];
    
    [self.pieChartLeft reloadData];
    
    [self.graphvieeww addSubview:self.pieChartLeft];
    
}

// Do any additional setup after loading the view, typically from a nib.




- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

#pragma mark - XYPieChart Data Source

- (NSUInteger)numberOfSlicesInPieChart:(XYPieChart *)pieChart
{
    return self.slices.count;
}

- (CGFloat)pieChart:(XYPieChart *)pieChart valueForSliceAtIndex:(NSUInteger)index
{

    return [[self.slices objectAtIndex:index] intValue];
}

- (UIColor *)pieChart:(XYPieChart *)pieChart colorForSliceAtIndex:(NSUInteger)index
{
    [legendColorArr addObject:[self.sliceColors objectAtIndex:(index % self.sliceColors.count)]];
    return [self.sliceColors objectAtIndex:(index % self.sliceColors.count)];
    
}

#pragma mark - XYPieChart Delegate
- (void)pieChart:(XYPieChart *)pieChart willSelectSliceAtIndex:(NSUInteger)index
{
    NSLog(@"will select slice at index %d",index);
}
- (void)pieChart:(XYPieChart *)pieChart willDeselectSliceAtIndex:(NSUInteger)index
{
    NSLog(@"will deselect slice at index %d",index);
}
- (void)pieChart:(XYPieChart *)pieChart didDeselectSliceAtIndex:(NSUInteger)index
{
    NSLog(@"did deselect slice at index %d",index);
}
- (void)pieChart:(XYPieChart *)pieChart didSelectSliceAtIndex:(NSUInteger)index
{
    NSLog(@"did select slice at index %d",index);
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [legendColorArr count];
}
-(LegendPlanSumryTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString*cellid =@"cell";
    
    LegendPlanSumryTableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellid];
    
    if (cell==nil)
    
    {
        
        NSArray* cellname=[[NSBundle mainBundle]loadNibNamed:@"LegendPlanSumryTableViewCell" owner:nil options:nil];
        
        // cell= [[LegendPlanSumryTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
        
        cell = cellname[0];
    }
    
  //  cell.lbllegendColour.backgroundColor= [UIColor ]
    
    
    
    
    
    return cell;
}



- (IBAction)planBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}
@end
