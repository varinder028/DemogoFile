//
//  MeetingCell.h
//  DemogoApplication
//
//  Created by katoch on 25/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeetingCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *txtStartTime;
@property (strong, nonatomic) IBOutlet UILabel *txtDate;
@property (strong, nonatomic) IBOutlet UILabel *txtEndTime;
@property (strong, nonatomic) IBOutlet UILabel *textChairPerson;
@property (strong, nonatomic) IBOutlet UIButton *btnEdit;
@property (strong, nonatomic) IBOutlet UIButton *btnDelete;
@property (strong, nonatomic) IBOutlet UIButton *btnDownload;

@end
