//
//  CorporateContDetailViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 03/02/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CorporateContDetailViewController : UIViewController

@end
