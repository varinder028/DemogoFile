//
//  SubscriptionViewViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 04/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ViewController.h"

@interface SubscriptionViewViewController : ViewController


@property (strong, nonatomic) IBOutlet UISegmentedControl *segment;
- (IBAction)SegmentControllerButton:(id)sender;



 ////     . . . . .    Label create change Value
@property (strong, nonatomic) IBOutlet UILabel *SixthDAP500xxxxLabel;
@property (strong, nonatomic) IBOutlet UILabel *FIfthDap2500LAbel;
@property (strong, nonatomic) IBOutlet UILabel *FourthDAP2500Label;
@property (strong, nonatomic) IBOutlet UILabel *THirdDAP2500Label;
@property (strong, nonatomic) IBOutlet UILabel *SecondDAP2500LAbel;
@property (strong, nonatomic) IBOutlet UILabel *FirstDAP2500LAbel;




@property (strong, nonatomic) IBOutlet UILabel *FirstLAbelView2500;

@property (strong, nonatomic) IBOutlet UILabel *FirstLAbelView0;

@property (strong, nonatomic) IBOutlet UILabel *SecondLabelVIew2500;

@property (strong, nonatomic) IBOutlet UILabel *SecondLAbelVIew0;


@property (strong, nonatomic) IBOutlet UILabel *thirdLAbelView2500;

@property (strong, nonatomic) IBOutlet UILabel *ThirdLAbelView0;

@property (strong, nonatomic) IBOutlet UILabel *FourthLAbelView2500;

@property (strong, nonatomic) IBOutlet UILabel *FOurthAlbelVIew0;


@property (strong, nonatomic) IBOutlet UILabel *FIfthLabelVIew2500;
@property (strong, nonatomic) IBOutlet UILabel *FifthVIewLAbel0;


@property (strong, nonatomic) IBOutlet UILabel *SixthLAbelView2500;
@property (strong, nonatomic) IBOutlet UILabel *SixthLAbelVIew0;

@end
