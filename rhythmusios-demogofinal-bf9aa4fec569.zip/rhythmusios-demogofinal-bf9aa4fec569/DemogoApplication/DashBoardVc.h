//
//  DashBoardVc.h
//  DemogoApplication
//
//  Created by katoch on 25/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClockView.h"


@interface DashBoardVc : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource>{
    
    NSString*RoleStr;
    NSMutableArray*dashArray;
    NSMutableArray*imgArray;
    
    ClockView *clockView;
    
}
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *bottomCv;
@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (strong, nonatomic) IBOutlet UIView *clockView;

@property (strong, nonatomic) IBOutlet UILabel *TxtDate;
@property (strong, nonatomic) IBOutlet UILabel *txtMonth;

@property (strong, nonatomic) IBOutlet UILabel *txtTime;

- (IBAction)MapButton:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnMap;

- (IBAction)btnMeeting:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnMeeting;
- (IBAction)palnSummaryClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnPlanSummry;
- (IBAction)btnBugget:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnBuggetSummary;

- (IBAction)btnBillGraph:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *BtnBillgraph;

@property (strong, nonatomic) IBOutlet UIView *viewDateOrClock;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *heigthClockView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *widthMap;

@end
