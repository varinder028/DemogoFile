//
//  LiveParticipantCell.m
//  nbng
//
//  Created by Rhythmus on 28/04/17.
//  Copyright © 2017 Rhythmus. All rights reserved.
//

#import "LiveParticipantCell.h"

@implementation LiveParticipantCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
