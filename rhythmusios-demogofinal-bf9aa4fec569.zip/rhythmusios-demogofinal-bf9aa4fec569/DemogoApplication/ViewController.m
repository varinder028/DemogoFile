//
//  ViewController.m
//  DemogoApplication
//
//  Created by varinder singh on 1/23/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ViewController.h"
#import "LoginOTPViewController.h"
#import "corporateLoginViewController.h"
#import <CoreLocation/CoreLocation.h>
#import "ForgotPAsViewController.h"
#import "LogSucessPasswordViewController.h"
#import "AppDelegate.h"
#import "TabView.h"
#import <MF_Base64Additions.h>
#import "KVNProgress.h"
#import <AFNetworking/AFNetworking.h>


@interface ViewController ()<CLLocationManagerDelegate,NSURLSessionDelegate,NSURLSessionDataDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIScrollViewDelegate>

{
    
    NSMutableDictionary *GETIDRESONSE;
    NSMutableString *getPersonID;
    NSString *FIRSTflag;
    NSString *passMobile;
    NSMutableString * Participant;
    NSMutableString * NAmeList;
    NSString *passResnedOTP;
    NSDictionary *userEmailID;
    NSMutableString *EMAILDATA;
    
    
    NSMutableString *personIDString;
    LoginOTPViewController *otp;
    NSMutableArray *otpNumber;
    NSString *fetchOTP;
    NSString *matchNum;
    NSString *Base64encodePassword ;
    
    
    
    NSUserDefaults *saveData;
    UIImage * imagesize;
    NSAttributedString *str;
    NSAttributedString *strpass;
    
    
    
    
     id PassedJSonArray;
    NSString * urlstring;
    NSURL *url;
    NSMutableDictionary *GetDicDta;
    
    
    
    
    NSMutableArray *CompanydetailsArray;
    UITableViewCell *cell ;
    NSString *strids;
    NSString *latitude;
    
//    else if ([FIRSTflag isEqualToString:@"0"] && [passStatus isEqualToString:@"0"] ){
//        
//        [self sendToChangePssword];
//        
//        
//    }
    
    
    
    NSString *longitude;
    NSDictionary *mapData;
    NSMutableString * versionNo;
    NSMutableString *OperatingNa;
    
    
    
    
    
    NSArray *getResponse;
    NSDictionary *dataDict;
    NSMutableArray *arrayID;
    NSString *newDateString;
    
    
    
    
    
    NSString *strPassword;
    NSMutableArray *cmpanyArrayID;
    NSString *compId;
    NSString * otpRes;
    
    
    
    
    NSMutableString *FOrgotEmail ;
    UIAlertController * alertCompany;
}



@property (strong, nonatomic) IBOutlet UIImageView *passwordImage;


@property (strong, nonatomic) IBOutlet NSLayoutConstraint *secauto;


@property (strong, nonatomic) IBOutlet NSLayoutConstraint *thirdauto;


@property (weak, nonatomic) IBOutlet UITextField *usernameTextfield;

@property (weak, nonatomic) IBOutlet UITextField *passwordtextfeild;

- (IBAction)loginbutton:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *loginButtonOutlet;

@property (strong, nonatomic) IBOutlet UIImageView *userimageicon;

@property (strong, nonatomic) IBOutlet UIView *usericonView;

@property (strong, nonatomic) IBOutlet UIView *passView;

@property (strong, nonatomic) IBOutlet UIButton *signupOutlet;


@property (strong, nonatomic) IBOutlet UIImageView *cMPImage;


@property (strong, nonatomic) IBOutlet UIButton *NameCmpBTN;

@property (strong, nonatomic)NSMutableArray *CompanydetailsArray;


@property (strong, nonatomic) IBOutlet UIView *companyview;

- (IBAction)companyNameBTN:(id)sender;

- (IBAction)ForgetButton:(UIButton *)sender;

- (IBAction)signupButton:(UIButton *)sender;


@end



@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    _txtCompnay.rightViewMode = UITextFieldViewModeAlways;
    _txtCompnay.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop-down-arrow (2).png"]];
    [self.view bringSubviewToFront:_txtCompnay.rightView];

    
    tapScrollView = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(scrollTap)];
    [self.view addGestureRecognizer:tapScrollView];
    
    
    tapScrollView.delegate = self;
    dropDownListArray = [NSMutableArray new];
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.tabView setHidden:YES];
        _locationManager = [[CLLocationManager alloc] init];
    [self getLocation];
    [_usernameTextfield addTarget:self
                             action:@selector(textFieldDidChange:)
                   forControlEvents:UIControlEventEditingChanged];
   
    
    GETIDRESONSE = [[NSMutableDictionary alloc]init];
    
    getPersonID = [[NSMutableString alloc]init];
    
    Participant = [[NSMutableString alloc]init];
    
    passMobile = [[NSString alloc]init];
    
    NAmeList = [[NSMutableString alloc]init];
    
    EMAILDATA =[[NSMutableString alloc]init];
    
    userEmailID = [[NSDictionary alloc]init];
    
    matchNum = [[NSString alloc]init];
    
    fetchOTP = [[NSString alloc]init];
    
    FIRSTflag = [[NSString alloc]init];
    
    passResnedOTP = [[NSString alloc]init];
    
    PassedJSonArray = [[NSMutableDictionary alloc]init];
    
    otpNumber = [[NSMutableArray alloc]init];
    
    CompanydetailsArray = [[NSMutableArray alloc]init];
    
    arrayID = [[NSMutableArray alloc]init];
    
    cmpanyArrayID = [[NSMutableArray alloc]init];
    
    
    //////////////////////////////////------------------------
    
    
    _txtCompanyHeight.constant = 0 ;
    [self.view layoutIfNeeded];
    
    
    
    
    
    matchNum =@"user exist";
    
    
    
    
    
    ///////////////////////////////////   --------------------------------
    
    
    
    
    
    versionNo= [[NSMutableString alloc]initWithFormat:@"%@",[UIDevice currentDevice].systemVersion];
    
    OperatingNa= [[NSMutableString alloc]initWithFormat:@"%@",[UIDevice currentDevice].systemName];
    
    NSLog(@"%@",versionNo);
    
    NSLog(@"%@",OperatingNa);
   
    
//    CLLocationCoordinate2D coordinate = [self getLocation];
//    
//    latitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
//    
//    longitude = [NSString stringWithFormat:@"%f", coordinate.longitude];
//    
//    NSLog(@"*dLatitude : %@", latitude);
//    
//    NSLog(@"*dLongitude : %@",longitude);
 
    
    
    /////////>>>>>>>>      Current Location Time UserLogin       >>>>>>>>>////////
    
    
    NSDate * now = [NSDate date];
    
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    
    [outputFormatter setDateFormat:@"hh:mm:ss"];
    
    NSString * newDat = [outputFormatter stringFromDate:now];
    
    newDateString  = [NSString stringWithFormat:@"%ld", (long)[newDat longLongValue]];
    
    NSLog(@"newDateString %@", newDateString);
    
    
    
    
    
    
    
    
    //////////   UsertextField    placeholder edit textfield     /////////
    
    self.usernameTextfield.delegate=self;
    
    str=[[NSAttributedString alloc]
         
         initWithString:@"Email Id/Mobile Number"
         
         attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.usernameTextfield.attributedPlaceholder=str;
    
    [self.usernameTextfield addTarget:self action:@selector(resignFirstResponder) forControlEvents:
     
     UIControlEventEditingDidEndOnExit];
    
    
    
    strpass=[[NSAttributedString alloc]
             
             initWithString:@"Password"
             
             attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.passwordtextfeild.attributedPlaceholder=strpass;
    
    
    
   NSAttributedString*selectComp=[[NSAttributedString alloc]
             
                                  initWithString:@"Select Company"
             
             attributes:@{NSForegroundColorAttributeName :[UIColor grayColor] }];
    
    self.txtCompnay.attributedPlaceholder = selectComp ;
  
    
    ///////// button redius , UserTextField,passtextField size edit  /////////
    
    self.signupOutlet.layer.cornerRadius = 12;
    
    self.loginButtonOutlet.layer.cornerRadius = 5.5;
    
    self.usernameTextfield.frame = CGRectMake(56, 234, 302, 50);
    
    self.passwordtextfeild.frame = CGRectMake(56, 338, 302, 50);
    
    ///////// button redius , User,pass image   size edit  /////////
    
    
    //self. usernameTextfield.layer.shadowRadius = 35.0;
    
    self.usericonView .layer.cornerRadius= 10.0;
    
    self.passView .layer.cornerRadius= 10.0;
    
    self.companyview.layer.cornerRadius = 10.0;
    
    
}


- (void)viewDidAppear:(BOOL)animated{
    NSLog(@"viewDidAppear loaded successfully");
    
}




-(void)viewWillAppear:(BOOL)animated

    {
            self.CompanydetailsArray=[[NSMutableArray alloc]init];
    
                [super viewWillAppear:animated];
        
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"AlreadyLogin"];
        [[NSUserDefaults standardUserDefaults]synchronize];

        
        
    }


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}



      //////////.......... Current Location Find Method  (Get Location)  ...........//////

//-(CLLocationCoordinate2D) getLocation
//
//
//    {
//    
//    
//        CLLocationManager *locationManager = [[CLLocationManager alloc] init] ;
//   
//                locationManager.delegate = self;
//    
//                    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
//   
//                        locationManager.distanceFilter = kCLDistanceFilterNone;
//    
//                            [locationManager startUpdatingLocation];
//   
//                                CLLocation *location = [locationManager location];
//   
//                                    CLLocationCoordinate2D coordinate = [location coordinate];
//    
//    return coordinate;
//}





  - (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


                    //////////////    Email send Second Api ////////////////


-(void)SaveDataSecondApi

{
    
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable) {
        UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message: @"No Network Connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        [alert show];
        return;
        
    }
    else
//        http://182.76.44.148:8081
//        http://182.76.44.135:8080
//  http://182.76.44.135:8080/demogomobile
//        http://192.168.1.94:4000
        
    urlstring  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/company/getemaildetails?email=%@",self.usernameTextfield.text];
    
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    
            NSURLSession *sessionData = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    
    
                url = [NSURL URLWithString:urlstring];
    
                        NSMutableURLRequest * SendingRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:
                                            
                        NSURLRequestUseProtocolCachePolicy timeoutInterval:100.0];
                                [SendingRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
                                    [SendingRequest setHTTPMethod:@"GET"];
    
    GetDicDta = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.usernameTextfield.text,@"email",nil];
    
        NSLog(@"%@",[SendingRequest allHTTPHeaderFields]);
    
    NSURLSessionDataTask *postDataTask = [sessionData dataTaskWithRequest:SendingRequest completionHandler:^(NSData* data, NSURLResponse* response, NSError* error)
                                          
                {
                   
                        NSString *theXML = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                
                                NSLog(@" the databse theXml is  =====  %@",theXML);
                                
                                            NSData *data1 =[theXML dataUsingEncoding:NSUTF8StringEncoding];
                                
                    
                                                    userEmailID = [NSJSONSerialization JSONObjectWithData:data1 options:kNilOptions error:&error];
                    
                    
                    
                    
                    [self performSelectorOnMainThread:@selector(ShowCompanyField) withObject:nil waitUntilDone:YES];
                   
                    
                    
                    NSLog(@" the email deatils is  =   %@",EMAILDATA);
                    
                    NSLog(@"the email response is = %@",userEmailID);

                 
                    
                                              
                }];
    
    
    [postDataTask resume];
    
    
}


-(void)ShowCompanyField{
    
    
    EMAILDATA = [userEmailID valueForKey:@"message"];
    
    
    if ([EMAILDATA isEqualToString:@"Email ID Do not exist"]) {
        NSLog(@" EEE E E E  E E E E E E E  R R R R R R R R  R   O O O O OO O O O  RR  R R R R R  R");
        
      UIAlertView* alertEmail=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the correct emailId/Mobile Number" delegate:self cancelButtonTitle:@"ok" otherButtonTitles: nil];
        
        _txtCompanyHeight.constant = 0 ;
        [self.view layoutIfNeeded];
        
        [alertEmail show];
        
        [_usernameTextfield becomeFirstResponder];
        
        
        
    }
    else if ([EMAILDATA isEqualToString:@"success"]){
        
        
        
        companyNameArray = [[userEmailID objectForKey:@"cmpList"]valueForKey:@"cmpNm"];
        _txtCompanyHeight.constant = 50 ;
        
        [self.view layoutIfNeeded];
        
        
       [self performSelectorOnMainThread:@selector(companyDatatable) withObject:nil waitUntilDone:YES];
        
        
        
    }

    
    
    
    
 //   if ([[arr valueForKey:@"message"] isEqualToString:@"Email ID Do not exist"]) {
//        _txtCompanylayout.constant = 0 ;
//        _imgCompanyLayout.constant = 0 ;
//        _lblHeightLayout.constant = 0;
//        [self.view layoutIfNeeded];
//        
//        alertEmail=[[UIAlertView alloc]initWithTitle:nil message:@"Please enter the correct emailId/Mobile Number" delegate:self cancelButtonTitle:@"ok" otherButtonTitles: nil];
//        
//        [alertEmail show];
//        
//        isError = YES;
//        
//        [_EmailIdMobileNumber becomeFirstResponder];
//        
//        
//    }else{
//        
//        _txtCompanylayout.constant = 30 ;
//        _imgCompanyLayout.constant = 28 ;
//        _lblHeightLayout.constant = 1;
//        
//        _imgTopLayout.constant = 29 ;
//        _topCompanyLayout.constant = 19;
//        _topLblLayout.constant = 8 ;
//        
//        [self.view layoutIfNeeded];
//        
//        
//        
//        [self.view layoutIfNeeded];
//        
//        isError = NO;
//        
//        
//    }
    
}



-(void)companyDatatable{
    
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    
    long maxHeight = 250 ;
    long  TableHeight = companyNameArray.count *30 ;
    
    
    if (TableHeight >=maxHeight ) {
        
        TableHeight = 250 ;
    }
    else{
        
        TableHeight = companyNameArray.count *30 ;
        
    }
    
    dropDownView = [[DropDownView alloc] initWithArrayData:companyNameArray cellHeight:40 heightTableView:TableHeight paddingTop:self.companyview.frame.origin.y  paddingLeft:_companyview.frame.origin.x paddingRight:0 refView:_txtCompnay animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:0.5];
    
    dropDownView.delegate = self;
    
    [self.view addSubview:dropDownView.view];
    
    [self.view bringSubviewToFront:dropDownView.view];
    
    [dropDownView openAnimation];
    
    NSLog(@" SSS  SSSS  S S S S S  USUU U     UUUU  U U U  U");
    
    
    
}



-(void)dropDownCellSelected:(NSInteger)returnIndex{
   
    
    
    
        self.txtCompnay.text = [companyNameArray objectAtIndex:returnIndex];
    
    compId = [[[userEmailID objectForKey:@"cmpList"]valueForKey:@"cmpId"]objectAtIndex:returnIndex];
    
    
    [[NSUserDefaults standardUserDefaults]setValue:compId forKey:@"ComId"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [dropDownView closeAnimation];
        
    
}




- (BOOL)textFieldShouldReturn:(UITextField *)textField


{
    
        [self.usernameTextfield resignFirstResponder];
    
        [self.passwordtextfeild resignFirstResponder];
    
    


    
    
    
    
//        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Select Company Name\n Your UserId Is"
//               
//             message:self.usernameTextfield.text preferredStyle:UIAlertControllerStyleAlert];
//    
//    
//    
//    
//    ////////    ......................Create Button On alert Notification ......................
//    
//        UIAlertAction* SelectCompany = [UIAlertAction actionWithTitle:@"CompanyName" style:UIAlertActionStyleDefault
//                                        
//            handler:^(UIAlertAction * action)
//                                        
//                    {
//                        
//                        //[self SaveDataSecondApi];
//                        
//                        if ([EMAILDATA isEqualToString:@"Email ID Do not exist"])
//                            
//                            
//                        {
//                            NSLog(@"email is not successfully");
//                            
//                            
//                            UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"USERNAME" message:
//                                                                  
//                                                                  @"USERNAME IS NOT CORRECT,PLEASE FILL CORRECT DETAILS" preferredStyle:UIAlertControllerStyleAlert];
//                            
//                            UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
//                                                        
//                                                        {
//                                                            
//                                                            
//                                                        }];
//                            
//                            [TextFieldError3 addAction:errorPass];
//                            
//                            [self presentViewController:TextFieldError3 animated:YES completion:nil];
//                            
//
//                            
//                            
//                            
//                            
//                            
//                            
//                            
//                        }
//                        
//                        
//                        
//                        
//                        else if ([EMAILDATA isEqualToString:@"success"])
//                            
//                        
//                        {
//                            
//                        
//                            NSLog(@" Alert Activate You Work it ");
//                                            
//                                [self.TableCompanyList reloadData];
//                        
////                                    self.companyview.hidden=NO;
////                        
////                                        self.cMPImage.hidden=NO;
////                        
////                                            self.thirdauto.constant=56;
////                        
////                                                self.NameCmpBTN.hidden=NO;
//                        }
//                        
//                        else {
//                            NSLog(@"ERROR EMAIL ID LINK");
//                        }
//                        
//                        
//                        
//                                        }];
//        
//        
//        
//        
//        [alertController addAction:SelectCompany];
//        
//        [self presentViewController:alertController animated:YES completion:nil];
//        
//        

    

    return YES;
    
    
}

-(void)kvnDismiss{
    
    [KVNProgress dismiss];
    
}

-(void)FirstAPIPostMethodUSed;


{
    
    if (latitude.length == 0 || latitude == nil || [latitude isKindOfClass:(id)[NSNull null]]) {
        [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
        UIAlertView *ALERT = [[UIAlertView alloc]initWithTitle:nil message:@"Please turn on Location Services first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [ALERT show];
        
        
    }else{
        
        strPassword= self.passwordtextfeild.text;
        NSData *nsdata = [strPassword
                          dataUsingEncoding:NSUTF8StringEncoding];
        Base64encodePassword = [nsdata base64EncodedStringWithOptions:0];
        NSLog(@"Encoded: %@", Base64encodePassword);
        
        NSString *apiURLStr  = [NSString stringWithFormat:@"http://182.76.44.135:8080/demogomobile/login/checklogin?"];
        
        
        mapData = [[NSDictionary alloc] initWithObjectsAndKeys:@"false",@"add",compId,@"cmpId",latitude,@"latitude",
                   
                   newDateString ,@"logintym",longitude,@"longitude",OperatingNa,@"os",self.usernameTextfield.text,@"username",
                   
                   Base64encodePassword,@"password",versionNo,@"version",nil];

        
        
        AFHTTPSessionManager * managerr = [AFHTTPSessionManager manager];
        managerr.requestSerializer = [AFJSONRequestSerializer serializer];
       // [managerr.requestSerializer setValue:companyToken forHTTPHeaderField:@"token"];
        
        [managerr POST:apiURLStr parameters:mapData success:^(NSURLSessionTask *task, id responseObject) {
            NSLog(@"PLIST: %@", responseObject);
            [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
            
            
            PassedJSonArray = responseObject ;
            
            [self performSelectorOnMainThread:@selector(loginData) withObject:nil waitUntilDone:YES];
            
            
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            [self performSelectorOnMainThread:@selector(kvnDismiss) withObject:nil waitUntilDone:YES];
            NSLog(@"Error: %@", error);
            
            
            
        }];
        
        
    }
    
}


-(void)loginData{
    
    NSString *message = [NSString stringWithFormat:@"%@",[PassedJSonArray valueForKey:@"message"]];
    
    NSString *token = [PassedJSonArray valueForKey:@"token"];
    
    if ([message isEqualToString:@"user not exist"] || [message isEqualToString:@"Password doesn't match"] || [message isEqualToString:@"<null>"] ) {
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please fill the correct details" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        
        
    }
    else{
        
        
        [[NSUserDefaults standardUserDefaults]setObject:[PassedJSonArray valueForKey:@"token"] forKey:@"Token"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        
        
        /// NSString *strRole = [NSString stringWithFormat:@"%@",[[PassedJSonArray valueForKey:@"result"]valueForKey:@"role"]];
        NSString *strRole;
        
        NSMutableArray *arrRole = [NSMutableArray arrayWithArray:[PassedJSonArray valueForKey:@"result"]];
        
        strRole = [[arrRole valueForKey:@"role"]objectAtIndex:0];
        
        
        
        
        [[NSUserDefaults standardUserDefaults]setObject:strRole forKey:@"role"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        dropDownListArray = [PassedJSonArray valueForKey:@"result"];
        
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dropDownListArray];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"Accounts"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        NSData *data2 = [NSKeyedArchiver archivedDataWithRootObject:dropDownListArray];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"adminAccount"];
        [[NSUserDefaults standardUserDefaults]synchronize];

        
        
        NSMutableArray *arrayData = [[NSMutableArray alloc]initWithObjects:PassedJSonArray, nil];
        
        
        
        
        
        NSArray *arr = [[arrayData valueForKey:@"result"]objectAtIndex:0];
        
        
        NSString *CompanyId = [arr[0] valueForKey:@"cmpId"];
        
        
        NSString *PersonId = [arr[0] valueForKey:@"personId"];
        NSString *token = [PassedJSonArray valueForKey:@"token"];
        NSString *comLogo = [arr[0] valueForKey:@"cmpLg"];
        NSString *cmpNm = [arr[0] valueForKey:@"cmpNm"];
        
        NSString *firstName = [arr[0] valueForKey:@"firstName"];
        NSString *role = [arr[0] valueForKey:@"role"];
        
        
        NSMutableArray *signUpdata = [[NSMutableArray alloc]initWithObjects:CompanyId,PersonId,token,comLogo,cmpNm,firstName, nil];
        
        
        
        
        [[NSUserDefaults standardUserDefaults]setObject:signUpdata forKey:@"signUpInfo"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        [[NSUserDefaults standardUserDefaults]setObject:PersonId forKey:@"personId"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [[NSUserDefaults standardUserDefaults]setObject:cmpNm forKey:@"cmpNm"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [[NSUserDefaults standardUserDefaults]setObject:comLogo forKey:@"comLogo"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [[NSUserDefaults standardUserDefaults]setObject:CompanyId forKey:@"CompanyId"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [[NSUserDefaults standardUserDefaults]setObject:token forKey:@"token"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        [[NSUserDefaults standardUserDefaults]setObject:firstName forKey:@"firstName"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        [[NSUserDefaults standardUserDefaults]setObject:role forKey:@"role"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        
        
        
        
        
        
        fetchOTP = [NSString stringWithFormat:@"%@",[PassedJSonArray valueForKey:@"message"]];
        
        FIRSTflag = [NSString stringWithFormat:@"%@",[PassedJSonArray valueForKey:@"frstLgn"]];
        passStatus = [NSString stringWithFormat:@"%@",[PassedJSonArray valueForKey:@"passSts"]];
        varifyStr = [NSString stringWithFormat:@"%@",[PassedJSonArray valueForKey:@"verify"]];
        
        [[NSUserDefaults standardUserDefaults]setObject:varifyStr forKey:@"varify"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        
        NSLog(@"%@",[PassedJSonArray valueForKey:@"message"]);
        
        NSLog(@"%@",[PassedJSonArray valueForKey:@"otp"]);
        
        NSLog(@"%@",fetchOTP);
        
        NSLog(@"  the total array is == %@   ", PassedJSonArray);
        
        NSLog(@"  the total array is == %@   ", PassedJSonArray);
        
        
        NSString *strError = [PassedJSonArray valueForKey:@"message"];
        
        
        if (strError !=nil || ![strError isEqual:(id)[NSNull null]])  {
            NSLog(@"%@",strError);
        }else{
            
            NSLog(@"%@",strError);
            
        }
        
        strError = [strError stringByReplacingOccurrencesOfString:@"<null>" withString:@""];
        
        if([strError isEqualToString:@""]){
            
            
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Incorrect Password" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            
            [alert show];
            
            
            
        }
        
        else if([fetchOTP isEqualToString:@"Password doesn't match"])
            
        {
            
            NSLog(@" the password is not correct  errrror ");
            
            UIAlertController * TextFieldError3= [UIAlertController alertControllerWithTitle: @"PASSWORD DOESN't CORRECT" message:@"Your password is not correct please fill Correct password" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* errorPass = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        
                                        {
                                            
                                            
                                        }];
            
            [TextFieldError3 addAction:errorPass];
            
            [self presentViewController:TextFieldError3 animated:YES completion:nil];
            
        }
        
        else{
            
            
            if ([fetchOTP isEqualToString:@"user exist"])
                
            {
                
                NSString *strr= [NSString stringWithFormat:@"%@",[[PassedJSonArray valueForKey:@"result"] valueForKey:@"role"]];
                
                // if ([strr isEqualToString:@"ROLE_SUPER_ADMIN"] ) {
                if ([FIRSTflag isEqualToString:@"1"] && [passStatus isEqualToString:@"0"] ) {
                    
                    
                    [self sendToChangePssword];
                    
                    
                }
                else if ([FIRSTflag isEqualToString:@"0"] && [passStatus isEqualToString:@"1"] ){
                    
                    [self sendToOtp];
                    
                    
                }
                
                else{
                    [self sendToOtp];
                    
                }
            }
            //                    else if([strr isEqualToString:@"ROLE_HOST"]){
            //
            //                        if ([FIRSTflag isEqualToString:@"1"] && [passStatus isEqualToString:@"0"] ) {
            //
            //
            //                            [self sendToChangePssword];
            //
            //
            //                        }
            //                        else if ([FIRSTflag isEqualToString:@"0"] && [passStatus isEqualToString:@"1"] ){
            //
            //                            [self sendToOtp];
            //
            //
            //                        }
            //
            //
            //                    }
            
            
            //        }
            
            
            
            
            
        }
        
        
    }
}
-(void)dismissKvn{
    
    [KVNProgress dismiss];
    
}


-(void)sendToOtp{
    
    for (GETIDRESONSE in [PassedJSonArray valueForKey:@"result"])
        
    {
        
        Participant = [NSMutableString stringWithFormat:@"%@",[GETIDRESONSE valueForKey:@"role"]];
        
        NSLog(@"%@",Participant);
        
        getPersonID = [NSMutableString stringWithFormat:@"%@",[GETIDRESONSE valueForKey:@"personId"]];
        
    }
    
    NSMutableArray *arr = [PassedJSonArray valueForKey:@"result"];
  
    
    personIDString = [arr[0] valueForKey:@"personId"];
    
    passMobile = [arr[0] valueForKey:@"pmobile"];
    
    
  //  NAmeList = [NSMutableString stringWithFormat:@"%@",[GETIDRESONSE valueForKey:@"firstName"]];
    NAmeList =   [arr[0] valueForKey:@"firstName"];
    
    
    
    otp = [self.storyboard instantiateViewControllerWithIdentifier:@"OTP"];
    
    otp.PartiCipantClient = Participant;
    
    otp.NAMEofClient = NAmeList;
    
    otp.StringOTP = [PassedJSonArray valueForKey:@"otp"];
    
    otp.PersonIDStr = personIDString;
    
    otp.PassMobileNUm = passMobile;
    
    
    otp.varify = varifyStr ;
    
    otp.passStatus = [NSString stringWithFormat:@"%@",[PassedJSonArray valueForKey:@"passSts"]];
 
    
    
    
    // [self presentViewController:otp animated:YES completion:nil];
    [self.navigationController pushViewController:otp animated:YES];
    
    NSLog(@"%@",otpNumber);
}



-(void)sendToChangePssword{
    
    for (GETIDRESONSE in [PassedJSonArray valueForKey:@"result"])
        
    {
        
        personIDString = [NSMutableString stringWithFormat:@"%@",[GETIDRESONSE valueForKey:@"personId"]];
        
        
        
        LogSucessPasswordViewController *succ = [self.storyboard instantiateViewControllerWithIdentifier:@"LSP"];
        
        [[NSUserDefaults standardUserDefaults]setObject:compId forKey:@"CMPID"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [[NSUserDefaults standardUserDefaults]setObject:personIDString forKey:@"PERSONID"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        
        [self.navigationController pushViewController:succ animated:YES];
        
    }
    
}


- (IBAction)loginbutton:(id)sender {
    
    [[NSUserDefaults standardUserDefaults]setValue:nil forKey:@"ConfId"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    
     if ([self.usernameTextfield.text isEqualToString:@""]){
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Enter the EmailID/Mobile Number" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
   else if ([self.passwordtextfeild.text isEqualToString:@""] )
       
    {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please Enter your password" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
    
    else if ([self.txtCompnay.text isEqualToString:@""]){
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please select the Company Name" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        
        [alert show];
        
    }
    else{
        
        
        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
        if (networkStatus == NotReachable) {
            UIAlertView *alert =[[UIAlertView alloc]initWithTitle:nil message: @"No Network Connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alert show];
            return;
            
            
        }
        
        else
        {
            
        [KVNProgress show];
        
        
        [self FirstAPIPostMethodUSed];
        
        }
    }

    
    
        
    
        
} 
       

                                 /////////////          Forgot Password       /////////////


- (IBAction)ForgetButton:(UIButton *)sender {
    
    
    
            ForgotPAsViewController *pass  = [self.storyboard instantiateViewControllerWithIdentifier:@"f"];
    
                    [self.navigationController pushViewController:pass animated:YES];
    
    
 }




                            ////////////////////////////   SignUP Button   ////////////





- (IBAction)signupButton:(UIButton *)sender {
    
    corporateLoginViewController *login = [self.storyboard instantiateViewControllerWithIdentifier:@"CL"];
    
    [self.navigationController pushViewController:login animated:YES];
    
}






/////////////////////         COmpany TableView Button Down Or Drop    //////////////////



- (IBAction)companyNameBTN:(id)sender;
 {
    
    
    
//       if (self.TableCompanyList.hidden==YES)
//       {
//         
//    
//        self.TableCompanyList.hidden=NO;
//    }else 
//    {
//        
//        
//        self.TableCompanyList.hidden=YES;
//    
//        
//    }

    
    
    
}



-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"DropHome"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    
    if (dropDownView != nil) {
        [dropDownView.view removeFromSuperview];
        dropDownView = nil;
    }
    if (textField == _usernameTextfield) {
        
        _passwordtextfeild.text = @"";
        
    }
    
    
  else if (textField == _passwordtextfeild) {
        [self.passwordtextfeild resignFirstResponder];
        [self.txtCompnay resignFirstResponder];
        [self.usernameTextfield resignFirstResponder];
        
        if (dropDownView != nil) {
            [dropDownView.view removeFromSuperview];
            dropDownView = nil;
        }
        
        if ([_usernameTextfield.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Enter EmailId/Mobile Number first" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alert show];
            
            return NO;
            
            
        }else{
            
             if (![_txtCompnay.text isEqualToString:@""]) {
                
                
                
             }else{
            
            [self SaveDataSecondApi];
                 
             }
            
            
            
        }
        
        
    }

    

   else if (textField == _txtCompnay) {
       
       [dropDownView closeAnimation];
       
       
       [self.usernameTextfield resignFirstResponder];
       [self.passwordtextfeild resignFirstResponder];
       [self.txtCompnay resignFirstResponder];
       
       [self SaveDataSecondApi];

       return false ;
       
   }

    return YES ;
    
}


-(void)textFieldDidChange:(UITextField*)textfield{
    
    [dropDownView closeAnimation];
    
    if (userEmailID.count >0) {
        
        
        if ([EMAILDATA  isEqualToString:@"success"]) {
            
            [self SaveDataSecondApi];
            
        }else{
            
            _txtCompnay.text = @"" ;
            
            compId = @"" ;
            
            
        }
        
        
        
    }
    
}


-(void)getLocation{
    
    self.locationManager = [[CLLocationManager alloc] init];
    
    self.locationManager.delegate = self;
    if([self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]){
        NSUInteger code = [CLLocationManager authorizationStatus];
        if (code == kCLAuthorizationStatusNotDetermined && [self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
            // choose one request according to your business.
            if([[NSBundle mainBundle] objectForInfoDictionaryKey:@"NSLocationWhenInUseUsageDescription"]) {
                [self.locationManager  requestWhenInUseAuthorization];
            } else {
                NSLog(@"Info.plist does not contain NSLocationAlwaysUsageDescription or NSLocationWhenInUseUsageDescription");
            }
        }
    }
    [self.locationManager startUpdatingLocation];
    
    
   
    
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    
    if([CLLocationManager locationServicesEnabled])
    {
        NSLog(@"Enabled");
        
        if([CLLocationManager authorizationStatus]==kCLAuthorizationStatusDenied)
        {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:NSLocalizedString( @"Please turn on Location Services first", @"" ) message:NSLocalizedString( @"Turn On", @"" ) preferredStyle:UIAlertControllerStyleAlert];
            
//            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString( @"Cancel", @"" ) style:UIAlertActionStyleCancel handler:nil];
            UIAlertAction *settingsAction = [UIAlertAction actionWithTitle:NSLocalizedString( @"Settings", @"" ) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:
                                                            UIApplicationOpenSettingsURLString]];
            }];
            
          //  [alertController addAction:cancelAction];
            [alertController addAction:settingsAction];
            
            [self presentViewController:alertController animated:YES completion:nil];
        }
    }
}



- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    

    
    if (currentLocation != nil) {
        latitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
        [[NSUserDefaults standardUserDefaults]setObject:latitude forKey:@"lat"];
        
        longitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        [[NSUserDefaults standardUserDefaults]setObject:longitude forKey:@"long"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
    
  }
    
     self.locationManager = nil;
   
    
}


+ (NSString *)base64String:(NSString *)str
{
    NSData *theData = [str dataUsingEncoding: NSASCIIStringEncoding];
    const uint8_t* input = (const uint8_t*)[theData bytes];
    NSInteger length = [theData length];
    
    static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=@";
    
    NSMutableData* data = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    uint8_t* output = (uint8_t*)data.mutableBytes;
    
    NSInteger i;
    for (i=0; i < length; i += 3) {
        NSInteger value = 0;
        NSInteger j;
        for (j = i; j < (i + 3); j++) {
            value <<= 8;
            
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        NSInteger theIndex = (i / 3) * 4;
        output[theIndex + 0] =                    table[(value >> 18) & 0x3F];
        output[theIndex + 1] =                    table[(value >> 12) & 0x3F];
        output[theIndex + 2] = (i + 1) < length ? table[(value >> 6)  & 0x3F] : '=';
        output[theIndex + 3] = (i + 2) < length ? table[(value >> 0)  & 0x3F] : '=';
    }
    
    return [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isDescendantOfView:dropDownView.view]) {
        
        // Don't let selections of auto-complete entries fire the
        // gesture recognizer
        // gesture recognizer
        
        return NO;
    }
    
    
    return YES;
}

-(void)scrollTap{
    
    [dropDownView closeAnimation];
    
}


@end



