//
//  QACell.h
//  DemogoApplication
//
//  Created by Rhythmus on 31/10/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QACell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *txtHome;
@property (strong, nonatomic) IBOutlet UILabel *txtMobileNumber;
@property (strong, nonatomic) IBOutlet UILabel *textQuestionType;

@property (strong, nonatomic) IBOutlet UIButton *btnCheckQA;

@property (strong, nonatomic) IBOutlet UIButton *btnQuestType;

@end
