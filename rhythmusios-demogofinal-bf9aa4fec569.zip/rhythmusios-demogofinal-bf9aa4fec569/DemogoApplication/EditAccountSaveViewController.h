//
//  EditAccountSaveViewController.h
//  DemogoApplication
//
//  Created by Rhythmus on 01/04/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "ViewController.h"

@interface EditAccountSaveViewController : ViewController



@property (strong, nonatomic) NSString *MobileString;



////                    Pass String Data                //////

@property (strong, nonatomic) NSString *FirstLAbel;

@property (strong, nonatomic) NSString *LAstLAbel;

@property (strong, nonatomic) NSString *EmailLabel;

@property (strong, nonatomic) NSString *LocationL;

@property (strong, nonatomic) NSString *AdminLAbel;

@property (strong, nonatomic) NSString *DepartLabel;



///////////////////////////////..............

@property (strong, nonatomic) IBOutlet UITextField *FirstNameLAbel;
@property (strong, nonatomic) IBOutlet UITextField *LAstNameLAbel;

@property (strong, nonatomic) IBOutlet UITextField *EmailNAmeLabel;
@property (strong, nonatomic) IBOutlet UILabel *MobileNumberLabel;
@property (strong, nonatomic) IBOutlet UITextField *LocationLAbel;

@property (strong, nonatomic) IBOutlet UILabel *AdminNAmeLAbel;

@property (strong, nonatomic) IBOutlet UIImageView *UploadImage;
- (IBAction)UploadPictureButton:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIButton *uploadpictureoutlet;


@property (strong, nonatomic) IBOutlet UIButton *SaveButtonOutlet;

- (IBAction)SaveButton:(UIButton *)sender;

@property (strong, nonatomic) IBOutlet UIButton *CancelButtonOutlet;

@property (strong, nonatomic) IBOutlet UIButton *cancel;


@property (strong, nonatomic) IBOutlet UIView *DetailsSaveView;

@property (strong, nonatomic) IBOutlet UILabel *DepartmentLabel;





@end
