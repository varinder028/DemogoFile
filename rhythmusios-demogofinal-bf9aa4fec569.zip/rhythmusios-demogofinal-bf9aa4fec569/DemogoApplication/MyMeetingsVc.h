//
//  MyMeetingsVc.h
//  DemogoApplication
//
//  Created by katoch on 25/05/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AFNetworking/AFNetworking.h>
#import <AVFoundation/AVFoundation.h>
#import <CloudKit/CloudKit.h>

@class MyMeetingsVc ;

@protocol senddataProtocolDelegate <NSObject>
@required
-(void)sendDataToA:(NSArray *)array;

@end

@interface MyMeetingsVc : UIViewController<UITableViewDelegate,UITableViewDataSource,senddataProtocolDelegate,UIAlertViewDelegate,UIGestureRecognizerDelegate,UIScrollViewDelegate,AVAudioPlayerDelegate>{
    
    id <senddataProtocolDelegate> delegate;
    id GetConfernceData ;
    NSURLSessionDataTask *taskHome ;
    NSURLSession *sessionhOME ;
    NSString*personId;
    NSString*companyId;
    NSString*Tokenid;
    NSMutableArray*enddataArray;
    NSMutableArray*onlyDates;
    NSMutableArray*confernceDetailArray;
    NSString*newDateString;
    NSDate*startToday;
    NSArray*TodayArray;
    NSMutableArray*todayMeetingArray;
    NSMutableArray*UpcomingMeetingArray ;
    UIAlertView *alertDeleteConf;
    
    UIButton *deleteBtn ;
    id cancelConference;
    
    NSString*cancelConfId ;
    AFHTTPSessionManager *manager ;
    UIAlertView *ALERTMAP;
    
    
    id historyMeetings ;
    
    int pageNo ;
    
    NSMutableArray *previousData;
    id downloadedFiles;
    AVAudioPlayer *audioPlayer ;
    
    
    
    NSMutableArray *fileNameList;
    NSMutableArray *fileObjectList;
    UIRefreshControl *refreshControl;
    NSString *pltId ;

    
}
@property (strong, nonatomic) IBOutlet UITableView *historyTableView;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *xSlide;

@property (strong, nonatomic) IBOutlet UITableView *meetingTableView;
- (IBAction)backBTn:(id)sender;
@property(nonatomic,assign)id<senddataProtocolDelegate>delegate;

@property (strong, nonatomic) IBOutlet UIView *secView;

@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UIButton *btnHistory;
@property (strong, nonatomic) IBOutlet UIButton *btnUpcoming;
@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *ConstantPickerDate;
@property (strong, nonatomic) IBOutlet UITextField *txtDate;

- (IBAction)upcomingClicked:(id)sender;
- (IBAction)historyClicked:(id)sender;
@end
