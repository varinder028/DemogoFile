//
//  customDashCell.m
//  DemogoApplication
//
//  Created by katoch on 05/07/17.
//  Copyright © 2017 DemogoApp. All rights reserved.
//

#import "customDashCell.h"

@implementation customDashCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
