//
//  CCPOViewController.m
//  CCIntegrationKit
//
//  Created by test on 5/12/14.
//  Copyright (c) 2014 Avenues. All rights reserved.
//

#import "CCWebViewController.h"
#import "CCResultViewController.h"
#import "CCTool.h"
#import "SubscriptionVC.h"
#import "PaymentVc.h"

#define BILLING_NAME @"billing_name"
#define BILLING_ADDRESS @"billing_address"
#define BILLING_CITY @"billing_city"
#define BILLING_STATE @"billing_state"
#define BILLING_ZIP @"billing_zip"
#define BILLING_COUNTRY @"billing_country"
#define BILLING_TEL @"billing_tel"
#define BILLING_EMAIL @"billing_email"
#define DELIVERY_NAME @"delivery_name"
#define DELIVERY_ADDRESS @"delivery_address"
#define DELIVERY_CITY @"delivery_city"
#define DELIVERY_STATE @"delivery_state"
#define DELIVERY_ZIP @"delivery_zip"
#define DELIVERY_COUNTRY @"delivery_country"
#define DELIVERY_TEL @"delivery_tel"


@interface CCWebViewController ()

@end

@implementation CCWebViewController

@synthesize rsaKeyUrl;@synthesize accessCode;@synthesize merchantId;@synthesize orderId;
@synthesize amount;@synthesize currency;@synthesize redirectUrl;@synthesize cancelUrl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
    
    [loadingView setHidden:NO];
    
}




- (void)viewDidLoad
{
    [super viewDidLoad];
    
    loadingView = [[UIView alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2 - 50,self.view.frame.size.height/2-50, 80, 80)];
    loadingView.backgroundColor = [UIColor colorWithWhite:0. alpha:0.6];
    loadingView.layer.cornerRadius = 5;
    
    UIActivityIndicatorView *activityView=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    activityView.center = CGPointMake(loadingView.frame.size.width / 2.0, 35);
    [activityView startAnimating];
    activityView.tag = 100;
    [loadingView addSubview:activityView];
    
    UILabel* lblLoading = [[UILabel alloc]initWithFrame:CGRectMake(0, 48, 80, 30)];
    lblLoading.text = @"Loading...";
    lblLoading.textColor = [UIColor whiteColor];
    lblLoading.font = [UIFont fontWithName:lblLoading.font.fontName size:15];
    lblLoading.textAlignment = NSTextAlignmentCenter;
    [loadingView addSubview:lblLoading];
    
    [self.viewWeb addSubview:loadingView];
    
    
    
    
    
    Tokenid = [[NSUserDefaults standardUserDefaults]valueForKey:@"Token"];

    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    self.viewWeb.delegate = self;
    
    accessCode = @"AVLW69EB31BN54WLNB";
    //AVIG63DA80CL61GILC
    rsaKeyUrl = @"http://182.76.44.135:8080/demogomobile/pay/secure/GetRSA";
    redirectUrl = @"http://182.76.44.135:8080/demogomobile/pay/ccavResponseHandler";
    cancelUrl = @"http://182.76.44.135:8080/demogomobile/pay/ccavResponseHandler";
    //cancelUrl = @"http://www.www.google.com";
    currency = @"INR";
    merchantId = @"89348";
    
    
    //Getting RSA Key
    NSString *rsaKeyDataStr = [NSString stringWithFormat:@"access_code=%@&order_id=%@",accessCode,orderId];
    NSData *requestData = [NSData dataWithBytes: [rsaKeyDataStr UTF8String] length: [rsaKeyDataStr length]];
    NSMutableURLRequest *rsaRequest = [[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString: rsaKeyUrl]];
    [rsaRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
      [rsaRequest setValue:Tokenid forHTTPHeaderField:@"token"];
    [rsaRequest setHTTPMethod:@"POST"];
    [rsaRequest setHTTPBody: requestData];
    NSData *rsaKeyData = [NSURLConnection sendSynchronousRequest: rsaRequest returningResponse: nil error: nil];
    
    NSString *rsaKey = [[NSString alloc] initWithData:rsaKeyData encoding:NSASCIIStringEncoding];
    rsaKey = [rsaKey stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];
    rsaKey = [NSString stringWithFormat:@"-----BEGIN PUBLIC KEY-----\n%@\n-----END PUBLIC KEY-----\n",rsaKey];
    NSLog(@"%@",rsaKey);
    
    //Encrypting Card Details
    NSString *myRequestString = [NSString stringWithFormat:@"amount=%@&currency=%@&&billing_name=%@&billing_address=%@&billing_city=%@&billing_state=%@&billing_zip=%@&billing_tel=%@&billing_email=%@",amount,currency,_billing_name,_billing_address,_billing_city,_billing_state,_billing_zip,_billing_tel,_billing_email];
    
    
    CCTool *ccTool = [[CCTool alloc] init];
    NSString *encVal = [ccTool encryptRSA:myRequestString key:rsaKey];
    encVal = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(NULL,
                                                                        (CFStringRef)encVal,
                                                                        NULL,
                                                                        (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                        kCFStringEncodingUTF8 ));
    
    //Preparing for a webview call
    
    
       
    
    NSString *urlAsString = [NSString stringWithFormat:@"https://secure.ccavenue.com/transaction/initTrans"];

    
    NSString *encryptedStr = [NSString stringWithFormat:@"merchant_id=%@&order_id=%@&redirect_url=%@&cancel_url=%@&enc_val=%@&access_code=%@" ,merchantId,orderId,redirectUrl,cancelUrl,encVal,accessCode];
    
    

    
    
    NSData *myRequestData = [NSData dataWithBytes: [encryptedStr UTF8String] length: [encryptedStr length]];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString: urlAsString]];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
    [request setValue:urlAsString forHTTPHeaderField:@"Referer"];
    // [request setValue:Tokenid forHTTPHeaderField:@"token"];
    [request setHTTPMethod: @"POST"];
    [request setHTTPBody: myRequestData];
    [_viewWeb loadRequest:request];


}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    NSString *string = webView.request.URL.absoluteString;
    
     [loadingView setHidden:YES];
    
    
    if ([string rangeOfString:@"/ccavResponseHandler"].location != NSNotFound) {
        
        
        NSString *html = [webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.outerHTML"];
        NSLog(@"%@",html);
        
       // [webView stringByEvaluatingJavaScriptFromString:
         //[NSString stringWithFormat:@"document.getElementById('msg').outerHTML = '%@'", html]];
        
        NSString *transStatus = @"Not Known";
        
        if (([html rangeOfString:@"Aborted"].location != NSNotFound) ||
            ([html rangeOfString:@"Cancel"].location != NSNotFound)) {
            transStatus = @"Transaction Cancelled";

        }else if (([html rangeOfString:@"Success"].location != NSNotFound)) {
            
            transStatus = @"Transaction Successful";
            
            
        }else if (([html rangeOfString:@"Fail"].location != NSNotFound)) {
            transStatus = @"Transaction Failed";

        }
        
        PaymentVc* controller = [self.storyboard instantiateViewControllerWithIdentifier:@"PaymentVc"];
        
        controller.transStatus = transStatus;
        controller.htmlText = html ;
        
       [self presentViewController:controller animated:YES completion:nil];
        
        
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}



- (IBAction)btnBack:(id)sender {

    [_viewWeb goBack];
}


@end
